package com.example.data

import com.example.model.CustodyStatus
import com.example.model.FamilyCortegeMilestone
import com.example.model.ShiftVehicleHandover
import com.example.model.WorkshopProductionStage
import com.example.ui.StaffPortalViewModel
import com.google.common.truth.Truth.assertThat
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.ExperimentalCoroutinesApi
import kotlinx.coroutines.test.UnconfinedTestDispatcher
import kotlinx.coroutines.test.resetMain
import kotlinx.coroutines.test.setMain
import org.junit.After
import org.junit.Before
import org.junit.Test

@OptIn(ExperimentalCoroutinesApi::class)
class OperationsWorkflowTest {

    private val testDispatcher = UnconfinedTestDispatcher()

    @Before
    fun setUp() {
        Dispatchers.setMain(testDispatcher)
    }

    @After
    fun tearDown() {
        Dispatchers.resetMain()
    }

    @Test
    fun updateWorkshopStage_autoDeductsBomIdempotentlyWithoutDoubleDeduction() {
        val repo = StaffPortalRepository()
        val job = repo.workshopItems.value.first { it.currentStage == WorkshopProductionStage.FRAME_AND_ASSEMBLY }
        val initialWoodQty = repo.inventoryMaterials.value.first { it.id == "MAT-001" }.quantity

        // Advance Stage 1 -> Stage 2 (Sanding & Painting): deducts Sandpaper MAT-008 & Varnish MAT-002
        val sandpaperBefore = repo.inventoryMaterials.value.first { it.id == "MAT-008" }.quantity
        repo.updateWorkshopStage(job.id, WorkshopProductionStage.SANDING_AND_PAINTING, percentage = 50)
        val afterStage2Job = repo.workshopItems.value.first { it.id == job.id }
        val sandpaperAfter = repo.inventoryMaterials.value.first { it.id == "MAT-008" }.quantity

        assertThat(afterStage2Job.currentStage).isEqualTo(WorkshopProductionStage.SANDING_AND_PAINTING)
        assertThat(afterStage2Job.autoBomDeductedStages).contains(WorkshopProductionStage.SANDING_AND_PAINTING.name)
        assertThat(sandpaperAfter).isLessThan(sandpaperBefore)

        // Calling again for same stage must NOT deduct a second time
        repo.updateWorkshopStage(job.id, WorkshopProductionStage.SANDING_AND_PAINTING, percentage = 55)
        val sandpaperAfterRepeat = repo.inventoryMaterials.value.first { it.id == "MAT-008" }.quantity
        assertThat(sandpaperAfterRepeat).isEqualTo(sandpaperAfter)

        // Ensure timber inventory wasn't corrupted by Stage 2
        assertThat(repo.inventoryMaterials.value.first { it.id == "MAT-001" }.quantity).isEqualTo(initialWoodQty)
    }

    @Test
    fun scanAssetCustody_checkoutCheckinAndDamagedFlagTriggersBreakageDeduction() {
        val repo = StaffPortalRepository()
        val targetAsset = repo.companyAssets.value.first()
        val initialBreakagesCount = repo.breakageRecords.value.size

        // Check-out to burial case
        val checkoutLog = repo.scanAssetCustody(
            qrOrTag = targetAsset.qrTagCode,
            actionCheckOut = true,
            caseReference = "JFD-2026-TEST",
            staffId = "OPR-001",
            staffName = "Dennis Omondi",
            isDamagedOrMissing = false,
            conditionNotes = "Checked out clean",
            breakageCostKes = 0.0
        )
        assertThat(checkoutLog).isNotNull()
        assertThat(checkoutLog!!.custodyStatus).isEqualTo(CustodyStatus.CHECKED_OUT)
        assertThat(repo.companyAssets.value.first { it.id == targetAsset.id }.custodyStatus)
            .isEqualTo(CustodyStatus.CHECKED_OUT)

        // Flag Damaged / Missing on return -> triggers breakage deduction
        val damagedLog = repo.scanAssetCustody(
            qrOrTag = targetAsset.qrTagCode,
            actionCheckOut = false,
            caseReference = "JFD-2026-TEST",
            staffId = "OPR-001",
            staffName = "Dennis Omondi",
            isDamagedOrMissing = true,
            conditionNotes = "Bent lowering pulley frame",
            breakageCostKes = 4_500.0
        )
        assertThat(damagedLog).isNotNull()
        assertThat(damagedLog!!.custodyStatus).isEqualTo(CustodyStatus.DAMAGED)
        assertThat(damagedLog.breakageRecordId).isNotNull()
        assertThat(repo.breakageRecords.value.size).isEqualTo(initialBreakagesCount + 1)
    }

    @Test
    fun advanceCortegeMilestoneAndRecordShiftHandover_updatesSchedulesAndFleet() {
        val repo = StaffPortalRepository()
        val schedule = repo.burialSchedules.value.first()

        val updatedSchedule = repo.advanceCortegeMilestone(
            burialScheduleId = schedule.id,
            milestone = FamilyCortegeMilestone.CHAPEL_ARRIVAL
        )
        assertThat(updatedSchedule).isNotNull()
        assertThat(updatedSchedule!!.currentMilestone).isEqualTo(FamilyCortegeMilestone.CHAPEL_ARRIVAL)

        val vehicle = repo.fleetGpsVehicles.value.first()
        val handover = ShiftVehicleHandover(
            id = "HND-TEST-1",
            vehicleReg = vehicle.registration,
            branch = "Bama Branch",
            outgoingStaffId = "DRV-001",
            outgoingStaffName = vehicle.driverName,
            incomingStaffId = "DRV-002",
            incomingStaffName = "Samuel Onyango",
            fuelPercent = 88,
            odometerKm = 152_400,
            loweringGearCount = 2,
            churchTrolleyOk = true,
            velvetDeckClean = true,
            spareTireAndJackOk = true,
            conditionNotes = "Clean handover",
            outgoingBiometricSigned = true,
            incomingBiometricSigned = true,
            timestamp = "14 Nov 2026 08:30"
        )
        repo.recordShiftHandover(handover)
        assertThat(repo.shiftHandovers.value.first().id).isEqualTo("HND-TEST-1")
        assertThat(repo.fleetGpsVehicles.value.first { it.registration == vehicle.registration }.driverName)
            .isEqualTo("Samuel Onyango")
        assertThat(repo.fleetGpsVehicles.value.first { it.registration == vehicle.registration }.fuelPercent)
            .isEqualTo(88)
    }

    @Test
    fun offlineQueue_queuesWhileOfflineAndFlushesUponConnectivityRestore() {
        val repo = StaffPortalRepository()
        val vm = StaffPortalViewModel(repository = repo, preferencesManager = null, connectivityObserver = null)
        vm.signIn("CEO-001", "admin123")

        // Simulate rural offline zone
        vm.toggleSimulatedOfflineMode()
        assertThat(vm.isDeviceOnline.value).isFalse()

        val initialActivityCount = repo.activities.value.size
        vm.logRuralFieldCheckIn("Ukwala Rural Site", "Tents & lowering gear pitched")
        vm.scanAssetCustody(
            qrOrTag = repo.companyAssets.value.first().qrTagCode,
            actionCheckOut = true,
            caseReference = "RUR-900",
            isDamagedOrMissing = false,
            conditionNotes = "Offline field dispatch"
        )

        assertThat(vm.offlineQueue.value.size).isEqualTo(2)
        // Should not have written to repo yet while offline
        assertThat(repo.activities.value.size).isEqualTo(initialActivityCount)

        // Restore connectivity -> automatically flushes queue
        vm.toggleSimulatedOfflineMode()
        assertThat(vm.isDeviceOnline.value).isTrue()
        assertThat(vm.offlineQueue.value).isEmpty()
        assertThat(repo.activities.value.size).isGreaterThan(initialActivityCount)
    }

    @Test
    fun offlineLeaveRequest_queuesWhileOfflineAndFlushesWithDeclineSupport() {
        val repo = StaffPortalRepository()
        val vm = StaffPortalViewModel(repository = repo, preferencesManager = null, connectivityObserver = null)
        vm.signIn("SLS-001", "password123")
        val salesAcc = vm.currentAccount.value!!
        val initialLeaveCount = repo.leaveRequests.value.size

        // Simulate rural offline zone and submit leave
        vm.toggleSimulatedOfflineMode()
        val pendingReq = com.example.model.LeaveRequest(
            id = "LV-TEST-901",
            staffId = salesAcc.id,
            staffName = salesAcc.fullName,
            department = salesAcc.department,
            leaveType = "Annual Leave",
            startDate = "10 Dec 2026",
            endDate = "15 Dec 2026",
            daysCount = 5,
            reason = "Upcountry travel",
            status = "Pending",
            approvedBy = null
        )
        vm.submitLeaveRequest(pendingReq)
        assertThat(vm.offlineQueue.value.any { it.actionType == com.example.model.OfflineActionType.LEAVE_REQUEST }).isTrue()
        assertThat(repo.leaveRequests.value.size).isEqualTo(initialLeaveCount)

        // Restore connectivity -> auto flush creates leave request
        vm.toggleSimulatedOfflineMode()
        assertThat(vm.offlineQueue.value).isEmpty()
        assertThat(repo.leaveRequests.value.size).isEqualTo(initialLeaveCount + 1)
        val createdLeave = repo.leaveRequests.value.first { it.id == "LV-TEST-901" }
        assertThat(createdLeave.status).isEqualTo("Pending")

        // Management can decline the leave request
        vm.rejectLeaveRequest(createdLeave.id, "Fredrick Hayoyo (CEO)")
        val declinedLeave = repo.leaveRequests.value.first { it.id == createdLeave.id }
        assertThat(declinedLeave.status).isEqualTo("Declined")
        assertThat(declinedLeave.approvedBy).isEqualTo("Fredrick Hayoyo (CEO)")
    }

    @Test
    fun deactivatedStaffAccount_isBlockedFromSignInQuickSwitchAndBiometric() {
        val repo = StaffPortalRepository()
        val vm = StaffPortalViewModel(repository = repo, preferencesManager = null, connectivityObserver = null)
        vm.signOut()
        val staff = repo.accounts.value.first { it.id == "SLS-001" }
        val disabled = staff.copy(isActive = false)
        repo.addOrReplaceStaffAccount(disabled)

        val result = vm.signIn("SLS-001", "password123")
        assertThat(result).isFalse()
        assertThat(vm.currentAccount.value).isNull()
        assertThat(vm.isPortalBiometricLocked.value).isTrue()
        assertThat(vm.authErrorMessage.value).contains("deactivated")

        vm.quickSignIn(disabled)
        assertThat(vm.currentAccount.value).isNull()
        assertThat(vm.isPortalBiometricLocked.value).isTrue()

        vm.triggerBiometricAuth(disabled)
        assertThat(vm.showBiometricDialog.value).isFalse()
        assertThat(vm.currentAccount.value).isNull()
    }
}

