package com.example.domain

import com.example.model.MarginEvaluation
import kotlin.math.roundToInt

enum class CostingBomPhase(val label: String) {
    BODY_WORK("1. Body Work (Timber & Frame)"),
    FINISHING("2. Interior & Hardware Finishing"),
    PAINT_ABRASIVES("3. Paint, Coat & Abrasives")
}

data class RawMaterialRate(
    val code: String,
    val category: String,
    val name: String,
    val unitPriceKes: Double,
    val unitOfMeasure: String,
    val isBulkDiscountOption: Boolean = false
)

data class BomSpecLineItem(
    val phase: CostingBomPhase,
    val rawSpecName: String,
    val rawQuantitySpec: String,
    val clarifiedLabel: String,
    val unitOfMeasure: String,
    val quantityNumeric: Double,
    val unitPriceKes: Double,
    val lineCostKes: Double,
    val isEstimatedAllocation: Boolean = false
)

data class EquipmentHireRate(
    val id: String,
    val serviceName: String,
    val rateKes: Double,
    val unitBasis: String,
    val category: String
)

data class WorkshopPersonnelRole(
    val department: String,
    val staffName: String,
    val status: String
)

data class ShopBranchLocation(
    val shopId: String,
    val name: String,
    val networkRole: String
)

data class CasketProductionCostModel(
    val id: String,
    val modelName: String,
    val coveredVariants: String,
    val tierLabel: String,
    val sizeSpec: String,
    val bomItems: List<BomSpecLineItem>,
    val baseBodyMaterialCostKes: Double,
    val finishingMaterialCostKes: Double,
    val paintAndAbrasivesCostKes: Double,
    val crewLaborCostKes: Double,
    val recommendedOrderPriceKes: Double,
    val floorOrderPriceKes: Double,
    val priceRangeLabel: String,
    val matchedBranchCasketTypes: List<String>,
    val matchedWorkshopTeam: String,
    val notes: String = ""
) {
    val directMaterialCostKes: Double
        get() = baseBodyMaterialCostKes + finishingMaterialCostKes + paintAndAbrasivesCostKes

    val totalProductionCostKes: Double
        get() = directMaterialCostKes + crewLaborCostKes

    val grossProfitAtGuideKes: Double
        get() = recommendedOrderPriceKes - totalProductionCostKes

    val grossMarginPercent: Double
        get() = if (recommendedOrderPriceKes > 0.0) {
            ((grossProfitAtGuideKes / recommendedOrderPriceKes) * 1000.0).roundToInt() / 10.0
        } else 0.0

    val salesCommissionAtGuideKes: Double
        get() = recommendedOrderPriceKes * 0.05

    val netProfitAfterCommissionKes: Double
        get() = grossProfitAtGuideKes - salesCommissionAtGuideKes
}

data class OrderQuoteBreakdown(
    val casketModel: CasketProductionCostModel,
    val casketQuantity: Int,
    val unitSellingPriceKes: Double,
    val equipmentHireTotalKes: Double,
    val clientOrderTotalKes: Double,
    val clientOrderTotalUsd: Double,
    val totalProductionCostKes: Double,
    val expectedSalesCommissionKes: Double,
    val netGrossProfitKes: Double,
    val marginEvaluation: MarginEvaluation
)

/**
 * Formulates authentic Casket Cost of Production, Direct Material BOM Breakdown,
 * Order Price Guidance, Equipment Hire Rates, Crew Directory, and Branch Shop Network
 * directly from Jabima_Costings_ebf8ba5f.pdf.
 */
object CasketCostingEngine {

    // Exact unit rates from PDF Pages 7-8
    private const val CHIPBOARD_12MM = 2500.0
    private const val PLYWOOD_9MM = 1700.0
    private const val HARD_BOARD = 800.0
    private const val TIMBER_6X15_FT = 30.0
    private const val HINGE_PIECE = 100.0 // 200.0 per Pair (2 pcs)
    private const val SCREWS_PACKET = 100.0
    private const val PIANO_HINGE_EST = 650.0
    private const val NAILS_KG_EST = 240.0 // Derived from Polished Nails 4,800 / 20kg box

    private const val GLUE_STANDARD_LTR = 1000.0
    private const val GLUE_BULK_LTR = 900.0
    private const val FORM_SHEET = 150.0
    private const val OPENER_PIECE = 55.0
    private const val CORNER_PIECE = 30.0
    private const val RIBBON_PIECE = 100.0
    private const val PINS_PIECE_ALLOC = 20.0 // Cocas Pins 200 / pkt
    private const val CLOTHING_SIMPLE_EST = 1500.0
    private const val CLOTHING_KIDS_EST = 1200.0
    private const val PILLOW_EST = 350.0
    private const val CLOTHING_EXEC_SATIN = 2500.0
    private const val PRINTED_SATIN = 2500.0
    private const val GLASS_SIMPLE = 400.0
    private const val GLASS_HALF_PANEL = 1200.0

    private const val HANDLES_H4_ASSORTED = 2000.0
    private const val HANDLES_H9_KIDS = 1500.0
    private const val HANDLES_LAST_SUPPER = 2500.0
    private const val HANDLES_SWING_BAR = 6500.0
    private const val SPINDLES_SET = 3000.0

    // PDF Page 7-8 Raw Material & Component Price List (All 32 items)
    val rawMaterialCatalog: List<RawMaterialRate> = listOf(
        // Handles & Hardware
        RawMaterialRate("RM-01", "Handles & Hardware", "Last Supper Handles", 2500.0, "Set"),
        RawMaterialRate("RM-02", "Handles & Hardware", "Prayer Hand Handles", 2500.0, "Set"),
        RawMaterialRate("RM-03", "Handles & Hardware", "H4 Assorted Handles", 2000.0, "Set"),
        RawMaterialRate("RM-04", "Handles & Hardware", "Swing Bar Handles", 6500.0, "Set"),
        RawMaterialRate("RM-05", "Handles & Hardware", "1.5 Inch Hinges", 200.0, "Pair / Pack"),
        RawMaterialRate("RM-06", "Handles & Hardware", "0.5 Inch Wood Screws", 100.0, "Packet"),
        RawMaterialRate("RM-07", "Handles & Hardware", "Openers", 55.0, "Piece"),
        RawMaterialRate("RM-08", "Handles & Hardware", "Corners", 30.0, "Piece"),
        // Boards & Timber
        RawMaterialRate("RM-09", "Boards & Timber", "9mm Plywood", 1700.0, "Sheet"),
        RawMaterialRate("RM-10", "Boards & Timber", "12mm Chipboard", 2500.0, "Sheet"),
        RawMaterialRate("RM-11", "Boards & Timber", "Hard Board", 800.0, "Sheet"),
        RawMaterialRate("RM-12", "Boards & Timber", "Timber 6x1.5", 30.0, "Per Foot"),
        // Finishing Materials
        RawMaterialRate("RM-13", "Finishing Materials", "Form Sheet", 150.0, "Sheet"),
        RawMaterialRate("RM-14", "Finishing Materials", "Standard Thinner (5 Litres)", 700.0, "Can (5L)"),
        RawMaterialRate("RM-15", "Finishing Materials", "Body Filler", 1700.0, "Tin"),
        RawMaterialRate("RM-16", "Finishing Materials", "Primer", 1800.0, "Tin"),
        RawMaterialRate("RM-17", "Finishing Materials", "Clear Coat", 2300.0, "Tin"),
        RawMaterialRate("RM-18", "Finishing Materials", "AC Paints", 2800.0, "Tin"),
        RawMaterialRate("RM-19", "Finishing Materials", "Unga", 1200.0, "Bag"),
        RawMaterialRate("RM-20", "Finishing Materials", "Shellack", 1000.0, "Pack/Ltr"),
        RawMaterialRate("RM-21", "Finishing Materials", "Glue (Standard)", 1000.0, "Ltr/Tin"),
        RawMaterialRate("RM-22", "Finishing Materials", "Glue (Bulk/Alt)", 900.0, "Ltr/Tin", isBulkDiscountOption = true),
        RawMaterialRate("RM-23", "Finishing Materials", "Spray", 500.0, "Can"),
        // Fabrics & Accessories
        RawMaterialRate("RM-24", "Fabrics & Accessories", "Satin", 2500.0, "Piece / Roll"),
        RawMaterialRate("RM-25", "Fabrics & Accessories", "Printed Satin", 2500.0, "Piece"),
        RawMaterialRate("RM-26", "Fabrics & Accessories", "Ribbons", 100.0, "Piece"),
        RawMaterialRate("RM-27", "Fabrics & Accessories", "Cocas Pins", 200.0, "Packet"),
        // Abrasives & Fasteners
        RawMaterialRate("RM-28", "Abrasives & Fasteners", "Indasa P60 Roll", 11000.0, "Roll"),
        RawMaterialRate("RM-29", "Abrasives & Fasteners", "No 150 Sandpaper", 1500.0, "Pack / Roll"),
        RawMaterialRate("RM-30", "Abrasives & Fasteners", "P36 Sandpaper", 1700.0, "Pack / Roll"),
        RawMaterialRate("RM-31", "Abrasives & Fasteners", "Polished Nails", 4800.0, "Bag/Box"),
        // Sets
        RawMaterialRate("RM-32", "Sets", "Spindles Set", 3000.0, "Set")
    )

    val catalogAverageMaterialPriceKes: Double = 1883.28
    val catalogHighestPricedMaterialKes: Double = 11000.0

    // PDF Page 9 Equipment Hire & Funeral Services Rates
    val equipmentHireRates: List<EquipmentHireRate> = listOf(
        EquipmentHireRate("EQP-01", "Lowering Gear", 5000.0, "Per Event", "Grave Equipment"),
        EquipmentHireRate("EQP-02", "Church Trolley", 1500.0, "Per Event", "Church Equipment"),
        EquipmentHireRate("EQP-03", "Grave Side Carpet", 3000.0, "Per Event", "Grave Equipment"),
        EquipmentHireRate("EQP-04", "Gazebo Carpet", 4000.0, "Per Event", "Grave Equipment"),
        EquipmentHireRate("EQP-05", "Walk Way Carpet", 4000.0, "Per Event", "Grave Equipment"),
        EquipmentHireRate("EQP-06", "Stanchions", 1000.0, "Per Event", "Ground Control")
    )

    // PDF Page 9 Sales & Dressing Products / Transport Catalog
    val salesDressingAndTransportItems: List<Triple<String, String, String>> = listOf(
        Triple("Burial Gown", "Dressing Apparel", "Sales & Dressing"),
        Triple("Suits", "Dressing Apparel", "Sales & Dressing"),
        Triple("Gloves", "Dressing Accessory", "Sales & Dressing"),
        Triple("Veil", "Dressing Accessory", "Sales & Dressing"),
        Triple("Sox (Socks)", "Dressing Accessory", "Sales & Dressing"),
        Triple("Flowers", "Floral Arrangements", "Decor & Tribute"),
        Triple("Hearse Van", "Fleet - Transport", "Transport Services"),
        Triple("Caravan Prado", "Fleet - Premium Transport", "Transport Services"),
        Triple("Caravan Ractis", "Fleet - Standard Transport", "Transport Services"),
        Triple("Body Bag", "Containment / Transport", "Supplies")
    )

    // PDF Page 10 Workshop Personnel & Roles
    val workshopPersonnelDirectory: List<WorkshopPersonnelRole> = listOf(
        WorkshopPersonnelRole("Body Works", "Silas Hayoyo", "Active Staff"),
        WorkshopPersonnelRole("Body Works", "John Odipo", "Active Staff"),
        WorkshopPersonnelRole("Body Works", "George Oduor", "Active Staff"),
        WorkshopPersonnelRole("Paint Work", "Brian Adoche", "Active Staff"),
        WorkshopPersonnelRole("Paint Work", "Shadrack Wangwero", "Active Staff"),
        WorkshopPersonnelRole("Paint Work", "Richard Opiyo", "Active Staff"),
        WorkshopPersonnelRole("Finishing", "Silas Hayoyo", "Active Staff")
    )

    // PDF Page 10 Branch / Shop Network (SH-01 to SH-08)
    val shopBranchNetwork: List<ShopBranchLocation> = listOf(
        ShopBranchLocation("SH-01", "Siaya Main", "Main Branch"),
        ShopBranchLocation("SH-02", "Bondo", "Branch Office"),
        ShopBranchLocation("SH-03", "Siaya Referral", "Hospital Outlet"),
        ShopBranchLocation("SH-04", "Bama", "Branch Office"),
        ShopBranchLocation("SH-05", "Rangala", "Branch Office"),
        ShopBranchLocation("SH-06", "Ukwala", "Branch Office"),
        ShopBranchLocation("SH-07", "Got Agulu", "Branch Office"),
        ShopBranchLocation("SH-08", "Uradi", "Branch Office")
    )

    val casketProductionModels: List<CasketProductionCostModel> by lazy {
        listOf(
            buildSimpleModel(),
            buildKids45Model(),
            buildSpindles35Model(),
            buildSpindles25Model(),
            buildHalfGlassesModel(),
            buildMiniDomesModel(),
            buildHighRoofsModel(),
            buildDomesModel(),
            buildExecutiveDomesModel()
        )
    }

    /**
     * Dynamically recalculates BOM & Production Cost for a model with workshop options:
     * - Bulk Glue saves KES 100 per Ltr (KES 900 vs KES 1,000)
     * - Adding Spindles Set (+KES 3,000) for decorative carved rails
     * - Upgrading Handles to Swing Bar (+diff over base handles)
     */
    fun calculateModelWithOptions(
        modelId: String,
        useBulkGlue: Boolean = false,
        includeSpindlesSet: Boolean = false,
        upgradeToSwingBarHandles: Boolean = false,
        customSellingPriceKes: Double? = null
    ): CasketProductionCostModel {
        val base = casketProductionModels.firstOrNull { it.id == modelId } ?: casketProductionModels.first()
        val updatedBom = base.bomItems.map { line ->
            if (useBulkGlue && line.rawSpecName.equals("Glue", ignoreCase = true)) {
                val bulkCost = line.quantityNumeric * GLUE_BULK_LTR
                line.copy(
                    clarifiedLabel = "Woodworking Glue Bulk Rate (${line.quantityNumeric} Ltr @ KES 900)",
                    unitPriceKes = GLUE_BULK_LTR,
                    lineCostKes = bulkCost
                )
            } else if (upgradeToSwingBarHandles && line.rawSpecName.contains("Handle", ignoreCase = true) && line.unitPriceKes < HANDLES_SWING_BAR) {
                line.copy(
                    clarifiedLabel = "Upgraded to Swing Bar Handles Set",
                    unitPriceKes = HANDLES_SWING_BAR,
                    lineCostKes = HANDLES_SWING_BAR
                )
            } else {
                line
            }
        }.toMutableList()

        val alreadyHasSpindles = updatedBom.any { it.rawSpecName.contains("Spindles", ignoreCase = true) }
        if (includeSpindlesSet && !alreadyHasSpindles) {
            updatedBom.add(
                BomSpecLineItem(
                    phase = CostingBomPhase.FINISHING,
                    rawSpecName = "Spindles Set",
                    rawQuantitySpec = "1 Set",
                    clarifiedLabel = "Optional Decorative Spindles Set",
                    unitOfMeasure = "Set",
                    quantityNumeric = 1.0,
                    unitPriceKes = SPINDLES_SET,
                    lineCostKes = SPINDLES_SET
                )
            )
        }

        val bodyCost = updatedBom.filter { it.phase == CostingBomPhase.BODY_WORK }.sumOf { it.lineCostKes }
        val finishCost = updatedBom.filter { it.phase == CostingBomPhase.FINISHING }.sumOf { it.lineCostKes }
        val paintCost = updatedBom.filter { it.phase == CostingBomPhase.PAINT_ABRASIVES }.sumOf { it.lineCostKes }

        return base.copy(
            bomItems = updatedBom,
            baseBodyMaterialCostKes = bodyCost,
            finishingMaterialCostKes = finishCost,
            paintAndAbrasivesCostKes = paintCost,
            recommendedOrderPriceKes = customSellingPriceKes ?: base.recommendedOrderPriceKes
        )
    }

    /**
     * Formulates a complete Client Order Quote using PDF Casket Guide Pricing + Page 9 Equipment Hire
     * and validates margin safety against total production cost.
     */
    fun buildOrderQuoteBreakdown(
        model: CasketProductionCostModel,
        casketQuantity: Int = 1,
        selectedEquipmentIds: Set<String> = emptySet(),
        overrideUnitSellingPriceKes: Double? = null
    ): OrderQuoteBreakdown {
        val qty = casketQuantity.coerceAtLeast(1)
        val unitSell = (overrideUnitSellingPriceKes ?: model.recommendedOrderPriceKes).coerceAtLeast(0.0)
        val equipHireTotal = equipmentHireRates
            .filter { selectedEquipmentIds.contains(it.id) }
            .sumOf { it.rateKes }
        val clientTotalKes = (unitSell * qty) + equipHireTotal
        val clientTotalUsd = clientTotalKes / 130.0
        val totalProdCost = model.totalProductionCostKes * qty
        val commission = (unitSell * qty) * 0.05
        val netProfit = (unitSell * qty) - totalProdCost

        val marginEval = PayrollRulesEngine.evaluateBomMargin(
            sellingPriceKes = unitSell * qty,
            materialCostKes = (model.baseBodyMaterialCostKes + model.paintAndAbrasivesCostKes) * qty,
            laborCostKes = model.crewLaborCostKes * qty,
            finishingCostKes = model.finishingMaterialCostKes * qty,
            minTargetMarginPercent = 20.0
        )

        return OrderQuoteBreakdown(
            casketModel = model,
            casketQuantity = qty,
            unitSellingPriceKes = unitSell,
            equipmentHireTotalKes = equipHireTotal,
            clientOrderTotalKes = clientTotalKes,
            clientOrderTotalUsd = clientTotalUsd,
            totalProductionCostKes = totalProdCost,
            expectedSalesCommissionKes = commission,
            netGrossProfitKes = netProfit,
            marginEvaluation = marginEval
        )
    }

    /**
     * Matches any catalog/branch casket display name back to its PDF production cost blueprint.
     */
    fun findModelForCasketName(casketName: String): CasketProductionCostModel? {
        val lower = casketName.trim().lowercase()
        return when {
            lower.contains("executive dome") || lower.contains("saitoti") || lower.contains("vip") || lower == "executive" ->
                casketProductionModels.firstOrNull { it.id == "MOD-EXEC-DOME" }
            lower.contains("half glass dome") || lower.contains("reagan") || lower.contains("mini executive") || lower == "domes" ->
                casketProductionModels.firstOrNull { it.id == "MOD-DOME" }
            lower.contains("high roof") ->
                casketProductionModels.firstOrNull { it.id == "MOD-HIGH-ROOF" }
            lower.contains("kupa") || lower.contains("english") || lower.contains("omondi") ||
                lower.contains("dumu") || lower.contains("dragon") || lower.contains("mosque") ||
                lower.contains("mini dome") || lower.contains("tonny") ->
                casketProductionModels.firstOrNull { it.id == "MOD-MINI-DOME" }
            lower.contains("half glass") || lower.contains("giraffe") ->
                casketProductionModels.firstOrNull { it.id == "MOD-HALF-GLASS" }
            lower.contains("2.5") || lower.contains("2½") || lower.contains("infant") ->
                casketProductionModels.firstOrNull { it.id == "MOD-SPINDLE-25" }
            lower.contains("3.5") || lower.contains("3½") || lower.contains("junior") ->
                casketProductionModels.firstOrNull { it.id == "MOD-SPINDLE-35" }
            lower.contains("kid") || lower.contains("4.5") || lower.contains("4½") ->
                casketProductionModels.firstOrNull { it.id == "MOD-KIDS-45" }
            lower.contains("simple") || lower.contains("pine") || lower.contains("eco") ->
                casketProductionModels.firstOrNull { it.id == "MOD-SIMPLE" }
            else -> null
        }
    }

    // -------------------------------------------------------------------------
    // MODEL FORMULATIONS (1:1 Mapped from Pages 1-6 + Pages 7-8 Prices)
    // -------------------------------------------------------------------------

    private fun buildSimpleModel(): CasketProductionCostModel {
        val bom = listOf(
            line(CostingBomPhase.BODY_WORK, "Boards", "1 ½ Boards", "1.5 Sheets 12mm Chipboard (@ 2,500)", "Boards", 1.5, CHIPBOARD_12MM),
            line(CostingBomPhase.BODY_WORK, "Bottom", "3 Pieces of feet each", "18 ft Timber 6x1.5 (3 pcs × 6 ft @ 30/ft)", "Feet", 18.0, TIMBER_6X15_FT),
            line(CostingBomPhase.BODY_WORK, "Nails", "¾ kgs", "0.75 kg Polished Nails (@ 240/kg est.)", "Kgs", 0.75, NAILS_KG_EST, true),
            line(CostingBomPhase.BODY_WORK, "Hinges", "3 Pieces", "3 Butt Hinges 1.5\" (1.5 Pairs @ 200/pair)", "Pieces", 3.0, HINGE_PIECE),
            line(CostingBomPhase.BODY_WORK, "Glue", "1 Ltr", "1 Ltr Woodworking Glue (@ 1,000/Ltr)", "Litres", 1.0, GLUE_STANDARD_LTR),

            line(CostingBomPhase.FINISHING, "Simple Clothing Set", "1 Set", "1 Simple Interior Clothing Set (Est.)", "Sets", 1.0, CLOTHING_SIMPLE_EST, true),
            line(CostingBomPhase.FINISHING, "Form Sheet", "1 Sheet", "1 Cushion Foam Form Sheet (@ 150)", "Sheets", 1.0, FORM_SHEET),
            line(CostingBomPhase.FINISHING, "Pins", "3 Pieces", "3 Cocas Decorative Pins (Pack Share)", "Pieces", 3.0, PINS_PIECE_ALLOC, true),
            line(CostingBomPhase.FINISHING, "Ribbon", "½ Piece", "0.5 Ribbon Strip (@ 100/pc)", "Pieces", 0.5, RIBBON_PIECE),
            line(CostingBomPhase.FINISHING, "Glass", "@ 400", "Standard Viewing Glass Insert (@ 400)", "Units", 1.0, GLASS_SIMPLE),
            line(CostingBomPhase.FINISHING, "Opener", "1 + 2 Screws", "1 Lid Opener (55) + Screws Share (15)", "Sets", 1.0, 70.0),
            line(CostingBomPhase.FINISHING, "Handles", "1 Assorted", "1 H4 Assorted Handles Set (@ 2,000)", "Sets", 1.0, HANDLES_H4_ASSORTED),
            line(CostingBomPhase.FINISHING, "Corners", "4 Corners", "4 Decorative Corner Caps (@ 30/pc)", "Pieces", 4.0, CORNER_PIECE),

            line(CostingBomPhase.PAINT_ABRASIVES, "Primer, Sandpaper & AC Stain Share", "Economy Spray Share", "Primer, P36/150 Sandpaper & Thinner Share", "Alloc", 1.0, 1680.0, true)
        )
        return assemble(
            id = "MOD-SIMPLE",
            name = "Simple Coffin",
            variants = "Simple Economy Tier",
            tier = "Economy Standard",
            size = "Full Adult 6 ft",
            bom = bom,
            labor = 3200.0,
            guidePrice = 25000.0,
            floorPrice = 20000.0,
            priceRange = "KES 22,000 – 28,000",
            matchedBranches = listOf("Simple"),
            team = "Body Works & Simple Finishing Crew",
            notes = "Lowest entry production cost; glass priced at fixed KES 400 allowance per PDF spec."
        )
    }

    private fun buildHalfGlassesModel(): CasketProductionCostModel {
        val bom = listOf(
            line(CostingBomPhase.BODY_WORK, "Boards", "1 ½ Boards", "1.5 Sheets 12mm Chipboard (@ 2,500)", "Boards", 1.5, CHIPBOARD_12MM),
            line(CostingBomPhase.BODY_WORK, "Bottom", "3 Pieces of feet each", "18 ft Timber 6x1.5 (3 pcs × 6 ft @ 30/ft)", "Feet", 18.0, TIMBER_6X15_FT),
            line(CostingBomPhase.BODY_WORK, "Nails", "¾ kgs", "0.75 kg Polished Nails (@ 240/kg)", "Kgs", 0.75, NAILS_KG_EST, true),
            line(CostingBomPhase.BODY_WORK, "Hinges", "4 Pieces", "4 Butt Hinges 1.5\" (2 Pairs @ 200/pair)", "Pieces", 4.0, HINGE_PIECE),
            line(CostingBomPhase.BODY_WORK, "Glue", "1 Ltr", "1 Ltr Woodworking Glue (@ 1,000)", "Litres", 1.0, GLUE_STANDARD_LTR),

            line(CostingBomPhase.FINISHING, "Form Sheet", "1 Piece", "1 Foam Form Sheet (@ 150)", "Sheets", 1.0, FORM_SHEET),
            line(CostingBomPhase.FINISHING, "Simple Clothing Set", "1 Set", "1 Simple Interior Clothing Set (Est.)", "Sets", 1.0, CLOTHING_SIMPLE_EST, true),
            line(CostingBomPhase.FINISHING, "Printed Satin", "1 Piece", "1 Printed Satin Interior Panel (@ 2,500)", "Pieces", 1.0, PRINTED_SATIN),
            line(CostingBomPhase.FINISHING, "Half Glass Panel", "Viewing Panel", "Tempered Half Viewing Glass Share", "Units", 1.0, GLASS_HALF_PANEL, true),
            line(CostingBomPhase.FINISHING, "Pins", "3 Pieces", "3 Cocas Decorative Pins", "Pieces", 3.0, PINS_PIECE_ALLOC, true),
            line(CostingBomPhase.FINISHING, "Ribbon", "½ Piece", "0.5 Ribbon Strip (@ 100)", "Pieces", 0.5, RIBBON_PIECE),
            line(CostingBomPhase.FINISHING, "Openers", "2 Pieces + 4 Screws", "2 Lid Openers (110) + Screws Share (25)", "Sets", 1.0, 135.0),
            line(CostingBomPhase.FINISHING, "Handles", "Assorted Set", "1 H4 Assorted Handles Set (@ 2,000)", "Sets", 1.0, HANDLES_H4_ASSORTED),
            line(CostingBomPhase.FINISHING, "Corners", "4 Corners", "4 Corner Brackets (@ 30)", "Pieces", 4.0, CORNER_PIECE),

            line(CostingBomPhase.PAINT_ABRASIVES, "Filler, Primer & Gloss Share", "Standard Gloss Finish", "Body Filler, Primer, AC Paint & Sandpaper Share", "Alloc", 1.0, 2415.0, true)
        )
        return assemble(
            id = "MOD-HALF-GLASS",
            name = "Half Glasses Coffin",
            variants = "Half Glass & Giraffe Flat",
            tier = "Mid-Standard Tier",
            size = "Full Adult 6 ft",
            bom = bom,
            labor = 5000.0,
            guidePrice = 58000.0,
            floorPrice = 42000.0,
            priceRange = "KES 48,000 – 75,000",
            matchedBranches = listOf("Half Glass", "Giraffe Flat"),
            team = "Body Works & Glass Viewing Crew",
            notes = "Upgrades Simple frame with 4 hinges, Printed Satin lining, and 2 openers."
        )
    }

    private fun buildHighRoofsModel(): CasketProductionCostModel {
        val bom = listOf(
            line(CostingBomPhase.BODY_WORK, "Boards", "2 Boards", "2 Sheets 12mm Chipboard (@ 2,500)", "Boards", 2.0, CHIPBOARD_12MM),
            line(CostingBomPhase.BODY_WORK, "Bottom", "3 Pieces of feet each", "18 ft Timber 6x1.5 (3 pcs × 6 ft @ 30/ft)", "Feet", 18.0, TIMBER_6X15_FT),
            line(CostingBomPhase.BODY_WORK, "Nails", "1 kg", "1.0 kg Polished Nails", "Kgs", 1.0, NAILS_KG_EST, true),
            line(CostingBomPhase.BODY_WORK, "Piano", "1 Long Piece", "1 Long Continuous Piano Hinge (Est.)", "Pieces", 1.0, PIANO_HINGE_EST, true),
            line(CostingBomPhase.BODY_WORK, "Glue", "1 ½ Ltrs", "1.5 Ltrs Woodworking Glue (@ 1,000)", "Litres", 1.5, GLUE_STANDARD_LTR),
            line(CostingBomPhase.BODY_WORK, "Screws", "1 Packet", "1 Packet 0.5\" Wood Screws (@ 100)", "Packets", 1.0, SCREWS_PACKET),

            line(CostingBomPhase.FINISHING, "Clothing Set", "1 Piece Executive", "1 Executive Satin Set (@ 2,500)", "Sets", 1.0, CLOTHING_EXEC_SATIN),
            line(CostingBomPhase.FINISHING, "Pins", "5 Pieces", "5 Cocas Decorative Pins", "Pieces", 5.0, PINS_PIECE_ALLOC, true),
            line(CostingBomPhase.FINISHING, "Ribbon", "1 Piece", "1 Full Ribbon Roll Piece (@ 100)", "Pieces", 1.0, RIBBON_PIECE),
            line(CostingBomPhase.FINISHING, "Openers", "2 Pieces + 4 Screws", "2 Lid Openers (110) + Screws Share (25)", "Sets", 1.0, 135.0),
            line(CostingBomPhase.FINISHING, "Form Sheets", "6 Sheets", "6 Foam Form Sheets (@ 150)", "Sheets", 6.0, FORM_SHEET),
            line(CostingBomPhase.FINISHING, "Handles", "Last Supper / Prayer Hand Set", "Last Supper or Prayer Hand Handles (@ 2,500)", "Sets", 1.0, HANDLES_LAST_SUPPER),
            line(CostingBomPhase.FINISHING, "Corners", "4 Corners", "4 Ornamental Corners (@ 30)", "Pieces", 4.0, CORNER_PIECE),

            line(CostingBomPhase.PAINT_ABRASIVES, "Multi-Coat Primer, Filler & Clear Coat", "High Roof Lacquer Share", "Primer + Body Filler + AC Paint + Clear Coat Share", "Alloc", 1.0, 5215.0, true)
        )
        return assemble(
            id = "MOD-HIGH-ROOF",
            name = "High Roofs (Modern High Roof)",
            variants = "Modern High Roof",
            tier = "Upper Executive",
            size = "Full Adult 6 ft Deep Lid",
            bom = bom,
            labor = 10500.0,
            guidePrice = 125000.0,
            floorPrice = 75000.0,
            priceRange = "KES 95,000 – 125,000",
            matchedBranches = listOf("Modern High Roof"),
            team = "Brian Adoche (Paint) & Silas Hayoyo (Finishing)",
            notes = "Uses continuous piano hinge, 6 form sheets for deep quilted interior, and Last Supper / Prayer Hand hardware."
        )
    }

    private fun buildMiniDomesModel(): CasketProductionCostModel {
        val bom = listOf(
            line(CostingBomPhase.BODY_WORK, "Boards", "2 ½ Boards", "2.5 Sheets 12mm Chipboard (@ 2,500)", "Boards", 2.5, CHIPBOARD_12MM),
            line(CostingBomPhase.BODY_WORK, "Bottom", "3 Pieces of feet each", "18 ft Timber 6x1.5 (@ 30/ft)", "Feet", 18.0, TIMBER_6X15_FT),
            line(CostingBomPhase.BODY_WORK, "Nails", "1 ½ kgs", "1.5 kg Polished Nails", "Kgs", 1.5, NAILS_KG_EST, true),
            line(CostingBomPhase.BODY_WORK, "Glue", "2 Ltrs", "2.0 Ltrs Woodworking Glue (@ 1,000)", "Litres", 2.0, GLUE_STANDARD_LTR),
            line(CostingBomPhase.BODY_WORK, "Hard Board", "½ Sheet", "0.5 Sheet Curved Dome Hard Board (@ 800)", "Sheets", 0.5, HARD_BOARD),
            line(CostingBomPhase.BODY_WORK, "Piano", "1 Long Piece", "1 Long Piano Hinge (Est.)", "Pieces", 1.0, PIANO_HINGE_EST, true),
            line(CostingBomPhase.BODY_WORK, "Screws", "1 Packet", "1 Packet 0.5\" Wood Screws (@ 100)", "Packets", 1.0, SCREWS_PACKET),

            line(CostingBomPhase.FINISHING, "Executive Clothing", "1 Set", "1 Executive Satin Clothing Set (@ 2,500)", "Sets", 1.0, CLOTHING_EXEC_SATIN),
            line(CostingBomPhase.FINISHING, "Pins", "6 Pieces", "6 Cocas Decorative Pins", "Pieces", 6.0, PINS_PIECE_ALLOC, true),
            line(CostingBomPhase.FINISHING, "Ribbon", "1 Piece", "1 Satin Ribbon Strip (@ 100)", "Pieces", 1.0, RIBBON_PIECE),
            line(CostingBomPhase.FINISHING, "Openers", "2 Pieces + 4 Screws", "2 Lid Openers (110) + Screws Share (25)", "Sets", 1.0, 135.0),
            line(CostingBomPhase.FINISHING, "Printed Satin", "1 Piece", "1 Printed Satin Headliner Panel (@ 2,500)", "Pieces", 1.0, PRINTED_SATIN),
            line(CostingBomPhase.FINISHING, "Handles", "Swing Bar Set", "1 Cast Swing Bar Handles Set (@ 6,500)", "Sets", 1.0, HANDLES_SWING_BAR),
            line(CostingBomPhase.FINISHING, "Form Sheets", "6 Sheets", "6 Foam Form Sheets (@ 150)", "Sheets", 6.0, FORM_SHEET),

            line(CostingBomPhase.PAINT_ABRASIVES, "Paint, Primer, Sandpaper & Thinner", "Curved Dome Spray Spec", "Primer, Filler, AC Paints & Indasa P60 Share", "Alloc", 1.0, 5045.0, true)
        )
        return assemble(
            id = "MOD-MINI-DOME",
            name = "Mini Domes",
            variants = "Kupa, English Coffin, Omondi, Dumu, Dragon, Mosque, Tonny",
            tier = "Heritage Mini-Dome",
            size = "Adult 6 ft Curved Lid",
            bom = bom,
            labor = 9500.0,
            guidePrice = 65000.0,
            floorPrice = 48000.0,
            priceRange = "KES 52,000 – 65,000",
            matchedBranches = listOf("Kupa", "English Coffin", "Dumu Mayai", "Dragon", "Tonny"),
            team = "Body Works Dome Mold Crew",
            notes = "Covers Jabima's highest-volume branch lines (Kupa, English, Omondi, Dumu, Dragon, Mosque). Swing Bar handles add KES 6,500."
        )
    }

    private fun buildDomesModel(): CasketProductionCostModel {
        val bom = listOf(
            line(CostingBomPhase.BODY_WORK, "Boards", "3 Boards", "3.0 Sheets 12mm Chipboard (@ 2,500)", "Boards", 3.0, CHIPBOARD_12MM),
            line(CostingBomPhase.BODY_WORK, "Bottom", "½ Piece of 9 Ply", "0.5 Sheet 9mm Plywood Base (@ 1,700)", "Sheets", 0.5, PLYWOOD_9MM),
            line(CostingBomPhase.BODY_WORK, "Nails", "2 kgs", "2.0 kg Polished Nails", "Kgs", 2.0, NAILS_KG_EST, true),
            line(CostingBomPhase.BODY_WORK, "Glue", "2 Ltrs", "2.0 Ltrs Woodworking Glue (@ 1,000)", "Litres", 2.0, GLUE_STANDARD_LTR),
            line(CostingBomPhase.BODY_WORK, "Hard Board", "1 ½ Sheets", "1.5 Sheets Hard Board Curve (@ 800)", "Sheets", 1.5, HARD_BOARD),
            line(CostingBomPhase.BODY_WORK, "Piano", "1 Piece", "1 Piano Hinge Strip (Est.)", "Pieces", 1.0, PIANO_HINGE_EST, true),
            line(CostingBomPhase.BODY_WORK, "Screws", "1 Packet", "1 Packet 0.5\" Wood Screws (@ 100)", "Packets", 1.0, SCREWS_PACKET),

            line(CostingBomPhase.FINISHING, "Executive Clothing", "1 Set", "1 Executive Satin Clothing Set (@ 2,500)", "Sets", 1.0, CLOTHING_EXEC_SATIN),
            line(CostingBomPhase.FINISHING, "Pins", "6 Pieces", "6 Cocas Decorative Pins", "Pieces", 6.0, PINS_PIECE_ALLOC, true),
            line(CostingBomPhase.FINISHING, "Ribbon", "1 Piece", "1 Ribbon Trim (@ 100)", "Pieces", 1.0, RIBBON_PIECE),
            line(CostingBomPhase.FINISHING, "Openers", "2 Pieces + 4 Screws", "2 Lid Openers (110) + Screws Share (25)", "Sets", 1.0, 135.0),
            line(CostingBomPhase.FINISHING, "Printed Satin", "1 Piece", "1 Printed Satin Interior (@ 2,500)", "Pieces", 1.0, PRINTED_SATIN),
            line(CostingBomPhase.FINISHING, "Handles", "Swing Bar Set", "1 Full Swing Bar Handles Set (@ 6,500)", "Sets", 1.0, HANDLES_SWING_BAR),
            line(CostingBomPhase.FINISHING, "Form Sheets", "6 Sheets", "6 Quilted Form Sheets (@ 150)", "Sheets", 6.0, FORM_SHEET),

            line(CostingBomPhase.PAINT_ABRASIVES, "Polyurethane Clear Coat & Filler", "Full Dome Mirror Finish", "Body Filler, Primer, AC Paint, Clear Coat & P60/150", "Alloc", 1.0, 6565.0, true)
        )
        return assemble(
            id = "MOD-DOME",
            name = "Domes (Half Glass Dome / Reagan)",
            variants = "Half Glass Dome, Mini Executive, Reagan",
            tier = "Premium Dome",
            size = "Oversized Curved Dome",
            bom = bom,
            labor = 12000.0,
            guidePrice = 95000.0,
            floorPrice = 80000.0,
            priceRange = "KES 85,000 – 95,000",
            matchedBranches = listOf("Half Glass Dome", "Mini Executive", "Reagan"),
            team = "Silas Hayoyo & Brian Adoche (Gloss Team)",
            notes = "Replaces timber bottom with 9mm Plywood structural base and 1.5 sheets Hard Board dome curvature."
        )
    }

    private fun buildExecutiveDomesModel(): CasketProductionCostModel {
        val bom = listOf(
            line(CostingBomPhase.BODY_WORK, "Boards", "3 ½ Boards", "3.5 Sheets 12mm Chipboard (@ 2,500)", "Boards", 3.5, CHIPBOARD_12MM),
            line(CostingBomPhase.BODY_WORK, "Bottom", "½ Piece 9 Ply", "0.5 Sheet 9mm Plywood Heavy Base (@ 1,700)", "Sheets", 0.5, PLYWOOD_9MM),
            line(CostingBomPhase.BODY_WORK, "Nails", "2 ½ kgs", "2.5 kg Polished Nails", "Kgs", 2.5, NAILS_KG_EST, true),
            line(CostingBomPhase.BODY_WORK, "Glue", "3 Ltrs", "3.0 Ltrs Woodworking Glue (@ 1,000)", "Litres", 3.0, GLUE_STANDARD_LTR),
            line(CostingBomPhase.BODY_WORK, "Hard Board", "1 ½ Sheets", "1.5 Sheets Hard Board Double Crown (@ 800)", "Sheets", 1.5, HARD_BOARD),
            line(CostingBomPhase.BODY_WORK, "Piano", "1 Long Piece", "1 Heavy Piano Hinge (Est.)", "Pieces", 1.0, PIANO_HINGE_EST, true),
            line(CostingBomPhase.BODY_WORK, "Screws", "1 Packet", "1 Packet 0.5\" Wood Screws (@ 100)", "Packets", 1.0, SCREWS_PACKET),

            line(CostingBomPhase.FINISHING, "Executive Clothing", "1 Set", "1 Executive Satin Set (@ 2,500)", "Sets", 1.0, CLOTHING_EXEC_SATIN),
            line(CostingBomPhase.FINISHING, "Pins", "6 Pieces", "6 Cocas Decorative Pins", "Pieces", 6.0, PINS_PIECE_ALLOC, true),
            line(CostingBomPhase.FINISHING, "Ribbon", "1 Piece", "1 Ceremonial Ribbon (@ 100)", "Pieces", 1.0, RIBBON_PIECE),
            line(CostingBomPhase.FINISHING, "Openers", "2 Pieces + 4 Screws", "2 Lid Openers (110) + Screws Share (25)", "Sets", 1.0, 135.0),
            line(CostingBomPhase.FINISHING, "Printed Satin", "1 Piece", "1 Printed Satin Interior (@ 2,500)", "Pieces", 1.0, PRINTED_SATIN),
            line(CostingBomPhase.FINISHING, "Handles", "Swing Bar Set", "1 Cast Swing Bar Handles Set (@ 6,500)", "Sets", 1.0, HANDLES_SWING_BAR),
            line(CostingBomPhase.FINISHING, "Form Sheets", "6 Sheets", "6 Deep Foam Form Sheets (@ 150)", "Sheets", 6.0, FORM_SHEET),

            line(CostingBomPhase.PAINT_ABRASIVES, "Multi-Coat Lacquer, Shellack & Indasa", "Presidential Gloss Spec", "Full AC Paint + Clear Coat + Shellack + Sanding", "Alloc", 1.0, 7695.0, true)
        )
        return assemble(
            id = "MOD-EXEC-DOME",
            name = "Executive Domes (Executive / Saitoti / VIP)",
            variants = "Executive, Saitoti, VIP Flagship",
            tier = "Flagship Luxury",
            size = "Extra-Wide Presidential Crown",
            bom = bom,
            labor = 14500.0,
            guidePrice = 125000.0,
            floorPrice = 105000.0,
            priceRange = "KES 105,000 – 140,000",
            matchedBranches = listOf("Executive", "Saitoti", "VIP"),
            team = "Master Craft & Multi-Stage Gloss Team",
            notes = "Highest material consumption (3.5 Boards + 3L Glue) supporting flagship retail orders KES 105k–140k."
        )
    }

    private fun buildKids45Model(): CasketProductionCostModel {
        val bom = listOf(
            line(CostingBomPhase.BODY_WORK, "Board", "¾ Board", "0.75 Sheet 12mm Chipboard (@ 2,500)", "Boards", 0.75, CHIPBOARD_12MM),
            line(CostingBomPhase.BODY_WORK, "Bottom", "2 Pieces of feet each", "9 ft Timber 6x1.5 (2 pcs × 4.5 ft @ 30/ft)", "Feet", 9.0, TIMBER_6X15_FT),
            line(CostingBomPhase.BODY_WORK, "Glue", "½ Ltr", "0.5 Ltr Woodworking Glue (@ 1,000)", "Litres", 0.5, GLUE_STANDARD_LTR),
            line(CostingBomPhase.BODY_WORK, "Hinges", "2 Pieces", "2 Hinges (1 Pair @ 200)", "Pieces", 2.0, HINGE_PIECE),
            line(CostingBomPhase.BODY_WORK, "Nails", "½ kg", "0.5 kg Polished Nails", "Kgs", 0.5, NAILS_KG_EST, true),

            line(CostingBomPhase.FINISHING, "Clothing", "1 Piece", "1 Kids Satin Clothing Lining (Est.)", "Pieces", 1.0, CLOTHING_KIDS_EST, true),
            line(CostingBomPhase.FINISHING, "Pillow", "1 Piece", "1 Soft Kids Pillow (Est.)", "Pieces", 1.0, PILLOW_EST, true),
            line(CostingBomPhase.FINISHING, "Pins", "2 Pieces", "2 Cocas Decorative Pins", "Pieces", 2.0, PINS_PIECE_ALLOC, true),
            line(CostingBomPhase.FINISHING, "Ribbon", "¼ Piece", "0.25 White Ribbon Trim (@ 100)", "Pieces", 0.25, RIBBON_PIECE),
            line(CostingBomPhase.FINISHING, "Form Sheet", "1 Sheet", "1 Foam Form Sheet (@ 150)", "Sheets", 1.0, FORM_SHEET),
            line(CostingBomPhase.FINISHING, "Opener", "1 + 2 Screws", "1 Lid Opener (55) + Screws (15)", "Sets", 1.0, 70.0),
            line(CostingBomPhase.FINISHING, "Handles", "H9 Set", "1 H9 Kids Handle Set (Est.)", "Sets", 1.0, HANDLES_H9_KIDS, true),
            line(CostingBomPhase.FINISHING, "Corners", "4 Corners", "4 Small Corners (@ 30)", "Pieces", 4.0, CORNER_PIECE),

            line(CostingBomPhase.PAINT_ABRASIVES, "White Primer & Gloss Spray", "Kids White Finish", "Primer + White Finish Paint & Sandpaper Share", "Alloc", 1.0, 1430.0, true)
        )
        return assemble(
            id = "MOD-KIDS-45",
            name = "Kids Casket (4 ½ Feet)",
            variants = "Spindles Set 4 ½ ft & Standard Kids",
            tier = "Pediatric / Youth",
            size = "4 ½ Feet",
            bom = bom,
            labor = 2800.0,
            guidePrice = 30000.0,
            floorPrice = 24000.0,
            priceRange = "KES 25,000 – 32,000",
            matchedBranches = listOf("Kids"),
            team = "Body Works & Pediatric Finishing",
            notes = "Toggle Spindles Set (+KES 3,000) above when building carved spindle-rail youth caskets."
        )
    }

    private fun buildSpindles35Model(): CasketProductionCostModel {
        val bom = listOf(
            line(CostingBomPhase.BODY_WORK, "Board", "½ Board", "0.5 Sheet 12mm Chipboard (@ 2,500)", "Boards", 0.5, CHIPBOARD_12MM),
            line(CostingBomPhase.BODY_WORK, "Bottom", "½ Piece of feet", "3.5 ft Timber 6x1.5 (@ 30/ft)", "Feet", 3.5, TIMBER_6X15_FT),
            line(CostingBomPhase.BODY_WORK, "Nails", "¼ kg", "0.25 kg Polished Nails", "Kgs", 0.25, NAILS_KG_EST, true),
            line(CostingBomPhase.BODY_WORK, "Glue", "¼ Ltr", "0.25 Ltr Glue (@ 1,000)", "Litres", 0.25, GLUE_STANDARD_LTR),
            line(CostingBomPhase.BODY_WORK, "Hinges", "2 Pieces", "2 Hinges (1 Pair @ 200)", "Pieces", 2.0, HINGE_PIECE),

            line(CostingBomPhase.FINISHING, "Spindles Set", "½ Set Share", "0.5 Spindles Rail Set Allocation (@ 3,000)", "Set", 0.5, SPINDLES_SET),
            line(CostingBomPhase.FINISHING, "Kids Lining & Pillow", "Kids Finish Spec", "Clothing (1,200) + Pillow (350) + Form (150) + H9 (1,500) + Hardware (255)", "Set", 1.0, 3455.0, true),

            line(CostingBomPhase.PAINT_ABRASIVES, "Paint & Sandpaper Share", "Junior White/Cream Finish", "Primer, Gloss Paint & Sandpaper Share", "Alloc", 1.0, 1180.0, true)
        )
        return assemble(
            id = "MOD-SPINDLE-35",
            name = "Spindles Set — 3 ½ Feet",
            variants = "Junior Child Spindles",
            tier = "Child Size",
            size = "3 ½ Feet",
            bom = bom,
            labor = 2000.0,
            guidePrice = 22000.0,
            floorPrice = 17500.0,
            priceRange = "KES 18,000 – 24,000",
            matchedBranches = listOf("Kids"),
            team = "Body Works & Junior Crew",
            notes = "Junior spindle specification using ½ Chipboard sheet and ¼ kg nails."
        )
    }

    private fun buildSpindles25Model(): CasketProductionCostModel {
        val bom = listOf(
            line(CostingBomPhase.BODY_WORK, "Board", "½ Board", "0.5 Sheet 12mm Chipboard (@ 2,500)", "Boards", 0.5, CHIPBOARD_12MM),
            line(CostingBomPhase.BODY_WORK, "Bottom", "½ Piece of feet", "2.5 ft Timber 6x1.5 (@ 30/ft)", "Feet", 2.5, TIMBER_6X15_FT),
            line(CostingBomPhase.BODY_WORK, "Nails", "¼ kg", "0.25 kg Polished Nails", "Kgs", 0.25, NAILS_KG_EST, true),
            line(CostingBomPhase.BODY_WORK, "Glue", "¼ Ltr", "0.25 Ltr Glue (@ 1,000)", "Litres", 0.25, GLUE_STANDARD_LTR),
            line(CostingBomPhase.BODY_WORK, "Hinges", "2 Pieces", "2 Hinges (1 Pair @ 200)", "Pieces", 2.0, HINGE_PIECE),

            line(CostingBomPhase.FINISHING, "Infant Lining & H9 Spec", "Kids Finish Spec", "Clothing (1,000) + Pillow (300) + Form (150) + H9/Corners (1,620)", "Set", 1.0, 3070.0, true),
            line(CostingBomPhase.PAINT_ABRASIVES, "Paint & Sandpaper Share", "Infant Gloss Finish", "Primer + Finish Coat Share", "Alloc", 1.0, 950.0, true)
        )
        return assemble(
            id = "MOD-SPINDLE-25",
            name = "Spindles Set — 2 ½ Feet",
            variants = "Infant Spindles",
            tier = "Infant Size",
            size = "2 ½ Feet",
            bom = bom,
            labor = 1800.0,
            guidePrice = 16000.0,
            floorPrice = 12500.0,
            priceRange = "KES 14,000 – 18,000",
            matchedBranches = listOf("Kids"),
            team = "Body Works & Junior Crew",
            notes = "Smallest footprint model; optimal for minimal board waste from remnant chipboard offcuts."
        )
    }

    private fun line(
        phase: CostingBomPhase,
        rawSpecName: String,
        rawQuantitySpec: String,
        clarifiedLabel: String,
        unitOfMeasure: String,
        qty: Double,
        unitPrice: Double,
        isEst: Boolean = false
    ): BomSpecLineItem = BomSpecLineItem(
        phase = phase,
        rawSpecName = rawSpecName,
        rawQuantitySpec = rawQuantitySpec,
        clarifiedLabel = clarifiedLabel,
        unitOfMeasure = unitOfMeasure,
        quantityNumeric = qty,
        unitPriceKes = unitPrice,
        lineCostKes = (qty * unitPrice * 100.0).roundToInt() / 100.0,
        isEstimatedAllocation = isEst
    )

    private fun assemble(
        id: String,
        name: String,
        variants: String,
        tier: String,
        size: String,
        bom: List<BomSpecLineItem>,
        labor: Double,
        guidePrice: Double,
        floorPrice: Double,
        priceRange: String,
        matchedBranches: List<String>,
        team: String,
        notes: String
    ): CasketProductionCostModel {
        val body = bom.filter { it.phase == CostingBomPhase.BODY_WORK }.sumOf { it.lineCostKes }
        val finish = bom.filter { it.phase == CostingBomPhase.FINISHING }.sumOf { it.lineCostKes }
        val paint = bom.filter { it.phase == CostingBomPhase.PAINT_ABRASIVES }.sumOf { it.lineCostKes }
        return CasketProductionCostModel(
            id = id,
            modelName = name,
            coveredVariants = variants,
            tierLabel = tier,
            sizeSpec = size,
            bomItems = bom,
            baseBodyMaterialCostKes = body,
            finishingMaterialCostKes = finish,
            paintAndAbrasivesCostKes = paint,
            crewLaborCostKes = labor,
            recommendedOrderPriceKes = guidePrice,
            floorOrderPriceKes = floorPrice,
            priceRangeLabel = priceRange,
            matchedBranchCasketTypes = matchedBranches,
            matchedWorkshopTeam = team,
            notes = notes
        )
    }
}
