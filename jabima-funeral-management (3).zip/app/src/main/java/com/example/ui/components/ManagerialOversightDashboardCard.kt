package com.example.ui.components

import androidx.compose.animation.core.Spring
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.spring
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowForward
import androidx.compose.material.icons.filled.AccessTime
import androidx.compose.material.icons.filled.BarChart
import androidx.compose.material.icons.filled.NotificationsActive
import androidx.compose.material.icons.filled.PendingActions
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material.icons.filled.Speed
import androidx.compose.material.icons.filled.TaskAlt
import androidx.compose.material.icons.filled.Warning
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.FilterChip
import androidx.compose.material3.FilterChipDefaults
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.minimumInteractiveComponentSize
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.CornerRadius
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.PathEffect
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.semantics.contentDescription
import androidx.compose.ui.semantics.semantics
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.domain.ManagerialOversightAggregator
import com.example.domain.OversightBarEntry
import com.example.domain.OversightChartDimension
import com.example.domain.OversightMetricMode
import com.example.model.ActivityStatus
import com.example.model.StaffAccount
import com.example.model.StaffActivity
import com.example.model.TaskPriority
import com.example.ui.theme.AmberLight
import com.example.ui.theme.AmberWarning
import com.example.ui.theme.BorderLight
import com.example.ui.theme.EmeraldLight
import com.example.ui.theme.EmeraldSuccess
import com.example.ui.theme.ForestGreenPrimary
import com.example.ui.theme.Navy900
import com.example.ui.theme.PureWhite
import com.example.ui.theme.RoyalCobaltBlue
import com.example.ui.theme.RoyalCobaltIce
import com.example.ui.theme.StrokeRed
import com.example.ui.theme.StrokeRedLight
import com.example.ui.theme.TextMuted
import com.example.ui.theme.TextSecondary
import java.util.Locale
import kotlin.math.ceil
import kotlin.math.max

/**
 * Executive Summary Dashboard featuring an interactive grouped Bar Chart visualizing
 * org-wide staff activity levels (Active Live vs Pending Funeral Service Tasks vs Completed)
 * and a prioritized pending tasks queue for rapid managerial action.
 */
@Composable
fun ManagerialOversightDashboardCard(
    staffAccounts: List<StaffAccount>,
    activities: List<StaffActivity>,
    onUpdateActivityStatus: (activityId: String, status: ActivityStatus) -> Unit = { _, _ -> },
    onDispatchTaskAlert: (StaffActivity) -> Unit = {},
    onOpenTasksTimeline: () -> Unit = {},
    modifier: Modifier = Modifier
) {
    var selectedDimension by remember { mutableStateOf(OversightChartDimension.DEPARTMENT) }
    var metricMode by remember { mutableStateOf(OversightMetricMode.TASK_COUNTS) }
    var selectedDateFilter by remember { mutableStateOf<String?>(null) }
    var selectedBarKey by remember { mutableStateOf<String?>(null) }

    val summary = remember(staffAccounts, activities, selectedDimension, selectedDateFilter) {
        ManagerialOversightAggregator.buildOversightSummary(
            staffAccounts = staffAccounts,
            activities = activities,
            dimension = selectedDimension,
            dateFilter = selectedDateFilter
        )
    }

    LaunchedEffect(summary.bars, selectedDimension) {
        if (selectedBarKey == null || summary.bars.none { it.key == selectedBarKey }) {
            selectedBarKey = summary.bars.firstOrNull { it.totalTasks > 0 }?.key
                ?: summary.bars.firstOrNull()?.key
        }
    }

    val selectedBar = summary.bars.firstOrNull { it.key == selectedBarKey }

    val maxScaleValue = remember(summary.bars, metricMode) {
        val rawMax = summary.bars.maxOfOrNull { entry ->
            if (metricMode == OversightMetricMode.TASK_COUNTS) {
                max(entry.activeCount, max(entry.pendingCount, entry.completedCount)).toFloat()
            } else {
                max(entry.activeHours, max(entry.pendingHours, entry.completedHours)).toFloat()
            }
        } ?: 0f
        if (rawMax <= 0f) 4f else ceil(rawMax.toDouble()).toFloat().coerceAtLeast(2f)
    }

    Card(
        shape = RoundedCornerShape(16.dp),
        colors = CardDefaults.cardColors(containerColor = PureWhite),
        border = BorderStroke(1.dp, BorderLight),
        elevation = CardDefaults.cardElevation(defaultElevation = 2.dp),
        modifier = modifier
            .fillMaxWidth()
            .testTag("managerial_oversight_dashboard_card")
    ) {
        Column(modifier = Modifier.padding(16.dp)) {
            // Header
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    modifier = Modifier.weight(1f)
                ) {
                    Surface(
                        shape = RoundedCornerShape(10.dp),
                        color = RoyalCobaltIce,
                        modifier = Modifier.size(36.dp)
                    ) {
                        Box(contentAlignment = Alignment.Center) {
                            Icon(
                                imageVector = Icons.Default.BarChart,
                                contentDescription = "Managerial Oversight Bar Chart",
                                tint = Navy900,
                                modifier = Modifier.size(20.dp)
                            )
                        }
                    }
                    Spacer(modifier = Modifier.width(10.dp))
                    Column {
                        Text(
                            text = "Managerial Activity & Service Oversight",
                            fontWeight = FontWeight.ExtraBold,
                            fontSize = 14.sp,
                            color = Navy900,
                            maxLines = 1,
                            overflow = TextOverflow.Ellipsis
                        )
                        Text(
                            text = "Staff activity levels & pending funeral duties bar chart",
                            fontSize = 11.sp,
                            color = TextMuted,
                            maxLines = 1,
                            overflow = TextOverflow.Ellipsis
                        )
                    }
                }

                Surface(
                    shape = RoundedCornerShape(10.dp),
                    color = if (summary.urgentHighPendingCount > 0) StrokeRedLight else EmeraldLight
                ) {
                    Text(
                        text = if (summary.urgentHighPendingCount > 0) {
                            "${summary.urgentHighPendingCount} Priority"
                        } else {
                            "On Track"
                        },
                        fontSize = 10.sp,
                        fontWeight = FontWeight.Bold,
                        color = if (summary.urgentHighPendingCount > 0) StrokeRed else EmeraldSuccess,
                        maxLines = 1,
                        softWrap = false,
                        modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp)
                    )
                }
            }

            Spacer(modifier = Modifier.height(12.dp))

            // Top KPI Strip (4 compact tiles)
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                OversightKpiTile(
                    label = "Total Tasks",
                    value = "${summary.totalTasks}",
                    sub = String.format(Locale.US, "%.1fh logged", summary.totalHours),
                    tint = Navy900,
                    bg = RoyalCobaltIce,
                    icon = Icons.Default.BarChart,
                    modifier = Modifier.weight(1f),
                    testTag = "oversight_kpi_total"
                )
                OversightKpiTile(
                    label = "Active Live",
                    value = "${summary.activeCount}",
                    sub = "In progress / transit",
                    tint = EmeraldSuccess,
                    bg = EmeraldLight,
                    icon = Icons.Default.Speed,
                    modifier = Modifier.weight(1f),
                    testTag = "oversight_kpi_active"
                )
                OversightKpiTile(
                    label = "Pending",
                    value = "${summary.pendingCount}",
                    sub = String.format(Locale.US, "%.1fh queued", summary.pendingHoursTotal),
                    tint = AmberWarning,
                    bg = AmberLight,
                    icon = Icons.Default.PendingActions,
                    modifier = Modifier.weight(1f),
                    testTag = "oversight_kpi_pending"
                )
                OversightKpiTile(
                    label = "Done Rate",
                    value = "${summary.completionRatePercent}%",
                    sub = "${summary.completedCount} completed",
                    tint = ForestGreenPrimary,
                    bg = Color(0xFFECFDF5),
                    icon = Icons.Default.TaskAlt,
                    modifier = Modifier.weight(1f),
                    testTag = "oversight_kpi_completion"
                )
            }

            Spacer(modifier = Modifier.height(12.dp))

            // Date Scope Filter + Metric Mode Row
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .horizontalScroll(rememberScrollState()),
                horizontalArrangement = Arrangement.spacedBy(6.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                FilterChip(
                    selected = selectedDateFilter == null,
                    onClick = { selectedDateFilter = null },
                    label = { Text("All Dates", fontSize = 11.sp, maxLines = 1, softWrap = false) },
                    modifier = Modifier.testTag("oversight_date_all")
                )
                summary.availableDates.forEach { date ->
                    FilterChip(
                        selected = selectedDateFilter == date,
                        onClick = { selectedDateFilter = date },
                        label = { Text(date, fontSize = 11.sp, maxLines = 1, softWrap = false) },
                        modifier = Modifier.testTag("oversight_date_$date")
                    )
                }
                Spacer(modifier = Modifier.width(4.dp))
                FilterChip(
                    selected = metricMode == OversightMetricMode.WORKLOAD_HOURS,
                    onClick = {
                        metricMode = if (metricMode == OversightMetricMode.TASK_COUNTS) {
                            OversightMetricMode.WORKLOAD_HOURS
                        } else {
                            OversightMetricMode.TASK_COUNTS
                        }
                    },
                    leadingIcon = {
                        Icon(
                            imageVector = Icons.Default.AccessTime,
                            contentDescription = "Toggle Workload Hours",
                            modifier = Modifier.size(14.dp)
                        )
                    },
                    label = {
                        Text(
                            text = if (metricMode == OversightMetricMode.TASK_COUNTS) "Metric: Tasks" else "Metric: Hours",
                            fontSize = 11.sp,
                            fontWeight = FontWeight.Bold,
                            maxLines = 1,
                            softWrap = false
                        )
                    },
                    colors = FilterChipDefaults.filterChipColors(
                        selectedContainerColor = Navy900,
                        selectedLabelColor = PureWhite,
                        selectedLeadingIconColor = PureWhite
                    ),
                    modifier = Modifier.testTag("oversight_metric_toggle")
                )
            }

            // Perspective / Dimension Chips
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .horizontalScroll(rememberScrollState()),
                horizontalArrangement = Arrangement.spacedBy(6.dp)
            ) {
                OversightChartDimension.values().forEach { dim ->
                    FilterChip(
                        selected = selectedDimension == dim,
                        onClick = { selectedDimension = dim },
                        label = {
                            Text(
                                text = dim.label,
                                fontSize = 11.sp,
                                fontWeight = if (selectedDimension == dim) FontWeight.Bold else FontWeight.Medium,
                                maxLines = 1,
                                softWrap = false
                            )
                        },
                        colors = FilterChipDefaults.filterChipColors(
                            selectedContainerColor = RoyalCobaltBlue,
                            selectedLabelColor = PureWhite
                        ),
                        modifier = Modifier.testTag("oversight_dim_${dim.name}")
                    )
                }
            }

            Spacer(modifier = Modifier.height(10.dp))

            // Bar Chart Panel
            Surface(
                color = Color(0xFFF8FAFC),
                shape = RoundedCornerShape(12.dp),
                border = BorderStroke(1.dp, BorderLight),
                modifier = Modifier
                    .fillMaxWidth()
                    .testTag("oversight_bar_chart_container")
            ) {
                Column(modifier = Modifier.padding(12.dp)) {
                    // Legend
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Row(horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                            ChartLegendDot(color = EmeraldSuccess, label = "Active Live")
                            ChartLegendDot(color = AmberWarning, label = "Pending Service")
                            ChartLegendDot(color = RoyalCobaltBlue, label = "Completed")
                        }
                        Text(
                            text = if (metricMode == OversightMetricMode.TASK_COUNTS) "Count" else "Hours",
                            fontSize = 10.sp,
                            fontWeight = FontWeight.SemiBold,
                            color = TextMuted
                        )
                    }

                    Spacer(modifier = Modifier.height(12.dp))

                    if (summary.bars.isEmpty() || summary.totalTasks == 0) {
                        Box(
                            modifier = Modifier
                                .fillMaxWidth()
                                .height(140.dp)
                                .testTag("oversight_empty_state"),
                            contentAlignment = Alignment.Center
                        ) {
                            Column(horizontalAlignment = Alignment.CenterHorizontally) {
                                Icon(
                                    imageVector = Icons.Default.BarChart,
                                    contentDescription = "No activity data",
                                    tint = TextMuted,
                                    modifier = Modifier.size(30.dp)
                                )
                                Spacer(modifier = Modifier.height(6.dp))
                                Text(
                                    text = "No staff activity records match this filter.",
                                    fontSize = 12.sp,
                                    fontWeight = FontWeight.SemiBold,
                                    color = TextSecondary
                                )
                            }
                        }
                    } else {
                        GroupedOversightBarChart(
                            bars = summary.bars,
                            metricMode = metricMode,
                            maxScaleValue = maxScaleValue,
                            selectedBarKey = selectedBarKey,
                            onSelectBar = { key -> selectedBarKey = key }
                        )
                    }
                }
            }

            // Selected Bar Drill-Down Card
            if (selectedBar != null && summary.totalTasks > 0) {
                Spacer(modifier = Modifier.height(10.dp))
                SelectedBarDetailBanner(
                    entry = selectedBar,
                    onOpenTasksTimeline = onOpenTasksTimeline
                )
            }

            // Pending Funeral Service Tasks Priority Queue
            if (summary.pendingTasks.isNotEmpty()) {
                Spacer(modifier = Modifier.height(14.dp))
                HorizontalDivider(color = BorderLight)
                Spacer(modifier = Modifier.height(12.dp))

                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Icon(
                            imageVector = Icons.Default.PendingActions,
                            contentDescription = "Pending Funeral Service Tasks",
                            tint = AmberWarning,
                            modifier = Modifier.size(18.dp)
                        )
                        Spacer(modifier = Modifier.width(6.dp))
                        Text(
                            text = "Pending Funeral Service Tasks (${summary.pendingTasks.size})",
                            fontWeight = FontWeight.Bold,
                            fontSize = 13.sp,
                            color = Navy900
                        )
                    }

                    Text(
                        text = "Open Timeline →",
                        fontSize = 11.sp,
                        fontWeight = FontWeight.Bold,
                        color = RoyalCobaltBlue,
                        modifier = Modifier
                            .minimumInteractiveComponentSize()
                            .clip(RoundedCornerShape(6.dp))
                            .clickable { onOpenTasksTimeline() }
                            .padding(horizontal = 6.dp, vertical = 4.dp)
                            .testTag("oversight_open_timeline_link")
                    )
                }

                Spacer(modifier = Modifier.height(8.dp))

                Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    summary.pendingTasks.take(4).forEach { task ->
                        PendingTaskQuickRow(
                            task = task,
                            onStartTask = { onUpdateActivityStatus(task.id, ActivityStatus.IN_PROGRESS) },
                            onAlertStaff = { onDispatchTaskAlert(task) }
                        )
                    }
                }
            }
        }
    }
}

@Composable
private fun GroupedOversightBarChart(
    bars: List<OversightBarEntry>,
    metricMode: OversightMetricMode,
    maxScaleValue: Float,
    selectedBarKey: String?,
    onSelectBar: (String) -> Unit
) {
    val maxTickLabel = if (metricMode == OversightMetricMode.TASK_COUNTS) {
        "${maxScaleValue.toInt()}"
    } else {
        String.format(Locale.US, "%.0fh", maxScaleValue)
    }
    val midTickLabel = if (metricMode == OversightMetricMode.TASK_COUNTS) {
        "${(maxScaleValue / 2f).toInt()}"
    } else {
        String.format(Locale.US, "%.1fh", maxScaleValue / 2f)
    }

    Row(
        modifier = Modifier
            .fillMaxWidth()
            .height(196.dp),
        verticalAlignment = Alignment.Top
    ) {
        // Fixed Y-axis scale aligned to the 136.dp plot canvas + 20.dp top value header
        Column(
            modifier = Modifier
                .width(34.dp)
                .height(156.dp)
                .padding(top = 18.dp, end = 4.dp),
            verticalArrangement = Arrangement.SpaceBetween,
            horizontalAlignment = Alignment.End
        ) {
            Text(text = maxTickLabel, fontSize = 9.sp, color = TextMuted, fontWeight = FontWeight.Medium)
            Text(text = midTickLabel, fontSize = 9.sp, color = TextMuted, fontWeight = FontWeight.Medium)
            Text(text = "0", fontSize = 9.sp, color = TextMuted, fontWeight = FontWeight.Medium)
        }

        // Grid + Scrollable Bar Columns
        Box(
            modifier = Modifier
                .weight(1f)
                .fillMaxHeight()
        ) {
            // Horizontal dashed reference lines behind columns
            Canvas(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(top = 20.dp)
                    .height(136.dp)
            ) {
                val dashEffect = PathEffect.dashPathEffect(floatArrayOf(8f, 6f), 0f)
                val gridColor = Color(0xFFCBD5E1)
                listOf(0f, size.height / 2f, size.height).forEach { y ->
                    drawLine(
                        color = gridColor,
                        start = Offset(0f, y),
                        end = Offset(size.width, y),
                        strokeWidth = if (y == size.height) 1.5.dp.toPx() else 1.dp.toPx(),
                        pathEffect = if (y == size.height) null else dashEffect
                    )
                }
            }

            Row(
                modifier = Modifier
                    .fillMaxSize()
                    .horizontalScroll(rememberScrollState()),
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                bars.forEach { entry ->
                    val isSelected = entry.key == selectedBarKey
                    val activeVal = if (metricMode == OversightMetricMode.TASK_COUNTS) entry.activeCount.toFloat() else entry.activeHours.toFloat()
                    val pendingVal = if (metricMode == OversightMetricMode.TASK_COUNTS) entry.pendingCount.toFloat() else entry.pendingHours.toFloat()
                    val doneVal = if (metricMode == OversightMetricMode.TASK_COUNTS) entry.completedCount.toFloat() else entry.completedHours.toFloat()

                    val animActive by animateFloatAsState(
                        targetValue = (activeVal / maxScaleValue).coerceIn(0f, 1f),
                        animationSpec = spring(stiffness = Spring.StiffnessMediumLow),
                        label = "active_bar_${entry.key}"
                    )
                    val animPending by animateFloatAsState(
                        targetValue = (pendingVal / maxScaleValue).coerceIn(0f, 1f),
                        animationSpec = spring(stiffness = Spring.StiffnessMediumLow),
                        label = "pending_bar_${entry.key}"
                    )
                    val animDone by animateFloatAsState(
                        targetValue = (doneVal / maxScaleValue).coerceIn(0f, 1f),
                        animationSpec = spring(stiffness = Spring.StiffnessMediumLow),
                        label = "done_bar_${entry.key}"
                    )

                    Column(
                        modifier = Modifier
                            .width(74.dp)
                            .fillMaxHeight()
                            .minimumInteractiveComponentSize()
                            .clip(RoundedCornerShape(8.dp))
                            .background(if (isSelected) RoyalCobaltIce.copy(alpha = 0.7f) else Color.Transparent)
                            .border(
                                width = if (isSelected) 1.dp else 0.dp,
                                color = if (isSelected) RoyalCobaltBlue.copy(alpha = 0.45f) else Color.Transparent,
                                shape = RoundedCornerShape(8.dp)
                            )
                            .clickable { onSelectBar(entry.key) }
                            .semantics {
                                contentDescription =
                                    "${entry.label}: ${entry.activeCount} active, ${entry.pendingCount} pending, ${entry.completedCount} completed"
                            }
                            .testTag("oversight_bar_${entry.key}"),
                        horizontalAlignment = Alignment.CenterHorizontally
                    ) {
                        // Top numeric triplet summary
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .height(20.dp)
                                .padding(horizontal = 4.dp),
                            horizontalArrangement = Arrangement.SpaceEvenly,
                            verticalAlignment = Alignment.Bottom
                        ) {
                            Text(
                                text = formatBarValue(activeVal, metricMode),
                                fontSize = 9.sp,
                                fontWeight = FontWeight.Bold,
                                color = if (activeVal > 0f) EmeraldSuccess else TextMuted
                            )
                            Text(
                                text = formatBarValue(pendingVal, metricMode),
                                fontSize = 9.sp,
                                fontWeight = FontWeight.Bold,
                                color = if (pendingVal > 0f) AmberWarning else TextMuted
                            )
                            Text(
                                text = formatBarValue(doneVal, metricMode),
                                fontSize = 9.sp,
                                fontWeight = FontWeight.Bold,
                                color = if (doneVal > 0f) RoyalCobaltBlue else TextMuted
                            )
                        }

                        // Grouped Bars Canvas (136.dp height matches reference grid)
                        Canvas(
                            modifier = Modifier
                                .fillMaxWidth()
                                .height(136.dp)
                                .padding(horizontal = 8.dp)
                        ) {
                            val barWidth = (size.width - 8.dp.toPx()) / 3f
                            val gap = 4.dp.toPx()
                            val cornerRadius = CornerRadius(4.dp.toPx(), 4.dp.toPx())

                            val series = listOf(
                                animActive to EmeraldSuccess,
                                animPending to AmberWarning,
                                animDone to RoyalCobaltBlue
                            )

                            series.forEachIndexed { idx, (fraction, barColor) ->
                                val barHeight = if (fraction > 0f) {
                                    (size.height * fraction).coerceAtLeast(6.dp.toPx())
                                } else {
                                    2.dp.toPx()
                                }
                                val left = idx * (barWidth + gap)
                                drawRoundRect(
                                    color = if (fraction > 0f) barColor else Color(0xFFE2E8F0),
                                    topLeft = Offset(left, size.height - barHeight),
                                    size = Size(barWidth, barHeight),
                                    cornerRadius = cornerRadius
                                )
                            }
                        }

                        Spacer(modifier = Modifier.height(4.dp))

                        Text(
                            text = entry.shortLabel,
                            fontSize = 10.sp,
                            fontWeight = if (isSelected) FontWeight.ExtraBold else FontWeight.SemiBold,
                            color = if (isSelected) Navy900 else TextSecondary,
                            maxLines = 1,
                            overflow = TextOverflow.Ellipsis,
                            textAlign = TextAlign.Center,
                            modifier = Modifier.padding(horizontal = 3.dp)
                        )
                    }
                }
            }
        }
    }
}

private fun formatBarValue(value: Float, mode: OversightMetricMode): String = when {
    value <= 0f -> "0"
    mode == OversightMetricMode.TASK_COUNTS -> "${value.toInt()}"
    else -> String.format(Locale.US, "%.1f", value)
}

@Composable
private fun SelectedBarDetailBanner(
    entry: OversightBarEntry,
    onOpenTasksTimeline: () -> Unit
) {
    Surface(
        color = RoyalCobaltIce,
        shape = RoundedCornerShape(10.dp),
        border = BorderStroke(1.dp, RoyalCobaltBlue.copy(alpha = 0.25f)),
        modifier = Modifier
            .fillMaxWidth()
            .testTag("oversight_selected_bar_detail")
    ) {
        Column(modifier = Modifier.padding(10.dp)) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Column(modifier = Modifier.weight(1f)) {
                    Text(
                        text = entry.label,
                        fontWeight = FontWeight.Bold,
                        fontSize = 12.sp,
                        color = Navy900,
                        maxLines = 1,
                        overflow = TextOverflow.Ellipsis
                    )
                    Text(
                        text = "${entry.activeCount} active • ${entry.pendingCount} pending • ${entry.completedCount} completed (${String.format(Locale.US, "%.1f", entry.totalHours)}h)",
                        fontSize = 10.sp,
                        color = TextSecondary
                    )
                }

                OutlinedButton(
                    onClick = onOpenTasksTimeline,
                    contentPadding = PaddingValues(horizontal = 10.dp, vertical = 4.dp),
                    shape = RoundedCornerShape(8.dp),
                    modifier = Modifier
                        .height(34.dp)
                        .testTag("oversight_inspect_selected_button")
                ) {
                    Text("Inspect", fontSize = 11.sp, fontWeight = FontWeight.Bold, maxLines = 1, softWrap = false)
                    Spacer(modifier = Modifier.width(3.dp))
                    Icon(
                        imageVector = Icons.AutoMirrored.Filled.ArrowForward,
                        contentDescription = "Inspect tasks",
                        modifier = Modifier.size(13.dp)
                    )
                }
            }

            if (entry.urgentPendingCount > 0 || entry.pendingAllowanceKes > 0.0) {
                Spacer(modifier = Modifier.height(6.dp))
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    if (entry.urgentPendingCount > 0) {
                        Surface(
                            shape = RoundedCornerShape(6.dp),
                            color = StrokeRedLight
                        ) {
                            Row(
                                modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp),
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Icon(
                                    imageVector = Icons.Default.Warning,
                                    contentDescription = null,
                                    tint = StrokeRed,
                                    modifier = Modifier.size(11.dp)
                                )
                                Spacer(modifier = Modifier.width(3.dp))
                                Text(
                                    text = "${entry.urgentPendingCount} Urgent/High Pending",
                                    fontSize = 9.sp,
                                    fontWeight = FontWeight.Bold,
                                    color = StrokeRed
                                )
                            }
                        }
                    }
                    if (entry.pendingAllowanceKes > 0.0) {
                        Surface(
                            shape = RoundedCornerShape(6.dp),
                            color = AmberLight
                        ) {
                            Text(
                                text = "Pending Allowances: KES ${String.format(Locale.US, "%,.0f", entry.pendingAllowanceKes)}",
                                fontSize = 9.sp,
                                fontWeight = FontWeight.Bold,
                                color = AmberWarning,
                                modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp)
                            )
                        }
                    }
                }
            }
        }
    }
}

@Composable
private fun PendingTaskQuickRow(
    task: StaffActivity,
    onStartTask: () -> Unit,
    onAlertStaff: () -> Unit
) {
    val priorityBg = when (task.priority) {
        TaskPriority.URGENT -> StrokeRedLight
        TaskPriority.HIGH -> AmberLight
        TaskPriority.NORMAL -> RoyalCobaltIce
    }
    val priorityFg = when (task.priority) {
        TaskPriority.URGENT -> StrokeRed
        TaskPriority.HIGH -> AmberWarning
        TaskPriority.NORMAL -> RoyalCobaltBlue
    }

    Surface(
        color = Color(0xFFFFFBEB),
        shape = RoundedCornerShape(10.dp),
        border = BorderStroke(1.dp, AmberWarning.copy(alpha = 0.35f)),
        modifier = Modifier
            .fillMaxWidth()
            .testTag("oversight_pending_task_${task.id}")
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 10.dp, vertical = 8.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.SpaceBetween
        ) {
            Column(modifier = Modifier.weight(1f)) {
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(6.dp)
                ) {
                    Surface(shape = RoundedCornerShape(4.dp), color = priorityBg) {
                        Text(
                            text = task.priority.label.uppercase(Locale.US),
                            fontSize = 8.sp,
                            fontWeight = FontWeight.ExtraBold,
                            color = priorityFg,
                            modifier = Modifier.padding(horizontal = 5.dp, vertical = 1.dp)
                        )
                    }
                    Text(
                        text = "${task.time} • ${task.caseReference}",
                        fontSize = 10.sp,
                        fontWeight = FontWeight.Bold,
                        color = AmberWarning,
                        maxLines = 1
                    )
                }
                Spacer(modifier = Modifier.height(2.dp))
                Text(
                    text = task.title,
                    fontSize = 12.sp,
                    fontWeight = FontWeight.Bold,
                    color = Navy900,
                    maxLines = 1,
                    overflow = TextOverflow.Ellipsis
                )
                Text(
                    text = "${task.staffName} • ${task.status.label}",
                    fontSize = 10.sp,
                    color = TextSecondary,
                    maxLines = 1,
                    overflow = TextOverflow.Ellipsis
                )
            }

            Spacer(modifier = Modifier.width(6.dp))

            Row(horizontalArrangement = Arrangement.spacedBy(4.dp)) {
                OutlinedButton(
                    onClick = onAlertStaff,
                    contentPadding = PaddingValues(horizontal = 8.dp, vertical = 2.dp),
                    shape = RoundedCornerShape(8.dp),
                    modifier = Modifier
                        .height(34.dp)
                        .testTag("oversight_alert_btn_${task.id}")
                ) {
                    Icon(
                        imageVector = Icons.Default.NotificationsActive,
                        contentDescription = "Alert ${task.staffName}",
                        tint = AmberWarning,
                        modifier = Modifier.size(13.dp)
                    )
                    Spacer(modifier = Modifier.width(3.dp))
                    Text("Alert", fontSize = 10.sp, fontWeight = FontWeight.Bold, color = AmberWarning, maxLines = 1, softWrap = false)
                }

                Button(
                    onClick = onStartTask,
                    colors = ButtonDefaults.buttonColors(containerColor = ForestGreenPrimary),
                    contentPadding = PaddingValues(horizontal = 8.dp, vertical = 2.dp),
                    shape = RoundedCornerShape(8.dp),
                    modifier = Modifier
                        .height(34.dp)
                        .testTag("oversight_start_btn_${task.id}")
                ) {
                    Icon(
                        imageVector = Icons.Default.PlayArrow,
                        contentDescription = "Start ${task.title}",
                        modifier = Modifier.size(13.dp)
                    )
                    Spacer(modifier = Modifier.width(2.dp))
                    Text("Start", fontSize = 10.sp, fontWeight = FontWeight.Bold, maxLines = 1, softWrap = false)
                }
            }
        }
    }
}

@Composable
private fun OversightKpiTile(
    label: String,
    value: String,
    sub: String,
    tint: Color,
    bg: Color,
    icon: ImageVector,
    modifier: Modifier = Modifier,
    testTag: String
) {
    Surface(
        color = bg,
        shape = RoundedCornerShape(10.dp),
        modifier = modifier.testTag(testTag)
    ) {
        Column(modifier = Modifier.padding(8.dp)) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(
                    text = label,
                    fontSize = 9.sp,
                    fontWeight = FontWeight.Bold,
                    color = tint,
                    maxLines = 1,
                    overflow = TextOverflow.Ellipsis
                )
                Icon(
                    imageVector = icon,
                    contentDescription = null,
                    tint = tint,
                    modifier = Modifier.size(13.dp)
                )
            }
            Spacer(modifier = Modifier.height(2.dp))
            Text(
                text = value,
                fontSize = 17.sp,
                fontWeight = FontWeight.ExtraBold,
                color = Navy900
            )
            Text(
                text = sub,
                fontSize = 8.sp,
                color = TextSecondary,
                maxLines = 1,
                overflow = TextOverflow.Ellipsis
            )
        }
    }
}

@Composable
private fun ChartLegendDot(color: Color, label: String) {
    Row(verticalAlignment = Alignment.CenterVertically) {
        Box(
            modifier = Modifier
                .size(8.dp)
                .clip(CircleShape)
                .background(color)
        )
        Spacer(modifier = Modifier.width(4.dp))
        Text(
            text = label,
            fontSize = 10.sp,
            fontWeight = FontWeight.SemiBold,
            color = TextSecondary,
            maxLines = 1,
            softWrap = false
        )
    }
}
