package com.example.domain

import com.example.model.CustomerOrderRecord
import com.example.model.Department
import com.example.model.MarginStatus
import com.example.model.PaymentStatus
import com.example.model.StaffAccount
import com.example.model.StaffBreakageRecord
import com.example.model.StaffRole
import com.example.model.TransactionType
import com.example.model.WalletTransaction
import com.google.common.truth.Truth.assertThat
import org.junit.Test

class PayrollRulesEngineTest {

    private fun sampleSalesAgent(id: String = "SLS-001", rate: Double = 5.0) = StaffAccount(
        id = id,
        fullName = "Grace Akinyi",
        email = "grace@jabima.co.ke",
        phone = "+254711111111",
        role = StaffRole.SALES_MARKETING,
        department = Department.SALES_MARKETING,
        password = "pass",
        nationalId = "30112233",
        branch = "Bama Branch",
        baseSalaryKes = 35000.0,
        allowanceKes = 8000.0,
        commissionRatePercent = rate
    )

    private fun sampleOrder(
        orderId: String = "ORD-101",
        selectedCasket: String = "Royal Oak (KES 80,000)",
        totalAmountKes: Double = 95000.0
    ) = CustomerOrderRecord(
        orderId = orderId,
        clientName = "Family Ochieng",
        clientPhone = "+254722222222",
        deceasedName = "Late John Ochieng",
        selectedPackage = "Dignity Package",
        selectedCasket = selectedCasket,
        selectedAddons = emptyList(),
        totalAmountKes = totalAmountKes,
        totalAmountUsd = totalAmountKes / 130.0,
        paymentMethod = "M-PESA",
        paymentTerms = "Full payment",
        paymentStatus = "CONFIRMED_PAID",
        referenceCode = "MPESA-991122",
        orderDate = "14 Nov 2026",
        branch = "Bama Branch",
        salesAgentName = "Grace Akinyi",
        commissionEarnedKes = 0.0
    )

    @Test
    fun calculateOrderCommission_standardOrder_appliesBase5Percent() {
        val agent = sampleSalesAgent(rate = 5.0)
        val order = sampleOrder(
            orderId = "ORD-201",
            selectedCasket = "Standard Cypress (KES 80,000)",
            totalAmountKes = 95_000.0
        )

        val result = PayrollRulesEngine.calculateOrderCommission(
            order = order,
            agent = agent,
            existingTransactions = emptyList()
        )

        assertThat(result.executiveBonusApplied).isFalse()
        assertThat(result.effectiveRatePercent).isWithin(0.001).of(5.0)
        assertThat(result.commissionAmountKes).isWithin(0.01).of(4000.0)
        assertThat(result.referenceNumber).isEqualTo("COM-ORD-201")
        assertThat(result.isDuplicatePrevented).isFalse()
    }

    @Test
    fun calculateOrderCommission_executiveTierOrderOver150k_addsBonusRate() {
        val agent = sampleSalesAgent(rate = 5.0)
        val order = sampleOrder(
            orderId = "ORD-202",
            selectedCasket = "Presidential Mahogany (KES 160,000)",
            totalAmountKes = 185_000.0
        )

        val result = PayrollRulesEngine.calculateOrderCommission(
            order = order,
            agent = agent,
            existingTransactions = emptyList()
        )

        assertThat(result.executiveBonusApplied).isTrue()
        assertThat(result.effectiveRatePercent).isWithin(0.001).of(6.5)
        assertThat(result.commissionAmountKes).isWithin(0.01).of(10_400.0)
    }

    @Test
    fun calculateOrderCommission_duplicateReference_preventsDoubleCredit() {
        val agent = sampleSalesAgent()
        val order = sampleOrder(orderId = "ORD-203")
        val existing = listOf(
            WalletTransaction(
                id = "TXN-1",
                staffId = agent.id,
                type = TransactionType.COMMISSION,
                title = "Commission ORD-203",
                referenceNumber = "COM-ORD-203",
                amount = 4000.0,
                date = "14 Nov 2026",
                status = PaymentStatus.DISBURSED
            )
        )

        val result = PayrollRulesEngine.calculateOrderCommission(
            order = order,
            agent = agent,
            existingTransactions = existing
        )

        assertThat(result.isDuplicatePrevented).isTrue()
        assertThat(result.commissionAmountKes).isEqualTo(0.0)
    }

    @Test
    fun computeWalletSummary_handlesCreditsWithdrawalsPendingAndBreakagesWithZeroFloor() {
        val staffId = "DRV-001"
        val txns = listOf(
            WalletTransaction("T1", staffId, TransactionType.SALARY_BASE, "Salary", "SAL-1", 40000.0, "01 Nov", PaymentStatus.DISBURSED),
            WalletTransaction("T2", staffId, TransactionType.COMMISSION, "Casket Comm", "COM-1", 5000.0, "02 Nov", PaymentStatus.DISBURSED),
            WalletTransaction("T3", staffId, TransactionType.OPERATOR_TRANSPORT_FEE, "Escort Fee", "TRN-1", 3000.0, "03 Nov", PaymentStatus.DISBURSED),
            WalletTransaction("T4", staffId, TransactionType.PAYOUT_WITHDRAWAL, "M-PESA", "WD-1", -12000.0, "04 Nov", PaymentStatus.DISBURSED),
            WalletTransaction("T5", staffId, TransactionType.PAYOUT_WITHDRAWAL, "Pending Req", "WD-2", -6000.0, "05 Nov", PaymentStatus.PENDING_APPROVAL)
        )
        val breakages = listOf(
            StaffBreakageRecord("BRK-1", staffId, "Driver", Department.DRIVERS, "Lowering Strap", "Damaged", 2500.0, "04 Nov", "Admin", isDeducted = true),
            StaffBreakageRecord("BRK-2", staffId, "Driver", Department.DRIVERS, "Minor", "Pending", 999.0, "05 Nov", "Admin", isDeducted = false)
        )

        val summary = PayrollRulesEngine.computeWalletSummary(staffId, txns, breakages)

        assertThat(summary.totalEarned).isWithin(0.01).of(48_000.0)
        assertThat(summary.totalWithdrawn).isWithin(0.01).of(12_000.0)
        assertThat(summary.pendingPayouts).isWithin(0.01).of(6_000.0)
        assertThat(summary.casketCommissionTotal).isWithin(0.01).of(5_000.0)
        assertThat(summary.servicePayoutsTotal).isWithin(0.01).of(3_000.0)
        assertThat(summary.breakageDeductionsTotal).isWithin(0.01).of(2_500.0)
        assertThat(summary.availableBalance).isWithin(0.01).of(27_500.0)

        // Verify zero-floor guard when deductions exceed earnings
        val overDeductedSummary = PayrollRulesEngine.computeWalletSummary(
            staffId = staffId,
            transactions = listOf(
                WalletTransaction("T6", staffId, TransactionType.SALARY_BASE, "Small", "SAL-2", 1000.0, "06 Nov", PaymentStatus.DISBURSED)
            ),
            breakageRecords = listOf(
                StaffBreakageRecord("BRK-3", staffId, "Driver", Department.DRIVERS, "Lamp", "Costly", 5000.0, "06 Nov", "Admin", isDeducted = true)
            )
        )
        assertThat(overDeductedSummary.availableBalance).isEqualTo(0.0)
    }

    @Test
    fun generateMonthlyPayrollRun_processesActiveStaffOffsetsBreakagesAndSkipsDuplicates() {
        val activeAgent = sampleSalesAgent("SLS-001")
        val inactiveAgent = sampleSalesAgent("SLS-999").copy(isActive = false)
        val alreadyPaidAgent = sampleSalesAgent("SLS-002")

        val existingTxns = listOf(
            WalletTransaction(
                id = "TXN-EX-1",
                staffId = alreadyPaidAgent.id,
                type = TransactionType.SALARY_BASE,
                title = "Automated Payroll Run • November 2026",
                referenceNumber = "PAYROLL-SLS-002-NOVEMBER-2026",
                amount = 43000.0,
                date = "01 Nov 2026",
                status = PaymentStatus.DISBURSED
            )
        )
        val pendingBreakage = StaffBreakageRecord(
            id = "BRK-10",
            staffId = activeAgent.id,
            staffName = activeAgent.fullName,
            department = activeAgent.department,
            itemBroken = "Velvet Drape",
            description = "Pending deduction",
            breakageCostKes = 3000.0,
            date = "10 Nov 2026",
            loggedBy = "Admin",
            isDeducted = false
        )

        val summary = PayrollRulesEngine.generateMonthlyPayrollRun(
            periodLabel = "November 2026",
            dateFormatted = "14 Nov 2026",
            staffAccounts = listOf(activeAgent, inactiveAgent, alreadyPaidAgent),
            existingTransactions = existingTxns,
            breakageRecords = listOf(pendingBreakage)
        )

        assertThat(summary.processedCount).isEqualTo(1)
        assertThat(summary.skippedDuplicateCount).isEqualTo(1)
        assertThat(summary.totalGrossDisbursedKes).isWithin(0.01).of(43_000.0)
        assertThat(summary.totalBreakagesOffsetKes).isWithin(0.01).of(3_000.0)
        assertThat(summary.totalNetDisbursedKes).isWithin(0.01).of(40_000.0)
        assertThat(summary.items.single().generatedTransaction.referenceNumber).isEqualTo("PAYROLL-SLS-001-NOVEMBER-2026")
    }

    @Test
    fun computeKenyanStatutoryBreakdown_computesShifNssfHousingLevyAndGraduatedPaye() {
        val breakdown = PayrollRulesEngine.computeKenyanStatutoryBreakdown(
            grossMonthlyPayKes = 100_000.0,
            applyStatutory = true
        )

        // SHIF 2.75% of 100k = 2,750
        assertThat(breakdown.shifDeductionKes).isWithin(0.01).of(2_750.0)
        // NSSF 6% capped at 72,000 = 4,320
        assertThat(breakdown.nssfDeductionKes).isWithin(0.01).of(4_320.0)
        // Housing Levy 1.5% of 100k = 1,500
        assertThat(breakdown.housingLevyKes).isWithin(0.01).of(1_500.0)
        // Taxable = 100,000 - 2,750 - 4,320 - 1,500 = 91,430
        assertThat(breakdown.taxablePayKes).isWithin(0.01).of(91_430.0)
        // Band 1: 24,000 * 0.10 = 2,400
        // Band 2: 8,333 * 0.25 = 2,083.25
        // Band 3: (91,430 - 32,333 = 59,097) * 0.30 = 17,729.10
        // Gross PAYE = 22,212.35; minus 2,400 relief = 19,812.35
        assertThat(breakdown.grossPayeKes).isWithin(0.05).of(22_212.35)
        assertThat(breakdown.netPayeKes).isWithin(0.05).of(19_812.35)
        assertThat(breakdown.totalStatutoryDeductionsKes).isWithin(0.05).of(2_750.0 + 4_320.0 + 1_500.0 + 19_812.35)
        assertThat(breakdown.netTakeHomeBeforeBreakageKes).isWithin(0.05).of(100_000.0 - breakdown.totalStatutoryDeductionsKes)
    }

    @Test
    fun computeKenyanStatutoryBreakdown_contractExemptAndLowPayRespectsFloor() {
        val lowPay = PayrollRulesEngine.computeKenyanStatutoryBreakdown(
            grossMonthlyPayKes = 8_000.0,
            applyStatutory = true
        )
        // Min SHIF floor KES 300
        assertThat(lowPay.shifDeductionKes).isWithin(0.01).of(300.0)
        assertThat(lowPay.nssfDeductionKes).isWithin(0.01).of(480.0)
        assertThat(lowPay.housingLevyKes).isWithin(0.01).of(120.0)
        assertThat(lowPay.netPayeKes).isEqualTo(0.0)

        val exempt = PayrollRulesEngine.computeKenyanStatutoryBreakdown(
            grossMonthlyPayKes = 65_000.0,
            applyStatutory = false
        )
        assertThat(exempt.totalStatutoryDeductionsKes).isEqualTo(0.0)
        assertThat(exempt.netTakeHomeBeforeBreakageKes).isWithin(0.01).of(65_000.0)
    }

    @Test
    fun evaluateBomMargin_detectsHealthyLowAndBelowCostMargins() {
        val healthy = PayrollRulesEngine.evaluateBomMargin(
            sellingPriceKes = 120_000.0,
            materialCostKes = 45_000.0,
            laborCostKes = 15_000.0,
            finishingCostKes = 10_000.0
        )
        assertThat(healthy.status).isEqualTo(MarginStatus.HEALTHY)
        assertThat(healthy.warningMessage).isNull()
        assertThat(healthy.profitKes).isWithin(0.01).of(50_000.0)

        val lowMargin = PayrollRulesEngine.evaluateBomMargin(
            sellingPriceKes = 100_000.0,
            materialCostKes = 70_000.0,
            laborCostKes = 12_000.0,
            finishingCostKes = 8_000.0
        )
        assertThat(lowMargin.status).isEqualTo(MarginStatus.LOW_MARGIN)
        assertThat(lowMargin.marginPercent).isWithin(0.1).of(10.0)
        assertThat(lowMargin.warningMessage).contains("LOW MARGIN WARNING")

        val loss = PayrollRulesEngine.evaluateBomMargin(
            sellingPriceKes = 50_000.0,
            materialCostKes = 40_000.0,
            laborCostKes = 10_000.0,
            finishingCostKes = 5_000.0
        )
        assertThat(loss.status).isEqualTo(MarginStatus.BELOW_COST)
        assertThat(loss.profitKes).isWithin(0.01).of(-5_000.0)
        assertThat(loss.warningMessage).contains("MARGIN GUARD ALERT")
    }
}
