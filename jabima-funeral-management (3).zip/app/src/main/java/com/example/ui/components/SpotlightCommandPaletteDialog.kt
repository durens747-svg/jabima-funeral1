package com.example.ui.components

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowForward
import androidx.compose.material.icons.filled.Clear
import androidx.compose.material.icons.filled.DirectionsCar
import androidx.compose.material.icons.filled.EventNote
import androidx.compose.material.icons.filled.FileUpload
import androidx.compose.material.icons.filled.Inventory2
import androidx.compose.material.icons.filled.Navigation
import androidx.compose.material.icons.filled.People
import androidx.compose.material.icons.filled.PrecisionManufacturing
import androidx.compose.material.icons.filled.Search
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.window.Dialog
import com.example.model.BurialScheduleEvent
import com.example.model.CasketItem
import com.example.model.FleetGpsVehicle
import com.example.model.MainAppTab
import com.example.model.StaffAccount
import com.example.ui.theme.BorderLight
import com.example.ui.theme.CyanPrimary
import com.example.ui.theme.EmeraldSuccess
import com.example.ui.theme.ForestGreenPrimary
import com.example.ui.theme.Navy900
import com.example.ui.theme.PureWhite
import com.example.ui.theme.TextMuted

data class SpotlightSearchResult(
    val id: String,
    val title: String,
    val subtitle: String,
    val category: String,
    val icon: ImageVector,
    val tagColor: Color,
    val onSelect: () -> Unit
)

@Composable
fun SpotlightCommandPaletteDialog(
    burialSchedules: List<BurialScheduleEvent>,
    fleetVehicles: List<FleetGpsVehicle>,
    staffAccounts: List<StaffAccount>,
    caskets: List<CasketItem>,
    onNavigateTab: (MainAppTab) -> Unit,
    onOpenExcelImport: () -> Unit,
    onOpenPriceEditor: () -> Unit,
    onOpenExportManifest: () -> Unit,
    onDismiss: () -> Unit
) {
    var query by remember { mutableStateOf("") }

    val results = remember(query, burialSchedules, fleetVehicles, staffAccounts, caskets) {
        val q = query.trim().lowercase()
        val list = mutableListOf<SpotlightSearchResult>()

        // 1. Direct App Commands
        val commands = listOf(
            SpotlightSearchResult("cmd_excel", "Import Excel Data Hub", "6 Datasets (.xlsx, .csv) Importer", "COMMAND", Icons.Default.FileUpload, Color(0xFF107C41)) {
                onDismiss()
                onOpenExcelImport()
            },
            SpotlightSearchResult("cmd_export", "Export Excel & Manifests", "Route sheets, equipment lists & payroll", "COMMAND", Icons.Default.Navigation, Color(0xFF0369A1)) {
                onDismiss()
                onOpenExportManifest()
            },
            SpotlightSearchResult("cmd_prices", "Price & Stock Editor", "Adjust casket selling prices & margins", "COMMAND", Icons.Default.Inventory2, Color(0xFFD97706)) {
                onDismiss()
                onOpenPriceEditor()
            },
            SpotlightSearchResult("cmd_workshop", "Go to Live Workshop", "Monitor 4 casket production stages", "NAVIGATION", Icons.Default.PrecisionManufacturing, CyanPrimary) {
                onDismiss()
                onNavigateTab(MainAppTab.WORKSHOP_PRODUCTION)
            },
            SpotlightSearchResult("cmd_fleet", "Go to Fleet GPS Tracking", "Monitor cortege vehicles & routes", "NAVIGATION", Icons.Default.DirectionsCar, Color(0xFF7C3AED)) {
                onDismiss()
                onNavigateTab(MainAppTab.FLEET_TRACKING)
            }
        )

        if (q.isBlank()) {
            list.addAll(commands)
        } else {
            // Filter commands
            list.addAll(commands.filter { it.title.lowercase().contains(q) || it.subtitle.lowercase().contains(q) })

            // Filter Burials
            burialSchedules.filter {
                it.deceasedName.lowercase().contains(q) ||
                        it.caseReference.lowercase().contains(q) ||
                        it.familyRepresentative.lowercase().contains(q) ||
                        it.churchVenue.lowercase().contains(q) ||
                        it.gravesiteLocation.lowercase().contains(q)
            }.take(4).forEach { b ->
                list.add(
                    SpotlightSearchResult(
                        id = b.id,
                        title = "${b.caseReference} • ${b.deceasedName}",
                        subtitle = "Venue: ${b.gravesiteLocation} • Hearse: ${b.assignedHearseReg ?: "Pending"}",
                        category = "BURIAL CASE",
                        icon = Icons.Default.EventNote,
                        tagColor = ForestGreenPrimary
                    ) {
                        onDismiss()
                        onNavigateTab(MainAppTab.BURIAL_SCHEDULING)
                    }
                )
            }

            // Filter Fleet
            fleetVehicles.filter {
                it.registration.lowercase().contains(q) ||
                        it.model.lowercase().contains(q) ||
                        it.driverName.lowercase().contains(q)
            }.take(3).forEach { f ->
                list.add(
                    SpotlightSearchResult(
                        id = f.registration,
                        title = "${f.registration} (${f.model})",
                        subtitle = "Driver: ${f.driverName} • Fuel: ${f.fuelPercent}%",
                        category = "FLEET VEHICLE",
                        icon = Icons.Default.DirectionsCar,
                        tagColor = Color(0xFF7C3AED)
                    ) {
                        onDismiss()
                        onNavigateTab(MainAppTab.FLEET_TRACKING)
                    }
                )
            }

            // Filter Caskets
            caskets.filter {
                it.name.lowercase().contains(q) ||
                        it.woodType.lowercase().contains(q)
            }.take(3).forEach { c ->
                list.add(
                    SpotlightSearchResult(
                        id = c.id,
                        title = c.name,
                        subtitle = "KES ${String.format("%,.0f", c.priceKes)} • Stock: ${c.stockCount} units (${c.woodType})",
                        category = "CASKET MODEL",
                        icon = Icons.Default.Inventory2,
                        tagColor = Color(0xFFD97706)
                    ) {
                        onDismiss()
                        onNavigateTab(MainAppTab.CASKET_SELECTION)
                    }
                )
            }

            // Filter Staff
            staffAccounts.filter {
                it.fullName.lowercase().contains(q) ||
                        it.phone.lowercase().contains(q) ||
                        it.role.title.lowercase().contains(q)
            }.take(3).forEach { s ->
                list.add(
                    SpotlightSearchResult(
                        id = s.id,
                        title = "${s.fullName} (${s.role.title})",
                        subtitle = "${s.department.displayName} • ${s.phone}",
                        category = "STAFF",
                        icon = Icons.Default.People,
                        tagColor = Navy900
                    ) {
                        onDismiss()
                        onNavigateTab(MainAppTab.STAFF_OPERATIONS)
                    }
                )
            }
        }
        list
    }

    Dialog(onDismissRequest = onDismiss) {
        Surface(
            shape = RoundedCornerShape(16.dp),
            color = PureWhite,
            tonalElevation = 10.dp,
            modifier = Modifier
                .fillMaxWidth()
                .padding(vertical = 12.dp)
                .testTag("spotlight_command_palette_dialog")
        ) {
            Column(modifier = Modifier.padding(14.dp)) {
                // Search Field
                OutlinedTextField(
                    value = query,
                    onValueChange = { query = it },
                    modifier = Modifier
                        .fillMaxWidth()
                        .testTag("spotlight_search_input"),
                    placeholder = {
                        Text("Search cases, hearses, caskets, staff, or commands...", fontSize = 12.sp, color = TextMuted)
                    },
                    leadingIcon = {
                        Icon(Icons.Default.Search, contentDescription = null, tint = ForestGreenPrimary, modifier = Modifier.size(20.dp))
                    },
                    trailingIcon = {
                        if (query.isNotEmpty()) {
                            IconButton(onClick = { query = "" }) {
                                Icon(Icons.Default.Clear, contentDescription = "Clear", modifier = Modifier.size(16.dp))
                            }
                        }
                    },
                    singleLine = true,
                    shape = RoundedCornerShape(10.dp),
                    colors = OutlinedTextFieldDefaults.colors(
                        focusedBorderColor = ForestGreenPrimary,
                        unfocusedBorderColor = BorderLight,
                        focusedContainerColor = PureWhite,
                        unfocusedContainerColor = Color(0xFFF8FAFC)
                    )
                )

                Spacer(modifier = Modifier.height(10.dp))

                // Results List
                Text(
                    text = if (query.isBlank()) "SUGGESTED COMMANDS & ACTIONS" else "MATCHING RESULTS (${results.size})",
                    fontSize = 10.sp,
                    fontWeight = FontWeight.Bold,
                    color = Color(0xFF64748B),
                    letterSpacing = 0.5.sp,
                    modifier = Modifier.padding(horizontal = 4.dp, vertical = 2.dp)
                )

                Spacer(modifier = Modifier.height(6.dp))

                LazyColumn(
                    modifier = Modifier.height(320.dp),
                    verticalArrangement = Arrangement.spacedBy(4.dp)
                ) {
                    items(results, key = { it.id }) { item ->
                        Surface(
                            onClick = item.onSelect,
                            color = Color(0xFFF8FAFC),
                            shape = RoundedCornerShape(8.dp),
                            border = BorderStroke(0.5.dp, BorderLight),
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            Row(
                                modifier = Modifier.padding(10.dp),
                                verticalAlignment = Alignment.CenterVertically,
                                horizontalArrangement = Arrangement.SpaceBetween
                            ) {
                                Row(
                                    verticalAlignment = Alignment.CenterVertically,
                                    modifier = Modifier.weight(1f)
                                ) {
                                    Surface(
                                        color = item.tagColor.copy(alpha = 0.12f),
                                        shape = CircleShape,
                                        modifier = Modifier.size(28.dp)
                                    ) {
                                        Box(contentAlignment = Alignment.Center) {
                                            Icon(
                                                imageVector = item.icon,
                                                contentDescription = null,
                                                tint = item.tagColor,
                                                modifier = Modifier.size(15.dp)
                                            )
                                        }
                                    }
                                    Spacer(modifier = Modifier.width(8.dp))
                                    Column {
                                        Row(verticalAlignment = Alignment.CenterVertically) {
                                            Text(
                                                text = item.title,
                                                fontSize = 12.sp,
                                                fontWeight = FontWeight.Bold,
                                                color = Navy900
                                            )
                                            Spacer(modifier = Modifier.width(6.dp))
                                            Surface(
                                                color = item.tagColor.copy(alpha = 0.12f),
                                                shape = RoundedCornerShape(4.dp)
                                            ) {
                                                Text(
                                                    text = item.category,
                                                    fontSize = 8.sp,
                                                    fontWeight = FontWeight.Bold,
                                                    color = item.tagColor,
                                                    modifier = Modifier.padding(horizontal = 4.dp, vertical = 1.dp)
                                                )
                                            }
                                        }
                                        Text(
                                            text = item.subtitle,
                                            fontSize = 10.sp,
                                            color = Color(0xFF64748B)
                                        )
                                    }
                                }

                                Icon(
                                    imageVector = Icons.AutoMirrored.Filled.ArrowForward,
                                    contentDescription = null,
                                    tint = Color.Gray,
                                    modifier = Modifier.size(14.dp)
                                )
                            }
                        }
                    }
                }
            }
        }
    }
}
