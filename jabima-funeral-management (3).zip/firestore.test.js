const {
  initializeTestEnvironment,
  assertFails,
  assertSucceeds,
} = require("@firebase/rules-unit-testing");
const { test, before, after, beforeEach } = require("node:test");
const fs = require("node:fs");

let testEnv;
const PROJECT_ID = process.env.GCP_PROJECT || "demo-no-project";
const ALICE_UID = "alice_staff_001";
const BOB_UID = "bob_staff_002";
const ADMIN_UID = "ceo_admin_001";
const [emulatorHost, emulatorPortStr] = (process.env.FIRESTORE_EMULATOR_HOST || "127.0.0.1:8085").split(":");
const emulatorPort = parseInt(emulatorPortStr, 10);

function serverTs() {
  return new Date(Date.now() - 2000);
}

before(async () => {
  const rules = fs.readFileSync("./firestore.rules", "utf8");
  testEnv = await initializeTestEnvironment({
    projectId: PROJECT_ID,
    firestore: {
      rules,
      host: emulatorHost,
      port: emulatorPort,
    },
  });
});

after(async () => {
  if (testEnv) {
    await testEnv.cleanup();
  }
});

beforeEach(async () => {
  if (testEnv) {
    await testEnv.clearFirestore();
  }
});

test("Unauthenticated user: cannot list or create wallet transactions", async () => {
  const unauthDb = testEnv.unauthenticatedContext().firestore();
  await assertFails(unauthDb.collection("wallet_transactions").get());
  await assertFails(
    unauthDb.collection("wallet_transactions").doc("txn_unauth").set({
      userId: ALICE_UID,
      staffId: "SLS-001",
      type: "COMMISSION",
      title: "Unauthorized credit",
      referenceNumber: "REF-1",
      amount: 5000,
      status: "DISBURSED",
      createdAt: serverTs(),
      updatedAt: serverTs(),
    })
  );
});

test("Email spoofing test: unverified admin email cannot read another staff wallet", async () => {
  await testEnv.withSecurityRulesDisabled(async (ctx) => {
    await ctx.firestore().collection("wallet_transactions").doc("txn_alice").set({
      userId: ALICE_UID,
      staffId: "SLS-001",
      type: "COMMISSION",
      title: "Casket commission",
      referenceNumber: "COM-101",
      amount: 4750,
      status: "DISBURSED",
      createdAt: new Date(),
      updatedAt: new Date(),
    });
  });

  const spoofDb = testEnv.authenticatedContext("spoof_uid", {
    email: "durens747@gmail.com",
    email_verified: false,
  }).firestore();
  await assertFails(spoofDb.collection("wallet_transactions").doc("txn_alice").get());
});

test("Authenticated staff: can create and query own wallet transactions", async () => {
  const aliceDb = testEnv.authenticatedContext(ALICE_UID, {
    email: "alice@jabima.com",
    email_verified: true,
  }).firestore();

  await assertSucceeds(
    aliceDb.collection("wallet_transactions").doc("txn_alice_1").set({
      userId: ALICE_UID,
      staffId: "SLS-001",
      staffName: "Alice Sales",
      type: "PAYOUT_WITHDRAWAL",
      title: "M-PESA Payout Request",
      referenceNumber: "WDL-8891",
      amount: -5000,
      status: "PENDING_APPROVAL",
      payoutMethod: "M-PESA",
      payoutDestination: "+254700000001",
      createdAt: serverTs(),
      updatedAt: serverTs(),
    })
  );

  await assertSucceeds(
    aliceDb.collection("wallet_transactions").where("userId", "==", ALICE_UID).get()
  );
});

test("Authenticated staff: fails unfiltered wallet list & cross-user read (Dirty Dozen)", async () => {
  await testEnv.withSecurityRulesDisabled(async (ctx) => {
    await ctx.firestore().collection("wallet_transactions").doc("txn_bob").set({
      userId: BOB_UID,
      staffId: "DRV-001",
      type: "ACTIVITY_ALLOWANCE",
      title: "Cortege escort payout",
      referenceNumber: "ALW-1",
      amount: 2500,
      status: "DISBURSED",
      createdAt: new Date(),
      updatedAt: new Date(),
    });
  });

  const aliceDb = testEnv.authenticatedContext(ALICE_UID).firestore();
  await assertFails(aliceDb.collection("wallet_transactions").get());
  await assertFails(aliceDb.collection("wallet_transactions").doc("txn_bob").get());
});

test("Shadow update & terminal state lock: staff cannot self-approve payout or inject ghost fields", async () => {
  const aliceDb = testEnv.authenticatedContext(ALICE_UID).firestore();
  await assertSucceeds(
    aliceDb.collection("wallet_transactions").doc("txn_pending").set({
      userId: ALICE_UID,
      staffId: "SLS-001",
      type: "PAYOUT_WITHDRAWAL",
      title: "M-PESA Request",
      referenceNumber: "WDL-123",
      amount: -3000,
      status: "PENDING_APPROVAL",
      createdAt: serverTs(),
      updatedAt: serverTs(),
    })
  );

  // Staff cannot flip own status to DISBURSED
  await assertFails(
    aliceDb.collection("wallet_transactions").doc("txn_pending").update({
      status: "DISBURSED",
      updatedAt: serverTs(),
    })
  );

  // Shadow update with ghost field rejected
  await assertFails(
    aliceDb.collection("wallet_transactions").doc("txn_pending").update({
      notes: "legit note",
      isVerifiedByCeo: true,
      updatedAt: serverTs(),
    })
  );
});

test("Staff activities: cannot self-verify on create; verified admin can approve & list all", async () => {
  const aliceDb = testEnv.authenticatedContext(ALICE_UID).firestore();

  // Self-verification on create blocked
  await assertFails(
    aliceDb.collection("staff_activities").doc("act_cheat").set({
      userId: ALICE_UID,
      staffId: "SLS-001",
      title: "Family consultation",
      status: "VERIFIED_BY_ADMIN",
      allowanceEarned: 5000,
      verifiedByAdmin: true,
      createdAt: serverTs(),
      updatedAt: serverTs(),
    })
  );

  // Valid activity create
  await assertSucceeds(
    aliceDb.collection("staff_activities").doc("act_valid").set({
      userId: ALICE_UID,
      staffId: "SLS-001",
      title: "Family consultation",
      status: "SCHEDULED",
      allowanceEarned: 1500,
      verifiedByAdmin: false,
      createdAt: serverTs(),
      updatedAt: serverTs(),
    })
  );

  // Bootstrap verified admin can list and verify
  const adminDb = testEnv.authenticatedContext(ADMIN_UID, {
    email: "durens747@gmail.com",
    email_verified: true,
  }).firestore();
  await assertSucceeds(adminDb.collection("staff_activities").get());
  await assertSucceeds(
    adminDb.collection("staff_activities").doc("act_valid").update({
      status: "VERIFIED_BY_ADMIN",
      verifiedByAdmin: true,
      allowanceEarned: 2500,
      updatedAt: serverTs(),
    })
  );
});

test("Customer orders & users profile enforce strict schema and ownership", async () => {
  const aliceDb = testEnv.authenticatedContext(ALICE_UID).firestore();
  await assertSucceeds(
    aliceDb.collection("users").doc(ALICE_UID).set({
      userId: ALICE_UID,
      displayName: "David Kimani",
      email: "dkimani@jabima.com",
      linkedStaffId: "SLS-001",
      darkModeEnabled: true,
      createdAt: serverTs(),
      updatedAt: serverTs(),
    })
  );

  const bobDb = testEnv.authenticatedContext(BOB_UID).firestore();
  await assertFails(bobDb.collection("users").doc(ALICE_UID).get());

  await assertSucceeds(
    aliceDb.collection("customer_orders").doc("ord_101").set({
      userId: ALICE_UID,
      orderNumber: "JFD-ORD-101",
      clientName: "Grace Ochieng",
      selectedCasket: "Executive Solid Mahogany",
      totalAmountKes: 110000,
      paymentStatus: "CONFIRMED_PAID",
      branch: "Bama Branch",
      salesAgentId: "SLS-001",
      commissionEarnedKes: 5500,
      createdAt: serverTs(),
      updatedAt: serverTs(),
    })
  );
});

test("Shift attendance logs: staff create/read own, cannot spoof or update; admin can manage all", async () => {
  const aliceDb = testEnv.authenticatedContext(ALICE_UID).firestore();
  const bobDb = testEnv.authenticatedContext(BOB_UID).firestore();
  const adminDb = testEnv.authenticatedContext(ADMIN_UID, {
    email: "durens747@gmail.com",
    email_verified: true,
  }).firestore();

  // Staff cannot spoof another userId
  await assertFails(
    aliceDb.collection("shift_attendance_logs").doc("att_spoof").set({
      userId: BOB_UID,
      staffId: "DRV-001",
      staffName: "Bob Driver",
      action: "CHECK_IN",
      verifiedByStaffId: "CEO-001",
      createdAt: serverTs(),
      updatedAt: serverTs(),
    })
  );

  // Valid create for own userId
  await assertSucceeds(
    aliceDb.collection("shift_attendance_logs").doc("att_alice_1").set({
      userId: ALICE_UID,
      staffId: "SLS-001",
      staffName: "Alice Sales",
      branch: "Nairobi Central Branch",
      action: "CHECK_IN",
      checkpointLocation: "Main Gate QR",
      verifiedByStaffId: "SUP-001",
      verifiedByName: "Night Supervisor",
      createdAt: serverTs(),
      updatedAt: serverTs(),
    })
  );

  // Staff can read own log, cannot read without filter, cannot update or delete
  await assertSucceeds(aliceDb.collection("shift_attendance_logs").where("userId", "==", ALICE_UID).get());
  await assertFails(bobDb.collection("shift_attendance_logs").doc("att_alice_1").get());
  await assertFails(
    aliceDb.collection("shift_attendance_logs").doc("att_alice_1").update({
      action: "CHECK_OUT",
      updatedAt: serverTs(),
    })
  );

  // Admin can list, update, and delete
  await assertSucceeds(adminDb.collection("shift_attendance_logs").get());
  await assertSucceeds(
    adminDb.collection("shift_attendance_logs").doc("att_alice_1").update({
      notes: "Verified by night branch audit",
      updatedAt: serverTs(),
    })
  );
  await assertSucceeds(adminDb.collection("shift_attendance_logs").doc("att_alice_1").delete());
});

test("Burial schedules: owner can update cortege milestone only; immutable deceasedName; admin full CRUD", async () => {
  const aliceDb = testEnv.authenticatedContext(ALICE_UID).firestore();
  const bobDb = testEnv.authenticatedContext(BOB_UID).firestore();
  const adminDb = testEnv.authenticatedContext(ADMIN_UID, {
    email: "durens747@gmail.com",
    email_verified: true,
  }).firestore();

  await assertSucceeds(
    aliceDb.collection("burial_schedules").doc("bur_101").set({
      userId: ALICE_UID,
      caseReference: "CASE-2026-101",
      deceasedName: "Late Mzee Kamau",
      burialDate: "2026-11-22",
      casketModel: "Executive Solid Mahogany",
      assignedHearseReg: "KDM 401J",
      status: "Scheduled",
      currentMilestone: "HEARSE_DISPATCHED",
      milestoneUpdatedAt: "08:30",
      rosterSynced: true,
      createdAt: serverTs(),
      updatedAt: serverTs(),
    })
  );

  // Non-owner rejected
  await assertFails(bobDb.collection("burial_schedules").doc("bur_101").get());

  // Owner allowed to advance cortege milestone
  await assertSucceeds(
    aliceDb.collection("burial_schedules").doc("bur_101").update({
      currentMilestone: "CHURCH_SERVICE",
      milestoneUpdatedAt: "10:15",
      status: "At Church",
      updatedAt: serverTs(),
    })
  );

  // Owner blocked from modifying protected fields or injecting extra fields
  await assertFails(
    aliceDb.collection("burial_schedules").doc("bur_101").update({
      deceasedName: "Tampered Name",
      updatedAt: serverTs(),
    })
  );
  await assertFails(
    aliceDb.collection("burial_schedules").doc("bur_101").update({
      currentMilestone: "GRAVESIDE_INTERMENT",
      ghostField: "bad",
      updatedAt: serverTs(),
    })
  );

  // Admin can update any validated field and delete
  await assertSucceeds(
    adminDb.collection("burial_schedules").doc("bur_101").update({
      assignedHearseReg: "KDN 999K",
      updatedAt: serverTs(),
    })
  );
  await assertSucceeds(adminDb.collection("burial_schedules").doc("bur_101").delete());
});

test("Workshop jobs: owner updates stage/notes only; admin edits pricing; full CRUD for admin", async () => {
  const aliceDb = testEnv.authenticatedContext(ALICE_UID).firestore();
  const adminDb = testEnv.authenticatedContext(ADMIN_UID, {
    email: "durens747@gmail.com",
    email_verified: true,
  }).firestore();

  await assertSucceeds(
    aliceDb.collection("workshop_jobs").doc("wrk_101").set({
      userId: ALICE_UID,
      casketType: "Royal Oak Veneer",
      assignedCraftsmanId: "WRK-001",
      assignedCraftsmanName: "Peter Carpenter",
      currentStage: "TIMBER_JOINERY",
      completionPercentage: 40,
      sellingPriceKes: 85000,
      materialCostKes: 28000,
      createdAt: serverTs(),
      updatedAt: serverTs(),
    })
  );

  // Craftsman/owner can update stage, completionPercentage, notes
  await assertSucceeds(
    aliceDb.collection("workshop_jobs").doc("wrk_101").update({
      currentStage: "FINISHING_POLISH",
      completionPercentage: 80,
      notes: "Gloss coat applied",
      updatedAt: serverTs(),
    })
  );

  // Non-admin blocked from editing sellingPriceKes
  await assertFails(
    aliceDb.collection("workshop_jobs").doc("wrk_101").update({
      sellingPriceKes: 120000,
      updatedAt: serverTs(),
    })
  );

  // Admin can update pricing and delete
  await assertSucceeds(
    adminDb.collection("workshop_jobs").doc("wrk_101").update({
      sellingPriceKes: 95000,
      updatedAt: serverTs(),
    })
  );
  await assertSucceeds(adminDb.collection("workshop_jobs").doc("wrk_101").delete());
});

test("Multi-device branch admins & admin-verified activity creation", async () => {
  const BRANCH_ADMIN_UID = "branch_sup_007";
  const aliceDb = testEnv.authenticatedContext(ALICE_UID).firestore();
  const branchAdminDb = testEnv.authenticatedContext(BRANCH_ADMIN_UID, {
    email: "supervisor.bama@jabima.com",
    email_verified: true,
  }).firestore();
  const adminDb = testEnv.authenticatedContext(ADMIN_UID, {
    email: "durens747@gmail.com",
    email_verified: true,
  }).firestore();

  // Regular staff cannot self-promote to /admins
  await assertFails(
    aliceDb.collection("admins").doc(ALICE_UID).set({
      email: "alice@jabima.com",
      role: "BRANCH_ADMIN",
      branch: "Bama Branch",
      updatedAt: serverTs(),
    })
  );

  // Alice creates a private order
  await assertSucceeds(
    aliceDb.collection("customer_orders").doc("ord_cross_branch").set({
      userId: ALICE_UID,
      orderNumber: "JFD-ORD-888",
      clientName: "Peter Otieno",
      selectedCasket: "Royal Cedar",
      totalAmountKes: 95000,
      paymentStatus: "CONFIRMED_PAID",
      branch: "Bama Branch",
      createdAt: serverTs(),
      updatedAt: serverTs(),
    })
  );

  // Before promotion, branchAdmin cannot read Alice's order
  await assertFails(branchAdminDb.collection("customer_orders").doc("ord_cross_branch").get());

  // Bootstrap admin authorizes branch supervisor in /admins/{uid}
  await assertSucceeds(
    adminDb.collection("admins").doc(BRANCH_ADMIN_UID).set({
      email: "supervisor.bama@jabima.com",
      role: "BRANCH_ADMIN",
      branch: "Bama Branch",
      updatedAt: serverTs(),
    })
  );

  // Seeded branch admin can now read/list cross-user records AND create pre-verified staff activities
  await assertSucceeds(branchAdminDb.collection("customer_orders").get());
  await assertSucceeds(
    branchAdminDb.collection("staff_activities").doc("act_admin_verified").set({
      userId: BRANCH_ADMIN_UID,
      staffId: "SUP-001",
      title: "Branch QR Shift Inspection",
      status: "VERIFIED_BY_ADMIN",
      allowanceEarned: 0,
      verifiedByAdmin: true,
      createdAt: serverTs(),
      updatedAt: serverTs(),
    })
  );

  // Bootstrap admin can revoke branch admin access
  await assertSucceeds(adminDb.collection("admins").doc(BRANCH_ADMIN_UID).delete());
  await assertFails(branchAdminDb.collection("customer_orders").get());
});

test("Inventory materials & Casket catalog: zero-trust branch sync permissions", async () => {
  const unauthDb = testEnv.unauthenticatedContext().firestore();
  const aliceDb = testEnv.authenticatedContext(ALICE_UID).firestore();
  const adminDb = testEnv.authenticatedContext(ADMIN_UID, {
    email: "durens747@gmail.com",
    email_verified: true,
  }).firestore();

  await assertFails(unauthDb.collection("inventory_materials").get());
  await assertFails(unauthDb.collection("casket_catalog").get());

  // Non-admin cannot create new inventory material or casket catalog item
  await assertFails(
    aliceDb.collection("inventory_materials").doc("INV-001").set({
      userId: ALICE_UID,
      materialId: "INV-001",
      name: "Mahogany Planks",
      quantity: 20,
      unitCostKes: 3500,
      status: "IN_STOCK",
      createdAt: serverTs(),
      updatedAt: serverTs(),
    })
  );
  await assertFails(
    aliceDb.collection("casket_catalog").doc("CSK-001").set({
      userId: ALICE_UID,
      casketId: "CSK-001",
      name: "Royal Cedar",
      priceKes: 95000,
      inStock: true,
      stockCount: 5,
      createdAt: serverTs(),
      updatedAt: serverTs(),
    })
  );

  // Admin can seed inventory material and casket catalog item
  await assertSucceeds(
    adminDb.collection("inventory_materials").doc("INV-001").set({
      userId: ADMIN_UID,
      materialId: "INV-001",
      name: "Mahogany Planks",
      quantity: 20,
      unitCostKes: 3500,
      status: "IN_STOCK",
      createdAt: serverTs(),
      updatedAt: serverTs(),
    })
  );
  await assertSucceeds(
    adminDb.collection("casket_catalog").doc("CSK-001").set({
      userId: ADMIN_UID,
      casketId: "CSK-001",
      name: "Royal Cedar",
      priceKes: 95000,
      inStock: true,
      stockCount: 5,
      createdAt: serverTs(),
      updatedAt: serverTs(),
    })
  );

  // Any signed-in branch staff can read both collections and update stock quantity/status
  await assertSucceeds(aliceDb.collection("inventory_materials").get());
  await assertSucceeds(aliceDb.collection("casket_catalog").get());
  await assertSucceeds(
    aliceDb.collection("inventory_materials").doc("INV-001").update({
      quantity: 12,
      status: "LOW_STOCK",
      updatedAt: serverTs(),
    })
  );

  // Staff blocked from tampering with unitCostKes or casket pricing or deleting
  await assertFails(
    aliceDb.collection("inventory_materials").doc("INV-001").update({
      unitCostKes: 1,
      updatedAt: serverTs(),
    })
  );
  await assertFails(
    aliceDb.collection("casket_catalog").doc("CSK-001").update({
      priceKes: 1,
      updatedAt: serverTs(),
    })
  );
  await assertFails(aliceDb.collection("casket_catalog").doc("CSK-001").delete());

  // Admin can update pricing and delete
  await assertSucceeds(
    adminDb.collection("casket_catalog").doc("CSK-001").update({
      priceKes: 105000,
      updatedAt: serverTs(),
    })
  );
  await assertSucceeds(adminDb.collection("inventory_materials").doc("INV-001").delete());
  await assertSucceeds(adminDb.collection("casket_catalog").doc("CSK-001").delete());
});

test("Case paperwork vault & App release config permissions", async () => {
  const unauthDb = testEnv.unauthenticatedContext().firestore();
  const aliceDb = testEnv.authenticatedContext(ALICE_UID).firestore();
  const bobDb = testEnv.authenticatedContext(BOB_UID).firestore();
  const adminDb = testEnv.authenticatedContext(ADMIN_UID, {
    email: "durens747@gmail.com",
    email_verified: true,
  }).firestore();

  // Unauthenticated cannot read or write case_documents or app_config
  await assertFails(unauthDb.collection("case_documents").get());
  await assertFails(unauthDb.collection("app_config").doc("release").get());

  // Non-admin cannot self-verify a case document on creation
  await assertFails(
    aliceDb.collection("case_documents").doc("DOC-BAD").set({
      userId: ALICE_UID,
      caseReference: "REF-2026-001",
      deceasedName: "Mama Mary",
      documentType: "BURIAL_PERMIT",
      title: "Burial Permit #442",
      uploadedByStaffId: "WRK-001",
      verifiedByAdmin: true,
      createdAt: serverTs(),
      updatedAt: serverTs(),
    })
  );

  // Alice creates valid unverified permit document
  await assertSucceeds(
    aliceDb.collection("case_documents").doc("DOC-1001").set({
      userId: ALICE_UID,
      caseReference: "REF-2026-001",
      deceasedName: "Mama Mary",
      documentType: "BURIAL_PERMIT",
      title: "Burial Permit #442",
      fileName: "permit_442.jpg",
      mimeType: "image/jpeg",
      thumbnailBase64: "abc123",
      uploadedByStaffId: "WRK-001",
      uploadedByStaffName: "Peter",
      verifiedByAdmin: false,
      createdAt: serverTs(),
      updatedAt: serverTs(),
    })
  );

  // Other staff can read vault docs, cannot delete or verify Alice's document
  await assertSucceeds(bobDb.collection("case_documents").get());
  await assertFails(
    bobDb.collection("case_documents").doc("DOC-1001").update({
      verifiedByAdmin: true,
      updatedAt: serverTs(),
    })
  );
  await assertFails(bobDb.collection("case_documents").doc("DOC-1001").delete());

  // Admin can verify and delete case document
  await assertSucceeds(
    adminDb.collection("case_documents").doc("DOC-1001").update({
      verifiedByAdmin: true,
      updatedAt: serverTs(),
    })
  );
  await assertSucceeds(adminDb.collection("case_documents").doc("DOC-1001").delete());

  // Non-admin cannot publish app release update
  await assertFails(
    aliceDb.collection("app_config").doc("release").set({
      latestVersionCode: 9,
      latestVersionName: "1.8",
      minSupportedVersionCode: 7,
      releaseNotes: "Unauthorized update",
      forceUpdate: true,
      updatedAt: serverTs(),
    })
  );

  // Admin publishes release update with hosted APK downloadUrl and signed-in staff can read it
  await assertSucceeds(
    adminDb.collection("app_config").doc("release").set({
      latestVersionCode: 9,
      latestVersionName: "1.8",
      minSupportedVersionCode: 7,
      releaseNotes: "Cloud vault and role-scoped dashboards",
      forceUpdate: false,
      downloadUrl: "https://downloads.jabimafuneral.co.ke/jabima-v1.8.apk",
      updatedBy: "CEO",
      updatedAt: serverTs(),
    })
  );
  await assertSucceeds(aliceDb.collection("app_config").doc("release").get());
});

test("Staff directory, branch boards, fleet vehicles & company assets: zero-trust operational sync", async () => {
  const unauthDb = testEnv.unauthenticatedContext().firestore();
  const aliceDb = testEnv.authenticatedContext(ALICE_UID).firestore();
  const adminDb = testEnv.authenticatedContext(ADMIN_UID, {
    email: "durens747@gmail.com",
    email_verified: true,
  }).firestore();

  // Unauthenticated denied
  await assertFails(unauthDb.collection("staff_directory").get());
  await assertFails(unauthDb.collection("branch_boards").get());
  await assertFails(unauthDb.collection("fleet_vehicles").get());
  await assertFails(unauthDb.collection("company_assets").get());

  // Non-admin blocked from creating staff, branch board, fleet vehicle, or company asset
  await assertFails(
    aliceDb.collection("staff_directory").doc("STF-001").set({
      userId: ALICE_UID,
      staffId: "STF-001",
      fullName: "Alice Sales",
      roleName: "SALES",
      branch: "Bama Branch",
      active: true,
      createdAt: serverTs(),
      updatedAt: serverTs(),
    })
  );

  // Admin seeds all 4 operational directories
  await assertSucceeds(
    adminDb.collection("staff_directory").doc("STF-001").set({
      userId: ADMIN_UID,
      staffId: "STF-001",
      fullName: "Alice Sales",
      email: "alice@jabima.com",
      roleName: "SALES",
      branch: "Bama Branch",
      active: true,
      mustRotatePassword: false,
      createdAt: serverTs(),
      updatedAt: serverTs(),
    })
  );
  await assertSucceeds(
    adminDb.collection("branch_boards").doc("BRN-BAMA").set({
      userId: ADMIN_UID,
      branchName: "Bama Branch",
      operationalStatus: "NORMAL",
      activeCasesCount: 4,
      coldRoomCapacity: 20,
      coldRoomOccupancy: 12,
      createdAt: serverTs(),
      updatedAt: serverTs(),
    })
  );
  await assertSucceeds(
    adminDb.collection("fleet_vehicles").doc("KDG-705Y").set({
      userId: ADMIN_UID,
      registration: "KDG 705Y",
      model: "Mercedes Hearse",
      statusLabel: "Stationed",
      moving: false,
      fuelPercent: 88,
      engineRunning: false,
      createdAt: serverTs(),
      updatedAt: serverTs(),
    })
  );
  await assertSucceeds(
    adminDb.collection("company_assets").doc("AST-001").set({
      userId: ADMIN_UID,
      assetId: "AST-001",
      name: "Brass Lowering Gear #1",
      category: "Lowering Gear",
      condition: "Good",
      custodyStatus: "IN_DEPOT",
      createdAt: serverTs(),
      updatedAt: serverTs(),
    })
  );

  // Non-admin cannot deactivate staff or change branch coldRoomCapacity or delete assets
  await assertFails(
    aliceDb.collection("staff_directory").doc("STF-001").update({
      active: false,
      updatedAt: serverTs(),
    })
  );
  await assertFails(
    aliceDb.collection("branch_boards").doc("BRN-BAMA").update({
      coldRoomCapacity: 50,
      updatedAt: serverTs(),
    })
  );
  await assertFails(aliceDb.collection("company_assets").doc("AST-001").delete());

  // Signed-in staff CAN update allowed live operational telemetry / custody fields
  await assertSucceeds(
    aliceDb.collection("branch_boards").doc("BRN-BAMA").update({
      coldRoomOccupancy: 18,
      operationalStatus: "HIGH LOAD",
      updatedAt: serverTs(),
    })
  );
  await assertSucceeds(
    aliceDb.collection("fleet_vehicles").doc("KDG-705Y").update({
      moving: true,
      speedKmh: 54,
      fuelPercent: 80,
      engineRunning: true,
      statusLabel: "In Transit",
      updatedAt: serverTs(),
    })
  );
  await assertSucceeds(
    aliceDb.collection("company_assets").doc("AST-001").update({
      custodyStatus: "CHECKED_OUT",
      custodianStaffName: "Alice Sales",
      checkedOutCaseRef: "REF-2026-101",
      updatedAt: serverTs(),
    })
  );

  // Admin can deactivate staff and delete operational records
  await assertSucceeds(
    adminDb.collection("staff_directory").doc("STF-001").update({
      active: false,
      updatedAt: serverTs(),
    })
  );
});

test("Leave requests: staff create Pending only, cannot self-approve; management approves/declines", async () => {
  const aliceDb = testEnv.authenticatedContext(ALICE_UID).firestore();
  const bobDb = testEnv.authenticatedContext(BOB_UID).firestore();
  const adminDb = testEnv.authenticatedContext(ADMIN_UID, {
    email: "durens747@gmail.com",
    email_verified: true,
  }).firestore();

  // Cannot create pre-approved leave request
  await assertFails(
    aliceDb.collection("leave_requests").doc("LV-CHEAT").set({
      userId: ALICE_UID,
      leaveId: "LV-CHEAT",
      staffId: "SLS-001",
      staffName: "Alice Sales",
      leaveType: "Annual Leave",
      startDate: "2026-12-01",
      endDate: "2026-12-05",
      daysCount: 5,
      status: "Approved",
      approvedBy: "Self",
      createdAt: serverTs(),
      updatedAt: serverTs(),
    })
  );

  // Valid Pending leave request
  await assertSucceeds(
    aliceDb.collection("leave_requests").doc("LV-101").set({
      userId: ALICE_UID,
      leaveId: "LV-101",
      staffId: "SLS-001",
      staffName: "Alice Sales",
      departmentName: "SALES",
      leaveType: "Annual Leave",
      startDate: "2026-12-01",
      endDate: "2026-12-05",
      daysCount: 5,
      reason: "Family obligation",
      status: "Pending",
      approvedBy: "",
      createdAt: serverTs(),
      updatedAt: serverTs(),
    })
  );

  // Other staff blocked from reading or updating Alice's leave
  await assertFails(bobDb.collection("leave_requests").doc("LV-101").get());
  await assertFails(
    aliceDb.collection("leave_requests").doc("LV-101").update({
      status: "Approved",
      approvedBy: "Alice Sales",
      updatedAt: serverTs(),
    })
  );

  // Admin can decline or approve leave
  await assertSucceeds(
    adminDb.collection("leave_requests").doc("LV-101").update({
      status: "Declined",
      approvedBy: "CEO",
      updatedAt: serverTs(),
    })
  );
  await assertSucceeds(adminDb.collection("leave_requests").doc("LV-101").delete());
});

