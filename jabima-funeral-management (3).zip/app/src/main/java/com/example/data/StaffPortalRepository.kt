package com.example.data

import com.example.domain.BatchPayrollRunSummary
import com.example.domain.PayrollRulesEngine
import com.example.model.ActivityCategory
import com.example.model.ActivityStatus
import com.example.model.BranchStatusBoard
import com.example.model.CustomerOrderRecord
import com.example.model.Department
import com.example.model.JABIMA_BRANCHES
import com.example.model.JABIMA_FLEET
import com.example.model.PaymentStatus
import com.example.model.StaffAccount
import com.example.model.StaffActivity
import com.example.model.FuneralArrangementStage
import com.example.model.TaskPriority
import com.example.model.StaffRole
import com.example.model.StaffShiftSchedule
import com.example.model.ShiftPeriod
import com.example.model.StaffWalletSummary
import com.example.model.StockMovementRecord
import com.example.model.StockMovementStatus
import com.example.model.TransactionType
import com.example.model.VendorProfile
import com.example.model.VendorTransaction
import com.example.model.VendorTransactionType
import com.example.model.WalletTransaction
import com.example.model.PerformanceIncentive
import com.example.model.IncentiveCategory
import com.example.model.StaffExpenseClaim
import com.example.model.ExpenseCategory
import com.example.model.ExpenseStatus
import com.example.model.StockCategory
import com.example.model.StockUploadItem
import com.example.model.PriceUpdateRecord
import com.example.model.PriceEditItem
import com.example.model.CasketItem
import com.example.model.SalesServiceItem
import com.example.model.PosItem
import com.example.model.PosCategory
import com.example.model.IntegrationPlatform
import com.example.model.SyncStatus
import com.example.model.PlatformIntegrationConfig
import com.example.model.IntegrationSyncLog
import com.example.model.FleetGpsVehicle
import com.example.model.FleetLocationPoint
import com.example.model.GeofenceZone
import com.example.model.GeofenceCheckinEvent
import com.example.model.FleetInspectionRecord
import com.example.model.FleetFuelLogRecord
import com.example.model.MpesaB2cReceipt
import com.example.model.CasketStockByBranchRow
import com.example.model.DashboardDailyKpis
import com.example.model.JABIMA_CASKET_TYPES
import com.example.model.WorkshopProductionStage
import com.example.model.WorkshopProductionItem
import com.example.model.MaterialCategory
import com.example.model.InventoryMaterialItem
import com.example.model.ProductItem
import com.example.model.StaffDailyReport
import com.example.model.BurialScheduleEvent
import com.example.model.BurialServiceTiming
import com.example.model.ServiceReminderLog
import com.example.model.OrderPackageItem
import com.example.model.OrderAddonItem
import com.example.model.StaffBreakageRecord
import com.example.model.OperatorWageAllocation
import com.example.model.StoreUpgradeDowngradeRecord
import com.example.model.AssetCustodyLog
import com.example.model.CustodyStatus
import com.example.model.FamilyCortegeMilestone
import com.example.model.MarginStatus
import com.example.model.ShiftVehicleHandover
import com.example.model.ShiftAttendanceAction
import com.example.model.ShiftAttendanceRecord
import com.example.model.CaseDocumentRecord
import com.example.model.CaseDocumentType
import com.example.model.StaffAlertNotification
import com.example.model.WorkshopMaterialAllocation
import com.example.domain.StaffQrIdentityCodec
import com.example.utils.PasswordSecurityHelper
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import java.util.UUID

class StaffPortalRepository {

    private val dateFormat = SimpleDateFormat("dd MMM yyyy, HH:mm", Locale.getDefault())
    private val shortDateFormat = SimpleDateFormat("dd MMM yyyy", Locale.getDefault())

    private val initialAccounts = listOf(
        // MANAGING DIRECTOR / CEO
        StaffAccount(
            id = "CEO-001",
            fullName = "Fredrick Hayoyo",
            email = "fhayoyo@jabimafuneral.co.ke",
            phone = "+254 793 553 434",
            role = StaffRole.MANAGING_DIRECTOR_CEO,
            department = Department.CEO,
            password = "admin",
            nationalId = "11223344",
            branch = "Siaya Referal",
            assignedVehicle = "KCT 871D",
            isActive = true,
            avatarColor = 0xFF0F172A,
            joinedDate = "01 Jan 2020",
            defaultMpesaNumber = "+254 793 553 434",
            defaultBankDetails = "Standard Chartered - Acc #010293847"
        ),

        // INVENTORY MANAGER (Silas - Authorized alongside CEO for Admin changes)
        StaffAccount(
            id = "INV-001",
            fullName = "Silas Hayoyo",
            email = "shayoyo@jabimafuneral.co.ke",
            phone = "+254 711 201 004",
            role = StaffRole.INVENTORY_MANAGER,
            department = Department.ADMINISTRATION,
            password = "admin",
            nationalId = "28349104",
            branch = "Bama Branch",
            isActive = true,
            avatarColor = 0xFF15803D,
            joinedDate = "10 Jan 2022",
            defaultMpesaNumber = "+254 711 201 004",
            defaultBankDetails = "KCB Bank - Acc #119283746"
        ),

        // WORKSHOP CRAFTSMEN (All Stationed at Workshop)
        StaffAccount(
            id = "WRK-001",
            fullName = "Brian Adoche",
            email = "badoche@jabimafuneral.co.ke",
            phone = "+254 711 201 001",
            role = StaffRole.WORKSHOP_WORKER,
            department = Department.WORKSHOP,
            password = "password123",
            nationalId = "28349101",
            branch = "Workshop",
            isActive = true,
            avatarColor = 0xFF0284C7,
            joinedDate = "15 Jan 2023",
            defaultMpesaNumber = "+254 711 201 001",
            defaultBankDetails = "Equity Bank - Acc #081293847"
        ),
        StaffAccount(
            id = "WRK-002",
            fullName = "George Munono",
            email = "gmunono@jabimafuneral.co.ke",
            phone = "+254 711 201 002",
            role = StaffRole.WORKSHOP_WORKER,
            department = Department.WORKSHOP,
            password = "password123",
            nationalId = "28349102",
            branch = "Workshop",
            isActive = true,
            avatarColor = 0xFF0369A1,
            joinedDate = "01 Mar 2023",
            defaultMpesaNumber = "+254 711 201 002",
            defaultBankDetails = "Cooperative Bank - Acc #011293847"
        ),
        StaffAccount(
            id = "WRK-003",
            fullName = "John Hayoyo",
            email = "jhayoyo@jabimafuneral.co.ke",
            phone = "+254 711 201 003",
            role = StaffRole.WORKSHOP_WORKER,
            department = Department.WORKSHOP,
            password = "password123",
            nationalId = "28349103",
            branch = "Workshop",
            isActive = true,
            avatarColor = 0xFF0EA5E9,
            joinedDate = "10 May 2023",
            defaultMpesaNumber = "+254 711 201 003",
            defaultBankDetails = "KCB Bank - Acc #112839485"
        ),
        StaffAccount(
            id = "WRK-004",
            fullName = "Stephen Odhiambo",
            email = "sodhiambo@jabimafuneral.co.ke",
            phone = "+254 711 201 024",
            role = StaffRole.WORKSHOP_WORKER,
            department = Department.WORKSHOP,
            password = "password123",
            nationalId = "28349124",
            branch = "Workshop",
            isActive = true,
            avatarColor = 0xFF38BDF8,
            joinedDate = "01 Jul 2023",
            defaultMpesaNumber = "+254 711 201 024",
            defaultBankDetails = "Equity Bank - Acc #081293849"
        ),
        StaffAccount(
            id = "WRK-005",
            fullName = "Richard Opiyo",
            email = "ropiyo@jabimafuneral.co.ke",
            phone = "+254 711 201 005",
            role = StaffRole.WORKSHOP_WORKER,
            department = Department.WORKSHOP,
            password = "password123",
            nationalId = "28349105",
            branch = "Workshop",
            isActive = true,
            avatarColor = 0xFF1E293B,
            joinedDate = "12 Aug 2023",
            defaultMpesaNumber = "+254 711 201 005",
            defaultBankDetails = "NCBA Bank - Acc #88291029"
        ),
        StaffAccount(
            id = "WRK-006",
            fullName = "Daniel Wagweru",
            email = "dwagweru@jabimafuneral.co.ke",
            phone = "+254 711 201 006",
            role = StaffRole.WORKSHOP_WORKER,
            department = Department.WORKSHOP,
            password = "password123",
            nationalId = "28349106",
            branch = "Workshop",
            isActive = true,
            avatarColor = 0xFF334155,
            joinedDate = "20 Oct 2023",
            defaultMpesaNumber = "+254 711 201 006",
            defaultBankDetails = "Absa Bank - Acc #44928103"
        ),
        StaffAccount(
            id = "WRK-007",
            fullName = "Noaah Wagweru",
            email = "nwagweru@jabimafuneral.co.ke",
            phone = "+254 711 201 007",
            role = StaffRole.WORKSHOP_WORKER,
            department = Department.WORKSHOP,
            password = "password123",
            nationalId = "28349107",
            branch = "Workshop",
            isActive = true,
            avatarColor = 0xFF475569,
            joinedDate = "15 Jan 2024",
            defaultMpesaNumber = "+254 711 201 007",
            defaultBankDetails = "Cooperative Bank - Acc #011293888"
        ),

        // DRIVERS & FLEET LOGISTICS (All Stationed at Bama Branch)
        StaffAccount(
            id = "DRV-001",
            fullName = "Victor Owino",
            email = "vowino.driver@jabimafuneral.co.ke",
            phone = "+254 722 301 001",
            role = StaffRole.DRIVER,
            department = Department.DRIVERS,
            password = "password123",
            nationalId = "29401821",
            branch = "Bama Branch",
            assignedVehicle = "KDG 705Y",
            isActive = true,
            avatarColor = 0xFF0284C7,
            joinedDate = "01 Feb 2023",
            defaultMpesaNumber = "+254 722 301 001",
            defaultBankDetails = "KCB Bank - Acc #129384021"
        ),
        StaffAccount(
            id = "DRV-002",
            fullName = "Joseph Ouma",
            email = "jouma@jabimafuneral.co.ke",
            phone = "+254 722 301 002",
            role = StaffRole.DRIVER,
            department = Department.DRIVERS,
            password = "password123",
            nationalId = "29401822",
            branch = "Bama Branch",
            assignedVehicle = "KCL 703C",
            isActive = true,
            avatarColor = 0xFF0369A1,
            joinedDate = "15 Mar 2023",
            defaultMpesaNumber = "+254 722 301 002",
            defaultBankDetails = "Equity Bank - Acc #140029381"
        ),
        StaffAccount(
            id = "DRV-003",
            fullName = "Fredrick Ochieng",
            email = "fochieng@jabimafuneral.co.ke",
            phone = "+254 722 301 003",
            role = StaffRole.DRIVER,
            department = Department.DRIVERS,
            password = "password123",
            nationalId = "29401823",
            branch = "Bama Branch",
            assignedVehicle = "KBR 104R",
            isActive = true,
            avatarColor = 0xFF0284C7,
            joinedDate = "10 May 2023",
            defaultMpesaNumber = "+254 722 301 003",
            defaultBankDetails = "Cooperative Bank - Acc #011293991"
        ),
        StaffAccount(
            id = "DRV-004",
            fullName = "Fredrick Osuru",
            email = "fosuru@jabimafuneral.co.ke",
            phone = "+254 722 301 004",
            role = StaffRole.DRIVER,
            department = Department.DRIVERS,
            password = "password123",
            nationalId = "29401824",
            branch = "Bama Branch",
            assignedVehicle = "KDH 172H",
            isActive = true,
            avatarColor = 0xFF0EA5E9,
            joinedDate = "01 Aug 2023",
            defaultMpesaNumber = "+254 722 301 004",
            defaultBankDetails = "KCB Bank - Acc #129384992"
        ),
        StaffAccount(
            id = "DRV-005",
            fullName = "Fredrick Okoth",
            email = "fokoth@jabimafuneral.co.ke",
            phone = "+254 722 301 005",
            role = StaffRole.DRIVER,
            department = Department.DRIVERS,
            password = "password123",
            nationalId = "29401825",
            branch = "Bama Branch",
            assignedVehicle = "KDY 211L",
            isActive = true,
            avatarColor = 0xFF38BDF8,
            joinedDate = "01 Nov 2023",
            defaultMpesaNumber = "+254 722 301 005",
            defaultBankDetails = "Standard Chartered - Acc #010293112"
        ),
        StaffAccount(
            id = "DRV-006",
            fullName = "Fredrick Hayoyo (Driver)",
            email = "fhayoyo.fleet@jabimafuneral.co.ke",
            phone = "+254 793 553 434",
            role = StaffRole.DRIVER,
            department = Department.DRIVERS,
            password = "password123",
            nationalId = "11223344",
            branch = "Bama Branch",
            assignedVehicle = "KCT 871D",
            isActive = true,
            avatarColor = 0xFF0F172A,
            joinedDate = "01 Jan 2020",
            defaultMpesaNumber = "+254 793 553 434",
            defaultBankDetails = "Standard Chartered - Acc #010293847"
        ),

        // OPERATORS DEPARTMENT (All Stationed at Bama Branch)
        StaffAccount(
            id = "OPR-001",
            fullName = "Peter Erkundi",
            email = "perkundi@jabimafuneral.co.ke",
            phone = "+254 744 501 001",
            role = StaffRole.OPERATOR,
            department = Department.OPERATORS,
            password = "password123",
            nationalId = "31002001",
            branch = "Bama Branch",
            isActive = true,
            avatarColor = 0xFF1D4ED8,
            joinedDate = "05 Jan 2023",
            defaultMpesaNumber = "+254 744 501 001",
            defaultBankDetails = "Equity Bank - Acc #140029901",
            transportFeeKes = 1200.0,
            dailyWageKes = 1800.0
        ),
        StaffAccount(
            id = "OPR-002",
            fullName = "Victor Ojow",
            email = "vojow@jabimafuneral.co.ke",
            phone = "+254 744 501 002",
            role = StaffRole.OPERATOR,
            department = Department.OPERATORS,
            password = "password123",
            nationalId = "31002002",
            branch = "Bama Branch",
            isActive = true,
            avatarColor = 0xFF2563EB,
            joinedDate = "10 Jan 2023",
            defaultMpesaNumber = "+254 744 501 002",
            defaultBankDetails = "KCB Bank - Acc #129384902",
            transportFeeKes = 1200.0,
            dailyWageKes = 1800.0
        ),
        StaffAccount(
            id = "OPR-003",
            fullName = "Stephen Ooko",
            email = "sooko@jabimafuneral.co.ke",
            phone = "+254 744 501 003",
            role = StaffRole.OPERATOR,
            department = Department.OPERATORS,
            password = "password123",
            nationalId = "31002003",
            branch = "Bama Branch",
            isActive = true,
            avatarColor = 0xFF3B82F6,
            joinedDate = "15 Jan 2023",
            defaultMpesaNumber = "+254 744 501 003",
            defaultBankDetails = "Cooperative Bank - Acc #011293903",
            transportFeeKes = 1000.0,
            dailyWageKes = 1650.0
        ),
        StaffAccount(
            id = "OPR-004",
            fullName = "Erick Omollo",
            email = "eomollo@jabimafuneral.co.ke",
            phone = "+254 744 501 004",
            role = StaffRole.OPERATOR,
            department = Department.OPERATORS,
            password = "password123",
            nationalId = "31002004",
            branch = "Bama Branch",
            isActive = true,
            avatarColor = 0xFF60A5FA,
            joinedDate = "01 Feb 2023",
            defaultMpesaNumber = "+254 744 501 004",
            defaultBankDetails = "Absa Bank - Acc #449281904",
            transportFeeKes = 1000.0,
            dailyWageKes = 1650.0
        ),
        StaffAccount(
            id = "OPR-005",
            fullName = "George Tunya",
            email = "gtunya@jabimafuneral.co.ke",
            phone = "+254 744 501 005",
            role = StaffRole.OPERATOR,
            department = Department.OPERATORS,
            password = "password123",
            nationalId = "31002005",
            branch = "Bama Branch",
            isActive = true,
            avatarColor = 0xFF1E40AF,
            joinedDate = "15 Feb 2023",
            defaultMpesaNumber = "+254 744 501 005",
            defaultBankDetails = "NCBA Bank - Acc #882910905",
            transportFeeKes = 1000.0,
            dailyWageKes = 1650.0
        ),
        StaffAccount(
            id = "OPR-006",
            fullName = "Fredrick Osur",
            email = "fosur@jabimafuneral.co.ke",
            phone = "+254 744 501 006",
            role = StaffRole.OPERATOR,
            department = Department.OPERATORS,
            password = "password123",
            nationalId = "31002006",
            branch = "Bama Branch",
            isActive = true,
            avatarColor = 0xFF1D4ED8,
            joinedDate = "01 Mar 2023",
            defaultMpesaNumber = "+254 744 501 006",
            defaultBankDetails = "Standard Chartered - Acc #010293906"
        ),
        StaffAccount(
            id = "OPR-007",
            fullName = "David Omondi",
            email = "domondi.opr@jabimafuneral.co.ke",
            phone = "+254 744 501 007",
            role = StaffRole.OPERATOR,
            department = Department.OPERATORS,
            password = "password123",
            nationalId = "31002007",
            branch = "Bama Branch",
            isActive = true,
            avatarColor = 0xFF2563EB,
            joinedDate = "15 Mar 2023",
            defaultMpesaNumber = "+254 744 501 007",
            defaultBankDetails = "Equity Bank - Acc #140029907"
        ),
        StaffAccount(
            id = "OPR-008",
            fullName = "Zaddock Otieno",
            email = "zotieno@jabimafuneral.co.ke",
            phone = "+254 744 501 008",
            role = StaffRole.OPERATOR,
            department = Department.OPERATORS,
            password = "password123",
            nationalId = "31002008",
            branch = "Bama Branch",
            isActive = true,
            avatarColor = 0xFF3B82F6,
            joinedDate = "01 Apr 2023",
            defaultMpesaNumber = "+254 744 501 008",
            defaultBankDetails = "KCB Bank - Acc #129384908"
        ),
        StaffAccount(
            id = "OPR-009",
            fullName = "Victor Owino (Operator)",
            email = "vowino.opr@jabimafuneral.co.ke",
            phone = "+254 744 501 009",
            role = StaffRole.OPERATOR,
            department = Department.OPERATORS,
            password = "password123",
            nationalId = "31002009",
            branch = "Bama Branch",
            isActive = true,
            avatarColor = 0xFF60A5FA,
            joinedDate = "15 Apr 2023",
            defaultMpesaNumber = "+254 744 501 009",
            defaultBankDetails = "Cooperative Bank - Acc #011293909"
        ),
        StaffAccount(
            id = "OPR-010",
            fullName = "Francis Gwayi",
            email = "fgwayi@jabimafuneral.co.ke",
            phone = "+254 744 501 010",
            role = StaffRole.OPERATOR,
            department = Department.OPERATORS,
            password = "password123",
            nationalId = "31002010",
            branch = "Bama Branch",
            isActive = true,
            avatarColor = 0xFF1E40AF,
            joinedDate = "01 May 2023",
            defaultMpesaNumber = "+254 744 501 010",
            defaultBankDetails = "Equity Bank - Acc #140029910"
        ),
        StaffAccount(
            id = "OPR-011",
            fullName = "Collins Aimba",
            email = "caimba@jabimafuneral.co.ke",
            phone = "+254 744 501 011",
            role = StaffRole.OPERATOR,
            department = Department.OPERATORS,
            password = "password123",
            nationalId = "31002011",
            branch = "Bama Branch",
            isActive = true,
            avatarColor = 0xFF1D4ED8,
            joinedDate = "15 May 2023",
            defaultMpesaNumber = "+254 744 501 011",
            defaultBankDetails = "KCB Bank - Acc #129384911"
        ),
        StaffAccount(
            id = "OPR-012",
            fullName = "Collins Godia",
            email = "cgodia@jabimafuneral.co.ke",
            phone = "+254 744 501 012",
            role = StaffRole.OPERATOR,
            department = Department.OPERATORS,
            password = "password123",
            nationalId = "31002012",
            branch = "Bama Branch",
            isActive = true,
            avatarColor = 0xFF2563EB,
            joinedDate = "01 Jun 2023",
            defaultMpesaNumber = "+254 744 501 012",
            defaultBankDetails = "Absa Bank - Acc #449281912"
        ),
        StaffAccount(
            id = "OPR-013",
            fullName = "Alphonce",
            email = "alphonce@jabimafuneral.co.ke",
            phone = "+254 744 501 013",
            role = StaffRole.OPERATOR,
            department = Department.OPERATORS,
            password = "password123",
            nationalId = "31002013",
            branch = "Bama Branch",
            isActive = true,
            avatarColor = 0xFF3B82F6,
            joinedDate = "15 Jun 2023",
            defaultMpesaNumber = "+254 744 501 013",
            defaultBankDetails = "Cooperative Bank - Acc #011293913"
        ),
        StaffAccount(
            id = "OPR-014",
            fullName = "Felix Otieno",
            email = "fotieno@jabimafuneral.co.ke",
            phone = "+254 744 501 014",
            role = StaffRole.OPERATOR,
            department = Department.OPERATORS,
            password = "password123",
            nationalId = "31002014",
            branch = "Bama Branch",
            isActive = true,
            avatarColor = 0xFF60A5FA,
            joinedDate = "01 Jul 2023",
            defaultMpesaNumber = "+254 744 501 014",
            defaultBankDetails = "Standard Chartered - Acc #010293914"
        ),
        StaffAccount(
            id = "OPR-015",
            fullName = "Calistus Omondi",
            email = "comondi.opr@jabimafuneral.co.ke",
            phone = "+254 744 501 015",
            role = StaffRole.OPERATOR,
            department = Department.OPERATORS,
            password = "password123",
            nationalId = "31002015",
            branch = "Bama Branch",
            isActive = true,
            avatarColor = 0xFF1E40AF,
            joinedDate = "15 Jul 2023",
            defaultMpesaNumber = "+254 744 501 015",
            defaultBankDetails = "NCBA Bank - Acc #882910915"
        ),
        StaffAccount(
            id = "OPR-016",
            fullName = "Jorim Onyango",
            email = "jonyango@jabimafuneral.co.ke",
            phone = "+254 744 501 016",
            role = StaffRole.OPERATOR,
            department = Department.OPERATORS,
            password = "password123",
            nationalId = "31002016",
            branch = "Bama Branch",
            isActive = true,
            avatarColor = 0xFF1D4ED8,
            joinedDate = "01 Aug 2023",
            defaultMpesaNumber = "+254 744 501 016",
            defaultBankDetails = "Equity Bank - Acc #140029916"
        ),
        StaffAccount(
            id = "OPR-017",
            fullName = "Erick",
            email = "erick.opr@jabimafuneral.co.ke",
            phone = "+254 744 501 017",
            role = StaffRole.OPERATOR,
            department = Department.OPERATORS,
            password = "password123",
            nationalId = "31002017",
            branch = "Bama Branch",
            isActive = true,
            avatarColor = 0xFF2563EB,
            joinedDate = "15 Aug 2023",
            defaultMpesaNumber = "+254 744 501 017",
            defaultBankDetails = "KCB Bank - Acc #129384917"
        ),
        StaffAccount(
            id = "OPR-018",
            fullName = "Nelson Otieno",
            email = "notieno@jabimafuneral.co.ke",
            phone = "+254 744 501 018",
            role = StaffRole.OPERATOR,
            department = Department.OPERATORS,
            password = "password123",
            nationalId = "31002018",
            branch = "Bama Branch",
            isActive = true,
            avatarColor = 0xFF3B82F6,
            joinedDate = "01 Sep 2023",
            defaultMpesaNumber = "+254 744 501 018",
            defaultBankDetails = "Cooperative Bank - Acc #011293918"
        ),
        StaffAccount(
            id = "OPR-019",
            fullName = "Chrispine Oluoch",
            email = "coluoch@jabimafuneral.co.ke",
            phone = "+254 744 501 019",
            role = StaffRole.OPERATOR,
            department = Department.OPERATORS,
            password = "password123",
            nationalId = "31002019",
            branch = "Bama Branch",
            isActive = true,
            avatarColor = 0xFF60A5FA,
            joinedDate = "15 Sep 2023",
            defaultMpesaNumber = "+254 744 501 019",
            defaultBankDetails = "Absa Bank - Acc #449281919"
        ),

        // SALES AND MARKETING STAFF
        StaffAccount(
            id = "SLS-001",
            fullName = "Clara Mwamburi",
            email = "cmwamburi@jabimafuneral.co.ke",
            phone = "+254 733 401 001",
            role = StaffRole.SALES_MARKETING,
            department = Department.SALES_MARKETING,
            password = "password123",
            nationalId = "30192811",
            branch = "Siaya Referral (Opposite Morgue)",
            isActive = true,
            avatarColor = 0xFF0284C7,
            joinedDate = "10 Jan 2024",
            defaultMpesaNumber = "+254 733 401 001",
            defaultBankDetails = "Equity Bank - Acc #140029881"
        ),
        StaffAccount(
            id = "SLS-002",
            fullName = "Michael wasamba",
            email = "mwasamba@jabimafuneral.co.ke",
            phone = "+254 733 401 002",
            role = StaffRole.SALES_MARKETING,
            department = Department.SALES_MARKETING,
            password = "password123",
            nationalId = "30192812",
            branch = "Bondo",
            isActive = true,
            avatarColor = 0xFF0369A1,
            joinedDate = "01 Feb 2024",
            defaultMpesaNumber = "+254 733 401 002",
            defaultBankDetails = "KCB Bank - Acc #129384771"
        ),
        StaffAccount(
            id = "SLS-003",
            fullName = "Evans Ayako",
            email = "eayako@jabimafuneral.co.ke",
            phone = "+254 733 401 003",
            role = StaffRole.SALES_MARKETING,
            department = Department.SALES_MARKETING,
            password = "password123",
            nationalId = "30192813",
            branch = "Bama Branch",
            isActive = true,
            avatarColor = 0xFF0EA5E9,
            joinedDate = "15 Feb 2024",
            defaultMpesaNumber = "+254 733 401 003",
            defaultBankDetails = "Cooperative Bank - Acc #011293774"
        ),
        StaffAccount(
            id = "SLS-004",
            fullName = "Grace Achieng",
            email = "gachieng@jabimafuneral.co.ke",
            phone = "+254 733 401 004",
            role = StaffRole.SALES_MARKETING,
            department = Department.SALES_MARKETING,
            password = "password123",
            nationalId = "30192814",
            branch = "Matibabu",
            isActive = true,
            avatarColor = 0xFF38BDF8,
            joinedDate = "01 Mar 2024",
            defaultMpesaNumber = "+254 733 401 004",
            defaultBankDetails = "Absa Bank - Acc #44928188"
        ),
        StaffAccount(
            id = "SLS-005",
            fullName = "Caroline Omondi",
            email = "comondi@jabimafuneral.co.ke",
            phone = "+254 733 401 005",
            role = StaffRole.SALES_MARKETING,
            department = Department.SALES_MARKETING,
            password = "password123",
            nationalId = "30192815",
            branch = "Siaya opposite Shell Petrol",
            isActive = true,
            avatarColor = 0xFF1E293B,
            joinedDate = "15 Mar 2024",
            defaultMpesaNumber = "+254 733 401 005",
            defaultBankDetails = "Equity Bank - Acc #140029552"
        ),
        StaffAccount(
            id = "SLS-006",
            fullName = "Victor Owino (Sales)",
            email = "vowino.sales@jabimafuneral.co.ke",
            phone = "+254 733 401 006",
            role = StaffRole.SALES_MARKETING,
            department = Department.SALES_MARKETING,
            password = "password123",
            nationalId = "30192816",
            branch = "Ukwala",
            isActive = true,
            avatarColor = 0xFF334155,
            joinedDate = "01 Apr 2024",
            defaultMpesaNumber = "+254 733 401 006",
            defaultBankDetails = "KCB Bank - Acc #129384555"
        ),
        StaffAccount(
            id = "SLS-007",
            fullName = "Urslar Hayoyo",
            email = "uhayoyo@jabimafuneral.co.ke",
            phone = "+254 733 401 007",
            role = StaffRole.SALES_MARKETING,
            department = Department.SALES_MARKETING,
            password = "password123",
            nationalId = "30192817",
            branch = "Uradi",
            isActive = true,
            avatarColor = 0xFF475569,
            joinedDate = "15 Apr 2024",
            defaultMpesaNumber = "+254 733 401 007",
            defaultBankDetails = "Cooperative Bank - Acc #011293551"
        ),
        StaffAccount(
            id = "SLS-008",
            fullName = "Joseph Odongo",
            email = "jodongo@jabimafuneral.co.ke",
            phone = "+254 733 401 008",
            role = StaffRole.SALES_MARKETING,
            department = Department.SALES_MARKETING,
            password = "password123",
            nationalId = "30192818",
            branch = "Rangala",
            isActive = true,
            avatarColor = 0xFF0284C7,
            joinedDate = "01 May 2024",
            defaultMpesaNumber = "+254 733 401 008",
            defaultBankDetails = "NCBA Bank - Acc #88291077"
        ),
        StaffAccount(
            id = "SLS-009",
            fullName = "Morine Otieno",
            email = "motieno@jabimafuneral.co.ke",
            phone = "+254 733 401 009",
            role = StaffRole.SALES_MARKETING,
            department = Department.SALES_MARKETING,
            password = "password123",
            nationalId = "30192819",
            branch = "Siaya Referral (Opposite Morgue)",
            isActive = true,
            avatarColor = 0xFF0369A1,
            joinedDate = "15 May 2024",
            defaultMpesaNumber = "+254 733 401 009",
            defaultBankDetails = "Standard Chartered - Acc #010293998"
        )
    )

    private val initialActivities = listOf(
        // ==========================================
        // TODAY'S TASKS (23 Sep 2026) - LIVE & REAL-TIME
        // ==========================================

        // 🟢 IN_PROGRESS: Hearse Escort & Procession (Fleet Cortege)
        StaffActivity(
            id = "ACT-109",
            staffId = "DRV-001",
            staffName = "Victor Owino",
            department = Department.DRIVERS,
            category = ActivityCategory.FLEET_TRANSPORT,
            title = "VIP Lead Hearse Cortege Escort (Fleet KDG 705Y)",
            caseReference = "JFD-2026-084",
            clientFamily = "Family of the Late M. Ochieng",
            location = "Siaya Referral Care Center -> Bondo Central Church",
            date = "23 Sep 2026",
            time = "08:30 AM",
            durationMinutes = 120,
            status = ActivityStatus.IN_PROGRESS,
            notes = "Lead ceremonial escort with Mercedes Limousine KDG 705Y. Dignified cortege protocol active. Escort speed regulated at 40 km/h.",
            allowanceEarned = 5000.0,
            verifiedByAdmin = false,
            arrangementStage = FuneralArrangementStage.FLEET_CORTEGE,
            priority = TaskPriority.URGENT,
            assignedVehicle = "KDG 705Y (Mercedes Limousine Hearse)",
            assignedEquipment = "PA Sound Horns & Ceremonial Flags",
            checklistItems = listOf(
                "Hearse exterior washed & ceremonial bunting mounted",
                "Fuel tank 100% full & tire pressure inspected",
                "Cortege flags & PA sound horns tested",
                "Police speed escort & motorcade lead cleared",
                "Bier locks and hydraulic casket rollers lubricated"
            ),
            completedChecklistItems = listOf(
                "Hearse exterior washed & ceremonial bunting mounted",
                "Fuel tank 100% full & tire pressure inspected",
                "Cortege flags & PA sound horns tested"
            ),
            startedTimestamp = System.currentTimeMillis() - 45 * 60 * 1000L,
            elapsedMinutesLogged = 45
        ),

        // 🟢 IN_PROGRESS: Embalming & Dressing (Intake & Mortuary Care)
        StaffActivity(
            id = "ACT-125",
            staffId = "WRK-001",
            staffName = "Brian Adoche",
            department = Department.WORKSHOP,
            category = ActivityCategory.EMBALMING_PREPARATION,
            title = "Arterial Embalming & Cold Room Preservation Treatment",
            caseReference = "JFD-2026-095",
            clientFamily = "Omondi Family Care",
            location = "Siaya Referral Mortuary Wing (Unit #01)",
            date = "23 Sep 2026",
            time = "09:00 AM",
            durationMinutes = 150,
            status = ActivityStatus.IN_PROGRESS,
            notes = "Arterial chemical perfusion and cavity embalming for delayed 2-week repatriation. Body cosmetics and suit dressing in progress.",
            allowanceEarned = 5500.0,
            verifiedByAdmin = false,
            arrangementStage = FuneralArrangementStage.INTAKE_MORTUARY,
            priority = TaskPriority.HIGH,
            assignedEquipment = "Cold Room Unit #01 & Hydraulic Embalming Rig",
            checklistItems = listOf(
                "Next-of-kin identification tag cross-checked with hospital register",
                "Preservation chemical index calculated for long holding",
                "Cosmetic shading and formal dressing completed",
                "Cold room chamber temperature verified at 4°C",
                "Biohazard safety protocol & sanitization sign-off"
            ),
            completedChecklistItems = listOf(
                "Next-of-kin identification tag cross-checked with hospital register",
                "Preservation chemical index calculated for long holding",
                "Cosmetic shading and formal dressing completed"
            ),
            startedTimestamp = System.currentTimeMillis() - 60 * 60 * 1000L,
            elapsedMinutesLogged = 60
        ),

        // 🚑 IN_TRANSIT: 24/7 First Call Emergency Evacuation
        StaffActivity(
            id = "ACT-110",
            staffId = "DRV-002",
            staffName = "Joseph Ouma",
            department = Department.DRIVERS,
            category = ActivityCategory.FLEET_TRANSPORT,
            title = "24/7 First-Call Deceased Evacuation & Intake Transit",
            caseReference = "JFD-2026-096",
            clientFamily = "Akinyi Bereaved Family",
            location = "Bondo Sub-County Hospital -> Matibabu Mortuary",
            date = "23 Sep 2026",
            time = "09:45 AM",
            durationMinutes = 90,
            status = ActivityStatus.IN_TRANSIT,
            notes = "Rapid response van KCL 703C responding to first-call distress transfer. Sanitized stretcher and body pouch engaged.",
            allowanceEarned = 4500.0,
            verifiedByAdmin = false,
            arrangementStage = FuneralArrangementStage.INTAKE_MORTUARY,
            priority = TaskPriority.URGENT,
            assignedVehicle = "KCL 703C (Rapid First-Call Van)",
            assignedEquipment = "Heavy-Duty Sanitized Stretcher & Intake Tagging Kit",
            checklistItems = listOf(
                "Dispatch authorization verified with family spokesperson",
                "Sanitized evacuation body pouch & tag affixed",
                "Transit permit verified with hospital administration",
                "Intake temperature logged upon arrival at Matibabu care center"
            ),
            completedChecklistItems = listOf(
                "Dispatch authorization verified with family spokesperson",
                "Sanitized evacuation body pouch & tag affixed"
            ),
            startedTimestamp = System.currentTimeMillis() - 25 * 60 * 1000L,
            elapsedMinutesLogged = 25
        ),

        // ⏳ SCHEDULED: Gravesite Rigging & Lowering Gear Setup
        StaffActivity(
            id = "ACT-126",
            staffId = "DRV-003",
            staffName = "Fredrick Ochieng",
            department = Department.OPERATORS,
            category = ActivityCategory.GRAVESITE_SETUP,
            title = "Hydraulic Lowering Gear & VIP Red Carpet Rigging",
            caseReference = "JFD-2026-084",
            clientFamily = "Family of the Late M. Ochieng",
            location = "Bondo Family Homestead Gravesite",
            date = "23 Sep 2026",
            time = "11:30 AM",
            durationMinutes = 120,
            status = ActivityStatus.SCHEDULED,
            notes = "Lowering gear #LG-01 test descent required before family arrival. 16 chrome stanchions, red carpet and 100-seater canopy staging.",
            allowanceEarned = 4500.0,
            verifiedByAdmin = false,
            arrangementStage = FuneralArrangementStage.GRAVESITE_LOWERING,
            priority = TaskPriority.HIGH,
            assignedVehicle = "KBR 104R (Equipment Support Van)",
            assignedEquipment = "Hydraulic Lowering Gear #LG-01, 16 Stanchions & Red Carpet",
            checklistItems = listOf(
                "Grave depth verified at 7.0 ft with leveled bottom",
                "Hydraulic lowering straps tested with 250kg test load",
                "Synthetic grass mats placed around perimeter edge",
                "Red carpet runner pinned along VIP procession pathway",
                "Grave lowering remote release safety lock engaged"
            ),
            completedChecklistItems = emptyList()
        ),

        // ⏳ SCHEDULED: Chapel & Church Vigil Sound Setup
        StaffActivity(
            id = "ACT-127",
            staffId = "WRK-002",
            staffName = "George Munono",
            department = Department.OPERATORS,
            category = ActivityCategory.CHAPEL_SERVICE,
            title = "Church Vigil Service Sound, Bier Trolley & Hymn Staging",
            caseReference = "JFD-2026-084",
            clientFamily = "Family of the Late M. Ochieng",
            location = "ACK St. Peter's Cathedral, Bondo",
            date = "23 Sep 2026",
            time = "10:15 AM",
            durationMinutes = 90,
            status = ActivityStatus.SCHEDULED,
            notes = "Staging rolling bier trolley with rubber lock wheels. Deploying 4 wireless microphones and 200 color hymn leaflets.",
            allowanceEarned = 3500.0,
            verifiedByAdmin = false,
            arrangementStage = FuneralArrangementStage.CHAPEL_VIGIL,
            priority = TaskPriority.NORMAL,
            assignedEquipment = "Church Trolley Bier #02, 4 Wireless Mics & PA Speaker",
            checklistItems = listOf(
                "Church bier trolley placed at chancel with wheels locked",
                "Wireless microphones frequency tuned & battery voltage verified",
                "Condolence book pedestal and visitor pens staged at entrance",
                "Floral tribute stands positioned symmetrically by sanctuary"
            ),
            completedChecklistItems = emptyList()
        ),

        // ⏸️ ON_HOLD: Casket Velvet Lining & Engraved Brass Plate
        StaffActivity(
            id = "ACT-103",
            staffId = "WRK-003",
            staffName = "John Hayoyo",
            department = Department.WORKSHOP,
            category = ActivityCategory.CASKET_FITTING,
            title = "Imperial Solid Mahogany Casket Velvet Lining & Brass Plate",
            caseReference = "JFD-2026-092",
            clientFamily = "Wanyama Family Memorial",
            location = "Bama Central Workshop",
            date = "23 Sep 2026",
            time = "08:00 AM",
            durationMinutes = 120,
            status = ActivityStatus.ON_HOLD,
            notes = "On hold awaiting family confirmation of middle name spelling on laser-etched brass nameplate. Velvet quilted interior prepared.",
            allowanceEarned = 4000.0,
            verifiedByAdmin = false,
            arrangementStage = FuneralArrangementStage.CASKET_FLORALS,
            priority = TaskPriority.NORMAL,
            assignedEquipment = "Velvet Lining Stitcher & Brass Etching Machine",
            checklistItems = listOf(
                "Hand-rubbed lacquer coat cured and inspected",
                "Champagne diamond-tufted velvet lining installed",
                "Heavy-duty swing-bar handles mounted and load-tested",
                "Brass nameplate engraving approved by next-of-kin",
                "Final airtight rubber gasket seal affixed"
            ),
            completedChecklistItems = listOf(
                "Hand-rubbed lacquer coat cured and inspected",
                "Champagne diamond-tufted velvet lining installed",
                "Heavy-duty swing-bar handles mounted and load-tested"
            )
        ),

        // ✅ COMPLETED: Family Arrangement Consultation & Statutory Clearance
        StaffActivity(
            id = "ACT-115",
            staffId = "SLS-001",
            staffName = "Clara Mwamburi",
            department = Department.SALES_MARKETING,
            category = ActivityCategory.SALES_CONSULTATION,
            title = "Executive Dignity Arrangement Consultation & Statutory Permits",
            caseReference = "JFD-2026-084",
            clientFamily = "Family of the Late M. Ochieng",
            location = "Siaya Shell Consultation Suite",
            date = "23 Sep 2026",
            time = "07:00 AM",
            durationMinutes = 90,
            status = ActivityStatus.COMPLETED,
            notes = "Funeral arrangement contract executed. Burial permit Form D1 verified with Siaya County Registrar. Program sequence approved.",
            allowanceEarned = 4500.0,
            verifiedByAdmin = true,
            arrangementStage = FuneralArrangementStage.FAMILY_PLANNING,
            priority = TaskPriority.HIGH,
            checklistItems = listOf(
                "Statutory death certificate and burial permit Form D1 verified",
                "Casket selection, hearse allocation and florals confirmed",
                "Cortege itinerary and church order-of-service approved",
                "Lipa Pole Pole payment structure schedule executed"
            ),
            completedChecklistItems = listOf(
                "Statutory death certificate and burial permit Form D1 verified",
                "Casket selection, hearse allocation and florals confirmed",
                "Cortege itinerary and church order-of-service approved",
                "Lipa Pole Pole payment structure schedule executed"
            )
        ),

        // ==========================================
        // YESTERDAY'S TASKS (22 Sep 2026) - LOGGED & VERIFIED
        // ==========================================

        // CEO Strategic Duty
        StaffActivity(
            id = "ACT-101",
            staffId = "CEO-001",
            staffName = "Fredrick Hayoyo",
            department = Department.CEO,
            category = ActivityCategory.CASE_HANDLING,
            title = "Executive Strategy & 8-Branch Operations Review",
            caseReference = "JFD-2026-HQ01",
            clientFamily = "Jabima Board & Branch Network",
            location = "Siaya Referral (Opposite Morgue)",
            date = "22 Sep 2026",
            time = "08:30 AM",
            durationMinutes = 120,
            status = ActivityStatus.COMPLETED,
            notes = "Oversight review across Siaya Referral, Bondo, Matibabu, Bama, Ukwala, Uradi, Siaya Shell, and Rangala branches. Approved 24/7 emergency dispatch protocols.",
            allowanceEarned = 10000.0,
            verifiedByAdmin = true,
            arrangementStage = FuneralArrangementStage.FAMILY_PLANNING,
            priority = TaskPriority.NORMAL,
            checklistItems = listOf(
                "Inspect cold room refrigeration at Siaya Referral",
                "Verify fleet maintenance logs for 6 active hearses",
                "Audit Lipa Pole Pole M-PESA collections",
                "Sign off staff activity allowances for past week"
            ),
            completedChecklistItems = listOf(
                "Inspect cold room refrigeration at Siaya Referral",
                "Verify fleet maintenance logs for 6 active hearses",
                "Audit Lipa Pole Pole M-PESA collections",
                "Sign off staff activity allowances for past week"
            )
        ),

        // Workshop Mahogany Casket
        StaffActivity(
            id = "ACT-102",
            staffId = "WRK-001",
            staffName = "Brian Adoche",
            department = Department.WORKSHOP,
            category = ActivityCategory.WORKSHOP_PRODUCTION,
            title = "Imperial Solid Mahogany Casket Sanding & Mirror Glaze",
            caseReference = "JFD-2026-084",
            clientFamily = "Family of the Late M. Ochieng",
            location = "Bama Branch Workshop",
            date = "22 Sep 2026",
            time = "09:00 AM",
            durationMinutes = 180,
            status = ActivityStatus.COMPLETED,
            notes = "Applying 4-coat high gloss polyurethane finish on seasoned mahogany wood. Precision bevel edges verified.",
            allowanceEarned = 4500.0,
            verifiedByAdmin = true,
            arrangementStage = FuneralArrangementStage.CASKET_FLORALS,
            priority = TaskPriority.HIGH,
            assignedEquipment = "Airless Spray Gun & 4-Coat Polyurethane",
            checklistItems = listOf(
                "Wood moisture meter test below 10%",
                "8-corner mortise joinery reinforced with brass brackets",
                "4-coat lacquer sprayed and heat cured",
                "Mirror finish buffing and scratch inspection"
            ),
            completedChecklistItems = listOf(
                "Wood moisture meter test below 10%",
                "8-corner mortise joinery reinforced with brass brackets",
                "4-coat lacquer sprayed and heat cured",
                "Mirror finish buffing and scratch inspection"
            )
        ),

        // Post-Burial Repatriation & Debrief
        StaffActivity(
            id = "ACT-128",
            staffId = "DRV-004",
            staffName = "Fredrick Osuru",
            department = Department.DRIVERS,
            category = ActivityCategory.ADMIN_INVENTORY,
            title = "Post-Burial Repatriation, Gear Sanitization & Family Sign-Off",
            caseReference = "JFD-2026-083",
            clientFamily = "Wambua Family Memorial",
            location = "Rangala Mission -> Bama Headquarters Depot",
            date = "22 Sep 2026",
            time = "04:30 PM",
            durationMinutes = 100,
            status = ActivityStatus.VERIFIED_BY_ADMIN,
            notes = "Lowering gear #LG-02 sanitized and returned to depot inventory. 16 stanchions cleaned. Hearse KDH 172H post-trip mechanical check logged.",
            allowanceEarned = 4200.0,
            verifiedByAdmin = true,
            arrangementStage = FuneralArrangementStage.DEBRIEF_COMPLETION,
            priority = TaskPriority.NORMAL,
            assignedVehicle = "KDH 172H (Ceremonial Hearse)",
            assignedEquipment = "Hydraulic Lowering Gear #LG-02 & Red Carpet Stanchions",
            checklistItems = listOf(
                "Lowering gear straps inspected for wear and sanitized",
                "Brass stanchions wiped and stored in canvas carrier bags",
                "Red carpet rolled and dry cleaned",
                "Family representative sign-off on satisfactory arrangement",
                "Hearse post-trip fuel level and mileage recorded"
            ),
            completedChecklistItems = listOf(
                "Lowering gear straps inspected for wear and sanitized",
                "Brass stanchions wiped and stored in canvas carrier bags",
                "Red carpet rolled and dry cleaned",
                "Family representative sign-off on satisfactory arrangement",
                "Hearse post-trip fuel level and mileage recorded"
            )
        ),

        // Bamboo Casket Weaving
        StaffActivity(
            id = "ACT-105",
            staffId = "WRK-004",
            staffName = "Silas Hayoyo",
            department = Department.WORKSHOP,
            category = ActivityCategory.WORKSHOP_PRODUCTION,
            title = "Eco-Bio Bamboo Casket Weaving & Gasket Fitting",
            caseReference = "JFD-2026-087",
            clientFamily = "Kiprono Family",
            location = "Bama Branch Workshop",
            date = "22 Sep 2026",
            time = "01:30 PM",
            durationMinutes = 150,
            status = ActivityStatus.COMPLETED,
            notes = "Hand-woven organic biodegradable bamboo casket with natural cotton lining and airtight rubber sealant gasket.",
            allowanceEarned = 4000.0,
            verifiedByAdmin = true,
            arrangementStage = FuneralArrangementStage.CASKET_FLORALS,
            priority = TaskPriority.NORMAL,
            checklistItems = listOf(
                "Natural bamboo canes sorted and treated",
                "Organic unbleached cotton lining hand-sewn",
                "Biodegradable hemp rope carrying handles affixed",
                "Airtight silicone seal tested"
            ),
            completedChecklistItems = listOf(
                "Natural bamboo canes sorted and treated",
                "Organic unbleached cotton lining hand-sewn",
                "Biodegradable hemp rope carrying handles affixed",
                "Airtight silicone seal tested"
            )
        ),

        // Night Vigil Transit
        StaffActivity(
            id = "ACT-112",
            staffId = "DRV-004",
            staffName = "Fredrick Osuru",
            department = Department.DRIVERS,
            category = ActivityCategory.FLEET_TRANSPORT,
            title = "Night Vigil Transit & PA Sound (Fleet KDH 172H)",
            caseReference = "JFD-2026-085",
            clientFamily = "Odhiambo Family",
            location = "Siaya opposite Shell Petrol -> Uradi",
            date = "22 Sep 2026",
            time = "06:00 PM",
            durationMinutes = 120,
            status = ActivityStatus.COMPLETED,
            notes = "Hearse KDH 172H assigned with mobile floral refrigeration and battery-powered PA sound setup.",
            allowanceEarned = 4200.0,
            verifiedByAdmin = true,
            arrangementStage = FuneralArrangementStage.CHAPEL_VIGIL,
            priority = TaskPriority.NORMAL,
            assignedVehicle = "KDH 172H (Ceremonial Hearse)",
            assignedEquipment = "Battery-Powered PA Sound & Mobile Floral Cooler",
            checklistItems = listOf(
                "Battery pack for night sound system fully charged",
                "Floral refrigeration cooler operating at 6°C",
                "Night illumination spotlights tested",
                "Homestead arrival safety protocol observed"
            ),
            completedChecklistItems = listOf(
                "Battery pack for night sound system fully charged",
                "Floral refrigeration cooler operating at 6°C",
                "Night illumination spotlights tested",
                "Homestead arrival safety protocol observed"
            )
        )
    )

    private val initialTransactions = listOf(
        // CEO TRANSACTIONS
        WalletTransaction(
            id = "TXN-101",
            staffId = "CEO-001",
            type = TransactionType.SALARY_BASE,
            title = "Executive Retainer & Management Allowance - Sep 2026",
            referenceNumber = "JFD-CEO-9901",
            amount = 120000.0,
            date = "01 Sep 2026",
            status = PaymentStatus.DISBURSED,
            notes = "Monthly executive director compensation"
        ),
        WalletTransaction(
            id = "TXN-101B",
            staffId = "CEO-001",
            type = TransactionType.PERFORMANCE_INCENTIVE,
            title = "Q3 Operating Target Milestone Exceeded (+142%)",
            referenceNumber = "INC-101",
            amount = 25000.0,
            date = "22 Sep 2026",
            status = PaymentStatus.DISBURSED,
            notes = "Awarded by Board of Directors: Achieved 100% dispatch readiness across all 4 branches"
        ),
        WalletTransaction(
            id = "TXN-101C",
            staffId = "CEO-001",
            type = TransactionType.COMMISSION,
            title = "5% Casket Commission: Presidential Solid Mahogany",
            referenceNumber = "INC-102",
            amount = 11250.0,
            date = "23 Sep 2026",
            status = PaymentStatus.DISBURSED,
            notes = "5% authorized casket consultation commission for Okello family arrangement (JFD-2026-89)"
        ),
        WalletTransaction(
            id = "TXN-101D",
            staffId = "CEO-001",
            type = TransactionType.EXPENSE_REIMBURSEMENT,
            title = "Reimbursement: Hearse Long-Distance Fuel & Tolls",
            referenceNumber = "EXP-101",
            amount = 6500.0,
            date = "22 Sep 2026",
            status = PaymentStatus.DISBURSED,
            notes = "Reimbursed for receipt #TOTAL-SYA-4482 (JFD-2026-89). Authorized by Audit & Finance"
        ),
        WalletTransaction(
            id = "TXN-102",
            staffId = "CEO-001",
            type = TransactionType.ACTIVITY_ALLOWANCE,
            title = "Executive Strategy & 8-Branch Operations Review",
            referenceNumber = "ALW-ACT-101",
            amount = 10000.0,
            date = "22 Sep 2026",
            status = PaymentStatus.DISBURSED,
            notes = "Official directorial supervision across Siaya network"
        ),

        // WORKSHOP TRANSACTIONS
        WalletTransaction(
            id = "TXN-103",
            staffId = "WRK-001",
            type = TransactionType.SALARY_BASE,
            title = "Workshop Craftsman Base Salary - Sep 2026",
            referenceNumber = "JFD-WRK-01",
            amount = 55000.0,
            date = "01 Sep 2026",
            status = PaymentStatus.DISBURSED
        ),
        WalletTransaction(
            id = "TXN-104",
            staffId = "WRK-001",
            type = TransactionType.ACTIVITY_ALLOWANCE,
            title = "Mahogany Casket Glaze Finishing",
            referenceNumber = "ALW-WRK-01",
            amount = 4500.0,
            date = "22 Sep 2026",
            status = PaymentStatus.DISBURSED
        ),
        WalletTransaction(
            id = "TXN-105",
            staffId = "WRK-001",
            type = TransactionType.PAYOUT_WITHDRAWAL,
            title = "M-PESA Payout Disbursed",
            referenceNumber = "WDL-MPESA-101",
            amount = -20000.0,
            date = "15 Sep 2026",
            status = PaymentStatus.DISBURSED,
            payoutMethod = "M-PESA",
            payoutDestination = "+254 711 201 001"
        ),
        WalletTransaction(
            id = "TXN-106",
            staffId = "WRK-003",
            type = TransactionType.SALARY_BASE,
            title = "Workshop Craftsman Base Salary - Sep 2026",
            referenceNumber = "JFD-WRK-03",
            amount = 55000.0,
            date = "01 Sep 2026",
            status = PaymentStatus.DISBURSED
        ),
        WalletTransaction(
            id = "TXN-107",
            staffId = "WRK-003",
            type = TransactionType.ACTIVITY_ALLOWANCE,
            title = "Brass Swing-Bar Assembly (ACT-104)",
            referenceNumber = "ALW-ACT-104",
            amount = 4000.0,
            date = "21 Sep 2026",
            status = PaymentStatus.DISBURSED
        ),

        // DRIVER TRANSACTIONS
        WalletTransaction(
            id = "TXN-108",
            staffId = "DRV-001",
            type = TransactionType.SALARY_BASE,
            title = "Fleet Driver Base Retainer - Sep 2026",
            referenceNumber = "JFD-DRV-01",
            amount = 52000.0,
            date = "01 Sep 2026",
            status = PaymentStatus.DISBURSED
        ),
        WalletTransaction(
            id = "TXN-109",
            staffId = "DRV-001",
            type = TransactionType.ACTIVITY_ALLOWANCE,
            title = "Hearse Escort KDG 705Y Siaya Referral -> Bondo",
            referenceNumber = "ALW-DRV-01",
            amount = 5000.0,
            date = "22 Sep 2026",
            status = PaymentStatus.DISBURSED
        ),
        WalletTransaction(
            id = "TXN-110",
            staffId = "DRV-001",
            type = TransactionType.PAYOUT_WITHDRAWAL,
            title = "M-PESA Payout Request",
            referenceNumber = "WDL-REQ-DRV01",
            amount = -15000.0,
            date = "22 Sep 2026",
            status = PaymentStatus.PENDING_APPROVAL,
            payoutMethod = "M-PESA",
            payoutDestination = "+254 722 301 001"
        ),
        WalletTransaction(
            id = "TXN-111",
            staffId = "DRV-002",
            type = TransactionType.SALARY_BASE,
            title = "Fleet Driver Base Retainer - Sep 2026",
            referenceNumber = "JFD-DRV-02",
            amount = 52000.0,
            date = "01 Sep 2026",
            status = PaymentStatus.DISBURSED
        ),
        WalletTransaction(
            id = "TXN-112",
            staffId = "DRV-002",
            type = TransactionType.ACTIVITY_ALLOWANCE,
            title = "24/7 First Call Evacuation (KCL 703C)",
            referenceNumber = "ALW-ACT-110",
            amount = 4500.0,
            date = "21 Sep 2026",
            status = PaymentStatus.DISBURSED
        ),

        // SALES & MARKETING TRANSACTIONS
        WalletTransaction(
            id = "TXN-113",
            staffId = "SLS-001",
            type = TransactionType.SALARY_BASE,
            title = "Family Service Counselor Retainer - Sep 2026",
            referenceNumber = "JFD-SLS-01",
            amount = 60000.0,
            date = "01 Sep 2026",
            status = PaymentStatus.DISBURSED
        ),
        WalletTransaction(
            id = "TXN-114",
            staffId = "SLS-001",
            type = TransactionType.COMMISSION,
            title = "Executive Dignity Package Sales Commission (JFD-2026-084)",
            referenceNumber = "CMS-SLS-01",
            amount = 7500.0,
            date = "22 Sep 2026",
            status = PaymentStatus.DISBURSED
        ),
        WalletTransaction(
            id = "TXN-115",
            staffId = "SLS-001",
            type = TransactionType.ACTIVITY_ALLOWANCE,
            title = "Intake Consultation Allowance (ACT-115)",
            referenceNumber = "ALW-ACT-115",
            amount = 4000.0,
            date = "22 Sep 2026",
            status = PaymentStatus.DISBURSED
        ),
        WalletTransaction(
            id = "TXN-116",
            staffId = "SLS-001",
            type = TransactionType.PAYOUT_WITHDRAWAL,
            title = "M-PESA Payout Disbursed",
            referenceNumber = "WDL-MPESA-SLS01",
            amount = -25000.0,
            date = "18 Sep 2026",
            status = PaymentStatus.DISBURSED,
            payoutMethod = "M-PESA",
            payoutDestination = "+254 733 401 001"
        )
    )

    private val initialIncentives = listOf(
        PerformanceIncentive(
            id = "INC-101",
            staffId = "CEO-001",
            staffName = "Fredrick Hayoyo",
            department = Department.CEO,
            category = IncentiveCategory.TARGET_MILESTONE,
            title = "Q3 Operating Target Milestone Exceeded (+142%)",
            amount = 25000.0,
            date = "22 Sep 2026",
            caseReference = "CORP-Q3-SIY",
            awardedBy = "Board of Directors",
            rationale = "Achieved 100% dispatch readiness across all 4 branches and reduced mortuary turnaround time."
        ),
        PerformanceIncentive(
            id = "INC-102",
            staffId = "CEO-001",
            staffName = "Fredrick Hayoyo",
            department = Department.CEO,
            category = IncentiveCategory.CASKET_COMMISSION,
            title = "5% Casket Commission: Presidential Solid Mahogany",
            amount = 11250.0,
            date = "23 Sep 2026",
            caseReference = "JFD-2026-89",
            awardedBy = "Accounts Dept",
            rationale = "5% authorized casket consultation commission for Okello family arrangement."
        ),
        PerformanceIncentive(
            id = "INC-103",
            staffId = "DRV-001",
            staffName = "Victor Owino",
            department = Department.DRIVERS,
            category = IncentiveCategory.ON_TIME_CORTEGE,
            title = "Flawless Motorcade Escort Siaya to Kisumu",
            amount = 4500.0,
            date = "23 Sep 2026",
            caseReference = "JFD-2026-89",
            awardedBy = "Fredrick Hayoyo (CEO)",
            rationale = "Punctual 4-car hearse cortege navigation with zero delays and high protocol discipline."
        ),
        PerformanceIncentive(
            id = "INC-104",
            staffId = "OPR-001",
            staffName = "Peter Erkundi",
            department = Department.OPERATORS,
            category = IncentiveCategory.CASE_EXCELLENCE,
            title = "Zero-Defect Gravesite & Lowering Gear Setup",
            amount = 6000.0,
            date = "21 Sep 2026",
            caseReference = "JFD-2026-84",
            awardedBy = "Fredrick Hayoyo (CEO)",
            rationale = "Pristine hydraulic lowering gear staging and ceremonial red carpet layout lauded by the family."
        ),
        PerformanceIncentive(
            id = "INC-105",
            staffId = "SLS-004",
            staffName = "Grace Achieng",
            department = Department.SALES_MARKETING,
            category = IncentiveCategory.CASKET_COMMISSION,
            title = "5% Commission on Imperial Hardwood Casket",
            amount = 8500.0,
            date = "22 Sep 2026",
            caseReference = "JFD-2026-91",
            awardedBy = "Accounts Dept",
            rationale = "Casket selection client consultation closed successfully with pre-paid floral wreath."
        ),
        PerformanceIncentive(
            id = "INC-106",
            staffId = "DRV-003",
            staffName = "Fredrick Ochieng",
            department = Department.DRIVERS,
            category = IncentiveCategory.CLIENT_PRAISE,
            title = "Family Commendation for Compassionate Driving",
            amount = 3500.0,
            date = "20 Sep 2026",
            caseReference = "JFD-2026-78",
            awardedBy = "Family Spokesperson & CEO",
            rationale = "Family specifically lauded driver Fredrick for dignified, patient, and gentle funeral transport."
        ),
        PerformanceIncentive(
            id = "INC-107",
            staffId = "DRV-001",
            staffName = "Victor Owino",
            department = Department.DRIVERS,
            category = IncentiveCategory.AFTER_HOURS_READINESS,
            title = "24/7 Midnight Hospital Emergency Dispatch",
            amount = 5000.0,
            date = "19 Sep 2026",
            caseReference = "JFD-2026-72",
            awardedBy = "Fredrick Hayoyo (CEO)",
            rationale = "Responded within 18 minutes to Siaya County Referral emergency transfer call."
        ),
        PerformanceIncentive(
            id = "INC-108",
            staffId = "SLS-001",
            staffName = "Clara Mwamburi",
            department = Department.SALES_MARKETING,
            category = IncentiveCategory.CASKET_COMMISSION,
            title = "5% Commission: Executive Dignity Package (JFD-2026-084)",
            amount = 7500.0,
            date = "22 Sep 2026",
            caseReference = "JFD-2026-084",
            awardedBy = "Accounts Dept",
            rationale = "Full family funeral arrangement package and casket upgrade commission."
        )
    )

    private val initialExpenses = listOf(
        StaffExpenseClaim(
            id = "EXP-101",
            staffId = "CEO-001",
            staffName = "Fredrick Hayoyo",
            department = Department.CEO,
            category = ExpenseCategory.FUEL_TOLLS,
            title = "Hearse Long-Distance Fuel & Highway Tolls",
            amount = 6500.0,
            date = "22 Sep 2026",
            caseReference = "JFD-2026-89",
            receiptNumber = "TOTAL-SYA-4482",
            vehiclePlate = "KCD 882X",
            status = ExpenseStatus.APPROVED_REIMBURSED,
            notes = "Diesel refuel at Total Siaya for cortege escort to Kisumu",
            reimbursementMethod = "M-PESA (+254 700 111 001)",
            authorizedBy = "Audit & Finance"
        ),
        StaffExpenseClaim(
            id = "EXP-102",
            staffId = "CEO-001",
            staffName = "Fredrick Hayoyo",
            department = Department.CEO,
            category = ExpenseCategory.POLICE_ESCORT_FACILITATION,
            title = "Highway Traffic Escort Facilitation Receipt",
            amount = 3000.0,
            date = "23 Sep 2026",
            caseReference = "JFD-2026-89",
            receiptNumber = "NPS-POL-9921",
            vehiclePlate = "KCD 882X",
            status = ExpenseStatus.PENDING_APPROVAL,
            notes = "Traffic police outriders clearance facilitation along Siaya-Kisumu highway corridor",
            reimbursementMethod = "M-PESA (+254 700 111 001)"
        ),
        StaffExpenseClaim(
            id = "EXP-103",
            staffId = "DRV-001",
            staffName = "Peter Otieno",
            department = Department.DRIVERS,
            category = ExpenseCategory.FUEL_TOLLS,
            title = "Mercedes Limousine Fuel Refill (Shell Ahero)",
            amount = 5200.0,
            date = "21 Sep 2026",
            caseReference = "JFD-2026-88",
            receiptNumber = "SHL-AHR-1092",
            vehiclePlate = "KBQ 771P",
            status = ExpenseStatus.APPROVED_REIMBURSED,
            notes = "V-Power premium fuel for VIP funeral cortege",
            reimbursementMethod = "M-PESA (+254 722 301 001)",
            authorizedBy = "Fredrick Hayoyo (CEO)"
        ),
        StaffExpenseClaim(
            id = "EXP-104",
            staffId = "DRV-001",
            staffName = "Peter Otieno",
            department = Department.DRIVERS,
            category = ExpenseCategory.HEARSE_WASH_FLORALS,
            title = "Hearse Detailing, Disinfection & Fresh Ribbons",
            amount = 2200.0,
            date = "23 Sep 2026",
            caseReference = "JFD-2026-89",
            receiptNumber = "WSH-SYA-082",
            vehiclePlate = "KCD 882X",
            status = ExpenseStatus.PENDING_APPROVAL,
            notes = "Pre-service steam wash and fresh floral wreaths fastening",
            reimbursementMethod = "M-PESA (+254 722 301 001)"
        ),
        StaffExpenseClaim(
            id = "EXP-105",
            staffId = "OPR-001",
            staffName = "Dr. Mary Wambui",
            department = Department.OPERATORS,
            category = ExpenseCategory.EMBALMING_PPE_SUPPLIES,
            title = "N95 Respirators & Embalming Fluid Top-up",
            amount = 7800.0,
            date = "22 Sep 2026",
            caseReference = "JFD-2026-91",
            receiptNumber = "MED-KSM-3041",
            vehiclePlate = null,
            status = ExpenseStatus.APPROVED_REIMBURSED,
            notes = "Procured emergency surgical gloves and fluid supplies in Kisumu",
            reimbursementMethod = "Bank SCBLKENX",
            authorizedBy = "Fredrick Hayoyo (CEO)"
        ),
        StaffExpenseClaim(
            id = "EXP-106",
            staffId = "DRV-003",
            staffName = "Victor Owino",
            department = Department.DRIVERS,
            category = ExpenseCategory.CREW_MEALS_STIPEND,
            title = "Night Vigil Support Crew Dinner & Hot Tea",
            amount = 2400.0,
            date = "22 Sep 2026",
            caseReference = "JFD-2026-89",
            receiptNumber = "REST-BON-451",
            vehiclePlate = "KBR 104R",
            status = ExpenseStatus.PENDING_APPROVAL,
            notes = "Meals for 4 overnight tent and sound operators during church vigil",
            reimbursementMethod = "M-PESA (+254 722 301 003)"
        ),
        StaffExpenseClaim(
            id = "EXP-107",
            staffId = "WRK-001",
            staffName = "Brian Adoche",
            department = Department.WORKSHOP,
            category = ExpenseCategory.EMERGENCY_REPAIR,
            title = "Puncture Patch & Fan Belt Replacement",
            amount = 3800.0,
            date = "20 Sep 2026",
            caseReference = "JFD-2026-79",
            receiptNumber = "AUTO-NYG-772",
            vehiclePlate = "KBR 104R",
            status = ExpenseStatus.APPROVED_REIMBURSED,
            notes = "Emergency road-side repair near Luanda market to avoid cortege delay",
            reimbursementMethod = "M-PESA (+254 711 201 001)",
            authorizedBy = "Fredrick Hayoyo (CEO)"
        )
    )

    private fun buildSeededStaffTransactions(): List<WalletTransaction> {
        val base = initialTransactions.toMutableList()
        val existingIds = base.map { it.staffId }.toSet()
        var seq = 400
        initialAccounts.forEachIndexed { idx, acc ->
            val hasCommission = base.any { it.staffId == acc.id && it.type == TransactionType.COMMISSION }
            val hasServicePayout = base.any {
                it.staffId == acc.id && (
                    it.type == TransactionType.ACTIVITY_ALLOWANCE ||
                    it.type == TransactionType.OPERATOR_DAILY_WAGE ||
                    it.type == TransactionType.OVERTIME_BONUS
                )
            }
            if (!existingIds.contains(acc.id)) {
                val baseSalary = when (acc.department) {
                    Department.CEO -> 120000.0
                    Department.ADMINISTRATION -> 68000.0
                    Department.SALES_MARKETING -> 52000.0
                    Department.WORKSHOP -> 48000.0
                    Department.DRIVERS -> 46000.0
                    Department.OPERATORS -> 38000.0
                }
                base.add(
                    WalletTransaction(
                        id = "TXN-SEED-${seq++}",
                        staffId = acc.id,
                        type = TransactionType.SALARY_BASE,
                        title = "${acc.role.title} Monthly Retainer - Sep 2026",
                        referenceNumber = "JFD-${acc.id}-09",
                        amount = baseSalary,
                        date = "01 Sep 2026",
                        status = PaymentStatus.DISBURSED,
                        notes = "Verified monthly payroll retainer (${acc.branch})"
                    )
                )
            }
            if (!hasCommission) {
                val commAmount = when (acc.department) {
                    Department.SALES_MARKETING -> 7500.0 + (idx % 4) * 1500.0
                    Department.WORKSHOP -> 4200.0 + (idx % 3) * 800.0
                    Department.DRIVERS -> 3500.0 + (idx % 3) * 750.0
                    Department.OPERATORS -> 2500.0 + (idx % 3) * 500.0
                    Department.ADMINISTRATION -> 6500.0
                    Department.CEO -> 11250.0
                }
                val commTitle = when (acc.department) {
                    Department.SALES_MARKETING -> "5% Casket & Package Commission (${acc.branch})"
                    Department.WORKSHOP -> "Workshop Casket Completion Commission"
                    Department.DRIVERS -> "VIP Cortege Referral & Escort Commission"
                    Department.OPERATORS -> "Funeral Setup & Family Care Commission"
                    else -> "Branch Inventory & Casket Sales Commission"
                }
                base.add(
                    WalletTransaction(
                        id = "TXN-COM-${seq++}",
                        staffId = acc.id,
                        type = TransactionType.COMMISSION,
                        title = commTitle,
                        referenceNumber = "CMS-${acc.id}-84",
                        amount = commAmount,
                        date = "22 Sep 2026",
                        status = PaymentStatus.DISBURSED,
                        notes = "${acc.commissionRatePercent}% authorized funeral commission for ${acc.fullName}"
                    )
                )
            }
            if (!hasServicePayout) {
                val servicePay = when (acc.department) {
                    Department.DRIVERS -> 4800.0
                    Department.WORKSHOP -> 4500.0
                    Department.OPERATORS -> if (acc.dailyWageKes > 0) acc.dailyWageKes + acc.transportFeeKes else 3200.0
                    Department.SALES_MARKETING -> 3800.0
                    else -> 5500.0
                }
                val serviceTitle = when (acc.department) {
                    Department.DRIVERS -> "Funeral Hearse Cortege Service Payout"
                    Department.WORKSHOP -> "Casket Assembly & Dressing Service Payout"
                    Department.OPERATORS -> "Gravesite Lowering & Setup Service Payout"
                    Department.SALES_MARKETING -> "Family Burial Arrangement Service Payout"
                    else -> "Branch Operations & Dispatch Service Payout"
                }
                base.add(
                    WalletTransaction(
                        id = "TXN-SRV-${seq++}",
                        staffId = acc.id,
                        type = if (acc.department == Department.OPERATORS) TransactionType.OPERATOR_DAILY_WAGE else TransactionType.ACTIVITY_ALLOWANCE,
                        title = serviceTitle,
                        referenceNumber = "SRV-${acc.id}-91",
                        amount = servicePay,
                        date = "23 Sep 2026",
                        status = PaymentStatus.DISBURSED,
                        notes = "Funeral service payout credited to ${acc.fullName} (${acc.branch})"
                    )
                )
            }
        }
        return base
    }

    private fun normalizeInitialAccountHash(acc: StaffAccount): StaffAccount {
        if (acc.passwordHash.isNotBlank()) {
            return acc.copy(password = "")
        }
        val raw = acc.password.trim().ifEmpty { "password123" }
        val hash = PasswordSecurityHelper.hashPassword(
            rawPassword = raw,
            saltHex = PasswordSecurityHelper.deterministicSaltForStaff(acc.id)
        )
        return acc.copy(
            password = "",
            passwordHash = hash,
            mustRotatePassword = PasswordSecurityHelper.isDefaultOrWeakPassword(raw)
        )
    }

    private val _accounts = MutableStateFlow(initialAccounts.map { normalizeInitialAccountHash(it) })
    val accounts: StateFlow<List<StaffAccount>> = _accounts.asStateFlow()

    private val _activities = MutableStateFlow(initialActivities)
    val activities: StateFlow<List<StaffActivity>> = _activities.asStateFlow()

    private val _transactions = MutableStateFlow(buildSeededStaffTransactions())
    val transactions: StateFlow<List<WalletTransaction>> = _transactions.asStateFlow()

    private val _incentives = MutableStateFlow(initialIncentives)
    val incentives: StateFlow<List<PerformanceIncentive>> = _incentives.asStateFlow()

    private val _expenses = MutableStateFlow(initialExpenses)
    val expenses: StateFlow<List<StaffExpenseClaim>> = _expenses.asStateFlow()

    // Find account by email/staff ID and salted SHA-256 password hash verification
    fun authenticate(identifier: String, pass: String): StaffAccount? {
        val cleanId = identifier.trim()
        val cleanPass = pass.trim()
        if (cleanId.isEmpty() || cleanPass.isEmpty()) return null

        val ceoAlias = cleanId.equals("admin", ignoreCase = true) ||
            cleanId.equals("fhayoyo", ignoreCase = true) ||
            cleanId.equals("CEO-001", ignoreCase = true) ||
            cleanId.equals("admin@jabima.com", ignoreCase = true)

        val candidate = if (ceoAlias) {
            _accounts.value.firstOrNull { it.id == "CEO-001" } ?: _accounts.value.firstOrNull()
        } else {
            _accounts.value.firstOrNull { acc ->
                acc.id.equals(cleanId, ignoreCase = true) ||
                    acc.email.equals(cleanId, ignoreCase = true) ||
                    acc.fullName.equals(cleanId, ignoreCase = true) ||
                    acc.phone.equals(cleanId, ignoreCase = true)
            }
        } ?: return null

        return if (PasswordSecurityHelper.verifyPassword(cleanPass, candidate.passwordHash, candidate.password)) {
            candidate
        } else {
            null
        }
    }

    fun applyPersistedPasswordHashes(persistedHashes: Map<String, String>) {
        if (persistedHashes.isEmpty()) return
        _accounts.value = _accounts.value.map { acc ->
            val persisted = persistedHashes[acc.id]
            if (!persisted.isNullOrBlank()) {
                acc.copy(
                    password = "",
                    passwordHash = persisted,
                    mustRotatePassword = false
                )
            } else {
                acc
            }
        }
    }

    // Register a new staff member with their desired hashed password
    fun registerStaff(
        fullName: String,
        email: String,
        phone: String,
        role: StaffRole,
        desiredPassword: String,
        nationalId: String,
        branch: String,
        defaultMpesaNumber: String,
        department: Department = Department.SALES_MARKETING,
        assignedVehicle: String? = null
    ): StaffAccount {
        val prefix = when (department) {
            Department.CEO -> "CEO"
            Department.WORKSHOP -> "WRK"
            Department.DRIVERS -> "DRV"
            Department.OPERATORS -> "OPR"
            Department.SALES_MARKETING -> "SLS"
            Department.ADMINISTRATION -> "ADM"
        }
        val newId = "$prefix-" + (100 + _accounts.value.size + 1)
        val colors = listOf(0xFF0284C7, 0xFF0369A1, 0xFF0EA5E9, 0xFF38BDF8, 0xFF1E293B, 0xFF334155)
        val color = colors[(_accounts.value.size) % colors.size]
        val cleanPass = desiredPassword.trim()
        val saltedHash = PasswordSecurityHelper.hashPassword(cleanPass)

        val newAccount = StaffAccount(
            id = newId,
            fullName = fullName.trim(),
            email = email.trim().lowercase(),
            phone = phone.trim(),
            role = role,
            department = department,
            password = "",
            nationalId = nationalId.trim(),
            branch = branch.trim(),
            assignedVehicle = assignedVehicle,
            isActive = true,
            avatarColor = color,
            joinedDate = shortDateFormat.format(Date()),
            defaultMpesaNumber = defaultMpesaNumber.ifBlank { phone.trim() },
            defaultBankDetails = "Jabima Corporate Payroll",
            passwordHash = saltedHash,
            mustRotatePassword = PasswordSecurityHelper.isDefaultOrWeakPassword(cleanPass)
        )

        _accounts.value = _accounts.value + newAccount

        // Seed initial wallet welcome credit
        val welcomeTxn = WalletTransaction(
            id = "TXN-" + UUID.randomUUID().toString().take(6).uppercase(),
            staffId = newId,
            type = TransactionType.SALARY_BASE,
            title = "Account Setup & Starter Retainer",
            referenceNumber = "JFD-INIT-" + (1000..9999).random(),
            amount = 45000.0,
            date = shortDateFormat.format(Date()),
            status = PaymentStatus.DISBURSED,
            notes = "Initial onboarding payroll allocation"
        )
        _transactions.value = listOf(welcomeTxn) + _transactions.value

        return newAccount
    }

    // Update staff password with salted SHA-256 hash
    fun updatePassword(staffId: String, newPassword: String, forceRotateOnNextLogin: Boolean = false): Boolean {
        val clean = newPassword.trim()
        if (clean.isEmpty()) return false
        val newHash = PasswordSecurityHelper.hashPassword(clean)
        var updated = false
        _accounts.value = _accounts.value.map {
            if (it.id == staffId) {
                updated = true
                it.copy(
                    password = "",
                    passwordHash = newHash,
                    mustRotatePassword = forceRotateOnNextLogin
                )
            } else {
                it
            }
        }
        return updated
    }

    fun updateAccount(account: StaffAccount) {
        _accounts.value = _accounts.value.map {
            if (it.id == account.id) account else it
        }
    }

    // Update staff profile details
    fun updateStaffAccount(updatedStaff: StaffAccount) {
        _accounts.value = _accounts.value.map {
            if (it.id == updatedStaff.id) updatedStaff else it
        }
    }

    // Admin/CEO edits staff values and roles
    fun updateStaffDetailsAndRole(
        staffId: String,
        fullName: String,
        phone: String,
        email: String,
        role: StaffRole,
        department: Department,
        branch: String,
        nationalId: String,
        assignedVehicle: String?,
        defaultMpesa: String,
        defaultBank: String,
        isActive: Boolean = true,
        baseSalaryKes: Double? = null,
        allowanceKes: Double? = null,
        commissionRatePercent: Double? = null,
        notes: String? = null
    ): Boolean {
        var updated = false
        var previousAcc: StaffAccount? = null
        var updatedAcc: StaffAccount? = null
        _accounts.value = _accounts.value.map { acc ->
            if (acc.id == staffId) {
                updated = true
                previousAcc = acc
                val next = acc.copy(
                    fullName = fullName.trim(),
                    phone = phone.trim(),
                    email = email.trim().lowercase(),
                    role = role,
                    department = department,
                    branch = branch.trim(),
                    nationalId = nationalId.trim(),
                    assignedVehicle = assignedVehicle?.trim()?.ifBlank { null },
                    defaultMpesaNumber = defaultMpesa.trim(),
                    defaultBankDetails = defaultBank.trim(),
                    isActive = isActive,
                    baseSalaryKes = baseSalaryKes ?: acc.baseSalaryKes,
                    allowanceKes = allowanceKes ?: acc.allowanceKes,
                    commissionRatePercent = commissionRatePercent ?: acc.commissionRatePercent,
                    notes = notes?.trim() ?: acc.notes
                )
                updatedAcc = next
                next
            } else acc
        }
        if (updated && previousAcc != null && updatedAcc != null) {
            val prev = previousAcc!!
            val next = updatedAcc!!
            if (prev.role != next.role || prev.department != next.department || prev.branch != next.branch) {
                dispatchStaffAlert(
                    recipientStaffId = next.id,
                    recipientName = next.fullName,
                    title = "Role, Branch or Department Reassigned",
                    message = "Admin reassigned your profile to ${next.role.title} • ${next.department.displayName} @ ${next.branch}.",
                    category = "ROLE_REASSIGNED",
                    relatedEntityId = next.id
                )
            }
        }
        return updated
    }

    // Log a new activity for staff
    fun logActivity(
        staffId: String,
        category: ActivityCategory,
        title: String,
        caseReference: String,
        clientFamily: String,
        location: String,
        date: String,
        time: String,
        durationMinutes: Int,
        notes: String,
        allowanceEarned: Double
    ): StaffActivity {
        val staff = _accounts.value.firstOrNull { it.id == staffId }
        val newActivity = StaffActivity(
            id = "ACT-" + (200 + _activities.value.size + 1),
            staffId = staffId,
            staffName = staff?.fullName ?: "Staff Member",
            department = staff?.department ?: Department.WORKSHOP,
            category = category,
            title = title.trim(),
            caseReference = caseReference.trim(),
            clientFamily = clientFamily.trim(),
            location = location.trim(),
            date = date.trim(),
            time = time.trim(),
            durationMinutes = durationMinutes,
            status = ActivityStatus.IN_PROGRESS,
            notes = notes.trim(),
            allowanceEarned = allowanceEarned,
            verifiedByAdmin = false
        )

        _activities.value = listOf(newActivity) + _activities.value
        return newActivity
    }

    // Update real-time status of an activity
    fun updateActivityStatus(activityId: String, newStatus: ActivityStatus, completionNotes: String? = null) {
        var activityToReward: StaffActivity? = null
        val now = System.currentTimeMillis()

        _activities.value = _activities.value.map { act ->
            if (act.id == activityId) {
                val updated = act.copy(
                    status = newStatus,
                    notes = if (!completionNotes.isNullOrBlank()) "${act.notes} | Update: $completionNotes" else act.notes,
                    verifiedByAdmin = if (newStatus == ActivityStatus.VERIFIED_BY_ADMIN) true else act.verifiedByAdmin,
                    startedTimestamp = if (newStatus == ActivityStatus.IN_PROGRESS && act.startedTimestamp == null) now else act.startedTimestamp,
                    completedTimestamp = if (newStatus == ActivityStatus.COMPLETED || newStatus == ActivityStatus.VERIFIED_BY_ADMIN) now else act.completedTimestamp
                )
                if ((newStatus == ActivityStatus.COMPLETED || newStatus == ActivityStatus.VERIFIED_BY_ADMIN) &&
                    act.status != ActivityStatus.COMPLETED && act.status != ActivityStatus.VERIFIED_BY_ADMIN &&
                    act.allowanceEarned > 0
                ) {
                    activityToReward = updated
                }
                updated
            } else {
                act
            }
        }

        // If completed, automatically credit activity allowance to the staff's wallet!
        activityToReward?.let { act ->
            val allowanceTxn = WalletTransaction(
                id = "TXN-" + UUID.randomUUID().toString().take(6).uppercase(),
                staffId = act.staffId,
                type = TransactionType.ACTIVITY_ALLOWANCE,
                title = "Activity Allowance: ${act.title}",
                referenceNumber = "ALW-" + act.id,
                amount = act.allowanceEarned,
                date = shortDateFormat.format(Date()),
                status = PaymentStatus.DISBURSED,
                notes = "Auto-credited upon task completion (${act.caseReference})"
            )
            _transactions.value = listOf(allowanceTxn) + _transactions.value
        }
    }

    fun recordFuneralArrangementTask(activity: StaffActivity) {
        _activities.value = listOf(activity) + _activities.value
    }

    fun toggleActivityChecklistItem(activityId: String, item: String) {
        _activities.value = _activities.value.map { act ->
            if (act.id == activityId) {
                val current = act.completedChecklistItems.toMutableList()
                if (current.contains(item)) {
                    current.remove(item)
                } else {
                    current.add(item)
                }
                act.copy(completedChecklistItems = current)
            } else {
                act
            }
        }
    }

    // Request payout / withdrawal from wallet
    fun requestPayout(
        staffId: String,
        amount: Double,
        method: String,
        destination: String,
        notes: String
    ): WalletTransaction {
        val newTxn = WalletTransaction(
            id = "TXN-" + UUID.randomUUID().toString().take(6).uppercase(),
            staffId = staffId,
            type = TransactionType.PAYOUT_WITHDRAWAL,
            title = "$method Payout Request",
            referenceNumber = "WDL-" + (1000..9999).random(),
            amount = -amount,
            date = dateFormat.format(Date()),
            status = PaymentStatus.PENDING_APPROVAL,
            payoutMethod = method,
            payoutDestination = destination,
            notes = notes.ifBlank { "Staff requested payout" }
        )

        _transactions.value = listOf(newTxn) + _transactions.value
        return newTxn
    }

    // Admin approves payout
    fun adminApprovePayout(transactionId: String) {
        _transactions.value = _transactions.value.map {
            if (it.id == transactionId) {
                it.copy(
                    status = PaymentStatus.DISBURSED,
                    notes = "${it.notes} (Approved by Admin on ${shortDateFormat.format(Date())})"
                )
            } else {
                it
            }
        }
    }

    // Admin rejects payout
    fun adminRejectPayout(transactionId: String, reason: String) {
        _transactions.value = _transactions.value.map {
            if (it.id == transactionId) {
                it.copy(
                    status = PaymentStatus.REJECTED,
                    notes = "Rejected by Admin: $reason"
                )
            } else {
                it
            }
        }
    }

    // Admin credits staff wallet directly (Bonus, Overtime, Stipend)
    fun adminCreditStaffWallet(
        staffId: String,
        amount: Double,
        title: String,
        type: TransactionType,
        notes: String
    ): WalletTransaction {
        val newTxn = WalletTransaction(
            id = "TXN-" + UUID.randomUUID().toString().take(6).uppercase(),
            staffId = staffId,
            type = type,
            title = title,
            referenceNumber = "ADM-CR-" + (1000..9999).random(),
            amount = amount,
            date = dateFormat.format(Date()),
            status = PaymentStatus.DISBURSED,
            notes = notes.ifBlank { "Admin credited payment" }
        )

        _transactions.value = listOf(newTxn) + _transactions.value
        return newTxn
    }

    // Calculate wallet summary for a specific staff member via deterministic PayrollRulesEngine
    fun getWalletSummary(staffId: String): StaffWalletSummary {
        return PayrollRulesEngine.computeWalletSummary(
            staffId = staffId,
            transactions = _transactions.value,
            breakageRecords = _breakageRecords.value
        )
    }

    fun getAllWalletSummaries(): Map<String, StaffWalletSummary> {
        return _accounts.value.associate { acc ->
            acc.id to getWalletSummary(acc.id)
        }
    }

    // Award performance incentive to staff member
    fun awardPerformanceIncentive(
        staffId: String,
        category: IncentiveCategory,
        title: String,
        amount: Double,
        caseReference: String?,
        awardedBy: String,
        rationale: String
    ): PerformanceIncentive {
        val staff = _accounts.value.firstOrNull { it.id == staffId }
        val newIncentive = PerformanceIncentive(
            id = "INC-" + (100 + _incentives.value.size + 1),
            staffId = staffId,
            staffName = staff?.fullName ?: "Staff Member",
            department = staff?.department ?: Department.SALES_MARKETING,
            category = category,
            title = title.trim(),
            amount = amount,
            date = shortDateFormat.format(Date()),
            caseReference = caseReference?.trim()?.ifBlank { null },
            awardedBy = awardedBy.trim(),
            rationale = rationale.trim()
        )
        _incentives.value = listOf(newIncentive) + _incentives.value

        // Automatically credit into the staff member's wallet!
        val txn = WalletTransaction(
            id = "TXN-" + UUID.randomUUID().toString().take(6).uppercase(),
            staffId = staffId,
            type = if (category == IncentiveCategory.CASKET_COMMISSION) TransactionType.COMMISSION else TransactionType.PERFORMANCE_INCENTIVE,
            title = "Incentive: ${category.label} - $title",
            referenceNumber = "INC-" + newIncentive.id,
            amount = amount,
            date = shortDateFormat.format(Date()),
            status = PaymentStatus.DISBURSED,
            notes = "Awarded by $awardedBy: $rationale"
        )
        _transactions.value = listOf(txn) + _transactions.value
        return newIncentive
    }

    // Staff submits a field expense claim
    fun submitExpenseClaim(
        staffId: String,
        category: ExpenseCategory,
        title: String,
        amount: Double,
        date: String,
        caseReference: String,
        receiptNumber: String,
        vehiclePlate: String? = null,
        notes: String = "",
        reimbursementMethod: String = "M-PESA Payout"
    ): StaffExpenseClaim {
        val staff = _accounts.value.firstOrNull { it.id == staffId }
        val newClaim = StaffExpenseClaim(
            id = "EXP-" + (100 + _expenses.value.size + 1),
            staffId = staffId,
            staffName = staff?.fullName ?: "Staff Member",
            department = staff?.department ?: Department.DRIVERS,
            category = category,
            title = title.trim(),
            amount = amount,
            date = date.ifBlank { shortDateFormat.format(Date()) },
            caseReference = caseReference.trim(),
            receiptNumber = receiptNumber.trim(),
            vehiclePlate = vehiclePlate?.trim()?.ifBlank { null },
            status = ExpenseStatus.PENDING_APPROVAL,
            notes = notes.trim(),
            reimbursementMethod = reimbursementMethod
        )
        _expenses.value = listOf(newClaim) + _expenses.value
        return newClaim
    }

    // Admin / Accounts approves an expense claim and reimburses it to wallet
    fun approveExpenseClaim(claimId: String, authorizedBy: String) {
        var reimbursedClaim: StaffExpenseClaim? = null
        _expenses.value = _expenses.value.map { claim ->
            if (claim.id == claimId && claim.status == ExpenseStatus.PENDING_APPROVAL) {
                val updated = claim.copy(
                    status = ExpenseStatus.APPROVED_REIMBURSED,
                    authorizedBy = authorizedBy
                )
                reimbursedClaim = updated
                updated
            } else claim
        }

        // Auto-credit reimbursed funds directly into staff wallet
        reimbursedClaim?.let { claim ->
            val reimbTxn = WalletTransaction(
                id = "TXN-" + UUID.randomUUID().toString().take(6).uppercase(),
                staffId = claim.staffId,
                type = TransactionType.EXPENSE_REIMBURSEMENT,
                title = "Reimbursement: ${claim.category.label}",
                referenceNumber = "REIMB-" + claim.receiptNumber,
                amount = claim.amount,
                date = shortDateFormat.format(Date()),
                status = PaymentStatus.DISBURSED,
                notes = "Reimbursed for receipt #${claim.receiptNumber} (${claim.caseReference}). Authorized by $authorizedBy"
            )
            _transactions.value = listOf(reimbTxn) + _transactions.value
        }
    }

    // Admin / Accounts rejects an expense claim
    fun rejectExpenseClaim(claimId: String, reason: String) {
        _expenses.value = _expenses.value.map { claim ->
            if (claim.id == claimId) {
                claim.copy(
                    status = ExpenseStatus.REJECTED,
                    notes = if (claim.notes.isNotBlank()) "${claim.notes} | Rejected: $reason" else "Rejected: $reason"
                )
            } else claim
        }
    }

    // ==========================================
    // STOCK MOVEMENT SYSTEM (Inter-Branch Logistics)
    // Inventory Manager has sole authorization authority
    // ==========================================
    private val _stockMovements = MutableStateFlow<List<StockMovementRecord>>(
        listOf(
            StockMovementRecord(
                id = "SM-2026-081",
                itemName = "Imperial Hardwood Mahogany Casket",
                category = "Caskets & Coffins",
                quantity = 2,
                sourceBranch = "Siaya Referral (Opposite Morgue)",
                destinationBranch = "Bondo",
                requestedByStaffId = "SALES-004",
                requestedByStaffName = "Grace Achieng",
                assignedVehicle = "KBR 104R",
                assignedDriverName = "Victor Owino",
                requestDate = "23 Sep 2026, 08:30",
                urgency = "Urgent - Weekend Cortege",
                status = StockMovementStatus.PENDING_AUTHORIZATION,
                authorizedByManagerName = null,
                authorizationTimestamp = null,
                notes = "Client booked Saturday full VIP funeral service in Bondo town."
            ),
            StockMovementRecord(
                id = "SM-2026-080",
                itemName = "Executive Oak Glass-Dome Casket",
                category = "Caskets & Coffins",
                quantity = 1,
                sourceBranch = "Siaya Referral (Opposite Morgue)",
                destinationBranch = "Siaya opposite Shell Petrol",
                requestedByStaffId = "SALES-001",
                requestedByStaffName = "Clara Mwamburi",
                assignedVehicle = "KDG 705Y",
                assignedDriverName = "Fredrick Osuru",
                requestDate = "23 Sep 2026, 07:15",
                urgency = "Routine Restock",
                status = StockMovementStatus.AUTHORIZED,
                authorizedByManagerName = "Brian Adoche (Chief Inventory Manager)",
                authorizationTimestamp = "23 Sep 2026, 07:45",
                notes = "Showroom inventory replenishment for walk-in client viewings."
            ),
            StockMovementRecord(
                id = "SM-2026-079",
                itemName = "Brass Lowering Gear & Green Velvet Carpet",
                category = "Gravesite Equipment",
                quantity = 2,
                sourceBranch = "Siaya Referral (Opposite Morgue)",
                destinationBranch = "Ukwala",
                requestedByStaffId = "SALES-002",
                requestedByStaffName = "Michael Wasamba",
                assignedVehicle = "KCL 703C",
                assignedDriverName = "Joseph Ouma",
                requestDate = "23 Sep 2026, 06:00",
                urgency = "Urgent - Weekend Cortege",
                status = StockMovementStatus.IN_TRANSIT,
                authorizedByManagerName = "Brian Adoche (Chief Inventory Manager)",
                authorizationTimestamp = "23 Sep 2026, 06:20",
                notes = "Dispatched via KCL 703C towards Ukwala for gravesite prep."
            ),
            StockMovementRecord(
                id = "SM-2026-078",
                itemName = "Arterial Embalming Fluid & Sanitizers (Crates)",
                category = "Mortuary Supplies",
                quantity = 8,
                sourceBranch = "Siaya Referral (Opposite Morgue)",
                destinationBranch = "Matibabu",
                requestedByStaffId = "SALES-003",
                requestedByStaffName = "Evans Ayako",
                assignedVehicle = "KDY 211L",
                assignedDriverName = "Fredrick Okoth",
                requestDate = "22 Sep 2026, 14:00",
                urgency = "Routine Restock",
                status = StockMovementStatus.DELIVERED,
                authorizedByManagerName = "Brian Adoche (Chief Inventory Manager)",
                authorizationTimestamp = "22 Sep 2026, 14:30",
                notes = "Safely received at Matibabu cold-room supply depot."
            ),
            StockMovementRecord(
                id = "SM-2026-077",
                itemName = "Cedar Dignity Casket & Interior Lace Lining",
                category = "Caskets & Coffins",
                quantity = 3,
                sourceBranch = "Siaya Referral (Opposite Morgue)",
                destinationBranch = "Rangala",
                requestedByStaffId = "SALES-005",
                requestedByStaffName = "Caroline Omondi",
                assignedVehicle = "KCT 871D",
                assignedDriverName = "Fredrick Ochieng",
                requestDate = "23 Sep 2026, 09:10",
                urgency = "Routine Restock",
                status = StockMovementStatus.PENDING_AUTHORIZATION,
                authorizedByManagerName = null,
                authorizationTimestamp = null,
                notes = "Pending inventory manager approval before loading onto cortege vehicle."
            ),
            StockMovementRecord(
                id = "SM-2026-076",
                itemName = "Chapel Memorial Sound System & Brass Cross",
                category = "Chapel Supplies",
                quantity = 1,
                sourceBranch = "Bama Branch",
                destinationBranch = "Uradi",
                requestedByStaffId = "SALES-008",
                requestedByStaffName = "Joseph Odongo",
                assignedVehicle = "KBR 104R",
                assignedDriverName = "Fredrick Hayoyo",
                requestDate = "23 Sep 2026, 08:00",
                urgency = "Routine Restock",
                status = StockMovementStatus.AUTHORIZED,
                authorizedByManagerName = "Brian Adoche (Chief Inventory Manager)",
                authorizationTimestamp = "23 Sep 2026, 08:30",
                notes = "Authorized for upcoming evening vigil service at Uradi parish."
            )
        )
    )
    val stockMovements: StateFlow<List<StockMovementRecord>> = _stockMovements.asStateFlow()

    fun authorizeStockMovement(recordId: String, managerName: String, isAuthorizedManager: Boolean): Result<Unit> {
        if (!isAuthorizedManager) {
            return Result.failure(IllegalAccessException("Access Denied: An inventory manager has the sole authority of authorizing stock movements between branches."))
        }
        val currentList = _stockMovements.value.toMutableList()
        val index = currentList.indexOfFirst { it.id == recordId }
        if (index == -1) {
            return Result.failure(NoSuchElementException("Stock movement record not found."))
        }
        val current = currentList[index]
        val updated = current.copy(
            status = StockMovementStatus.AUTHORIZED,
            authorizedByManagerName = managerName,
            authorizationTimestamp = dateFormat.format(Date())
        )
        currentList[index] = updated
        _stockMovements.value = currentList
        return Result.success(Unit)
    }

    fun rejectStockMovement(recordId: String, managerName: String, isAuthorizedManager: Boolean): Result<Unit> {
        if (!isAuthorizedManager) {
            return Result.failure(IllegalAccessException("Access Denied: An inventory manager has the sole authority of authorizing stock movements."))
        }
        val currentList = _stockMovements.value.toMutableList()
        val index = currentList.indexOfFirst { it.id == recordId }
        if (index != -1) {
            val current = currentList[index]
            currentList[index] = current.copy(
                status = StockMovementStatus.REJECTED,
                authorizedByManagerName = managerName,
                authorizationTimestamp = dateFormat.format(Date()),
                notes = current.notes + " [Rejected by Inventory Manager]"
            )
            _stockMovements.value = currentList
        }
        return Result.success(Unit)
    }

    fun markStockInTransit(recordId: String) {
        val currentList = _stockMovements.value.toMutableList()
        val index = currentList.indexOfFirst { it.id == recordId }
        if (index != -1) {
            currentList[index] = currentList[index].copy(status = StockMovementStatus.IN_TRANSIT)
            _stockMovements.value = currentList
        }
    }

    fun markStockDelivered(recordId: String) {
        val currentList = _stockMovements.value.toMutableList()
        val index = currentList.indexOfFirst { it.id == recordId }
        if (index != -1) {
            currentList[index] = currentList[index].copy(status = StockMovementStatus.DELIVERED)
            _stockMovements.value = currentList
        }
    }

    fun requestStockMovement(
        itemName: String,
        category: String,
        quantity: Int,
        sourceBranch: String,
        destinationBranch: String,
        staffId: String,
        staffName: String,
        assignedVehicle: String,
        assignedDriverName: String,
        urgency: String,
        notes: String
    ): StockMovementRecord {
        val newRecord = StockMovementRecord(
            id = "SM-2026-${(100..999).random()}",
            itemName = itemName,
            category = category,
            quantity = quantity,
            sourceBranch = sourceBranch,
            destinationBranch = destinationBranch,
            requestedByStaffId = staffId,
            requestedByStaffName = staffName,
            assignedVehicle = assignedVehicle,
            assignedDriverName = assignedDriverName,
            requestDate = dateFormat.format(Date()),
            urgency = urgency,
            status = StockMovementStatus.PENDING_AUTHORIZATION,
            notes = notes
        )
        _stockMovements.value = listOf(newRecord) + _stockMovements.value
        return newRecord
    }

    // ==========================================
    // BRANCH STATUS & INFORMATION BOARDS
    // Captures current state of the business across all 8 branches
    // ==========================================
    private val _branchStatusBoards = MutableStateFlow<List<BranchStatusBoard>>(
        listOf(
            BranchStatusBoard(
                branchName = "Siaya Referral (Opposite Morgue)",
                operationalStatus = "Active 24/7 Operations",
                activeCasesCount = 14,
                coldRoomCapacity = 28,
                coldRoomOccupancy = 21,
                hearseFleetStationed = listOf("KDG 705Y", "KDH 172H"),
                hearseFleetInTransit = listOf("KCL 703C"),
                onDutyStaffCount = 7,
                todayCortegeDepartures = 3,
                pendingStockRequests = 2,
                contactPhone = "+254 793 553 434",
                leadSupervisor = "Fredrick Hayoyo (CEO / Funeral Director)",
                activeAdvisories = listOf(
                    "Major cortege dispatch at 11:30 AM via Busia-Siaya Highway.",
                    "Cold room unit 2 scheduled routine temp inspection at 4:00 PM."
                )
            ),
            BranchStatusBoard(
                branchName = "Siaya opposite Shell Petrol",
                operationalStatus = "Normal Showroom Operations",
                activeCasesCount = 8,
                coldRoomCapacity = 16,
                coldRoomOccupancy = 9,
                hearseFleetStationed = listOf("KDY 211L"),
                hearseFleetInTransit = emptyList(),
                onDutyStaffCount = 4,
                todayCortegeDepartures = 1,
                pendingStockRequests = 1,
                contactPhone = "+254 712 345 601",
                leadSupervisor = "Clara Mwamburi (Sales Lead)",
                activeAdvisories = listOf(
                    "Family consultation bookings scheduled until 2:30 PM.",
                    "Showroom casket display restock requested from central warehouse."
                )
            ),
            BranchStatusBoard(
                branchName = "Bama Branch",
                operationalStatus = "Active Operations",
                activeCasesCount = 6,
                coldRoomCapacity = 12,
                coldRoomOccupancy = 5,
                hearseFleetStationed = listOf("KCT 871D"),
                hearseFleetInTransit = emptyList(),
                onDutyStaffCount = 3,
                todayCortegeDepartures = 1,
                pendingStockRequests = 0,
                contactPhone = "+254 712 345 602",
                leadSupervisor = "Urslar Hayoyo (Family Counselor)",
                activeAdvisories = listOf(
                    "Vigil tent and lowering gear retrieval scheduled for 3:00 PM."
                )
            ),
            BranchStatusBoard(
                branchName = "Bondo",
                operationalStatus = "High Case Volume",
                activeCasesCount = 11,
                coldRoomCapacity = 20,
                coldRoomOccupancy = 17,
                hearseFleetStationed = listOf("KBR 104R"),
                hearseFleetInTransit = listOf("KDG 705Y"),
                onDutyStaffCount = 5,
                todayCortegeDepartures = 2,
                pendingStockRequests = 1,
                contactPhone = "+254 712 345 603",
                leadSupervisor = "Grace Achieng (Branch Supervisor)",
                activeAdvisories = listOf(
                    "Weekend VIP funeral booking for Saturday morning; casket in transit.",
                    "Overnight hearse return expected from Kisumu cortege."
                )
            ),
            BranchStatusBoard(
                branchName = "Matibabu",
                operationalStatus = "Normal Care Operations",
                activeCasesCount = 5,
                coldRoomCapacity = 10,
                coldRoomOccupancy = 4,
                hearseFleetStationed = emptyList(),
                hearseFleetInTransit = listOf("KDY 211L"),
                onDutyStaffCount = 3,
                todayCortegeDepartures = 0,
                pendingStockRequests = 0,
                contactPhone = "+254 712 345 604",
                leadSupervisor = "Evans Ayako (Senior Counselor)",
                activeAdvisories = listOf(
                    "Mortuary chemicals batch verified and logged into statutory registers."
                )
            ),
            BranchStatusBoard(
                branchName = "Ukwala",
                operationalStatus = "Cortege Dispatched",
                activeCasesCount = 7,
                coldRoomCapacity = 12,
                coldRoomOccupancy = 6,
                hearseFleetStationed = listOf("KCL 703C"),
                hearseFleetInTransit = emptyList(),
                onDutyStaffCount = 3,
                todayCortegeDepartures = 1,
                pendingStockRequests = 1,
                contactPhone = "+254 712 345 605",
                leadSupervisor = "Michael Wasamba (Operations Officer)",
                activeAdvisories = listOf(
                    "Gravesite lowering gear setup ongoing at Ukwala parish grounds."
                )
            ),
            BranchStatusBoard(
                branchName = "Uradi",
                operationalStatus = "Normal Operations",
                activeCasesCount = 4,
                coldRoomCapacity = 8,
                coldRoomOccupancy = 3,
                hearseFleetStationed = emptyList(),
                hearseFleetInTransit = emptyList(),
                onDutyStaffCount = 2,
                todayCortegeDepartures = 0,
                pendingStockRequests = 0,
                contactPhone = "+254 712 345 606",
                leadSupervisor = "Joseph Odongo (Family Counselor)",
                activeAdvisories = listOf(
                    "Chapel open for private prayer vigil until 8:00 PM."
                )
            ),
            BranchStatusBoard(
                branchName = "Rangala",
                operationalStatus = "Active Service Operations",
                activeCasesCount = 6,
                coldRoomCapacity = 12,
                coldRoomOccupancy = 7,
                hearseFleetStationed = emptyList(),
                hearseFleetInTransit = listOf("KCT 871D"),
                onDutyStaffCount = 3,
                todayCortegeDepartures = 1,
                pendingStockRequests = 1,
                contactPhone = "+254 712 345 607",
                leadSupervisor = "Caroline Omondi (Liaison Counselor)",
                activeAdvisories = listOf(
                    "Casket restock transfer requested from Siaya Main Workshop depot."
                )
            )
        )
    )
    val branchStatusBoards: StateFlow<List<BranchStatusBoard>> = _branchStatusBoards.asStateFlow()

    // ==========================================
    // VENDOR MANAGEMENT (Transactions Submitted & Received)
    // ==========================================
    private val _vendors = MutableStateFlow<List<VendorProfile>>(
        listOf(
            VendorProfile(
                id = "V-01",
                vendorName = "Kakamega Timber & Hardwood Sawmills Ltd",
                category = "Hardwood Timber & Seasoned Mahogany",
                contactPerson = "David Wanyama",
                phoneNumber = "+254 722 890 120",
                paymentTerms = "Net 14 Days",
                bankOrMpesaDetails = "KCB Bank Kakamega Ac: 110928374",
                totalPaidSubmitted = 420000.0,
                totalReceivedRebates = 15000.0,
                pendingBalanceDue = 65000.0
            ),
            VendorProfile(
                id = "V-02",
                vendorName = "Mombasa Brass Metalcraft & Casket Fittings",
                category = "Brass Handles, Crosses & Casket Metalware",
                contactPerson = "Farah Omar",
                phoneNumber = "+254 733 445 566",
                paymentTerms = "50% Advance / 50% Delivery",
                bankOrMpesaDetails = "Equity Bank Mombasa Ac: 045129883",
                totalPaidSubmitted = 280000.0,
                totalReceivedRebates = 0.0,
                pendingBalanceDue = 45000.0
            ),
            VendorProfile(
                id = "V-03",
                vendorName = "Kisumu Textile Millers Ltd (Satin & Velvet)",
                category = "Satin, Velvet & Interior Lining Fabrics",
                contactPerson = "Pritesh Patel",
                phoneNumber = "+254 720 112 233",
                paymentTerms = "Immediate M-PESA B2B",
                bankOrMpesaDetails = "M-PESA Paybill: 882910 Ac: JABIMA",
                totalPaidSubmitted = 195000.0,
                totalReceivedRebates = 8000.0,
                pendingBalanceDue = 0.0
            ),
            VendorProfile(
                id = "V-04",
                vendorName = "PharmaCare Kenya Mortuary Supplies Ltd",
                category = "Preservation Chemicals, PPE & Body Bags",
                contactPerson = "Dr. Angela Mutua",
                phoneNumber = "+254 721 990 011",
                paymentTerms = "Net 30 Days",
                bankOrMpesaDetails = "Co-op Bank Nairobi Ac: 0112938475",
                totalPaidSubmitted = 340000.0,
                totalReceivedRebates = 0.0,
                pendingBalanceDue = 82000.0
            ),
            VendorProfile(
                id = "V-05",
                vendorName = "Shell Siaya Fuel Station (Fleet Partner)",
                category = "Hearse Diesel, Engine Lubricants & Wash",
                contactPerson = "Kennedy Onyango",
                phoneNumber = "+254 793 112 244",
                paymentTerms = "Weekly Commercial Fleet Account",
                bankOrMpesaDetails = "M-PESA Till: 772819",
                totalPaidSubmitted = 215000.0,
                totalReceivedRebates = 12500.0,
                pendingBalanceDue = 28000.0
            ),
            VendorProfile(
                id = "V-06",
                vendorName = "Naivasha Sympathy Blooms & Floral Farms",
                category = "Fresh Casket Sprays & Memorial Wreaths",
                contactPerson = "Wanjiku Njoroge",
                phoneNumber = "+254 724 667 788",
                paymentTerms = "Payment on Delivery",
                bankOrMpesaDetails = "M-PESA Paybill: 522522 Ac: BLOOMS",
                totalPaidSubmitted = 98000.0,
                totalReceivedRebates = 4500.0,
                pendingBalanceDue = 0.0
            ),
            VendorProfile(
                id = "V-07",
                vendorName = "Siaya County Police Traffic Escort Liaison",
                category = "VIP Highway Cortege Siren & Siren Escorts",
                contactPerson = "Inspector John Ochieng",
                phoneNumber = "+254 722 000 119",
                paymentTerms = "Per Escort Mission",
                bankOrMpesaDetails = "National Bank Siaya Ac: 01029384",
                totalPaidSubmitted = 75000.0,
                totalReceivedRebates = 0.0,
                pendingBalanceDue = 15000.0
            )
        )
    )
    val vendors: StateFlow<List<VendorProfile>> = _vendors.asStateFlow()

    private val _vendorTransactions = MutableStateFlow<List<VendorTransaction>>(
        listOf(
            VendorTransaction(
                id = "VTX-101",
                vendorId = "V-01",
                vendorName = "Kakamega Timber & Hardwood Sawmills Ltd",
                transactionType = VendorTransactionType.PAYMENT_SUBMITTED,
                amount = 65000.0,
                description = "Quarterly seasoned mahogany planks delivery for casket workshop crafting",
                invoiceNumber = "INV-KT-8841",
                date = "20 Sep 2026",
                paymentMethod = "KCB Bank RTGS",
                mpesaOrBankRef = "RTGS-99381029",
                authorizedBy = "Fredrick Hayoyo (CEO)",
                status = "Completed"
            ),
            VendorTransaction(
                id = "VTX-102",
                vendorId = "V-05",
                vendorName = "Shell Siaya Fuel Station (Fleet Partner)",
                transactionType = VendorTransactionType.PAYMENT_SUBMITTED,
                amount = 38500.0,
                description = "Weekly fleet diesel refueling for hearses (KDG 705Y, KBR 104R, KCL 703C)",
                invoiceNumber = "INV-SH-4421",
                date = "21 Sep 2026",
                paymentMethod = "M-PESA B2B Paybill",
                mpesaOrBankRef = "MP-SI-773821",
                authorizedBy = "Victor Owino (Fleet Lead)",
                status = "Completed"
            ),
            VendorTransaction(
                id = "VTX-103",
                vendorId = "V-05",
                vendorName = "Shell Siaya Fuel Station (Fleet Partner)",
                transactionType = VendorTransactionType.PAYMENT_RECEIVED,
                amount = 12500.0,
                description = "Commercial fleet loyalty cashback & volume diesel rebate Q3",
                invoiceNumber = "REB-SH-093",
                date = "22 Sep 2026",
                paymentMethod = "M-PESA Direct Credit",
                mpesaOrBankRef = "MP-RB-00291",
                authorizedBy = "Fredrick Hayoyo (CEO)",
                status = "Completed"
            ),
            VendorTransaction(
                id = "VTX-104",
                vendorId = "V-04",
                vendorName = "PharmaCare Kenya Mortuary Supplies Ltd",
                transactionType = VendorTransactionType.PAYMENT_SUBMITTED,
                amount = 45000.0,
                description = "Arterial chemical fluid restock batch #99 and heavy duty body bags",
                invoiceNumber = "INV-PC-104",
                date = "22 Sep 2026",
                paymentMethod = "Co-op Bank Wire",
                mpesaOrBankRef = "CB-TR-55410",
                authorizedBy = "Fredrick Hayoyo (CEO)",
                status = "Completed"
            ),
            VendorTransaction(
                id = "VTX-105",
                vendorId = "V-03",
                vendorName = "Kisumu Textile Millers Ltd (Satin & Velvet)",
                transactionType = VendorTransactionType.PAYMENT_RECEIVED,
                amount = 8000.0,
                description = "Bulk order volume rebate on premium casket interior white satin fabrics",
                invoiceNumber = "REB-KT-011",
                date = "23 Sep 2026",
                paymentMethod = "M-PESA B2B Inflow",
                mpesaOrBankRef = "MP-IN-88301",
                authorizedBy = "Brian Adoche (Chief Inventory Manager)",
                status = "Completed"
            ),
            VendorTransaction(
                id = "VTX-106",
                vendorId = "V-06",
                vendorName = "Naivasha Sympathy Blooms & Floral Farms",
                transactionType = VendorTransactionType.PAYMENT_SUBMITTED,
                amount = 18000.0,
                description = "Fresh white lily casket wreath sprays and floral pedestals for Saturday cortege",
                invoiceNumber = "INV-NB-722",
                date = "23 Sep 2026",
                paymentMethod = "M-PESA Paybill",
                mpesaOrBankRef = "MP-FL-33921",
                authorizedBy = "Grace Achieng (Sales Lead)",
                status = "Completed"
            )
        )
    )
    val vendorTransactions: StateFlow<List<VendorTransaction>> = _vendorTransactions.asStateFlow()

    fun recordVendorTransaction(
        vendorId: String,
        transactionType: VendorTransactionType,
        amount: Double,
        description: String,
        invoiceNumber: String,
        paymentMethod: String,
        mpesaOrBankRef: String,
        authorizedBy: String
    ): VendorTransaction {
        val vendor = _vendors.value.firstOrNull { it.id == vendorId }
        val vendorName = vendor?.vendorName ?: "Authorized Vendor"
        val newTxn = VendorTransaction(
            id = "VTX-${(200..999).random()}",
            vendorId = vendorId,
            vendorName = vendorName,
            transactionType = transactionType,
            amount = amount,
            description = description,
            invoiceNumber = invoiceNumber.ifBlank { "INV-${System.currentTimeMillis() % 10000}" },
            date = shortDateFormat.format(Date()),
            paymentMethod = paymentMethod,
            mpesaOrBankRef = mpesaOrBankRef.ifBlank { "REF-${System.currentTimeMillis() % 100000}" },
            authorizedBy = authorizedBy,
            status = "Completed"
        )
        _vendorTransactions.value = listOf(newTxn) + _vendorTransactions.value

        // Update vendor balance totals
        val currentVendors = _vendors.value.toMutableList()
        val vIndex = currentVendors.indexOfFirst { it.id == vendorId }
        if (vIndex != -1) {
            val v = currentVendors[vIndex]
            if (transactionType == VendorTransactionType.PAYMENT_SUBMITTED) {
                currentVendors[vIndex] = v.copy(
                    totalPaidSubmitted = v.totalPaidSubmitted + amount,
                    pendingBalanceDue = (v.pendingBalanceDue - amount).coerceAtLeast(0.0)
                )
            } else {
                currentVendors[vIndex] = v.copy(
                    totalReceivedRebates = v.totalReceivedRebates + amount
                )
            }
            _vendors.value = currentVendors
        }

        return newTxn
    }

    // ==========================================
    // VISUAL CALENDAR VIEW & STAFF ROSTER OVERSIGHT
    // Displays shifts and availability across all funeral home branches
    // ==========================================
    // VISUAL CALENDAR & STAFF ROSTER SHIFTS (ACTIVE, UPCOMING, PAST)
    // ==========================================
    private val _staffShiftSchedules = MutableStateFlow<List<StaffShiftSchedule>>(
        listOf(
            // --- 🟢 ACTIVE SHIFTS (HAPPENING TODAY / CURRENTLY DEPLOYED) ---
            StaffShiftSchedule(
                id = "SH-ACT-001",
                staffId = "CEO-001",
                staffName = "Fredrick Hayoyo",
                department = Department.CEO,
                assignedBranch = "Siaya Referral (Opposite Morgue)",
                shiftType = "Executive Oversight (08:00 - 18:00)",
                dayOfWeek = "Wednesday",
                dateFormatted = "23 Sep 2026",
                availabilityStatus = "On-Duty Active",
                hearseAssigned = "KCT 871D",
                shiftPeriod = ShiftPeriod.ACTIVE,
                startTime = "08:00",
                endTime = "18:00",
                equipmentAssigned = "Command Tablet & Central Dispatch Key",
                destination = "All Branch Centers Oversight",
                supervisorName = "Fredrick Hayoyo (CEO)",
                hoursLogged = 6.5,
                checkInStatus = "On-Site Active",
                notes = "Overall leadership & cortege protocol supervision across Siaya branches."
            ),
            StaffShiftSchedule(
                id = "SH-ACT-002",
                staffId = "DRV-001",
                staffName = "Victor Owino",
                department = Department.DRIVERS,
                assignedBranch = "Siaya Referral (Opposite Morgue)",
                shiftType = "Morning Cortege Escort (06:00 - 14:00)",
                dayOfWeek = "Wednesday",
                dateFormatted = "23 Sep 2026",
                availabilityStatus = "In Cortege Transit",
                hearseAssigned = "KBR 104R",
                shiftPeriod = ShiftPeriod.ACTIVE,
                startTime = "06:00",
                endTime = "14:00",
                equipmentAssigned = "VIP Church Trolley Bier #02 & Cortege Flags",
                caseReference = "CASE-2026-0891",
                familyName = "Late Mzee Omondi Family",
                destination = "Siaya Referral -> Bondo Central Cemetery",
                supervisorName = "Fredrick Hayoyo (CEO)",
                hoursLogged = 5.0,
                checkInStatus = "En Route (Speed 45 km/h)",
                notes = "Long-distance highway cortege dispatch towards Bondo. Motorcade procession lead."
            ),
            StaffShiftSchedule(
                id = "SH-ACT-003",
                staffId = "DRV-002",
                staffName = "Joseph Ouma",
                department = Department.DRIVERS,
                assignedBranch = "Ukwala",
                shiftType = "Morning Cortege Escort (06:00 - 14:00)",
                dayOfWeek = "Wednesday",
                dateFormatted = "23 Sep 2026",
                availabilityStatus = "In Cortege Transit",
                hearseAssigned = "KCL 703C",
                shiftPeriod = ShiftPeriod.ACTIVE,
                startTime = "06:00",
                endTime = "14:00",
                equipmentAssigned = "Lowering Gear #LG-02 & Church Bier",
                caseReference = "CASE-2026-0894",
                familyName = "Late Mama Anyango Family",
                destination = "Ukwala Mission Hospital -> Family Homestead",
                supervisorName = "Fredrick Hayoyo (CEO)",
                hoursLogged = 4.5,
                checkInStatus = "En Route",
                notes = "Lowering gear and cortege transfer to Ukwala. Escort speed maintained."
            ),
            StaffShiftSchedule(
                id = "SH-ACT-004",
                staffId = "DRV-004",
                staffName = "Fredrick Osuru",
                department = Department.DRIVERS,
                assignedBranch = "Siaya opposite Shell Petrol",
                shiftType = "Morning Standby (06:00 - 14:00)",
                dayOfWeek = "Wednesday",
                dateFormatted = "23 Sep 2026",
                availabilityStatus = "On-Duty Active",
                hearseAssigned = "KDG 705Y",
                shiftPeriod = ShiftPeriod.ACTIVE,
                startTime = "06:00",
                endTime = "14:00",
                equipmentAssigned = "VIP Mercedes Hearse Equipment Set",
                destination = "Siaya Shell Base Standby",
                supervisorName = "Fredrick Hayoyo (CEO)",
                hoursLogged = 5.5,
                checkInStatus = "Stationed at Base",
                notes = "VIP Mercedes Hearse standby ready for afternoon executive cortege."
            ),
            StaffShiftSchedule(
                id = "SH-ACT-005",
                staffId = "OPR-001",
                staffName = "Kevin Odhiambo",
                department = Department.OPERATORS,
                assignedBranch = "Bondo",
                shiftType = "Gravesite Setup (07:00 - 15:00)",
                dayOfWeek = "Wednesday",
                dateFormatted = "23 Sep 2026",
                availabilityStatus = "On-Duty Active",
                shiftPeriod = ShiftPeriod.ACTIVE,
                startTime = "07:00",
                endTime = "15:00",
                equipmentAssigned = "Lowering Gear #LG-01, Red Carpet & 12 Brass Stunchions",
                caseReference = "CASE-2026-0891",
                familyName = "Late Mzee Omondi Family",
                destination = "Bondo Central Cemetery Grave Plot #14",
                supervisorName = "Fredrick Hayoyo (CEO)",
                hoursLogged = 4.0,
                checkInStatus = "Gravesite Rigging Complete",
                notes = "Gravesite lowering gear, church trolleys, red carpets & stunchions setup in progress."
            ),
            StaffShiftSchedule(
                id = "SH-ACT-006",
                staffId = "WS-001",
                staffName = "Brian Adoche",
                department = Department.WORKSHOP,
                assignedBranch = "Bama Branch",
                shiftType = "Morning Crafting (06:00 - 14:00)",
                dayOfWeek = "Wednesday",
                dateFormatted = "23 Sep 2026",
                availabilityStatus = "On-Duty Active",
                shiftPeriod = ShiftPeriod.ACTIVE,
                startTime = "06:00",
                endTime = "14:00",
                equipmentAssigned = "Mahogany Dome Carving Station #01",
                destination = "Bama Central Workshop",
                supervisorName = "Fredrick Hayoyo (CEO)",
                hoursLogged = 5.5,
                checkInStatus = "At Workbench",
                notes = "Chief Inventory Manager - Inter-branch stock movement verification & dome casket fabrication."
            ),
            StaffShiftSchedule(
                id = "SH-ACT-007",
                staffId = "WS-002",
                staffName = "George Munono",
                department = Department.WORKSHOP,
                assignedBranch = "Bama Branch",
                shiftType = "Morning Crafting (06:00 - 14:00)",
                dayOfWeek = "Wednesday",
                dateFormatted = "23 Sep 2026",
                availabilityStatus = "On-Duty Active",
                shiftPeriod = ShiftPeriod.ACTIVE,
                startTime = "06:00",
                endTime = "14:00",
                equipmentAssigned = "Heavy Duty Router & Brass Fitting Jig",
                destination = "Bama Central Workshop",
                supervisorName = "Fredrick Hayoyo (CEO)",
                hoursLogged = 5.5,
                checkInStatus = "At Workbench",
                notes = "Hardwood mahogany jointing & dome carving for President Royal Oak batch."
            ),
            StaffShiftSchedule(
                id = "SH-ACT-008",
                staffId = "SALES-001",
                staffName = "Clara Mwamburi",
                department = Department.SALES_MARKETING,
                assignedBranch = "Siaya opposite Shell Petrol",
                shiftType = "Full Day Counseling (08:00 - 17:00)",
                dayOfWeek = "Wednesday",
                dateFormatted = "23 Sep 2026",
                availabilityStatus = "On-Duty Active",
                shiftPeriod = ShiftPeriod.ACTIVE,
                startTime = "08:00",
                endTime = "17:00",
                destination = "Siaya Shell Consultation Suite",
                supervisorName = "Fredrick Hayoyo (CEO)",
                hoursLogged = 3.5,
                checkInStatus = "In Family Consultation",
                notes = "Family consultations & POS sales intake for upcoming weekend burials."
            ),
            StaffShiftSchedule(
                id = "SH-ACT-009",
                staffId = "DRV-005",
                staffName = "Fredrick Okoth",
                department = Department.DRIVERS,
                assignedBranch = "Matibabu",
                shiftType = "24/7 Night Vigil On-Call",
                dayOfWeek = "Wednesday",
                dateFormatted = "23 Sep 2026",
                availabilityStatus = "On-Call Emergency",
                hearseAssigned = "KDY 211L",
                shiftPeriod = ShiftPeriod.ACTIVE,
                startTime = "00:00",
                endTime = "23:59",
                equipmentAssigned = "Deceased Evacuation Stretcher & Sanitized Protective Kit",
                destination = "Matibabu Morgue Transfer Standby",
                supervisorName = "Fredrick Hayoyo (CEO)",
                hoursLogged = 7.0,
                checkInStatus = "Standby Ready (<10 min callout)",
                notes = "24/7 Deceased removal & evacuation on-call driver. Connected via 3CX Ext 105."
            ),

            // --- 🔵 UPCOMING SHIFTS (SCHEDULED FOR TONIGHT, TOMORROW & THIS WEEK) ---
            StaffShiftSchedule(
                id = "SH-UPC-001",
                staffId = "WS-003",
                staffName = "John Hayoyo",
                department = Department.WORKSHOP,
                assignedBranch = "Bama Branch",
                shiftType = "Evening Shift (14:00 - 22:00)",
                dayOfWeek = "Wednesday",
                dateFormatted = "23 Sep 2026",
                availabilityStatus = "Scheduled Upcoming",
                shiftPeriod = ShiftPeriod.UPCOMING,
                startTime = "14:00",
                endTime = "22:00",
                equipmentAssigned = "Velvet Pleating & Satin Stitching Station",
                destination = "Bama Casket Workshop",
                supervisorName = "Fredrick Hayoyo (CEO)",
                hoursLogged = 0.0,
                checkInStatus = "Scheduled (Starts in 2h 30m)",
                notes = "Interior velvet and satin tailoring for Presidential Tier custom casket."
            ),
            StaffShiftSchedule(
                id = "SH-UPC-002",
                staffId = "WS-004",
                staffName = "Silas Hayoyo",
                department = Department.WORKSHOP,
                assignedBranch = "Bondo",
                shiftType = "Evening Shift (14:00 - 22:00)",
                dayOfWeek = "Wednesday",
                dateFormatted = "23 Sep 2026",
                availabilityStatus = "Scheduled Upcoming",
                shiftPeriod = ShiftPeriod.UPCOMING,
                startTime = "14:00",
                endTime = "22:00",
                equipmentAssigned = "High-Pressure Lacquer Spray Booth",
                destination = "Bondo Finishing Workshop",
                supervisorName = "Fredrick Hayoyo (CEO)",
                hoursLogged = 0.0,
                checkInStatus = "Scheduled",
                notes = "High-gloss lacquer spray and 48hr heat curing for 3 mahogany caskets."
            ),
            StaffShiftSchedule(
                id = "SH-UPC-003",
                staffId = "DRV-003",
                staffName = "Fredrick Ochieng",
                department = Department.DRIVERS,
                assignedBranch = "Rangala",
                shiftType = "Evening Vigil Cortege (14:00 - 22:00)",
                dayOfWeek = "Wednesday",
                dateFormatted = "23 Sep 2026",
                availabilityStatus = "Scheduled Upcoming",
                hearseAssigned = "KCT 871D",
                shiftPeriod = ShiftPeriod.UPCOMING,
                startTime = "14:00",
                endTime = "22:00",
                equipmentAssigned = "Church Trolley Bier #03 & Red Carpet Roll",
                caseReference = "CASE-2026-0902",
                familyName = "Late Elder Otieno Family",
                destination = "Rangala Parish Church & Night Vigil",
                supervisorName = "Fredrick Hayoyo (CEO)",
                hoursLogged = 0.0,
                checkInStatus = "Scheduled",
                notes = "Standby hearse ready for afternoon church service & evening vigil transfer."
            ),
            StaffShiftSchedule(
                id = "SH-UPC-004",
                staffId = "WS-005",
                staffName = "Richard Opiyo",
                department = Department.WORKSHOP,
                assignedBranch = "Siaya Referral (Opposite Morgue)",
                shiftType = "24/7 Night Vigil On-Call",
                dayOfWeek = "Wednesday",
                dateFormatted = "23 Sep 2026",
                availabilityStatus = "Scheduled Upcoming",
                shiftPeriod = ShiftPeriod.UPCOMING,
                startTime = "22:00",
                endTime = "06:00",
                destination = "Siaya Referral Standby",
                supervisorName = "Fredrick Hayoyo (CEO)",
                hoursLogged = 0.0,
                checkInStatus = "Scheduled",
                notes = "Emergency overnight casket assembly & brass fittings on call."
            ),
            StaffShiftSchedule(
                id = "SH-UPC-005",
                staffId = "DRV-001",
                staffName = "Victor Owino",
                department = Department.DRIVERS,
                assignedBranch = "Bama Branch",
                shiftType = "Dawn Cortege Escort (06:00 - 14:00)",
                dayOfWeek = "Thursday",
                dateFormatted = "24 Sep 2026",
                availabilityStatus = "Scheduled Upcoming",
                hearseAssigned = "KDG 705Y",
                shiftPeriod = ShiftPeriod.UPCOMING,
                startTime = "06:00",
                endTime = "14:00",
                equipmentAssigned = "VIP Executive Hearse Equipment & PA Horns",
                caseReference = "CASE-2026-0910",
                familyName = "Late Mwalimu Okello Family",
                destination = "Bama Base -> Siaya Cathedral -> Uradi Cemetery",
                supervisorName = "Fredrick Hayoyo (CEO)",
                hoursLogged = 0.0,
                checkInStatus = "Scheduled Tomorrow",
                notes = "VIP Mercedes Hearse departure scheduled 06:30 AM sharp. Church Mass at 10:00 AM."
            ),
            StaffShiftSchedule(
                id = "SH-UPC-006",
                staffId = "OPR-002",
                staffName = "Daniel Wagweru",
                department = Department.OPERATORS,
                assignedBranch = "Ukwala",
                shiftType = "Morning Gravesite Setup (06:00 - 14:00)",
                dayOfWeek = "Thursday",
                dateFormatted = "24 Sep 2026",
                availabilityStatus = "Scheduled Upcoming",
                shiftPeriod = ShiftPeriod.UPCOMING,
                startTime = "06:00",
                endTime = "14:00",
                equipmentAssigned = "Lowering Gear #LG-03, Brass Stunchions & Green Artificial Turf",
                caseReference = "CASE-2026-0914",
                familyName = "Late Mama Rose Family",
                destination = "Ukwala Parish Cemetery",
                supervisorName = "Fredrick Hayoyo (CEO)",
                hoursLogged = 0.0,
                checkInStatus = "Scheduled Tomorrow",
                notes = "Complete gravesite canopy, lowering straps, and green artificial turf setup."
            ),
            StaffShiftSchedule(
                id = "SH-UPC-007",
                staffId = "SALES-002",
                staffName = "Michael Wasamba",
                department = Department.SALES_MARKETING,
                assignedBranch = "Ukwala",
                shiftType = "Family Intake & Care (08:00 - 17:00)",
                dayOfWeek = "Thursday",
                dateFormatted = "24 Sep 2026",
                availabilityStatus = "Scheduled Upcoming",
                shiftPeriod = ShiftPeriod.UPCOMING,
                startTime = "08:00",
                endTime = "17:00",
                destination = "Ukwala Branch Family Care Room",
                supervisorName = "Fredrick Hayoyo (CEO)",
                hoursLogged = 0.0,
                checkInStatus = "Scheduled Tomorrow",
                notes = "Ukwala parish family grief counseling & order contract signing."
            ),
            StaffShiftSchedule(
                id = "SH-UPC-008",
                staffId = "SALES-004",
                staffName = "Grace Achieng",
                department = Department.SALES_MARKETING,
                assignedBranch = "Bondo",
                shiftType = "Weekend Burial Planning (08:00 - 17:00)",
                dayOfWeek = "Friday",
                dateFormatted = "25 Sep 2026",
                availabilityStatus = "Scheduled Upcoming",
                shiftPeriod = ShiftPeriod.UPCOMING,
                startTime = "08:00",
                endTime = "17:00",
                destination = "Bondo Branch Office",
                supervisorName = "Fredrick Hayoyo (CEO)",
                hoursLogged = 0.0,
                checkInStatus = "Scheduled Friday",
                notes = "Bondo branch lead - Finalizing 5 Saturday burial cortege departure schedules."
            ),

            // --- ⚪ PAST SHIFTS (COMPLETED & VERIFIED WITH LOGGED HOURS) ---
            StaffShiftSchedule(
                id = "SH-PST-001",
                staffId = "DRV-001",
                staffName = "Victor Owino",
                department = Department.DRIVERS,
                assignedBranch = "Bondo",
                shiftType = "Full Day Cortege Escort (06:00 - 15:30)",
                dayOfWeek = "Tuesday",
                dateFormatted = "22 Sep 2026",
                availabilityStatus = "Shift Completed",
                hearseAssigned = "KBR 104R",
                shiftPeriod = ShiftPeriod.PAST,
                startTime = "06:00",
                endTime = "15:30",
                equipmentAssigned = "VIP Church Trolley Bier #02",
                caseReference = "CASE-2026-0885",
                familyName = "Late Mzee Odhiambo Family",
                destination = "Siaya Referral -> Bondo Family Homestead",
                supervisorName = "Fredrick Hayoyo (CEO)",
                hoursLogged = 9.5,
                checkInStatus = "Completed & Signed-Off",
                notes = "Completed dignified cortege escort. Vehicle washed, refueled and parked at Bama Base.",
                completionNotes = "Arrived on schedule at 09:30 AM. Gravesite lowering completed at 14:15. Driver allowance logged."
            ),
            StaffShiftSchedule(
                id = "SH-PST-002",
                staffId = "WS-001",
                staffName = "Brian Adoche",
                department = Department.WORKSHOP,
                assignedBranch = "Bama Branch",
                shiftType = "Morning Crafting Shift (06:00 - 14:30)",
                dayOfWeek = "Tuesday",
                dateFormatted = "22 Sep 2026",
                availabilityStatus = "Shift Completed",
                shiftPeriod = ShiftPeriod.PAST,
                startTime = "06:00",
                endTime = "14:30",
                equipmentAssigned = "Dome Carving Station #01",
                destination = "Bama Workshop",
                supervisorName = "Fredrick Hayoyo (CEO)",
                hoursLogged = 8.5,
                checkInStatus = "Completed & Signed-Off",
                notes = "Fabricated 2 Grand Cedar caskets with satin lining. Quality inspection verified.",
                completionNotes = "Both caskets cleared QA with zero defects. Transferred to Bama Showroom stock."
            ),
            StaffShiftSchedule(
                id = "SH-PST-003",
                staffId = "OPR-001",
                staffName = "Kevin Odhiambo",
                department = Department.OPERATORS,
                assignedBranch = "Ukwala",
                shiftType = "Gravesite Setup & Rigging (07:00 - 15:00)",
                dayOfWeek = "Tuesday",
                dateFormatted = "22 Sep 2026",
                availabilityStatus = "Shift Completed",
                shiftPeriod = ShiftPeriod.PAST,
                startTime = "07:00",
                endTime = "15:00",
                equipmentAssigned = "Lowering Gear #LG-02, Red Carpets & 16 Brass Stunchions",
                caseReference = "CASE-2026-0888",
                familyName = "Late Daktari Ochieng Family",
                destination = "Ukwala Parish Cemetery",
                supervisorName = "Fredrick Hayoyo (CEO)",
                hoursLogged = 8.0,
                checkInStatus = "Completed & Signed-Off",
                notes = "Gravesite lowering gear operation successful. All gear sanitized and returned to Bama Base.",
                completionNotes = "Lowering mechanism operated smoothly in presence of family. Stunchions returned intact."
            ),
            StaffShiftSchedule(
                id = "SH-PST-004",
                staffId = "DRV-005",
                staffName = "Fredrick Okoth",
                department = Department.DRIVERS,
                assignedBranch = "Matibabu",
                shiftType = "Emergency Midnight Recovery (23:00 - 04:00)",
                dayOfWeek = "Monday",
                dateFormatted = "21 Sep 2026",
                availabilityStatus = "Shift Completed",
                hearseAssigned = "KDY 211L",
                shiftPeriod = ShiftPeriod.PAST,
                startTime = "23:00",
                endTime = "04:00",
                equipmentAssigned = "Deceased Evacuation Stretcher & Cold Storage Bag",
                caseReference = "CASE-2026-0882",
                familyName = "Emergency Hospital Referral",
                destination = "Matibabu Morgue -> Siaya Referral Preservation Cold Room",
                supervisorName = "Fredrick Hayoyo (CEO)",
                hoursLogged = 5.0,
                checkInStatus = "Overtime Verified",
                notes = "Emergency midnight evacuation from Matibabu morgue to Siaya Referral cold room. 5.0 hrs overtime approved.",
                completionNotes = "Handled with utmost dignity. Body tagging verified with hospital pathologist."
            ),
            StaffShiftSchedule(
                id = "SH-PST-005",
                staffId = "SALES-001",
                staffName = "Clara Mwamburi",
                department = Department.SALES_MARKETING,
                assignedBranch = "Siaya opposite Shell Petrol",
                shiftType = "Full Day Intake & POS (08:00 - 17:30)",
                dayOfWeek = "Monday",
                dateFormatted = "21 Sep 2026",
                availabilityStatus = "Shift Completed",
                shiftPeriod = ShiftPeriod.PAST,
                startTime = "08:00",
                endTime = "17:30",
                destination = "Siaya Shell Consultation Suite",
                supervisorName = "Fredrick Hayoyo (CEO)",
                hoursLogged = 9.5,
                checkInStatus = "Completed & Signed-Off",
                notes = "Completed 4 family consultation intakes, finalized 2 casket orders with 5% commission logged.",
                completionNotes = "KES 340,000 total order value booked. Family feedback rated 5-star."
            ),
            StaffShiftSchedule(
                id = "SH-PST-006",
                staffId = "DRV-003",
                staffName = "Fredrick Ochieng",
                department = Department.DRIVERS,
                assignedBranch = "Rangala",
                shiftType = "Memorial Church Service (09:00 - 17:00)",
                dayOfWeek = "Sunday",
                dateFormatted = "20 Sep 2026",
                availabilityStatus = "Shift Completed",
                hearseAssigned = "KCT 871D",
                shiftPeriod = ShiftPeriod.PAST,
                startTime = "09:00",
                endTime = "17:00",
                equipmentAssigned = "Church Trolley Bier #01",
                caseReference = "CASE-2026-0879",
                familyName = "Late Canon Joshua Family",
                destination = "Rangala Mission Church & Cemetery",
                supervisorName = "Fredrick Hayoyo (CEO)",
                hoursLogged = 8.0,
                checkInStatus = "Completed & Signed-Off",
                notes = "Memorial service cortege completed in Rangala. Vehicle inspection passed.",
                completionNotes = "Full church service and cemetery interment conducted with zero delays."
            )
        )
    )
    val staffShiftSchedules: StateFlow<List<StaffShiftSchedule>> = _staffShiftSchedules.asStateFlow()

    fun updateShiftSchedule(shift: StaffShiftSchedule) {
        val currentList = _staffShiftSchedules.value.toMutableList()
        val index = currentList.indexOfFirst { it.id == shift.id }
        if (index != -1) {
            currentList[index] = shift
        } else {
            currentList.add(shift)
        }
        _staffShiftSchedules.value = currentList
    }

    fun addShiftSchedule(shift: StaffShiftSchedule) {
        val currentList = _staffShiftSchedules.value.toMutableList()
        currentList.add(0, shift)
        _staffShiftSchedules.value = currentList
    }

    fun deleteShiftSchedule(shiftId: String) {
        val currentList = _staffShiftSchedules.value.toMutableList()
        currentList.removeAll { it.id == shiftId }
        _staffShiftSchedules.value = currentList
    }

    fun setShiftStatus(shiftId: String, newAvailability: String, newPeriod: ShiftPeriod? = null) {
        val currentList = _staffShiftSchedules.value.toMutableList()
        val index = currentList.indexOfFirst { it.id == shiftId }
        if (index != -1) {
            val old = currentList[index]
            currentList[index] = old.copy(
                availabilityStatus = newAvailability,
                shiftPeriod = newPeriod ?: old.shiftPeriod,
                checkInStatus = if (newAvailability == "Shift Completed") "Completed & Signed-Off" else old.checkInStatus
            )
            _staffShiftSchedules.value = currentList
        }
    }

    // ==========================================
    // CASKET SELECTION & EXCHANGE (RETURN INWARDS / OUTWARDS)
    // ==========================================
    private val _caskets = MutableStateFlow(
        listOf(
            com.example.model.CasketItem(
                id = "CSK-01",
                name = "President Royal Oak",
                woodType = "Aged American White Oak",
                finish = "High-Gloss Mirror Piano Lacquer",
                interiorLining = "Crushed Diamond Velvet with Pearl Piping",
                tier = "Presidential Luxury",
                priceKes = 240000.0,
                priceUsd = 1846.0,
                stockCount = 4,
                features = listOf("Solid Brass Swing Bar Handles", "Locking Mechanism", "Memory Tube", "Waterproof Seal")
            ),
            com.example.model.CasketItem(
                id = "CSK-02",
                name = "Imperial Solid Mahogany",
                woodType = "Imported African Mahogany",
                finish = "Deep Merlot Hand-Rubbed Satin",
                interiorLining = "Champagne French Crepe with Quilted Headrest",
                tier = "Executive Tier",
                priceKes = 185000.0,
                priceUsd = 1423.0,
                stockCount = 6,
                features = listOf("Solid Cast Brass Corner Brackets", "Adjustable Bed", "Padded Pillow", "Hermetic Gasket")
            ),
            com.example.model.CasketItem(
                id = "CSK-03",
                name = "Executive Walnut Deluxe",
                woodType = "Prime Black Walnut",
                finish = "Warm Amber Semi-Gloss",
                interiorLining = "Ivory Rosetan Silk Lining",
                tier = "Executive Tier",
                priceKes = 165000.0,
                priceUsd = 1269.0,
                stockCount = 5,
                features = listOf("Brass Drop Bar Handles", "Tufted Velvet Panel", "Reinforced Base", "Protective Clear Coat")
            ),
            com.example.model.CasketItem(
                id = "CSK-04",
                name = "Silver Bronze Metal Liner Casket",
                woodType = "Solid Hardwood Core with Metal Vault Liner",
                finish = "Brushed Silver Electroplate",
                interiorLining = "Silvery Ice White Satin",
                tier = "Heritage Vault",
                priceKes = 320000.0,
                priceUsd = 2462.0,
                stockCount = 2,
                features = listOf("Hermetically Sealed Vault Liner", "Platinum Tone Hardware", "Eternal Memory Keepsake Drawer")
            ),
            com.example.model.CasketItem(
                id = "CSK-05",
                name = "Golden Sovereign Dignity",
                woodType = "Heavy Red Cedar & Brass Inlay",
                finish = "Polished Golden Honey Glaze",
                interiorLining = "Royal Gold Jacquard Silk",
                tier = "Presidential Luxury",
                priceKes = 280000.0,
                priceUsd = 2154.0,
                stockCount = 3,
                features = listOf("24k Gold Accented Handles", "Engraved Corner Plaques", "Full Split-Lid Display")
            ),
            com.example.model.CasketItem(
                id = "CSK-06",
                name = "Artisan Cedar Carved",
                woodType = "Indigenous Kenyan Cedar",
                finish = "Natural Teak Oil & Beeswax Polish",
                interiorLining = "White Satin with Floral Cross Stitching",
                tier = "Artisan Craft",
                priceKes = 130000.0,
                priceUsd = 1000.0,
                stockCount = 8,
                features = listOf("Hand-Carved Relief Panels", "Sturdy Timber Handles", "Aromatic Natural Cedar Scent")
            ),
            com.example.model.CasketItem(
                id = "CSK-07",
                name = "Traditional Pine Heritage",
                woodType = "Kiln-Dried Highland Pine",
                finish = "Clear Matt Sealant",
                interiorLining = "Classic White Cotton Crepe",
                tier = "Traditional Heritage",
                priceKes = 75000.0,
                priceUsd = 577.0,
                stockCount = 12,
                features = listOf("Solid Pine Bar Handles", "Embossed Cross Lid", "Comfort Pillow Set")
            ),
            com.example.model.CasketItem(
                id = "CSK-08",
                name = "Eco-Bio Bamboo Woven",
                woodType = "100% Biodegradable Hand-Woven Bamboo & Wicker",
                finish = "Organic Unvarnished Natural",
                interiorLining = "Unbleached Organic Calico Cotton",
                tier = "Eco-Bio Green",
                priceKes = 55000.0,
                priceUsd = 423.0,
                stockCount = 7,
                features = listOf("Natural Hemp Rope Handles", "Zero Metal / Zero Plastic", "Certified Green Burial Compliant")
            ),
            com.example.model.CasketItem(
                id = "CSK-09",
                name = "Executive Dome (Executive / Saitoti / VIP)",
                woodType = "3.5 Boards 12mm Chipboard + 9mm Ply Base",
                finish = "Multi-Coat Gloss Clear Coat & AC Lacquer",
                interiorLining = "Executive Printed Satin + 6 Foam Form Sheets",
                tier = "Flagship Executive Dome (Guide)",
                priceKes = 125000.0,
                priceUsd = 962.0,
                stockCount = 9,
                features = listOf("Cast Swing Bar Handles", "Hard Board Double Crown", "Est. Production Cost KES 50,000")
            ),
            com.example.model.CasketItem(
                id = "CSK-10",
                name = "Modern High Roof",
                woodType = "2 Boards Chipboard + Timber Frame",
                finish = "High Roof Polyurethane Gloss",
                interiorLining = "Executive Satin + 6 Form Sheets",
                tier = "Upper Executive (Guide)",
                priceKes = 125000.0,
                priceUsd = 962.0,
                stockCount = 6,
                features = listOf("Last Supper / Prayer Hand Handles", "Long Piano Hinge", "Est. Production Cost KES 30,000")
            ),
            com.example.model.CasketItem(
                id = "CSK-11",
                name = "Domes (Half Glass Dome / Reagan)",
                woodType = "3 Boards Chipboard + 9mm Plywood Bottom",
                finish = "High-Gloss Clear Coat",
                interiorLining = "Executive Satin + Printed Headliner",
                tier = "Premium Dome (Guide)",
                priceKes = 95000.0,
                priceUsd = 731.0,
                stockCount = 8,
                features = listOf("Swing Bar Handles", "1.5 Hard Board Dome Curve", "Est. Production Cost KES 44,000")
            ),
            com.example.model.CasketItem(
                id = "CSK-12",
                name = "Mini Dome (Dragon / Kupa / English / Dumu)",
                woodType = "2.5 Boards Chipboard + Hard Board Dome",
                finish = "AC Paint & Clear Spray Seal",
                interiorLining = "Printed Satin + 6 Foam Form Sheets",
                tier = "Heritage Mini-Dome (Guide)",
                priceKes = 65000.0,
                priceUsd = 500.0,
                stockCount = 14,
                features = listOf("Swing Bar Set", "Piano Hinge & 2 Openers", "Est. Production Cost KES 37,500")
            ),
            com.example.model.CasketItem(
                id = "CSK-13",
                name = "Half Glass Coffin",
                woodType = "1.5 Boards Chipboard + Timber Bottom",
                finish = "Standard AC Satin Gloss",
                interiorLining = "Printed Satin + Simple Clothing",
                tier = "Mid-Standard (Guide)",
                priceKes = 58000.0,
                priceUsd = 446.0,
                stockCount = 9,
                features = listOf("4 Hinges & 2 Openers", "H4 Assorted Handles", "Est. Production Cost KES 21,000")
            ),
            com.example.model.CasketItem(
                id = "CSK-14",
                name = "Simple Coffin",
                woodType = "1.5 Boards Chipboard + 18ft Timber Base",
                finish = "Economy Primer & Gloss Finish",
                interiorLining = "Simple Clothing + 1 Form Sheet",
                tier = "Economy Standard (Guide)",
                priceKes = 25000.0,
                priceUsd = 192.0,
                stockCount = 15,
                features = listOf("H4 Assorted Handles", "Viewing Glass Insert", "Est. Production Cost KES 15,000")
            ),
            com.example.model.CasketItem(
                id = "CSK-15",
                name = "Kids Casket (4.5 ft Spindles)",
                woodType = "0.75 Board Chipboard + 9ft Timber Base",
                finish = "Soft White Gloss Spray",
                interiorLining = "Pediatric Satin Clothing + Pillow",
                tier = "Youth 4.5 ft (Guide)",
                priceKes = 30000.0,
                priceUsd = 231.0,
                stockCount = 7,
                features = listOf("H9 Handle Set", "4 Corner Caps", "Est. Production Cost KES 11,000")
            )
        )
    )
    val caskets: StateFlow<List<com.example.model.CasketItem>> = _caskets.asStateFlow()

    // CASKET EXCHANGE LEDGER (RETURN INWARDS / RETURN OUTWARDS)
    private val _casketExchanges = MutableStateFlow(
        listOf(
            com.example.model.CasketExchangeRecord(
                id = "EXC-101",
                clientFamily = "Family of Mzee Ouko",
                caseReference = "JFD-2026-081",
                originalCasketName = "Traditional Pine Heritage",
                originalCasketPrice = 75000.0,
                newCasketName = "Imperial Solid Mahogany",
                newCasketPrice = 185000.0,
                returnType = com.example.model.CasketReturnType.RETURN_OUTWARD,
                priceDifferenceKes = 110000.0, // Family upgraded: paid KES 110,000 top up
                reason = "Family decided on state honours upgrade following diaspora family arrival",
                conditionAssessment = "Original Pine returned in pristine unsoiled condition (Workshop verified)",
                branch = "Siaya Referral (Opposite Morgue)",
                processedByStaffName = "Clara Mwamburi",
                date = "22 Sep 2026",
                status = "Approved & Exchanged"
            ),
            com.example.model.CasketExchangeRecord(
                id = "EXC-102",
                clientFamily = "Family of Mama Jane Achieng",
                caseReference = "JFD-2026-088",
                originalCasketName = "President Royal Oak",
                originalCasketPrice = 240000.0,
                newCasketName = "Executive Walnut Deluxe",
                newCasketPrice = 165000.0,
                returnType = com.example.model.CasketReturnType.RETURN_INWARD,
                priceDifferenceKes = -75000.0, // Downgrade / budget adjustment: KES 75,000 credit note issued
                reason = "Family reallocated budget towards extended church choir vigil & cortege",
                conditionAssessment = "Inspected at Bama Branch workshop. Sealed satin lining intact",
                branch = "Bama Branch",
                processedByStaffName = "Brian Adoche",
                date = "21 Sep 2026",
                status = "Credit Note Issued"
            )
        )
    )
    val casketExchanges: StateFlow<List<com.example.model.CasketExchangeRecord>> = _casketExchanges.asStateFlow()

    fun recordCasketExchange(record: com.example.model.CasketExchangeRecord) {
        _casketExchanges.value = listOf(record) + _casketExchanges.value
    }

    // Admin/CEO update casket price & stock count
    fun updateCasketPrice(casketId: String, newPriceKes: Double, newPriceUsd: Double = newPriceKes / 130.0, stockCount: Int? = null) {
        _caskets.value = _caskets.value.map { csk ->
            if (csk.id == casketId) {
                csk.copy(
                    priceKes = newPriceKes,
                    priceUsd = newPriceUsd,
                    stockCount = stockCount ?: csk.stockCount,
                    inStock = (stockCount ?: csk.stockCount) > 0
                )
            } else csk
        }
    }

    // Admin/CEO upload new casket / stock item
    fun addCasketItem(newItem: com.example.model.CasketItem) {
        _caskets.value = listOf(newItem) + _caskets.value
    }

    // Admin/CEO update sales service price
    fun updateSalesServicePrice(serviceId: String, newPriceKes: Double) {
        _salesServices.value = _salesServices.value.map { srv ->
            if (srv.id == serviceId) {
                srv.copy(priceKes = newPriceKes)
            } else srv
        }
    }

    // Admin/CEO upload new sales service item
    fun addSalesServiceItem(newItem: com.example.model.SalesServiceItem) {
        _salesServices.value = _salesServices.value + newItem
    }

    // ==========================================
    // AUTHORIZED SALES SERVICES (14 SPECIFIC SERVICES)
    // ==========================================
    private val _salesServices = MutableStateFlow(
        listOf(
            com.example.model.SalesServiceItem("SRV-01", "Caravan", 45000.0, "Fleet & Escort", "Executive cortege VIP caravan vehicle for family cortege transport"),
            com.example.model.SalesServiceItem("SRV-02", "Caravan with Accessories", 65000.0, "Fleet & Escort", "Caravan fitted with PA sound system, flags, ribbons, roof rack & LED beacons"),
            com.example.model.SalesServiceItem("SRV-03", "Hearse", 35000.0, "Fleet Logistics", "Dedicated Mercedes / Landau hearse for dignified transit from morgue to home"),
            com.example.model.SalesServiceItem("SRV-04", "Hearse Set with accessories", 55000.0, "Fleet Logistics", "Hearse equipped with cortege escort, chrome rollers, draped curtains & crests"),
            com.example.model.SalesServiceItem("SRV-05", "Lowering Gear", 15000.0, "Gravesite Setup", "Heavy duty automatic mechanical lowering device with green synthetic grass turf"),
            com.example.model.SalesServiceItem("SRV-06", "Church Trolley", 8000.0, "Church & Chapel", "Chrome collapsible church bier trolley with quiet rubber swivel caster wheels"),
            com.example.model.SalesServiceItem("SRV-07", "Red Carpet", 5000.0, "Ceremonial Decor", "50-meter plush ceremonial VIP red carpet runner for church and gravesite entrance"),
            com.example.model.SalesServiceItem("SRV-08", "Roses", 3500.0, "Florals", "Fresh cut red & white condolences petal roses for gravesite tribute drop"),
            com.example.model.SalesServiceItem("SRV-09", "Socks / Stockings", 1200.0, "Dignified Apparel", "Premium formal white cotton socks and luxury sheer stockings for deceased dressing"),
            com.example.model.SalesServiceItem("SRV-10", "Stunchions", 6000.0, "Ceremonial Decor", "Set of 6 polished brass stunchions with velvet braided ropes for VIP crowd queue"),
            com.example.model.SalesServiceItem("SRV-11", "Suits", 18000.0, "Dignified Apparel", "3-piece executive funeral formal suit tailored with shirt, tie and pocket square"),
            com.example.model.SalesServiceItem("SRV-12", "Veils", 4500.0, "Dignified Apparel", "Handmade embroidered lace burial face veil and mourning head covering"),
            com.example.model.SalesServiceItem("SRV-13", "Burial Gown", 12000.0, "Dignified Apparel", "Handcrafted satin and lace formal burial gown for dignified lady presentation"),
            com.example.model.SalesServiceItem("SRV-14", "Burial Wreaths", 7500.0, "Florals", "Fresh natural flower wreath tribute with custom printed personalized condolence ribbon")
        )
    )
    val salesServices: StateFlow<List<com.example.model.SalesServiceItem>> = _salesServices.asStateFlow()

    // ==========================================
    // CUSTOMER ORDERS & 5% CASKET COMMISSIONS
    // ==========================================
    private val _customerOrders = MutableStateFlow(
        listOf(
            com.example.model.CustomerOrderRecord(
                orderId = "ORD-2026-091",
                clientName = "Ezekiel Ochieng",
                clientPhone = "+254 712 345 678",
                deceasedName = "The Late M. Ochieng",
                selectedPackage = "Executive Dignity",
                selectedCasket = "Imperial Solid Mahogany (KES 185,000)",
                selectedAddons = listOf("Caravan with Accessories", "Lowering Gear", "Red Carpet"),
                totalAmountKes = 270000.0,
                totalAmountUsd = 2077.0,
                paymentMethod = "M-PESA",
                paymentTerms = "Full payment",
                paymentStatus = "Confirmed & Paid",
                referenceCode = "QA8921KL9X",
                orderDate = "22 Sep 2026, 11:30",
                branch = "Siaya Referral (Opposite Morgue)",
                salesAgentName = "Clara Mwamburi",
                commissionEarnedKes = 9250.0 // 5% of KES 185,000 casket
            ),
            com.example.model.CustomerOrderRecord(
                orderId = "ORD-2026-092",
                clientName = "Beatrice Auma",
                clientPhone = "+254 723 456 789",
                deceasedName = "The Late Elder G. Auma",
                selectedPackage = "Traditional Heritage",
                selectedCasket = "Traditional Pine Heritage (KES 75,000)",
                selectedAddons = listOf("Hearse", "Lowering Gear", "Burial Wreaths"),
                totalAmountKes = 132500.0,
                totalAmountUsd = 1019.0,
                paymentMethod = "BANK_TRANSFER",
                paymentTerms = "Lipa pole pole Option (2 installments)",
                paymentStatus = "Installment 1 Received (KES 70,000)",
                referenceCode = "SCB-TRX-882910",
                orderDate = "21 Sep 2026, 14:15",
                branch = "Bondo",
                salesAgentName = "Michael Wasamba",
                commissionEarnedKes = 3750.0 // 5% of KES 75,000 casket
            )
        )
    )
    val customerOrders: StateFlow<List<com.example.model.CustomerOrderRecord>> = _customerOrders.asStateFlow()

    fun submitCustomerOrder(order: com.example.model.CustomerOrderRecord) {
        _customerOrders.value = listOf(order) + _customerOrders.value

        // Seamless supply chain: deduct sold casket stock from catalog, branch stock, and inventory products
        val cleanCasketName = order.selectedCasket.substringBefore(" (").trim()
        _caskets.value = _caskets.value.map { csk ->
            if (cleanCasketName.contains(csk.name, ignoreCase = true) || csk.name.equals(cleanCasketName, ignoreCase = true)) {
                val nextStock = (csk.stockCount - 1).coerceAtLeast(0)
                csk.copy(stockCount = nextStock, inStock = nextStock > 0)
            } else csk
        }
        _inventoryProducts.value = _inventoryProducts.value.map { prod ->
            if (prod.category.equals("Casket", ignoreCase = true) &&
                (cleanCasketName.contains(prod.casketType ?: prod.name, ignoreCase = true) ||
                        prod.name.contains(cleanCasketName, ignoreCase = true))
            ) {
                prod.copy(stockCount = (prod.stockCount - 1).coerceAtLeast(0))
            } else prod
        }
        _casketStockByBranch.value = _casketStockByBranch.value.map { row ->
            if (cleanCasketName.contains(row.casketType, ignoreCase = true) || row.casketType.equals(cleanCasketName, ignoreCase = true)) {
                val updatedMap = row.branchStockMap.toMutableMap()
                val branchKey = updatedMap.keys.firstOrNull { it.equals(order.branch, ignoreCase = true) || order.branch.contains(it, ignoreCase = true) }
                    ?: "Bama Branch"
                val cur = updatedMap[branchKey] ?: 0
                if (cur > 0) updatedMap[branchKey] = cur - 1
                row.copy(branchStockMap = updatedMap)
            } else row
        }

        // Update daily sales KPI seamlessly
        _dashboardDailyKpis.value = _dashboardDailyKpis.value.copy(
            totalSalesToday = _dashboardDailyKpis.value.totalSalesToday + order.totalAmountKes,
            totalPaymentsToday = _dashboardDailyKpis.value.totalPaymentsToday + order.totalAmountKes
        )

        // If sales commission applies, compute via PayrollRulesEngine (with duplicate COM-<orderId> guard)
        val agent = _accounts.value.firstOrNull { it.fullName.contains(order.salesAgentName, ignoreCase = true) }
        if (agent != null && (order.commissionEarnedKes > 0 || agent.commissionRatePercent > 0)) {
            val calc = PayrollRulesEngine.calculateOrderCommission(
                order = order,
                agent = agent,
                existingTransactions = _transactions.value
            )
            val payoutAmount = if (calc.isDuplicatePrevented) {
                0.0
            } else {
                maxOf(order.commissionEarnedKes, calc.commissionAmountKes)
            }
            if (payoutAmount > 0.0) {
                val tierLabel = if (calc.executiveBonusApplied) "${calc.effectiveRatePercent}% Executive Tier" else "${calc.effectiveRatePercent}%"
                val commissionTxn = com.example.model.WalletTransaction(
                    id = "TXN-COM-${order.orderId.replace(Regex("[^A-Za-z0-9]"), "")}",
                    staffId = agent.id,
                    type = com.example.model.TransactionType.COMMISSION,
                    title = "$tierLabel Casket Commission: $cleanCasketName",
                    referenceNumber = calc.referenceNumber,
                    amount = payoutAmount,
                    date = shortDateFormat.format(Date()),
                    status = com.example.model.PaymentStatus.DISBURSED,
                    notes = "Earned on casket sale for Order #${order.orderId} (Client: ${order.clientName})"
                )
                _transactions.value = listOf(commissionTxn) + _transactions.value
            }
        }
    }

    fun updateCustomerOrderPaymentStatus(
        orderId: String,
        newStatus: String,
        updatedRef: String? = null
    ): Boolean {
        var found = false
        _customerOrders.value = _customerOrders.value.map { order ->
            if (order.orderId == orderId) {
                found = true
                order.copy(
                    paymentStatus = newStatus,
                    referenceCode = updatedRef?.takeIf { it.isNotBlank() } ?: order.referenceCode
                )
            } else {
                order
            }
        }
        return found
    }

    // ==========================================
    // COMPANY ASSETS CONTROL
    // ==========================================
    private val _companyAssets = MutableStateFlow(
        listOf(
            com.example.model.CompanyAsset("AST-01", "Executive Hearse (Mercedes)", "Fleet", "KDG 705Y", "Bama Branch", "Operational", "20 Sep 2026", "Victor Owino"),
            com.example.model.CompanyAsset("AST-02", "VIP Cortege Hearse", "Fleet", "KCL 703C", "Bama Branch", "Operational", "19 Sep 2026", "Joseph Ouma"),
            com.example.model.CompanyAsset("AST-03", "Standard Transfer Hearse", "Fleet", "KBR 104R", "Bama Branch", "Operational", "21 Sep 2026", "Fredrick Ochieng"),
            com.example.model.CompanyAsset("AST-04", "Long Distance Hearse", "Fleet", "KDH 172H", "Bama Branch", "Operational", "18 Sep 2026", "Fredrick Osuru"),
            com.example.model.CompanyAsset("AST-05", "Rural 4x4 Escort Hearse", "Fleet", "KDY 211L", "Bama Branch", "Operational", "22 Sep 2026", "Fredrick Okoth"),
            com.example.model.CompanyAsset("AST-06", "Director Executive Hearse", "Fleet", "KCT 871D", "Bama Branch", "Operational", "23 Sep 2026", "Fredrick Hayoyo"),
            com.example.model.CompanyAsset("AST-07", "Heavy Duty Lowering Gear #1", "Lowering Gear", "LG-BAMA-01", "Bama Branch", "Operational", "21 Sep 2026", "Peter Erkundi"),
            com.example.model.CompanyAsset("AST-08", "Automatic Lowering Gear #2", "Lowering Gear", "LG-SIAYA-02", "Siaya Referral", "Operational", "20 Sep 2026", "Victor Ojow"),
            com.example.model.CompanyAsset("AST-09", "Chrome Church Trolley Bier #1", "Church Trolley", "TRL-01", "Bama Branch", "Operational", "22 Sep 2026", "Stephen Ooko"),
            com.example.model.CompanyAsset("AST-10", "Chrome Church Trolley Bier #2", "Church Trolley", "TRL-02", "Bondo", "Operational", "21 Sep 2026", "George Tunya"),
            com.example.model.CompanyAsset("AST-11", "Brass Stunchions & Ropes Set A", "Stunchions", "STN-SET-A", "Bama Branch", "Operational", "22 Sep 2026", "David Omondi"),
            com.example.model.CompanyAsset("AST-12", "50m VIP Red Carpet #1", "Red Carpet", "RCP-01", "Bama Branch", "Operational", "23 Sep 2026", "Francis Gwayi"),
            com.example.model.CompanyAsset("AST-13", "Cold Room Unit 1 (18-Chamber)", "Cold Room", "CR-REF-01", "Siaya Referral", "Operational (4°C)", "23 Sep 2026", "Brian Adoche"),
            com.example.model.CompanyAsset("AST-14", "Cold Room Unit 2 (12-Chamber)", "Cold Room", "CR-BONDO-02", "Bondo", "Operational (3.8°C)", "22 Sep 2026", "Fredrick Osur"),
            com.example.model.CompanyAsset("AST-15", "Heavy Duty Workshop Timber Planer", "Workshop Machinery", "WKP-PLN-01", "Bama Branch", "Operational", "20 Sep 2026", "Brian Adoche")
        )
    )
    val companyAssets: StateFlow<List<com.example.model.CompanyAsset>> = _companyAssets.asStateFlow()

    fun updateAssetStatus(assetId: String, newCondition: String) {
        val list = _companyAssets.value.map {
            if (it.id == assetId) it.copy(condition = newCondition, lastInspected = shortDateFormat.format(Date())) else it
        }
        _companyAssets.value = list
    }

    // ==========================================
    // LEAVE MANAGEMENT
    // ==========================================
    private val _leaveRequests = MutableStateFlow(
        listOf(
            com.example.model.LeaveRequest(
                id = "LVE-101",
                staffId = "WRK-002",
                staffName = "George Munono",
                department = Department.WORKSHOP,
                leaveType = "Annual Leave",
                startDate = "28 Sep 2026",
                endDate = "05 Oct 2026",
                daysCount = 7,
                reason = "Scheduled annual family leave after completion of 10-casket batch",
                status = "Approved",
                approvedBy = "Fredrick Hayoyo (CEO)"
            ),
            com.example.model.LeaveRequest(
                id = "LVE-102",
                staffId = "DRV-002",
                staffName = "Joseph Ouma",
                department = Department.DRIVERS,
                leaveType = "Off-Duty Rest",
                startDate = "25 Sep 2026",
                endDate = "27 Sep 2026",
                daysCount = 2,
                reason = "Compensatory rest days following continuous long distance cortege transit to Nairobi",
                status = "Approved",
                approvedBy = "Fredrick Hayoyo (CEO)"
            ),
            com.example.model.LeaveRequest(
                id = "LVE-103",
                staffId = "OPR-004",
                staffName = "Erick Omollo",
                department = Department.OPERATORS,
                leaveType = "Compassionate / Bereavement",
                startDate = "26 Sep 2026",
                endDate = "29 Sep 2026",
                daysCount = 3,
                reason = "Attending family bereavement in Alego",
                status = "Pending",
                approvedBy = null
            )
        )
    )
    val leaveRequests: StateFlow<List<com.example.model.LeaveRequest>> = _leaveRequests.asStateFlow()

    fun submitLeaveRequest(request: com.example.model.LeaveRequest) {
        _leaveRequests.value = listOf(request) + _leaveRequests.value
    }

    fun approveLeaveRequest(requestId: String, approvedBy: String) {
        _leaveRequests.value = _leaveRequests.value.map {
            if (it.id == requestId) it.copy(status = "Approved", approvedBy = approvedBy) else it
        }
    }

    fun rejectLeaveRequest(requestId: String, rejectedBy: String) {
        _leaveRequests.value = _leaveRequests.value.map {
            if (it.id == requestId) it.copy(status = "Declined", approvedBy = rejectedBy) else it
        }
    }

    // ==========================================
    // 3CX UNIFIED COMMUNICATION EXTENSIONS & CALL LOGS
    // ==========================================
    private val _voipExtensions = MutableStateFlow(
        listOf(
            com.example.model.VoipExtension("100", "Executive Office", "Fredrick Hayoyo (CEO)", "Online", "+254793553434"),
            com.example.model.VoipExtension("101", "24/7 Emergency Dispatch", "Hotline Control Room", "Online (24/7)", "+254793553434"),
            com.example.model.VoipExtension("102", "Workshop Production", "Brian Adoche (Bama)", "Online", "Ext 102"),
            com.example.model.VoipExtension("103", "Operators & Grounds", "Peter Erkundi (Lead)", "Online", "Ext 103"),
            com.example.model.VoipExtension("104", "Sales & Marketing", "Clara Mwamburi", "Online", "Ext 104"),
            com.example.model.VoipExtension("201", "Bama Branch Desk", "Duty Officer", "Online", "+254711201001"),
            com.example.model.VoipExtension("202", "Bondo Branch Desk", "Michael Wasamba", "Online", "+254733401002"),
            com.example.model.VoipExtension("203", "Matibabu Branch Desk", "Grace Achieng", "Online", "+254733401004"),
            com.example.model.VoipExtension("204", "Siaya opposite Shell", "Caroline Omondi", "Online", "+254733401005"),
            com.example.model.VoipExtension("205", "Ukwala Branch Desk", "Victor Owino (Sales)", "Online", "+254733401006"),
            com.example.model.VoipExtension("206", "Uradi Branch Desk", "Urslar Hayoyo", "Online", "+254733401007"),
            com.example.model.VoipExtension("207", "Siaya Referral Desk", "Morine Otieno", "Online", "+254733401009"),
            com.example.model.VoipExtension("208", "Rangala Branch Desk", "Joseph Odongo", "Online", "+254733401008")
        )
    )
    val voipExtensions: StateFlow<List<com.example.model.VoipExtension>> = _voipExtensions.asStateFlow()

    private val _voipCallLogs = MutableStateFlow(
        listOf(
            com.example.model.VoipCallLog("CDR-901", "Inbound", "Ezekiel Ochieng (Client)", "+254 712 345 678", "04:12 min", "Today, 10:45 AM", "Connected HD (Opus)", true),
            com.example.model.VoipCallLog("CDR-902", "Intercom", "Brian Adoche (Workshop)", "Ext 102", "01:48 min", "Today, 09:30 AM", "Connected HD (G.711u)", true),
            com.example.model.VoipCallLog("CDR-903", "Outbound", "24/7 Hotline Central Dispatch", "+254793553434", "06:25 min", "Today, 08:15 AM", "Connected HD (Opus)", true),
            com.example.model.VoipCallLog("CDR-904", "Missed", "Matibabu Branch Desk", "Ext 203", "00:00 min", "Yesterday, 06:10 PM", "Missed Call", false),
            com.example.model.VoipCallLog("CDR-905", "Outbound", "Victor Owino (Hearse Driver)", "+254 711 201 001", "02:50 min", "Yesterday, 04:22 PM", "Connected HD (Opus)", true),
            com.example.model.VoipCallLog("CDR-906", "Inbound", "Mama Grace Wanjiku", "+254 722 990 114", "05:18 min", "Yesterday, 02:00 PM", "Connected HD (Opus)", true)
        )
    )
    val voipCallLogs: StateFlow<List<com.example.model.VoipCallLog>> = _voipCallLogs.asStateFlow()

    fun recordVoipCall(log: com.example.model.VoipCallLog) {
        _voipCallLogs.value = listOf(log) + _voipCallLogs.value
    }

    // ==========================================
    // BULK SMS SYSTEM
    // ==========================================
    private val _bulkSmsMessages = MutableStateFlow(
        listOf(
            com.example.model.BulkSmsMessage(
                id = "SMS-01",
                recipientType = "Client Family",
                recipientDetails = "+254712345678 (Ezekiel Ochieng)",
                messageBody = "Jabima Funeral Directors: Dear Ezekiel, receipt confirmed for Case #JFD-2026-084. Imperial Mahogany casket & Mercedes Hearse booked. 24/7 hotline: +254793553434.",
                timestamp = "22 Sep 2026, 11:35",
                status = "Delivered via Safaricom Gateway",
                senderId = "JABIMA_LTD",
                units = 1
            ),
            com.example.model.BulkSmsMessage(
                id = "SMS-02",
                recipientType = "All Staff Branches",
                recipientDetails = "All 8 Branches (Bama, Bondo, Matibabu, Shell, Ukwala, Uradi, Referral, Rangala)",
                messageBody = "Jabima Internal: Weekend cortege schedule synchronized. All fleet stationed at Bama Branch on alert. Verify fuel & cold room logs.",
                timestamp = "22 Sep 2026, 08:00",
                status = "Delivered via Safaricom Gateway",
                senderId = "JABIMA_CORTEGE",
                units = 1
            ),
            com.example.model.BulkSmsMessage(
                id = "SMS-03",
                recipientType = "Fleet Logistics",
                recipientDetails = "Hearse Drivers Group (KDG 705Y, KCL 703C, KBR 104R, KDH 172H, KDY 211L, KCT 871D)",
                messageBody = "Jabima 24/7 Dispatch: Cortege departure alert for Kisumu route at 08:30 AM tomorrow. Pre-trip vehicle inspection checklist required.",
                timestamp = "21 Sep 2026, 16:45",
                status = "Delivered via Safaricom Gateway",
                senderId = "JABIMA_24_7",
                units = 1
            )
        )
    )
    val bulkSmsMessages: StateFlow<List<com.example.model.BulkSmsMessage>> = _bulkSmsMessages.asStateFlow()

    fun sendBulkSms(
        recipientType: String,
        recipients: String,
        body: String,
        senderId: String = "JABIMA_LTD",
        units: Int = 1
    ) {
        val newSms = com.example.model.BulkSmsMessage(
            id = "SMS-${(100..999).random()}",
            recipientType = recipientType,
            recipientDetails = recipients,
            messageBody = body,
            timestamp = dateFormat.format(Date()),
            status = "Delivered via Safaricom Gateway",
            senderId = senderId,
            units = units
        )
        _bulkSmsMessages.value = listOf(newSms) + _bulkSmsMessages.value
    }

    // ==========================================
    // ADMIN / CEO PRICE MANAGEMENT & AUDIT LOG
    // ==========================================
    private val initialPriceUpdates = listOf(
        PriceUpdateRecord(
            id = "PRC-001",
            itemId = "CSK-01",
            itemName = "Imperial Solid Mahogany Casket",
            itemType = "Casket",
            previousPriceKes = 175000.0,
            newPriceKes = 185000.0,
            updatedByStaffName = "Fredrick Hayoyo (CEO)",
            dateUpdated = "20 Sep 2026",
            notes = "Adjusted for premium imported Ghanaian timber inflation & brass fittings"
        ),
        PriceUpdateRecord(
            id = "PRC-002",
            itemId = "SRV-02",
            itemName = "Caravan with Accessories",
            itemType = "Sales Service",
            previousPriceKes = 60000.0,
            newPriceKes = 65000.0,
            updatedByStaffName = "Fredrick Hayoyo (CEO)",
            dateUpdated = "21 Sep 2026",
            notes = "Added upgraded PA amplifier sound system and high-lumen cortege beacons"
        ),
        PriceUpdateRecord(
            id = "PRC-003",
            itemId = "CSK-02",
            itemName = "President Royal Oak Casket",
            itemType = "Casket",
            previousPriceKes = 225000.0,
            newPriceKes = 240000.0,
            updatedByStaffName = "Fredrick Hayoyo (CEO)",
            dateUpdated = "23 Sep 2026",
            notes = "Standardized national luxury state honours pricing"
        )
    )

    private val _priceUpdateHistory = MutableStateFlow(initialPriceUpdates)
    val priceUpdateHistory: StateFlow<List<PriceUpdateRecord>> = _priceUpdateHistory.asStateFlow()

    fun updateCasketPriceAndStock(
        casketId: String,
        newPriceKes: Double,
        newPriceUsd: Double? = null,
        newStockCount: Int? = null,
        inStock: Boolean? = null,
        updatedBy: String = "Fredrick Hayoyo (CEO)",
        notes: String = ""
    ) {
        val calculatedUsd = newPriceUsd ?: Math.round(newPriceKes / 130.0).toDouble()
        _caskets.value = _caskets.value.map { casket ->
            if (casket.id == casketId) {
                val audit = PriceUpdateRecord(
                    id = "PRC-" + UUID.randomUUID().toString().take(6).uppercase(),
                    itemId = casketId,
                    itemName = casket.name,
                    itemType = "Casket",
                    previousPriceKes = casket.priceKes,
                    newPriceKes = newPriceKes,
                    updatedByStaffName = updatedBy,
                    dateUpdated = shortDateFormat.format(Date()),
                    notes = notes.ifBlank { "Price & inventory update authorized by $updatedBy" }
                )
                _priceUpdateHistory.value = listOf(audit) + _priceUpdateHistory.value

                casket.copy(
                    priceKes = newPriceKes,
                    priceUsd = calculatedUsd,
                    stockCount = newStockCount ?: casket.stockCount,
                    inStock = inStock ?: ((newStockCount ?: casket.stockCount) > 0)
                )
            } else casket
        }
    }

    fun updateSalesServicePrice(
        serviceId: String,
        newPriceKes: Double,
        updatedBy: String = "Fredrick Hayoyo (CEO)",
        notes: String = ""
    ) {
        _salesServices.value = _salesServices.value.map { srv ->
            if (srv.id == serviceId) {
                val audit = PriceUpdateRecord(
                    id = "PRC-" + UUID.randomUUID().toString().take(6).uppercase(),
                    itemId = serviceId,
                    itemName = srv.name,
                    itemType = "Sales Service",
                    previousPriceKes = srv.priceKes,
                    newPriceKes = newPriceKes,
                    updatedByStaffName = updatedBy,
                    dateUpdated = shortDateFormat.format(Date()),
                    notes = notes.ifBlank { "Service tariff revision authorized by $updatedBy" }
                )
                _priceUpdateHistory.value = listOf(audit) + _priceUpdateHistory.value
                srv.copy(priceKes = newPriceKes)
            } else srv
        }
    }

    // ==========================================
    // STOCK INVENTORY UPLOAD & RECEPTION MODULE
    // ==========================================
    private val initialStockUploads = listOf(
        StockUploadItem(
            id = "STK-UPL-001",
            name = "Royal Solid Teak Imperial Casket",
            category = StockCategory.CASKET,
            sku = "CSK-TEAK-09",
            description = "Solid Grade-A Ghanaian Teak, High Gloss Piano Finish, Velvet Ivory Quilted Interior with Heavy Brass Bar Handles",
            quantity = 4,
            reorderThreshold = 2,
            costPriceKes = 120000.0,
            sellingPriceKes = 210000.0,
            branchWarehouse = "Bama Branch",
            supplierName = "Bama Master Craftsmen Workshop",
            invoiceOrBatchNumber = "BAMA-LOT-2026-44",
            dateUploaded = "02 Oct 2026",
            uploadedByStaffName = "Fredrick Hayoyo (CEO)"
        ),
        StockUploadItem(
            id = "STK-UPL-002",
            name = "Champion 36 Arterial Embalming Fluid (Pack of 12)",
            category = StockCategory.MORTUARY_CHEMICALS,
            sku = "CHM-EMB-12",
            description = "High index firming preservative chemical compound with natural cosmetic humectant",
            quantity = 25,
            reorderThreshold = 5,
            costPriceKes = 4200.0,
            sellingPriceKes = 7500.0,
            branchWarehouse = "Siaya Referral (Opposite Morgue)",
            supplierName = "Apex Medical Supplies Nairobi",
            invoiceOrBatchNumber = "INV-APX-88219",
            dateUploaded = "03 Oct 2026",
            uploadedByStaffName = "Fredrick Hayoyo (CEO)"
        ),
        StockUploadItem(
            id = "STK-UPL-003",
            name = "Executive 3-Piece Burial Suits & Ties (Assorted Navy/Charcoal)",
            category = StockCategory.BURIAL_APPAREL,
            sku = "APP-SUIT-03",
            description = "Formal tailored burial suits with white dress shirts, silk ties, and pocket handkerchiefs",
            quantity = 15,
            reorderThreshold = 4,
            costPriceKes = 11000.0,
            sellingPriceKes = 18000.0,
            branchWarehouse = "Siaya opposite Shell Petrol",
            supplierName = "Kisumu Tailoring Guild",
            invoiceOrBatchNumber = "KTG-BATCH-301",
            dateUploaded = "04 Oct 2026",
            uploadedByStaffName = "Fredrick Hayoyo (CEO)"
        ),
        StockUploadItem(
            id = "STK-UPL-004",
            name = "Heavy-Duty Chrome Church Bier Trolley (Rubber Shock Castors)",
            category = StockCategory.CEREMONIAL_EQUIPMENT,
            sku = "EQP-TRL-06",
            description = "Collapsible chrome church bier trolley with hydraulic lock, 400kg capacity",
            quantity = 6,
            reorderThreshold = 2,
            costPriceKes = 35000.0,
            sellingPriceKes = 55000.0,
            branchWarehouse = "Bondo",
            supplierName = "Funeral Equipment Ltd Mombasa",
            invoiceOrBatchNumber = "FEL-IMP-0941",
            dateUploaded = "05 Oct 2026",
            uploadedByStaffName = "Fredrick Hayoyo (CEO)"
        )
    )

    private val _uploadedStockItems = MutableStateFlow(initialStockUploads)
    val uploadedStockItems: StateFlow<List<StockUploadItem>> = _uploadedStockItems.asStateFlow()

    fun uploadStockItem(item: StockUploadItem) {
        _uploadedStockItems.value = listOf(item) + _uploadedStockItems.value

        // If it's a casket, automatically make it available in caskets catalog!
        if (item.category == StockCategory.CASKET) {
            val casketId = item.sku.ifBlank { "CSK-" + (100 + _caskets.value.size) }
            val existingIdx = _caskets.value.indexOfFirst {
                it.name.equals(item.name, ignoreCase = true) || it.id.equals(casketId, ignoreCase = true)
            }

            if (existingIdx >= 0) {
                val list = _caskets.value.toMutableList()
                val old = list[existingIdx]
                list[existingIdx] = old.copy(
                    stockCount = old.stockCount + item.quantity,
                    priceKes = item.sellingPriceKes,
                    priceUsd = Math.round(item.sellingPriceKes / 130.0).toDouble(),
                    inStock = true
                )
                _caskets.value = list
            } else {
                val newCasket = CasketItem(
                    id = casketId,
                    name = item.name,
                    woodType = item.description.take(45),
                    finish = "Premium Gloss Finish",
                    interiorLining = "Quilted Ivory Satin",
                    tier = if (item.sellingPriceKes >= 180000) "Presidential Elite" else if (item.sellingPriceKes >= 120000) "Executive Deluxe" else "Classic Dignity",
                    priceKes = item.sellingPriceKes,
                    priceUsd = Math.round(item.sellingPriceKes / 130.0).toDouble(),
                    stockCount = item.quantity,
                    inStock = item.quantity > 0,
                    features = listOf("Imported Consignment", item.supplierName, item.branchWarehouse)
                )
                _caskets.value = _caskets.value + newCasket
            }
        }

        // Record a verified stock intake record in stockMovements
        val intakeRecord = StockMovementRecord(
            id = "STK-IN-" + UUID.randomUUID().toString().take(6).uppercase(),
            itemName = item.name,
            category = item.category.label,
            quantity = item.quantity,
            sourceBranch = "Vendor: ${item.supplierName}",
            destinationBranch = item.branchWarehouse,
            requestedByStaffId = "CEO-ADM-01",
            requestedByStaffName = item.uploadedByStaffName,
            assignedVehicle = "Consignment Truck",
            assignedDriverName = "Vendor Logistics",
            requestDate = item.dateUploaded,
            urgency = "Normal Intake",
            status = StockMovementStatus.DELIVERED,
            authorizedByManagerName = item.uploadedByStaffName,
            notes = "Stock Intake [${item.invoiceOrBatchNumber}]: Unit selling price KES ${String.format("%,.0f", item.sellingPriceKes)}. Logged by CEO."
        )
        _stockMovements.value = listOf(intakeRecord) + _stockMovements.value
    }

    fun batchUploadStockItems(items: List<StockUploadItem>) {
        items.forEach { uploadStockItem(it) }
    }

    fun deleteUploadedStockItem(itemId: String) {
        _uploadedStockItems.value = _uploadedStockItems.value.filter { it.id != itemId }
    }

    // =========================================================================
    // ENTERPRISE PLATFORM INTEGRATIONS (ZOHO ONE, FRESHSALES, ZURI, HUBSPOT)
    // =========================================================================
    private val initialIntegrationConfigs = listOf(
        PlatformIntegrationConfig(
            platform = IntegrationPlatform.ZOHO_ONE,
            isEnabled = true,
            status = SyncStatus.ACTIVE_CONNECTED,
            apiEndpoint = "https://accounts.zoho.com/api/v2/jabimafuneral",
            organizationId = "ZH-ORG-884920",
            lastSyncTime = "07 Oct 2026, 03:15",
            syncedRecordsCount = 428,
            webhookActive = true,
            autoSyncIntervalMinutes = 15,
            pendingQueueCount = 2
        ),
        PlatformIntegrationConfig(
            platform = IntegrationPlatform.FRESHSALES,
            isEnabled = true,
            status = SyncStatus.ACTIVE_CONNECTED,
            apiEndpoint = "https://jabimafuneral.myfreshworks.com/crm/sales/api",
            organizationId = "FS-DEALS-10992",
            lastSyncTime = "07 Oct 2026, 03:00",
            syncedRecordsCount = 294,
            webhookActive = true,
            autoSyncIntervalMinutes = 10,
            pendingQueueCount = 1
        ),
        PlatformIntegrationConfig(
            platform = IntegrationPlatform.ZURI_PLATFORM,
            isEnabled = true,
            status = SyncStatus.ACTIVE_CONNECTED,
            apiEndpoint = "https://cloud.zuriafrica.health/api/v1/mortuary-transit",
            organizationId = "ZURI-KE-MORGUE-47",
            lastSyncTime = "07 Oct 2026, 02:45",
            syncedRecordsCount = 186,
            webhookActive = true,
            autoSyncIntervalMinutes = 30,
            pendingQueueCount = 0
        ),
        PlatformIntegrationConfig(
            platform = IntegrationPlatform.HUBSPOT,
            isEnabled = true,
            status = SyncStatus.ACTIVE_CONNECTED,
            apiEndpoint = "https://api.hubapi.com/crm/v3/jabima-bereavement",
            organizationId = "HUB-PORTAL-4481029",
            lastSyncTime = "07 Oct 2026, 02:30",
            syncedRecordsCount = 312,
            webhookActive = true,
            autoSyncIntervalMinutes = 20,
            pendingQueueCount = 0
        )
    )

    private val initialIntegrationSyncLogs = listOf(
        IntegrationSyncLog(
            id = "SYNC-LOG-01",
            platform = IntegrationPlatform.ZOHO_ONE,
            actionType = "Outbound Ledger Push",
            recordSummary = "Synchronized KES 485,000 payroll disbursements & EXP claims to Zoho Books",
            entityType = "Payroll & Books",
            timestamp = "07 Oct 2026, 03:15",
            status = "Success (200 OK)",
            itemsProcessed = 14
        ),
        IntegrationSyncLog(
            id = "SYNC-LOG-02",
            platform = IntegrationPlatform.FRESHSALES,
            actionType = "Deal Stage Webhook",
            recordSummary = "Synced 6 Executive Casket order inquiries & 5% sales commissions to CRM pipeline",
            entityType = "Family Deals",
            timestamp = "07 Oct 2026, 03:00",
            status = "Success (200 OK)",
            itemsProcessed = 6
        ),
        IntegrationSyncLog(
            id = "SYNC-LOG-03",
            platform = IntegrationPlatform.ZURI_PLATFORM,
            actionType = "Mortuary Intake Sync",
            recordSummary = "Verified Siaya Referral morgue body clearance & digitized county transit permit",
            entityType = "Mortuary Transit",
            timestamp = "07 Oct 2026, 02:45",
            status = "Success (200 OK)",
            itemsProcessed = 4
        ),
        IntegrationSyncLog(
            id = "SYNC-LOG-04",
            platform = IntegrationPlatform.HUBSPOT,
            actionType = "Service Feedback Sync",
            recordSummary = "Published 3 online memorial tribute pages and logged 8 family post-burial CSAT responses",
            entityType = "Memorial & CSAT",
            timestamp = "07 Oct 2026, 02:30",
            status = "Success (200 OK)",
            itemsProcessed = 11
        )
    )

    private val _integrationConfigs = MutableStateFlow(initialIntegrationConfigs)
    val integrationConfigs: StateFlow<List<PlatformIntegrationConfig>> = _integrationConfigs.asStateFlow()

    private val _integrationSyncLogs = MutableStateFlow(initialIntegrationSyncLogs)
    val integrationSyncLogs: StateFlow<List<IntegrationSyncLog>> = _integrationSyncLogs.asStateFlow()

    fun triggerPlatformSync(platform: IntegrationPlatform): IntegrationSyncLog {
        val now = dateFormat.format(Date())
        val (summary, entity, count) = when (platform) {
            IntegrationPlatform.ZOHO_ONE -> Triple(
                "Pushed ${_transactions.value.size} payroll transactions and ${_uploadedStockItems.value.size} inventory batches to Zoho Books & Inventory",
                "ERP & Payroll",
                _transactions.value.size
            )
            IntegrationPlatform.FRESHSALES -> Triple(
                "Synchronized ${_customerOrders.value.size} bereaved family deals and sales rep commission allocations to Freshsales pipeline",
                "Sales & Leads",
                _customerOrders.value.size
            )
            IntegrationPlatform.ZURI_PLATFORM -> Triple(
                "Synchronized ${_branchStatusBoards.value.size} branch morgue intake records, cold room slots & body transport clearances",
                "Mortuary Health Cloud",
                _branchStatusBoards.value.size
            )
            IntegrationPlatform.HUBSPOT -> Triple(
                "Synchronized family support tickets, condolences message dispatch logs and memorial tribute notices to HubSpot CRM",
                "Support & Memorials",
                _bulkSmsMessages.value.size
            )
        }

        val newLog = IntegrationSyncLog(
            id = "SYNC-LOG-" + UUID.randomUUID().toString().take(6).uppercase(),
            platform = platform,
            actionType = "Manual On-Demand Sync",
            recordSummary = summary,
            entityType = entity,
            timestamp = now,
            status = "Success (200 OK)",
            itemsProcessed = count
        )

        _integrationSyncLogs.value = listOf(newLog) + _integrationSyncLogs.value

        _integrationConfigs.value = _integrationConfigs.value.map { cfg ->
            if (cfg.platform == platform) {
                cfg.copy(
                    lastSyncTime = now,
                    status = SyncStatus.ACTIVE_CONNECTED,
                    syncedRecordsCount = cfg.syncedRecordsCount + count,
                    pendingQueueCount = 0
                )
            } else cfg
        }

        return newLog
    }

    fun updatePlatformConfig(
        platform: IntegrationPlatform,
        isEnabled: Boolean,
        apiEndpoint: String,
        organizationId: String,
        autoSyncInterval: Int = 15
    ) {
        _integrationConfigs.value = _integrationConfigs.value.map { cfg ->
            if (cfg.platform == platform) {
                cfg.copy(
                    isEnabled = isEnabled,
                    apiEndpoint = apiEndpoint.trim(),
                    organizationId = organizationId.trim(),
                    autoSyncIntervalMinutes = autoSyncInterval
                )
            } else cfg
        }
    }

    // =========================================================================
    // LIVE FLEET GPS TRACKING & TELEMETRY (GOOGLE MAPS INCORPORATION)
    // =========================================================================
    private val initialFleetGpsVehicles = listOf(
        FleetGpsVehicle(
            registration = "KDG 705Y",
            model = "Mercedes-Benz E250 Executive Limousine Hearse",
            driverName = "Fredrick Hayoyo (Executive Escort)",
            driverPhone = "+254793553434",
            latitude = 0.0632,
            longitude = 34.2810,
            speedKmh = 42,
            headingDegrees = 215f,
            statusLabel = "In Transit (Cortege Escort)",
            isMoving = true,
            fuelPercent = 84,
            engineRunning = true,
            activeCaseRef = "JAB-2026-088 • Late Mzee Odhiambo Funeral",
            destination = "Uradi Homestead Gravesite",
            eta = "14:15 EAT (22 mins)",
            currentStreet = "C28 Bondo-Siaya Road, near Wagai Junction",
            lastPingSecondsAgo = 8,
            routeBreadcrumbs = listOf(
                FleetLocationPoint(0.0607, 34.2881, "Bama Branch Base (Dep 12:45)"),
                FleetLocationPoint(0.0620, 34.2855, "Siaya Town Roundabout"),
                FleetLocationPoint(0.0628, 34.2830, "Ahindi Gardens Turnoff"),
                FleetLocationPoint(0.0632, 34.2810, "Wagai Junction (Current)")
            )
        ),
        FleetGpsVehicle(
            registration = "KCL 703C",
            model = "Mercedes-Benz E200 Classic Hearse",
            driverName = "Evans Odhiambo",
            driverPhone = "+254712345678",
            latitude = 0.0607,
            longitude = 34.2881,
            speedKmh = 0,
            headingDegrees = 0f,
            statusLabel = "Standby at Base",
            isMoving = false,
            fuelPercent = 92,
            engineRunning = false,
            activeCaseRef = "Standby for 24/7 Dispatch",
            destination = "Bama Branch Base Bay #2",
            eta = "Ready for immediate deployment",
            currentStreet = "Bama Branch Workshop Base, Siaya",
            lastPingSecondsAgo = 25,
            routeBreadcrumbs = listOf(
                FleetLocationPoint(0.0607, 34.2881, "Bama Branch Base")
            )
        ),
        FleetGpsVehicle(
            registration = "KBR 104R",
            model = "Toyota Land Cruiser 4x4 Rugged Terrain Hearse",
            driverName = "Victor Owino",
            driverPhone = "+254722889900",
            latitude = 0.1512,
            longitude = 34.1920,
            speedKmh = 34,
            headingDegrees = 310f,
            statusLabel = "Rural Gravesite Transit",
            isMoving = true,
            fuelPercent = 68,
            engineRunning = true,
            activeCaseRef = "JAB-2026-092 • Mama Achieng Funeral",
            destination = "Nyadorera Rural Homestead",
            eta = "15:00 EAT (38 mins)",
            currentStreet = "Ukwala-Nyadorera Murram Road",
            lastPingSecondsAgo = 12,
            routeBreadcrumbs = listOf(
                FleetLocationPoint(0.1558, 34.1884, "Ukwala Branch Base"),
                FleetLocationPoint(0.1530, 34.1905, "Ugunja Crossroad"),
                FleetLocationPoint(0.1512, 34.1920, "Nyadorera Rural (Current)")
            )
        ),
        FleetGpsVehicle(
            registration = "KDH 172H",
            model = "Mercedes-Benz E-Class Hearse",
            driverName = "Collins Otieno",
            driverPhone = "+254733445566",
            latitude = 0.0628,
            longitude = 34.2865,
            speedKmh = 0,
            headingDegrees = 90f,
            statusLabel = "Hospital Morgue Intake",
            isMoving = false,
            fuelPercent = 76,
            engineRunning = true,
            activeCaseRef = "JAB-2026-094 • Deceased Transfer Intake",
            destination = "Bama Branch Preservation Facility",
            eta = "Loading body • Dep: 13:45",
            currentStreet = "Hospital Rd, Siaya Referral Morgue Gate",
            lastPingSecondsAgo = 5,
            routeBreadcrumbs = listOf(
                FleetLocationPoint(0.0607, 34.2881, "Bama Base Departure"),
                FleetLocationPoint(0.0628, 34.2865, "Siaya Referral Hospital Morgue")
            )
        ),
        FleetGpsVehicle(
            registration = "KDY 211L",
            model = "Nissan Urvan Operators & Equipment Van",
            driverName = "Kennedy Omondi (Lead Operator)",
            driverPhone = "+254744556677",
            latitude = 0.0890,
            longitude = 34.3120,
            speedKmh = 58,
            headingDegrees = 45f,
            statusLabel = "Equipment Setup In Transit",
            isMoving = true,
            fuelPercent = 61,
            engineRunning = true,
            activeCaseRef = "Lowering Gear & Church Trolleys Setup",
            destination = "Rangala Mission Church & Cemetery",
            eta = "13:55 EAT (14 mins)",
            currentStreet = "B1 Kisumu-Busia Highway, Rangala Turnoff",
            lastPingSecondsAgo = 9,
            routeBreadcrumbs = listOf(
                FleetLocationPoint(0.0607, 34.2881, "Bama Workshop Gear Load"),
                FleetLocationPoint(0.0754, 34.2982, "Siaya Junction B1 Highway"),
                FleetLocationPoint(0.0890, 34.3120, "Rangala Highway Turnoff (Current)")
            )
        ),
        FleetGpsVehicle(
            registration = "KCT 871D",
            model = "Mercedes-Benz VIP Presidential Reserve Hearse",
            driverName = "Peter Oduor",
            driverPhone = "+254755667788",
            latitude = 0.0595,
            longitude = 34.2840,
            speedKmh = 0,
            headingDegrees = 0f,
            statusLabel = "Executive Reserve",
            isMoving = false,
            fuelPercent = 98,
            engineRunning = false,
            activeCaseRef = "VIP Reserve Standby (State / Dignitary Escort)",
            destination = "Siaya Shell Central Fleet Bay",
            eta = "On 24/7 Call",
            currentStreet = "Siaya Town Central, Opposite Shell Petrol",
            lastPingSecondsAgo = 45,
            routeBreadcrumbs = listOf(
                FleetLocationPoint(0.0595, 34.2840, "Siaya Shell Depot Base")
            )
        )
    )

    private val _fleetGpsVehicles = MutableStateFlow(initialFleetGpsVehicles)
    val fleetGpsVehicles: StateFlow<List<FleetGpsVehicle>> = _fleetGpsVehicles.asStateFlow()

    fun refreshFleetTelemetry() {
        _fleetGpsVehicles.value = _fleetGpsVehicles.value.map { v ->
            v.copy(lastPingSecondsAgo = (1..6).random())
        }
    }

    fun simulateFleetStepMovement() {
        _fleetGpsVehicles.value = _fleetGpsVehicles.value.map { vehicle ->
            if (vehicle.isMoving) {
                val deltaLat = ((-5..5).random()) * 0.0003
                val deltaLng = ((-5..5).random()) * 0.0003
                val newSpeed = (35..55).random()
                val newHeading = (vehicle.headingDegrees + (-10..10).random()).coerceIn(0f, 360f)
                val newPoint = FleetLocationPoint(vehicle.latitude + deltaLat, vehicle.longitude + deltaLng, "Live GPS Ping")
                vehicle.copy(
                    latitude = vehicle.latitude + deltaLat,
                    longitude = vehicle.longitude + deltaLng,
                    speedKmh = newSpeed,
                    headingDegrees = newHeading,
                    lastPingSecondsAgo = 1,
                    routeBreadcrumbs = (vehicle.routeBreadcrumbs + newPoint).takeLast(6)
                )
            } else {
                vehicle.copy(lastPingSecondsAgo = (vehicle.lastPingSecondsAgo + 5).coerceAtMost(60))
            }
        }
    }

    // Admin updates or adds vehicle details (make, registration, driver, destination)
    fun updateFleetVehicle(
        oldRegistration: String,
        newRegistration: String,
        newModel: String,
        newDriverName: String,
        newDriverPhone: String,
        newDestination: String
    ): Result<Unit> {
        val current = _fleetGpsVehicles.value
        val existingIndex = current.indexOfFirst { it.registration.equals(oldRegistration, ignoreCase = true) }
        return if (existingIndex != -1) {
            val updated = current.toMutableList()
            val orig = updated[existingIndex]
            updated[existingIndex] = orig.copy(
                registration = newRegistration.uppercase().trim(),
                model = newModel.trim(),
                driverName = newDriverName.trim(),
                driverPhone = newDriverPhone.trim(),
                destination = newDestination.trim().ifEmpty { orig.destination }
            )
            _fleetGpsVehicles.value = updated
            Result.success(Unit)
        } else {
            val newVeh = FleetGpsVehicle(
                registration = newRegistration.uppercase().trim(),
                model = newModel.trim(),
                driverName = newDriverName.trim(),
                driverPhone = newDriverPhone.trim(),
                latitude = 0.0607,
                longitude = 34.2881,
                speedKmh = 0,
                headingDegrees = 0f,
                statusLabel = "Standby at Base",
                isMoving = false,
                fuelPercent = 100,
                engineRunning = false,
                activeCaseRef = "Available for cortege dispatch",
                destination = newDestination.trim().ifEmpty { "Bama Branch Base" },
                eta = "Ready for immediate deployment",
                currentStreet = "Jabima Fleet Depot, Siaya",
                lastPingSecondsAgo = 1,
                routeBreadcrumbs = listOf(FleetLocationPoint(0.0607, 34.2881, "Bama Branch Depot"))
            )
            _fleetGpsVehicles.value = current + newVeh
            Result.success(Unit)
        }
    }

    // ==========================================
    // GEOFENCING & AUTO-CHECKIN FOR HEARSE CORTEGE
    // ==========================================
    private val initialGeofenceZones = listOf(
        GeofenceZone("GF-01", "Bama Headquarters Depot", "Headquarters Depot", 0.0607, 34.2881, 350.0, 0xFF10B981),
        GeofenceZone("GF-02", "Siaya Referral Hospital & Morgue", "Morgue Intake", 0.0628, 34.2865, 300.0, 0xFF2563EB),
        GeofenceZone("GF-03", "Bondo Sub-County Hospital & Branch", "Branch Office & Morgue", 0.2386, 34.2700, 400.0, 0xFF38BDF8),
        GeofenceZone("GF-04", "Matibabu Hospital Preservation", "Hospital Mortuary", 0.1200, 34.3300, 350.0, 0xFF7C3AED),
        GeofenceZone("GF-05", "Ukwala Sub-County Chapel & Cemetery", "Church & Chapel", 0.1600, 34.1900, 450.0, 0xFFD97706),
        GeofenceZone("GF-06", "Rangala Mission Church & Cemetery", "Cemetery & Gravesite", 0.0890, 34.3120, 400.0, 0xFFDC2626),
        GeofenceZone("GF-07", "Uradi Grounds & Gravesite", "Gravesite", 0.0450, 34.2500, 350.0, 0xFF0D9488)
    )

    private val initialGeofenceEvents = listOf(
        GeofenceCheckinEvent(
            id = "GFC-101",
            vehicleReg = "KDG 705Y",
            driverName = "Peter Odhiambo",
            zoneName = "Bondo Sub-County Hospital & Branch",
            eventType = "ENTERED",
            caseReference = "JAB-2026-088 • Ochieng Family Cortege",
            timestamp = "13:42 EAT",
            statusSummary = "Auto-Checkin: Hearse entered Bondo Morgue perimeter. Body transfer & floral casket fitting initiated."
        ),
        GeofenceCheckinEvent(
            id = "GFC-102",
            vehicleReg = "KCL 703C",
            driverName = "David Otieno",
            zoneName = "Rangala Mission Church & Cemetery",
            eventType = "ON_SITE_ACTIVE",
            caseReference = "JAB-2026-091 • Auma Family Requiem",
            timestamp = "13:30 EAT",
            statusSummary = "Auto-Checkin: Hearse stationed at Church driveway. Requiem mass underway."
        ),
        GeofenceCheckinEvent(
            id = "GFC-103",
            vehicleReg = "KBR 104R",
            driverName = "Charles Onyango",
            zoneName = "Siaya Referral Hospital & Morgue",
            eventType = "ON_SITE_ACTIVE",
            caseReference = "JAB-2026-094 • Deceased Transfer Intake",
            timestamp = "13:15 EAT",
            statusSummary = "Auto-Checkin: Body intake verification & county clearance completed."
        )
    )

    private val _geofenceZones = MutableStateFlow(initialGeofenceZones)
    val geofenceZones: StateFlow<List<GeofenceZone>> = _geofenceZones.asStateFlow()

    private val _geofenceCheckinEvents = MutableStateFlow(initialGeofenceEvents)
    val geofenceCheckinEvents: StateFlow<List<GeofenceCheckinEvent>> = _geofenceCheckinEvents.asStateFlow()

    fun triggerSimulatedGeofenceAutoCheckin(vehicleReg: String, zoneName: String? = null): GeofenceCheckinEvent {
        val vehicle = _fleetGpsVehicles.value.firstOrNull { it.registration == vehicleReg }
            ?: _fleetGpsVehicles.value.first()
        val zone = if (zoneName != null) {
            _geofenceZones.value.firstOrNull { it.name == zoneName } ?: _geofenceZones.value.first()
        } else {
            _geofenceZones.value.random()
        }
        val eventType = listOf("ENTERED", "ON_SITE_ACTIVE", "EXITED").random()
        val timeNow = SimpleDateFormat("HH:mm", Locale.getDefault()).format(Date()) + " EAT"
        val statusText = when (eventType) {
            "ENTERED" -> "Geofence Auto-Trigger: ${vehicle.registration} crossed perimeter of ${zone.name}. Cortege arrived on schedule."
            "ON_SITE_ACTIVE" -> "Geofence Radar: ${vehicle.registration} stationary at ${zone.name}. Hydraulic deck & flowers active."
            else -> "Geofence Departure: ${vehicle.registration} departed ${zone.name} en route to next cortege station."
        }

        val event = GeofenceCheckinEvent(
            id = "GFC-" + UUID.randomUUID().toString().take(6).uppercase(),
            vehicleReg = vehicle.registration,
            driverName = vehicle.driverName,
            zoneName = zone.name,
            eventType = eventType,
            caseReference = vehicle.activeCaseRef,
            timestamp = timeNow,
            statusSummary = statusText
        )

        _geofenceCheckinEvents.value = listOf(event) + _geofenceCheckinEvents.value
        return event
    }

    // ==========================================
    // HEARSE FLEET INSPECTION CHECKLIST
    // ==========================================
    private val initialFleetInspections = listOf(
        FleetInspectionRecord(
            id = "INSP-001",
            vehicleReg = "KDG 705Y",
            inspectorDriverName = "Peter Odhiambo (Driver)",
            date = "08 Oct 2026",
            time = "06:30 EAT",
            odometerKm = 142850,
            deckRollersAndClampLocks = true,
            hydraulicLiftOperating = true,
            ceremonialFlagsAndRibbons = true,
            engineOilAndCoolantOk = true,
            tirePressureAndTreadOk = true,
            interiorSanitizedAndVelvetClean = true,
            ceremonialUniformAndGlovesReady = true,
            overallStatus = "Passed - Certified Ready for Cortege",
            notes = "Full pre-trip inspection passed. Velvet deck cleaned, gold ribbons fitted."
        ),
        FleetInspectionRecord(
            id = "INSP-002",
            vehicleReg = "KCL 703C",
            inspectorDriverName = "David Otieno (Driver)",
            date = "08 Oct 2026",
            time = "07:00 EAT",
            odometerKm = 98400,
            deckRollersAndClampLocks = true,
            hydraulicLiftOperating = true,
            ceremonialFlagsAndRibbons = true,
            engineOilAndCoolantOk = true,
            tirePressureAndTreadOk = true,
            interiorSanitizedAndVelvetClean = true,
            ceremonialUniformAndGlovesReady = true,
            overallStatus = "Passed - Certified Ready for Cortege",
            notes = "Hydraulic lowering deck lubricated. Sound speaker system tested."
        )
    )

    private val _fleetInspections = MutableStateFlow(initialFleetInspections)
    val fleetInspections: StateFlow<List<FleetInspectionRecord>> = _fleetInspections.asStateFlow()

    fun submitFleetInspection(record: FleetInspectionRecord) {
        _fleetInspections.value = listOf(record) + _fleetInspections.value
    }

    // ==========================================
    // FUEL LOG BOOK RECORDS
    // ==========================================
    private val initialFuelLogs = listOf(
        FleetFuelLogRecord(
            id = "FUEL-001",
            vehicleReg = "KDG 705Y",
            driverName = "Peter Odhiambo",
            stationName = "Shell Siaya (Opposite Branch)",
            date = "07 Oct 2026",
            odometerKm = 142610,
            litersPumped = 45.0,
            pricePerLiterKes = 217.50,
            totalAmountKes = 9787.50,
            receiptOrMpesaRef = "SHL-SIA-9921",
            fuelCardNumber = "JABIMA-PETRO-042",
            calculatedEfficiencyKmPerL = 10.2,
            notes = "Filled tank before Bondo funeral cortege dispatch."
        ),
        FleetFuelLogRecord(
            id = "FUEL-002",
            vehicleReg = "KCL 703C",
            driverName = "David Otieno",
            stationName = "TotalEnergies Bondo Road",
            date = "06 Oct 2026",
            odometerKm = 98150,
            litersPumped = 40.0,
            pricePerLiterKes = 218.00,
            totalAmountKes = 8720.00,
            receiptOrMpesaRef = "TOT-BND-4819",
            fuelCardNumber = "JABIMA-PETRO-018",
            calculatedEfficiencyKmPerL = 9.6,
            notes = "Refueled for Rangala chapel night vigil."
        ),
        FleetFuelLogRecord(
            id = "FUEL-003",
            vehicleReg = "KBR 104R",
            driverName = "Charles Onyango",
            stationName = "Shell Siaya Town",
            date = "05 Oct 2026",
            odometerKm = 115200,
            litersPumped = 50.0,
            pricePerLiterKes = 217.50,
            totalAmountKes = 10875.00,
            receiptOrMpesaRef = "SHL-SIA-8812",
            fuelCardNumber = "JABIMA-PETRO-031",
            calculatedEfficiencyKmPerL = 10.5,
            notes = "Hospital transfer reserve fuel."
        )
    )

    private val _fleetFuelLogs = MutableStateFlow(initialFuelLogs)
    val fleetFuelLogs: StateFlow<List<FleetFuelLogRecord>> = _fleetFuelLogs.asStateFlow()

    fun recordFuelLog(record: FleetFuelLogRecord) {
        _fleetFuelLogs.value = listOf(record) + _fleetFuelLogs.value
    }

    // ==========================================
    // INSTANT M-PESA B2C PAYOUT WORKFLOW
    // ==========================================
    fun disburseInstantMpesaB2c(
        staffId: String,
        amount: Double,
        phone: String,
        category: String,
        reason: String
    ): MpesaB2cReceipt {
        val staff = _accounts.value.firstOrNull { it.id == staffId }
            ?: _accounts.value.first()
        val mpesaCode = "QHX" + (1000000..9999999).random().toString()
        val dateStr = SimpleDateFormat("dd MMM yyyy", Locale.getDefault()).format(Date())
        val timeStr = SimpleDateFormat("HH:mm:ss", Locale.getDefault()).format(Date()) + " EAT"
        val formattedAmount = String.format("%,.2f", amount)

        val smsText = "$mpesaCode Confirmed. Ksh $formattedAmount sent to ${staff.fullName} $phone on $dateStr at $timeStr. Transfer fee Ksh 0.00. Utility Balance: 889420 (Jabima Funeral Directors Ltd Payroll)."

        // Record immediate deduction in Wallet Transactions
        val txn = WalletTransaction(
            id = "TXN-" + UUID.randomUUID().toString().take(6).uppercase(),
            staffId = staffId,
            type = TransactionType.PAYOUT_WITHDRAWAL,
            title = "Instant M-PESA B2C: $category",
            referenceNumber = mpesaCode,
            amount = -amount,
            date = "$dateStr, $timeStr",
            status = PaymentStatus.DISBURSED,
            notes = "$reason (Daraja B2C Instant Disbursal via 889420)",
            payoutMethod = "M-PESA B2C Live Disbursement",
            payoutDestination = phone
        )
        _transactions.value = listOf(txn) + _transactions.value

        return MpesaB2cReceipt(
            transactionId = mpesaCode,
            recipientName = staff.fullName,
            recipientPhone = phone,
            staffId = staffId,
            amountKes = amount,
            disbursementCategory = category,
            date = dateStr,
            time = timeStr,
            status = "Success (200 OK - Disbursed)",
            b2cUtilityAccount = "889420 - Jabima Funeral Directors Ltd",
            safaricomSmsText = smsText
        )
    }

    // =========================================================================
    // 1. DASHBOARD DAILY FINANCIAL & PRODUCTION KPIS + 16 CASKET TYPES STOCK TABLE
    // =========================================================================
    private val _dashboardDailyKpis = MutableStateFlow(
        DashboardDailyKpis(
            totalMaterialCostsToday = 84500.0,
            finishedProductsToday = 8,
            productsInProduction = 14,
            totalSalesToday = 420000.0,
            totalStaffEarnings = 65000.0,
            totalPaymentsToday = 380000.0
        )
    )
    val dashboardDailyKpis: StateFlow<DashboardDailyKpis> = _dashboardDailyKpis.asStateFlow()

    // 16 Casket Types: Dragon, Dumu Mayai, English Coffin, Executive, Giraffe Flat,
    // Half Glass, Half Glass Dome, Kids, Kupa, Mini Executive, Modern High Roof,
    // Reagan, Saitoti, Simple, Tonny, VIP
    private val initialCasketStockByBranch = listOf(
        CasketStockByBranchRow("Dragon", mapOf("Bama Branch" to 8, "Bondo" to 3, "Matibabu" to 2, "Siaya opposite Shell Petrol" to 4, "Ukwala" to 1, "Uradi" to 2, "Siaya Referral (Opposite Morgue)" to 5, "Rangala" to 1), 65000.0),
        CasketStockByBranchRow("Dumu Mayai", mapOf("Bama Branch" to 6, "Bondo" to 2, "Matibabu" to 1, "Siaya opposite Shell Petrol" to 3, "Ukwala" to 1, "Uradi" to 1, "Siaya Referral (Opposite Morgue)" to 4, "Rangala" to 2), 55000.0),
        CasketStockByBranchRow("English Coffin", mapOf("Bama Branch" to 10, "Bondo" to 4, "Matibabu" to 3, "Siaya opposite Shell Petrol" to 5, "Ukwala" to 2, "Uradi" to 3, "Siaya Referral (Opposite Morgue)" to 6, "Rangala" to 2), 48000.0),
        CasketStockByBranchRow("Executive", mapOf("Bama Branch" to 12, "Bondo" to 5, "Matibabu" to 4, "Siaya opposite Shell Petrol" to 6, "Ukwala" to 3, "Uradi" to 2, "Siaya Referral (Opposite Morgue)" to 7, "Rangala" to 3), 110000.0),
        CasketStockByBranchRow("Giraffe Flat", mapOf("Bama Branch" to 5, "Bondo" to 2, "Matibabu" to 1, "Siaya opposite Shell Petrol" to 2, "Ukwala" to 1, "Uradi" to 1, "Siaya Referral (Opposite Morgue)" to 3, "Rangala" to 1), 58000.0),
        CasketStockByBranchRow("Half Glass", mapOf("Bama Branch" to 9, "Bondo" to 4, "Matibabu" to 2, "Siaya opposite Shell Petrol" to 5, "Ukwala" to 2, "Uradi" to 2, "Siaya Referral (Opposite Morgue)" to 6, "Rangala" to 2), 75000.0),
        CasketStockByBranchRow("Half Glass Dome", mapOf("Bama Branch" to 8, "Bondo" to 3, "Matibabu" to 3, "Siaya opposite Shell Petrol" to 4, "Ukwala" to 2, "Uradi" to 1, "Siaya Referral (Opposite Morgue)" to 5, "Rangala" to 2), 85000.0),
        CasketStockByBranchRow("Kids", mapOf("Bama Branch" to 7, "Bondo" to 2, "Matibabu" to 2, "Siaya opposite Shell Petrol" to 3, "Ukwala" to 1, "Uradi" to 1, "Siaya Referral (Opposite Morgue)" to 4, "Rangala" to 1), 30000.0),
        CasketStockByBranchRow("Kupa", mapOf("Bama Branch" to 6, "Bondo" to 2, "Matibabu" to 1, "Siaya opposite Shell Petrol" to 3, "Ukwala" to 1, "Uradi" to 2, "Siaya Referral (Opposite Morgue)" to 3, "Rangala" to 1), 52000.0),
        CasketStockByBranchRow("Mini Executive", mapOf("Bama Branch" to 8, "Bondo" to 3, "Matibabu" to 2, "Siaya opposite Shell Petrol" to 4, "Ukwala" to 2, "Uradi" to 1, "Siaya Referral (Opposite Morgue)" to 5, "Rangala" to 2), 88000.0),
        CasketStockByBranchRow("Modern High Roof", mapOf("Bama Branch" to 11, "Bondo" to 4, "Matibabu" to 3, "Siaya opposite Shell Petrol" to 6, "Ukwala" to 2, "Uradi" to 3, "Siaya Referral (Opposite Morgue)" to 7, "Rangala" to 3), 125000.0),
        CasketStockByBranchRow("Reagan", mapOf("Bama Branch" to 7, "Bondo" to 3, "Matibabu" to 2, "Siaya opposite Shell Petrol" to 4, "Ukwala" to 1, "Uradi" to 2, "Siaya Referral (Opposite Morgue)" to 4, "Rangala" to 2), 95000.0),
        CasketStockByBranchRow("Saitoti", mapOf("Bama Branch" to 9, "Bondo" to 3, "Matibabu" to 2, "Siaya opposite Shell Petrol" to 4, "Ukwala" to 2, "Uradi" to 2, "Siaya Referral (Opposite Morgue)" to 5, "Rangala" to 2), 105000.0),
        CasketStockByBranchRow("Simple", mapOf("Bama Branch" to 14, "Bondo" to 6, "Matibabu" to 5, "Siaya opposite Shell Petrol" to 8, "Ukwala" to 4, "Uradi" to 4, "Siaya Referral (Opposite Morgue)" to 9, "Rangala" to 5), 25000.0),
        CasketStockByBranchRow("Tonny", mapOf("Bama Branch" to 6, "Bondo" to 2, "Matibabu" to 1, "Siaya opposite Shell Petrol" to 3, "Ukwala" to 1, "Uradi" to 1, "Siaya Referral (Opposite Morgue)" to 4, "Rangala" to 1), 60000.0),
        CasketStockByBranchRow("VIP", mapOf("Bama Branch" to 10, "Bondo" to 4, "Matibabu" to 3, "Siaya opposite Shell Petrol" to 5, "Ukwala" to 2, "Uradi" to 2, "Siaya Referral (Opposite Morgue)" to 6, "Rangala" to 3), 140000.0)
    )
    private val _casketStockByBranch = MutableStateFlow(initialCasketStockByBranch)
    val casketStockByBranch: StateFlow<List<CasketStockByBranchRow>> = _casketStockByBranch.asStateFlow()

    // =========================================================================
    // 2. LIVE WORKSHOP OVERVIEW & 4 PRODUCTION STAGES
    // =========================================================================
    private val initialWorkshopItems = listOf(
        WorkshopProductionItem(
            id = "PRD-2026-081",
            casketType = "Executive",
            woodType = "Seasoned Mahogany",
            currentStage = WorkshopProductionStage.CLOTH_LINING_AND_FINAL_ASSEMBLY,
            percentageDone = 75,
            assignedCraftsmanId = "WRK-001",
            assignedCraftsmanName = "Brian Adoche",
            isDoneForDay = false,
            isCompleted = false,
            startedDate = "08 Oct 2026",
            targetCompletionDate = "10 Oct 2026",
            notes = "Family requested Royal Ivory satin quilted lining with double brass swing handles",
            sellingPriceKes = 110000.0,
            materialCostKes = 38500.0,
            laborCostKes = 12000.0,
            finishingCostKes = 6500.0
        ),
        WorkshopProductionItem(
            id = "PRD-2026-082",
            casketType = "Modern High Roof",
            woodType = "Imported Hardwood Teak",
            currentStage = WorkshopProductionStage.SANDING_AND_PAINTING,
            percentageDone = 50,
            assignedCraftsmanId = "WRK-002",
            assignedCraftsmanName = "Peter Ochieng",
            isDoneForDay = false,
            isCompleted = false,
            startedDate = "08 Oct 2026",
            targetCompletionDate = "11 Oct 2026",
            notes = "Applying 3 coats of polyurethane high-gloss walnut finish",
            sellingPriceKes = 125000.0,
            materialCostKes = 42000.0,
            laborCostKes = 9500.0,
            finishingCostKes = 5200.0
        ),
        WorkshopProductionItem(
            id = "PRD-2026-083",
            casketType = "VIP",
            woodType = "Prime Hardwood & Oak",
            currentStage = WorkshopProductionStage.GLASS_FITTING,
            percentageDone = 95,
            assignedCraftsmanId = "WRK-003",
            assignedCraftsmanName = "Kennedy Odhiambo",
            isDoneForDay = true,
            isCompleted = false,
            startedDate = "06 Oct 2026",
            targetCompletionDate = "09 Oct 2026",
            notes = "Tempered viewing glass installed, airtight seal and gold trim latch fitted",
            sellingPriceKes = 140000.0,
            materialCostKes = 46000.0,
            laborCostKes = 14000.0,
            finishingCostKes = 8500.0
        ),
        WorkshopProductionItem(
            id = "PRD-2026-084",
            casketType = "Half Glass Dome",
            woodType = "Cypress & Cedar Core",
            currentStage = WorkshopProductionStage.FRAME_AND_ASSEMBLY,
            percentageDone = 25,
            assignedCraftsmanId = "WRK-004",
            assignedCraftsmanName = "John Otieno",
            isDoneForDay = false,
            isCompleted = false,
            startedDate = "09 Oct 2026",
            targetCompletionDate = "12 Oct 2026",
            notes = "Base frame glued and nailed, corner joint brackets secured",
            sellingPriceKes = 85000.0,
            materialCostKes = 24000.0,
            laborCostKes = 6500.0,
            finishingCostKes = 0.0
        ),
        WorkshopProductionItem(
            id = "PRD-2026-085",
            casketType = "Dragon",
            woodType = "Seasoned Pine",
            currentStage = WorkshopProductionStage.SANDING_AND_PAINTING,
            percentageDone = 50,
            assignedCraftsmanId = "WRK-005",
            assignedCraftsmanName = "Evans Omolo",
            isDoneForDay = false,
            isCompleted = false,
            startedDate = "07 Oct 2026",
            targetCompletionDate = "10 Oct 2026",
            notes = "Primer smoothed, deep mahogany stain applied",
            sellingPriceKes = 65000.0,
            materialCostKes = 19500.0,
            laborCostKes = 6000.0,
            finishingCostKes = 3200.0
        ),
        WorkshopProductionItem(
            id = "PRD-2026-086",
            casketType = "Reagan",
            woodType = "Hardwood Mahogany",
            currentStage = WorkshopProductionStage.GLASS_FITTING,
            percentageDone = 100,
            assignedCraftsmanId = "WRK-001",
            assignedCraftsmanName = "Brian Adoche",
            isDoneForDay = true,
            isCompleted = true,
            startedDate = "05 Oct 2026",
            targetCompletionDate = "09 Oct 2026",
            notes = "Complete QA passed, transferred to Bama showroom dispatch",
            sellingPriceKes = 95000.0,
            materialCostKes = 31000.0,
            laborCostKes = 10000.0,
            finishingCostKes = 6800.0
        ),
        WorkshopProductionItem(
            id = "PRD-2026-087",
            casketType = "Mini Executive",
            woodType = "Oak Hardwood",
            currentStage = WorkshopProductionStage.CLOTH_LINING_AND_FINAL_ASSEMBLY,
            percentageDone = 75,
            assignedCraftsmanId = "WRK-002",
            assignedCraftsmanName = "Peter Ochieng",
            isDoneForDay = true,
            isCompleted = false,
            startedDate = "07 Oct 2026",
            targetCompletionDate = "10 Oct 2026",
            notes = "White silk lining with edge gold rope trim",
            sellingPriceKes = 88000.0,
            materialCostKes = 28500.0,
            laborCostKes = 8500.0,
            finishingCostKes = 4500.0
        ),
        WorkshopProductionItem(
            id = "PRD-2026-088",
            casketType = "Saitoti",
            woodType = "Heavy Grain Hardwood",
            currentStage = WorkshopProductionStage.FRAME_AND_ASSEMBLY,
            percentageDone = 25,
            assignedCraftsmanId = "WRK-003",
            assignedCraftsmanName = "Kennedy Odhiambo",
            isDoneForDay = false,
            isCompleted = false,
            startedDate = "09 Oct 2026",
            targetCompletionDate = "13 Oct 2026",
            notes = "Side panels clamped, bottom reinforcement fitted",
            sellingPriceKes = 105000.0,
            materialCostKes = 34000.0,
            laborCostKes = 9000.0,
            finishingCostKes = 2000.0
        )
    )
    private val _workshopItems = MutableStateFlow(initialWorkshopItems)
    val workshopItems: StateFlow<List<WorkshopProductionItem>> = _workshopItems.asStateFlow()

    fun updateWorkshopStage(
        itemId: String,
        nextStage: WorkshopProductionStage,
        percentage: Int,
        stageCostAddKes: Double = 0.0,
        allocatedBy: String = "Auto-BOM Engine"
    ): String {
        var shouldTransferToStore = false
        val deductedSummary = mutableListOf<String>()

        val currentJob = _workshopItems.value.firstOrNull { it.id == itemId }
        val autoAllocations = mutableListOf<WorkshopMaterialAllocation>()
        var autoMaterialCost = 0.0

        if (currentJob != null && !currentJob.autoBomDeductedStages.contains(nextStage.name)) {
            val bomRecipe: List<Pair<String, Int>> = when (nextStage) {
                WorkshopProductionStage.FRAME_AND_ASSEMBLY -> listOf("MAT-001" to 2, "MAT-002" to 2)
                WorkshopProductionStage.SANDING_AND_PAINTING -> listOf("MAT-008" to 1, "MAT-009" to 1)
                WorkshopProductionStage.CLOTH_LINING_AND_FINAL_ASSEMBLY -> listOf("MAT-003" to 1, "MAT-005" to 1)
                WorkshopProductionStage.GLASS_FITTING -> listOf("MAT-010" to 1, "MAT-007" to 1)
            }
            val today = shortDateFormat.format(Date())
            bomRecipe.forEach { (matId, reqQty) ->
                val mat = _inventoryMaterials.value.firstOrNull { it.id == matId }
                if (mat != null && mat.quantity > 0) {
                    val actualQty = minOf(reqQty, mat.quantity)
                    val cost = actualQty * mat.unitCostKes
                    autoMaterialCost += cost
                    autoAllocations.add(
                        WorkshopMaterialAllocation(
                            materialId = mat.id,
                            materialName = "${mat.name} [Auto-BOM]",
                            quantity = actualQty,
                            unit = mat.unit,
                            unitCostKes = mat.unitCostKes,
                            totalCostKes = cost,
                            allocatedDate = today,
                            allocatedBy = allocatedBy
                        )
                    )
                    deductedSummary.add("${actualQty}x ${mat.name}")
                    _inventoryMaterials.value = _inventoryMaterials.value.map { m ->
                        if (m.id == mat.id) {
                            val remaining = (m.quantity - actualQty).coerceAtLeast(0)
                            val nextStatus = when {
                                remaining == 0 -> "OUT_OF_STOCK"
                                remaining <= m.minThreshold -> "LOW_STOCK"
                                else -> "IN_STOCK"
                            }
                            m.copy(quantity = remaining, status = nextStatus)
                        } else m
                    }
                }
            }
        }

        _workshopItems.value = _workshopItems.value.map { item ->
            if (item.id == itemId) {
                val completed = nextStage == WorkshopProductionStage.GLASS_FITTING && percentage >= 100
                if (completed && !item.isCompleted) {
                    shouldTransferToStore = true
                }
                val addLabor = if (nextStage == WorkshopProductionStage.FRAME_AND_ASSEMBLY || nextStage == WorkshopProductionStage.CLOTH_LINING_AND_FINAL_ASSEMBLY) stageCostAddKes else 0.0
                val addFinish = if (nextStage == WorkshopProductionStage.SANDING_AND_PAINTING || nextStage == WorkshopProductionStage.GLASS_FITTING) stageCostAddKes else 0.0
                val updatedStages = if (item.autoBomDeductedStages.contains(nextStage.name)) {
                    item.autoBomDeductedStages
                } else {
                    item.autoBomDeductedStages + nextStage.name
                }
                item.copy(
                    currentStage = nextStage,
                    percentageDone = percentage.coerceIn(0, 100),
                    isCompleted = completed,
                    isDoneForDay = if (completed) true else item.isDoneForDay,
                    materialCostKes = item.materialCostKes + autoMaterialCost,
                    laborCostKes = item.laborCostKes + addLabor,
                    finishingCostKes = item.finishingCostKes + addFinish,
                    allocatedMaterials = item.allocatedMaterials + autoAllocations,
                    autoBomDeductedStages = updatedStages
                )
            } else item
        }

        if (autoMaterialCost > 0) {
            _dashboardDailyKpis.value = _dashboardDailyKpis.value.copy(
                totalMaterialCostsToday = _dashboardDailyKpis.value.totalMaterialCostsToday + autoMaterialCost
            )
        }

        // Evaluate BOM Margin Guard after deduction
        _workshopItems.value.firstOrNull { it.id == itemId }?.let { updated ->
            val eval = PayrollRulesEngine.evaluateBomMargin(
                sellingPriceKes = updated.sellingPriceKes,
                materialCostKes = updated.materialCostKes,
                laborCostKes = updated.laborCostKes,
                finishingCostKes = updated.finishingCostKes
            )
            if (eval.status != MarginStatus.HEALTHY && eval.warningMessage != null) {
                raiseMarginGuardAlert(
                    casketName = "${updated.casketType} (#${updated.id})",
                    warningMessage = eval.warningMessage,
                    relatedEntityId = updated.id
                )
            }
        }

        if (shouldTransferToStore) {
            completeWorkshopJobToStore(itemId)
        }

        return if (deductedSummary.isNotEmpty()) {
            "BOM Auto-Deducted: ${deductedSummary.joinToString(", ")}"
        } else {
            "Stage updated to ${nextStage.title}"
        }
    }

    fun addWorkshopProductionStageCost(
        itemId: String,
        laborAddKes: Double,
        finishingAddKes: Double
    ) {
        _workshopItems.value = _workshopItems.value.map { item ->
            if (item.id == itemId) {
                item.copy(
                    laborCostKes = item.laborCostKes + laborAddKes.coerceAtLeast(0.0),
                    finishingCostKes = item.finishingCostKes + finishingAddKes.coerceAtLeast(0.0)
                )
            } else item
        }
    }

    fun allocateMaterialToWorkshopJob(
        jobId: String,
        materialId: String,
        quantity: Int,
        allocatedBy: String
    ): Boolean {
        val mat = _inventoryMaterials.value.firstOrNull { it.id == materialId } ?: return false
        if (quantity <= 0 || mat.quantity < quantity) return false
        val totalCost = quantity * mat.unitCostKes
        val today = shortDateFormat.format(Date())

        _inventoryMaterials.value = _inventoryMaterials.value.map { m ->
            if (m.id == materialId) {
                val remaining = (m.quantity - quantity).coerceAtLeast(0)
                val nextStatus = when {
                    remaining == 0 -> "OUT_OF_STOCK"
                    remaining <= m.minThreshold -> "LOW_STOCK"
                    else -> "IN_STOCK"
                }
                m.copy(quantity = remaining, status = nextStatus)
            } else m
        }

        val allocation = WorkshopMaterialAllocation(
            materialId = mat.id,
            materialName = mat.name,
            quantity = quantity,
            unit = mat.unit,
            unitCostKes = mat.unitCostKes,
            totalCostKes = totalCost,
            allocatedDate = today,
            allocatedBy = allocatedBy
        )

        _workshopItems.value = _workshopItems.value.map { job ->
            if (job.id == jobId) {
                job.copy(
                    materialCostKes = job.materialCostKes + totalCost,
                    allocatedMaterials = job.allocatedMaterials + allocation
                )
            } else job
        }

        _dashboardDailyKpis.value = _dashboardDailyKpis.value.copy(
            totalMaterialCostsToday = _dashboardDailyKpis.value.totalMaterialCostsToday + totalCost
        )
        return true
    }

    fun completeWorkshopJobToStore(itemId: String): Boolean {
        val job = _workshopItems.value.firstOrNull { it.id == itemId } ?: return false
        _workshopItems.value = _workshopItems.value.map { item ->
            if (item.id == itemId) {
                item.copy(
                    currentStage = WorkshopProductionStage.GLASS_FITTING,
                    percentageDone = 100,
                    isCompleted = true,
                    isDoneForDay = true
                )
            } else item
        }

        val today = shortDateFormat.format(Date())
        // 1. Sync Finished Product Inventory
        val existingProdIdx = _inventoryProducts.value.indexOfFirst {
            (it.casketType.equals(job.casketType, ignoreCase = true) || it.name.contains(job.casketType, ignoreCase = true)) &&
                it.category.equals("Casket", ignoreCase = true)
        }
        if (existingProdIdx >= 0) {
            _inventoryProducts.value = _inventoryProducts.value.mapIndexed { idx, prod ->
                if (idx == existingProdIdx) {
                    prod.copy(
                        stockCount = prod.stockCount + 1,
                        costPriceKes = if (job.totalProductionCostKes > 0) job.totalProductionCostKes else prod.costPriceKes,
                        sellingPriceKes = if (job.sellingPriceKes > 0) job.sellingPriceKes else prod.sellingPriceKes
                    )
                } else prod
            }
        } else {
            val newProd = ProductItem(
                id = "PRD-CK-" + (100 + _inventoryProducts.value.size),
                name = "${job.casketType} Casket",
                category = "Casket",
                casketType = job.casketType,
                stockCount = 1,
                costPriceKes = job.totalProductionCostKes.takeIf { it > 0 } ?: 45000.0,
                sellingPriceKes = job.sellingPriceKes.takeIf { it > 0 } ?: 95000.0,
                branchWarehouse = "Bama Branch",
                dateAdded = today,
                addedBy = job.assignedCraftsmanName
            )
            _inventoryProducts.value = listOf(newProd) + _inventoryProducts.value
        }

        // 2. Sync Sales Caskets Catalog
        val existingCasketIdx = _caskets.value.indexOfFirst {
            it.name.equals(job.casketType, ignoreCase = true) || it.name.contains(job.casketType, ignoreCase = true)
        }
        if (existingCasketIdx >= 0) {
            _caskets.value = _caskets.value.mapIndexed { idx, csk ->
                if (idx == existingCasketIdx) {
                    val newStock = csk.stockCount + 1
                    csk.copy(stockCount = newStock, inStock = newStock > 0)
                } else csk
            }
        } else {
            val newCasket = CasketItem(
                id = "CSK-PRD-" + (100 + _caskets.value.size),
                name = job.casketType,
                woodType = job.woodType,
                finish = "High-Gloss Polyurethane Polish",
                interiorLining = "Quilted Ivory Satin Lining",
                tier = if (job.isCustomDesign) "Custom Workshop Edition" else "Workshop Handcrafted",
                priceKes = job.sellingPriceKes.takeIf { it > 0 } ?: 95000.0,
                priceUsd = Math.round((job.sellingPriceKes.takeIf { it > 0 } ?: 95000.0) / 130.0).toDouble(),
                inStock = true,
                stockCount = 1,
                features = listOf("Crafted at Bama Workshop", "Total Cost KES ${String.format("%,.0f", job.totalProductionCostKes)}", "QA Certified")
            )
            _caskets.value = listOf(newCasket) + _caskets.value
        }

        // 3. Sync Branch Stock Matrix
        val branchIdx = _casketStockByBranch.value.indexOfFirst { it.casketType.equals(job.casketType, ignoreCase = true) }
        if (branchIdx >= 0) {
            _casketStockByBranch.value = _casketStockByBranch.value.mapIndexed { idx, row ->
                if (idx == branchIdx) {
                    val map = row.branchStockMap.toMutableMap()
                    map["Bama Branch"] = (map["Bama Branch"] ?: 0) + 1
                    row.copy(branchStockMap = map)
                } else row
            }
        } else {
            _casketStockByBranch.value = listOf(
                CasketStockByBranchRow(
                    casketType = job.casketType,
                    branchStockMap = mapOf("Bama Branch" to 1),
                    priceKes = job.sellingPriceKes.takeIf { it > 0 } ?: 95000.0
                )
            ) + _casketStockByBranch.value
        }

        _dashboardDailyKpis.value = _dashboardDailyKpis.value.copy(
            finishedProductsToday = _dashboardDailyKpis.value.finishedProductsToday + 1
        )
        return true
    }

    fun assignCraftsmanToWorkshopItem(itemId: String, craftsmanId: String, craftsmanName: String) {
        _workshopItems.value = _workshopItems.value.map { item ->
            if (item.id == itemId) {
                item.copy(assignedCraftsmanId = craftsmanId, assignedCraftsmanName = craftsmanName)
            } else item
        }
        dispatchStaffAlert(
            recipientStaffId = craftsmanId,
            recipientName = craftsmanName,
            title = "Workshop Production Job Assigned",
            message = "You have been assigned workshop production job $itemId.",
            category = "TASK_ASSIGNED",
            relatedEntityId = itemId
        )
    }

    fun markWorkshopItemDoneForDay(itemId: String, isDone: Boolean) {
        _workshopItems.value = _workshopItems.value.map { item ->
            if (item.id == itemId) {
                item.copy(isDoneForDay = isDone)
            } else item
        }
    }

    fun createWorkshopItem(
        casketType: String,
        craftsmanId: String,
        craftsmanName: String,
        initialStage: WorkshopProductionStage = WorkshopProductionStage.FRAME_AND_ASSEMBLY,
        notes: String = "",
        sellingPriceKes: Double = 95000.0,
        materialCostKes: Double = 25000.0,
        laborCostKes: Double = 8000.0,
        finishingCostKes: Double = 4000.0
    ) {
        val newId = "PRD-2026-" + (100..999).random().toString()
        val todayStr = SimpleDateFormat("dd MMM yyyy", Locale.getDefault()).format(Date())
        val matchedPrice = _caskets.value.firstOrNull { it.name.contains(casketType, ignoreCase = true) }?.priceKes
            ?: _casketStockByBranch.value.firstOrNull { it.casketType.equals(casketType, ignoreCase = true) }?.priceKes
            ?: sellingPriceKes
        val newItem = WorkshopProductionItem(
            id = newId,
            casketType = casketType,
            currentStage = initialStage,
            percentageDone = initialStage.defaultPercentage,
            assignedCraftsmanId = craftsmanId,
            assignedCraftsmanName = craftsmanName,
            isDoneForDay = false,
            isCompleted = false,
            startedDate = todayStr,
            targetCompletionDate = "14 Oct 2026",
            notes = notes,
            sellingPriceKes = matchedPrice,
            materialCostKes = materialCostKes,
            laborCostKes = laborCostKes,
            finishingCostKes = finishingCostKes
        )
        _workshopItems.value = listOf(newItem) + _workshopItems.value
        dispatchStaffAlert(
            recipientStaffId = craftsmanId,
            recipientName = craftsmanName,
            title = "New Workshop Job: $casketType",
            message = "Production job $newId ($casketType) assigned at stage ${initialStage.title}.",
            category = "TASK_ASSIGNED",
            relatedEntityId = newId
        )
    }

    fun createCustomProductionCasketType(
        name: String,
        woodType: String,
        tier: String,
        finish: String,
        interiorLining: String,
        sellingPriceKes: Double,
        materialCostKes: Double,
        laborCostKes: Double,
        finishingCostKes: Double,
        craftsmanId: String,
        craftsmanName: String,
        branch: String = "Bama Branch",
        notes: String = ""
    ): WorkshopProductionItem {
        val cleanName = name.trim()
        val usd = Math.round(sellingPriceKes / 130.0).toDouble()
        // Add to sales casket catalog
        val existingCasket = _caskets.value.firstOrNull { it.name.equals(cleanName, ignoreCase = true) }
        if (existingCasket == null) {
            val newCasket = CasketItem(
                id = "CSK-CST-" + (100 + _caskets.value.size),
                name = cleanName,
                woodType = woodType.ifBlank { "Custom Timber Spec" },
                finish = finish.ifBlank { "Custom Satin Polish" },
                interiorLining = interiorLining.ifBlank { "Quilted Ivory Velvet" },
                tier = tier.ifBlank { "Custom Production Design" },
                priceKes = sellingPriceKes,
                priceUsd = usd,
                inStock = true,
                stockCount = 1,
                features = listOf("Custom Admin Design", woodType, finish)
            )
            _caskets.value = listOf(newCasket) + _caskets.value
        } else {
            _caskets.value = _caskets.value.map {
                if (it.id == existingCasket.id) it.copy(priceKes = sellingPriceKes, priceUsd = usd) else it
            }
        }

        // Sync Branch Stock Table
        if (_casketStockByBranch.value.none { it.casketType.equals(cleanName, ignoreCase = true) }) {
            _casketStockByBranch.value = listOf(
                CasketStockByBranchRow(
                    casketType = cleanName,
                    branchStockMap = mapOf(branch to 1),
                    priceKes = sellingPriceKes
                )
            ) + _casketStockByBranch.value
        }

        val todayStr = shortDateFormat.format(Date())
        val jobId = "PRD-CST-" + (100..999).random()
        val job = WorkshopProductionItem(
            id = jobId,
            casketType = cleanName,
            woodType = woodType.ifBlank { "Custom Timber" },
            currentStage = WorkshopProductionStage.FRAME_AND_ASSEMBLY,
            percentageDone = 25,
            assignedCraftsmanId = craftsmanId,
            assignedCraftsmanName = craftsmanName,
            isDoneForDay = false,
            isCompleted = false,
            startedDate = todayStr,
            targetCompletionDate = "16 Oct 2026",
            branch = branch,
            notes = notes.ifBlank { "Admin custom casket design queued for production" },
            sellingPriceKes = sellingPriceKes,
            materialCostKes = materialCostKes,
            laborCostKes = laborCostKes,
            finishingCostKes = finishingCostKes,
            isCustomDesign = true
        )
        _workshopItems.value = listOf(job) + _workshopItems.value
        dispatchStaffAlert(
            recipientStaffId = craftsmanId,
            recipientName = craftsmanName,
            title = "Custom Casket Design Assigned: $cleanName",
            message = "Admin set price KES ${String.format("%,.0f", sellingPriceKes)}. Craft job $jobId started.",
            category = "TASK_ASSIGNED",
            relatedEntityId = jobId
        )
        return job
    }

    // =========================================================================
    // 3. INVENTORY MANAGEMENT (Overview, Products Tab, Materials Categories Tab)
    // =========================================================================
    private val initialMaterialCategories = listOf(
        MaterialCategory("CAT-01", "Hardwood & Seasoned Timber", "Mahogany, Cypress, Teak and Pine planks for casket frames", "Running Feet / Planks", 15, 24, 780000.0),
        MaterialCategory("CAT-02", "Satin & Velvet Linings", "Quilted pure silk, ivory satin, pleated foam and royal blue velvet", "Meters / Rolls", 10, 18, 340000.0),
        MaterialCategory("CAT-03", "Brass Handles & Cross Fittings", "Cast brass swing bars, corner brackets, crucifixes and nameplates", "Sets / Pieces", 20, 32, 420000.0),
        MaterialCategory("CAT-04", "Glass & Dome Fittings", "Tempered viewing glass, dome seals, rubber gaskets and latches", "Panels / Units", 8, 12, 290000.0),
        MaterialCategory("CAT-05", "Paints, Primers & Varnishes", "Polyurethane gloss, walnut wood stain, primers and spray thinners", "Liters / Cans", 12, 16, 210000.0),
        MaterialCategory("CAT-06", "Fasteners, Glues & Screws", "Heavy-duty timber screws, wood glue, staples and brass pins", "Boxes / Kg", 25, 40, 110000.0),
        MaterialCategory("CAT-07", "Mortuary Chemicals & PPE", "Embalming fluids, sanitizers, gloves, face shields and body bags", "Bottles / Sets", 30, 22, 295000.0)
    )
    private val _materialCategories = MutableStateFlow(initialMaterialCategories)
    val materialCategories: StateFlow<List<MaterialCategory>> = _materialCategories.asStateFlow()

    fun addMaterialCategory(category: MaterialCategory) {
        _materialCategories.value = _materialCategories.value + category
    }

    fun updateMaterialCategory(category: MaterialCategory) {
        _materialCategories.value = _materialCategories.value.map {
            if (it.id == category.id) category else it
        }
    }

    private val initialInventoryMaterials = listOf(
        InventoryMaterialItem("MAT-001", "Seasoned Mahogany Planks 12ft", "CAT-01", "Hardwood & Seasoned Timber", 85, "Planks", 2800.0, 20, "Bama Branch", "IN_STOCK"),
        InventoryMaterialItem("MAT-002", "Cypress Frame Beams 2x4", "CAT-01", "Hardwood & Seasoned Timber", 120, "Beams", 1200.0, 25, "Bama Branch", "IN_STOCK"),
        InventoryMaterialItem("MAT-003", "Ivory Satin Quilted Fabric", "CAT-02", "Satin & Velvet Linings", 8, "Rolls", 9500.0, 10, "Bama Branch", "LOW_STOCK"),
        InventoryMaterialItem("MAT-004", "Royal Blue Velvet Lining", "CAT-02", "Satin & Velvet Linings", 14, "Rolls", 11000.0, 8, "Bama Branch", "IN_STOCK"),
        InventoryMaterialItem("MAT-005", "Cast Brass Swing Bar Handles", "CAT-03", "Brass Handles & Cross Fittings", 32, "Sets", 4500.0, 15, "Bama Branch", "IN_STOCK"),
        InventoryMaterialItem("MAT-006", "Gold-Plated Crucifix Badges", "CAT-03", "Brass Handles & Cross Fittings", 5, "Pieces", 1800.0, 10, "Bama Branch", "LOW_STOCK"),
        InventoryMaterialItem("MAT-007", "Tempered Half-Glass Viewing Panels", "CAT-04", "Glass & Dome Fittings", 0, "Panels", 6500.0, 5, "Bama Branch", "OUT_OF_STOCK"),
        InventoryMaterialItem("MAT-008", "High-Gloss Clear Polyurethane Varnish", "CAT-05", "Paints, Primers & Varnishes", 22, "Tins (4L)", 3200.0, 12, "Bama Branch", "IN_STOCK"),
        InventoryMaterialItem("MAT-009", "Walnut Dark Wood Stain", "CAT-05", "Paints, Primers & Varnishes", 18, "Tins (4L)", 2600.0, 8, "Bama Branch", "IN_STOCK"),
        InventoryMaterialItem("MAT-010", "Industrial Woodworking Adhesive Glue", "CAT-06", "Fasteners, Glues & Screws", 35, "Tins (5kg)", 1950.0, 10, "Bama Branch", "IN_STOCK"),
        InventoryMaterialItem("MAT-011", "12mm Chipboard Boards", "CAT-01", "Hardwood & Seasoned Timber", 64, "Sheets", 2500.0, 15, "Bama Branch", "IN_STOCK"),
        InventoryMaterialItem("MAT-012", "9mm Plywood Sheets", "CAT-01", "Hardwood & Seasoned Timber", 42, "Sheets", 1700.0, 12, "Bama Branch", "IN_STOCK"),
        InventoryMaterialItem("MAT-013", "Hard Board Dome Sheets", "CAT-01", "Hardwood & Seasoned Timber", 48, "Sheets", 800.0, 12, "Bama Branch", "IN_STOCK"),
        InventoryMaterialItem("MAT-014", "Timber 6x1.5 Framing", "CAT-01", "Hardwood & Seasoned Timber", 450, "Feet", 30.0, 100, "Bama Branch", "IN_STOCK"),
        InventoryMaterialItem("MAT-015", "Last Supper Handle Sets", "CAT-03", "Brass Handles & Cross Fittings", 20, "Sets", 2500.0, 6, "Bama Branch", "IN_STOCK"),
        InventoryMaterialItem("MAT-016", "Swing Bar Handle Sets", "CAT-03", "Brass Handles & Cross Fittings", 18, "Sets", 6500.0, 6, "Bama Branch", "IN_STOCK"),
        InventoryMaterialItem("MAT-017", "Foam Form Sheets", "CAT-02", "Satin & Velvet Linings", 90, "Sheets", 150.0, 20, "Bama Branch", "IN_STOCK"),
        InventoryMaterialItem("MAT-018", "AC Paints Tin", "CAT-05", "Paints, Primers & Varnishes", 24, "Tins", 2800.0, 8, "Bama Branch", "IN_STOCK"),
        InventoryMaterialItem("MAT-019", "Standard Thinner (5L)", "CAT-05", "Paints, Primers & Varnishes", 19, "Cans (5L)", 700.0, 6, "Bama Branch", "IN_STOCK"),
        InventoryMaterialItem("MAT-020", "Decorative Spindles Sets", "CAT-03", "Brass Handles & Cross Fittings", 14, "Sets", 3000.0, 5, "Bama Branch", "IN_STOCK")
    )
    private val _inventoryMaterials = MutableStateFlow(initialInventoryMaterials)
    val inventoryMaterials: StateFlow<List<InventoryMaterialItem>> = _inventoryMaterials.asStateFlow()

    private val initialInventoryProducts = listOf(
        ProductItem("PRD-CK-01", "Executive Casket", "Casket", "Executive", 12, 45000.0, 110000.0, "Bama Branch", "01 Oct 2026", "Fredrick Hayoyo (CEO)"),
        ProductItem("PRD-CK-02", "Modern High Roof Casket", "Casket", "Modern High Roof", 11, 52000.0, 125000.0, "Bama Branch", "02 Oct 2026", "Fredrick Hayoyo (CEO)"),
        ProductItem("PRD-CK-03", "VIP Casket", "Casket", "VIP", 10, 58000.0, 140000.0, "Bama Branch", "02 Oct 2026", "Fredrick Hayoyo (CEO)"),
        ProductItem("PRD-CK-04", "Half Glass Dome Casket", "Casket", "Half Glass Dome", 8, 38000.0, 85000.0, "Siaya Referral", "03 Oct 2026", "Fredrick Hayoyo (CEO)"),
        ProductItem("PRD-CK-05", "Dragon Casket", "Casket", "Dragon", 8, 29000.0, 65000.0, "Bama Branch", "03 Oct 2026", "Fredrick Hayoyo (CEO)"),
        ProductItem("PRD-CK-06", "Reagan Casket", "Casket", "Reagan", 7, 42000.0, 95000.0, "Bondo", "04 Oct 2026", "Fredrick Hayoyo (CEO)"),
        ProductItem("PRD-CK-07", "Saitoti Casket", "Casket", "Saitoti", 9, 46000.0, 105000.0, "Matibabu", "04 Oct 2026", "Fredrick Hayoyo (CEO)"),
        ProductItem("PRD-CK-08", "Simple Casket", "Casket", "Simple", 14, 12000.0, 25000.0, "Bama Branch", "04 Oct 2026", "Fredrick Hayoyo (CEO)"),
        ProductItem("PRD-EQ-09", "Church Trolley Bier", "Equipment", null, 6, 35000.0, 55000.0, "Bama Branch", "05 Oct 2026", "Fredrick Hayoyo (CEO)"),
        ProductItem("PRD-EQ-10", "Hydraulic Lowering Gear Set", "Equipment", null, 4, 180000.0, 280000.0, "Bama Branch", "05 Oct 2026", "Fredrick Hayoyo (CEO)")
    )
    private val _inventoryProducts = MutableStateFlow(initialInventoryProducts)
    val inventoryProducts: StateFlow<List<ProductItem>> = _inventoryProducts.asStateFlow()

    fun addProductItem(product: ProductItem) {
        _inventoryProducts.value = listOf(product) + _inventoryProducts.value
    }

    // =========================================================================
    // 4. DAILY REPORT TAB (Staff Submissions, Tasks Done, Unsubmitted Staff)
    // =========================================================================
    private val initialDailyReports = listOf(
        StaffDailyReport(
            id = "REP-2026-001",
            staffId = "WRK-001",
            staffName = "Brian Adoche",
            role = StaffRole.WORKSHOP_WORKER,
            department = Department.WORKSHOP,
            branch = "Bama Branch",
            date = "09 Oct 2026",
            submissionTime = "17:15 EAT",
            tasksDoneCount = 4,
            tasksSummary = listOf(
                "Completed satin lining for PRD-2026-081 (Executive Casket)",
                "Mounted cast brass handles and decorative cross",
                "Final inspection and buffing for PRD-2026-086 (Reagan Casket)",
                "Stock count of ivory satin rolls in timber storeroom"
            ),
            materialsUsedSummary = "2 Rolls Ivory Satin, 1 set brass handles, 16 zinc screws",
            hoursLogged = 8.5,
            notes = "Reagan casket passed all QA specs and is ready for dispatch."
        ),
        StaffDailyReport(
            id = "REP-2026-002",
            staffId = "DRV-001",
            staffName = "Erick Omondi",
            role = StaffRole.DRIVER,
            department = Department.DRIVERS,
            branch = "Bama Branch",
            date = "09 Oct 2026",
            submissionTime = "16:40 EAT",
            tasksDoneCount = 3,
            tasksSummary = listOf(
                "Pre-trip fleet inspection for hearse KDG 705Y",
                "Cortege escort to Bondo St. Andrew Church (Case REF-2026-99)",
                "Hearse exterior wash and interior velvet vacuuming at Bama base"
            ),
            materialsUsedSummary = "45 Liters diesel pumped at Shell Siaya (Total KES 7,850)",
            hoursLogged = 8.0,
            notes = "Smooth transit with zero mechanical issues."
        ),
        StaffDailyReport(
            id = "REP-2026-003",
            staffId = "OPR-001",
            staffName = "Duncan Odhiambo",
            role = StaffRole.OPERATOR,
            department = Department.OPERATORS,
            branch = "Bama Branch",
            date = "09 Oct 2026",
            submissionTime = "17:05 EAT",
            tasksDoneCount = 4,
            tasksSummary = listOf(
                "Gravesite setup at Nyang'oma: hydraulic lowering gear & grass mats",
                "Erected 2 family canopies, 60 chairs & ceremonial red carpet",
                "Assisted pallbearers with church bier trolley transition",
                "Sanitization and gear pack-up into transit van KCL 703C"
            ),
            materialsUsedSummary = "Lowering straps checked; hydraulic lubricant topped up",
            hoursLogged = 8.0,
            notes = "Gravesite lowering proceeded with utmost dignity and reverence."
        ),
        StaffDailyReport(
            id = "REP-2026-004",
            staffId = "SLS-001",
            staffName = "Mercy Achieng",
            role = StaffRole.SALES_MARKETING,
            department = Department.SALES_MARKETING,
            branch = "Siaya Referral (Opposite Morgue)",
            date = "09 Oct 2026",
            submissionTime = "16:55 EAT",
            tasksDoneCount = 3,
            tasksSummary = listOf(
                "Client family intake consultation for the late Mama Grace Otieno",
                "Secured Executive Casket booking + hearse escort package (KES 185,000)",
                "Reconciled M-PESA Daraja receipts with Accounts Officer"
            ),
            materialsUsedSummary = "Case dossier #REF-2026-104 opened; permit copied",
            hoursLogged = 7.5,
            notes = "Family satisfied with arrangements; 5% casket commission recorded."
        )
    )
    private val _dailyReports = MutableStateFlow(initialDailyReports)
    val dailyReports: StateFlow<List<StaffDailyReport>> = _dailyReports.asStateFlow()

    fun submitDailyReport(report: StaffDailyReport) {
        _dailyReports.value = listOf(report) + _dailyReports.value
    }

    // =========================================================================
    // 5. DYNAMIC BURIAL SCHEDULING INTERFACE & SERVICE TIMING REMINDERS
    // =========================================================================
    private val initialBurialSchedules = listOf(
        BurialScheduleEvent(
            id = "BUR-2026-042",
            caseReference = "REF-2026-99",
            deceasedName = "The late Mzee Peter Omolo",
            familyRepresentative = "Grace Omolo (+254 712 345 678)",
            familyPhone = "+254712345678",
            burialDate = "10 Oct 2026",
            casketModel = "Executive Casket",
            churchVenue = "St. Andrew Church, Bondo",
            gravesiteLocation = "Nyang'oma Homestead, Bondo",
            assignedHearseReg = "KDG 705Y",
            assignedDriverName = "Erick Omondi",
            assignedOperators = listOf("Duncan Odhiambo", "Samson Otieno"),
            assignedDirector = "Fredrick Hayoyo (CEO)",
            timings = listOf(
                BurialServiceTiming(FuneralArrangementStage.INTAKE_MORTUARY, "07:30 AM", "Bama Morgue Intake", listOf("DRV-001"), listOf("Erick Omondi"), "KDG 705Y", true, "09 Oct 18:00"),
                BurialServiceTiming(FuneralArrangementStage.FLEET_CORTEGE, "08:45 AM", "Bama Branch to Bondo Highway", listOf("DRV-001"), listOf("Erick Omondi"), "KDG 705Y", true, "09 Oct 18:00"),
                BurialServiceTiming(FuneralArrangementStage.CHAPEL_VIGIL, "10:30 AM", "St. Andrew Church Bondo", listOf("OPR-001", "OPR-002"), listOf("Duncan Odhiambo", "Samson Otieno"), null, false),
                BurialServiceTiming(FuneralArrangementStage.GRAVESITE_LOWERING, "01:30 PM", "Nyang'oma Gravesite", listOf("OPR-001", "OPR-002", "CEO-001"), listOf("Duncan Odhiambo", "Samson Otieno", "Fredrick Hayoyo"), "KDG 705Y", false)
            ),
            status = "Confirmed & Roster Synced",
            isRosterSynced = true
        ),
        BurialScheduleEvent(
            id = "BUR-2026-043",
            caseReference = "REF-2026-104",
            deceasedName = "The late Mama Grace Anyango",
            familyRepresentative = "Collins Otieno (+254 722 998 877)",
            familyPhone = "+254722998877",
            burialDate = "11 Oct 2026",
            casketModel = "Modern High Roof",
            churchVenue = "St. Peters Cathedral, Siaya",
            gravesiteLocation = "Ukwala Family Grounds, Siaya",
            assignedHearseReg = "KCL 703C",
            assignedDriverName = "James Mwangi",
            assignedOperators = listOf("Duncan Odhiambo", "Samson Otieno"),
            assignedDirector = "Fredrick Hayoyo (CEO)",
            timings = listOf(
                BurialServiceTiming(FuneralArrangementStage.INTAKE_MORTUARY, "07:00 AM", "Siaya Referral Cold Room", listOf("DRV-002"), listOf("James Mwangi"), "KCL 703C", false),
                BurialServiceTiming(FuneralArrangementStage.FLEET_CORTEGE, "08:15 AM", "Siaya Town Cortege Escort", listOf("DRV-002"), listOf("James Mwangi"), "KCL 703C", false),
                BurialServiceTiming(FuneralArrangementStage.CHAPEL_VIGIL, "09:30 AM", "St. Peters Cathedral", listOf("OPR-001", "OPR-002"), listOf("Duncan Odhiambo", "Samson Otieno"), null, false),
                BurialServiceTiming(FuneralArrangementStage.GRAVESITE_LOWERING, "02:00 PM", "Ukwala Gravesite", listOf("OPR-001", "OPR-002", "CEO-001"), listOf("Duncan Odhiambo", "Samson Otieno", "Fredrick Hayoyo"), "KCL 703C", false)
            ),
            status = "Confirmed & Roster Synced",
            isRosterSynced = true
        )
    )
    private val _burialSchedules = MutableStateFlow(initialBurialSchedules)
    val burialSchedules: StateFlow<List<BurialScheduleEvent>> = _burialSchedules.asStateFlow()

    private val initialServiceReminders = listOf(
        ServiceReminderLog(
            id = "RMD-001",
            burialScheduleId = "BUR-2026-042",
            deceasedName = "The late Mzee Peter Omolo",
            serviceStage = "Body Intake & Hearse Cortege",
            timing = "10 Oct 2026 at 07:30 AM",
            recipients = listOf("Erick Omondi (Driver)", "Duncan Odhiambo (Operator)", "Fredrick Hayoyo (CEO)"),
            messageText = "JABIMA SERVICE REMINDER: Upcoming cortege for the late Mzee Peter Omolo departs Bama Base at 08:45 AM. Assigned hearse KDG 705Y. Duty crew report by 07:15 AM.",
            timestamp = "09 Oct 2026, 18:00 EAT"
        )
    )
    private val _serviceReminderLogs = MutableStateFlow(initialServiceReminders)
    val serviceReminderLogs: StateFlow<List<ServiceReminderLog>> = _serviceReminderLogs.asStateFlow()

    fun addBurialSchedule(event: BurialScheduleEvent) {
        _burialSchedules.value = listOf(event) + _burialSchedules.value

        // Automatically sync with the Staff Shifts Roster:
        val dateParts = event.burialDate.split(" ")
        val dayName = "Saturday"
        val newShift = StaffShiftSchedule(
            id = "SFT-" + UUID.randomUUID().toString().take(6).uppercase(),
            staffId = "DRV-001",
            staffName = event.assignedDriverName,
            department = Department.DRIVERS,
            assignedBranch = "Bama Branch",
            shiftType = "Hearse Cortege & Burial Escort",
            dayOfWeek = dayName,
            dateFormatted = event.burialDate,
            availabilityStatus = "On-Duty Assigned",
            hearseAssigned = event.assignedHearseReg,
            notes = "Burial service for ${event.deceasedName} at ${event.gravesiteLocation}",
            shiftPeriod = ShiftPeriod.UPCOMING,
            startTime = "07:30",
            endTime = "17:00",
            caseReference = event.caseReference,
            familyName = event.deceasedName,
            destination = event.gravesiteLocation
        )
        _staffShiftSchedules.value = listOf(newShift) + _staffShiftSchedules.value
    }

    fun sendBurialServiceReminder(
        burialScheduleId: String,
        timingStage: FuneralArrangementStage,
        customMessage: String = ""
    ): ServiceReminderLog {
        val schedule = _burialSchedules.value.firstOrNull { it.id == burialScheduleId }
            ?: _burialSchedules.value.first()
        val timing = schedule.timings.firstOrNull { it.stage == timingStage }
            ?: schedule.timings.first()

        val recipientNames = timing.assignedStaffNames.ifEmpty {
            listOf(schedule.assignedDriverName, schedule.assignedDirector) + schedule.assignedOperators
        }
        val timeNow = SimpleDateFormat("dd MMM yyyy, HH:mm", Locale.getDefault()).format(Date()) + " EAT"
        val msg = if (customMessage.isNotBlank()) customMessage else {
            "JABIMA SERVICE TIMING ALERT: Reminder for ${schedule.deceasedName}. Stage: ${timingStage.label} at ${timing.timeFormatted} (${timing.venue}). Hearse: ${timing.assignedHearseReg ?: schedule.assignedHearseReg}. Please be on standby and properly equipped."
        }

        val log = ServiceReminderLog(
            id = "RMD-" + (1000..9999).random().toString(),
            burialScheduleId = burialScheduleId,
            deceasedName = schedule.deceasedName,
            serviceStage = timingStage.label,
            timing = "${schedule.burialDate} at ${timing.timeFormatted}",
            recipients = recipientNames,
            messageText = msg,
            timestamp = timeNow
        )

        _serviceReminderLogs.value = listOf(log) + _serviceReminderLogs.value

        // Mark timing as reminderSent
        _burialSchedules.value = _burialSchedules.value.map { b ->
            if (b.id == burialScheduleId) {
                b.copy(timings = b.timings.map { t ->
                    if (t.stage == timingStage) t.copy(reminderSent = true, lastReminderTime = timeNow) else t
                })
            } else b
        }

        return log
    }

    // ==========================================
    // ADMIN MASTER DATA MANAGEMENT: CRUD OPERATIONS
    // Allows Admin to Add, Edit, Replace, or Delete all information in the app
    // ==========================================

    fun deleteStaffAccount(staffId: String): Boolean {
        if (staffId == "CEO-001") return false
        _accounts.value = _accounts.value.filter { it.id != staffId }
        return true
    }

    fun addOrReplaceStaffAccount(account: StaffAccount) {
        val existing = _accounts.value.firstOrNull { it.id == account.id }
        val normalized = when {
            account.password.isNotBlank() -> {
                val raw = account.password.trim()
                account.copy(
                    password = "",
                    passwordHash = PasswordSecurityHelper.hashPassword(raw),
                    mustRotatePassword = PasswordSecurityHelper.isDefaultOrWeakPassword(raw)
                )
            }
            account.passwordHash.isBlank() && existing != null -> {
                account.copy(
                    password = "",
                    passwordHash = existing.passwordHash,
                    mustRotatePassword = existing.mustRotatePassword
                )
            }
            account.passwordHash.isBlank() -> {
                account.copy(
                    password = "",
                    passwordHash = PasswordSecurityHelper.hashPassword("123456"),
                    mustRotatePassword = true
                )
            }
            else -> account.copy(password = "")
        }
        val idx = _accounts.value.indexOfFirst { it.id == normalized.id }
        if (idx >= 0) {
            _accounts.value = _accounts.value.map { if (it.id == normalized.id) normalized else it }
        } else {
            _accounts.value = _accounts.value + normalized
        }
    }

    fun deleteCasketItem(casketId: String) {
        val casket = _caskets.value.firstOrNull { it.id == casketId }
        val name = casket?.name ?: casketId
        _caskets.value = _caskets.value.filter { it.id != casketId }
        _casketStockByBranch.value = _casketStockByBranch.value.filter { it.casketType != name }
    }

    fun addOrReplaceCasketItem(item: com.example.model.CasketItem) {
        val idx = _caskets.value.indexOfFirst { it.id == item.id }
        if (idx >= 0) {
            _caskets.value = _caskets.value.map { if (it.id == item.id) item else it }
        } else {
            _caskets.value = listOf(item) + _caskets.value
        }
    }

    fun deleteInventoryMaterial(materialId: String) {
        _inventoryMaterials.value = _inventoryMaterials.value.filter { it.id != materialId }
    }

    fun addOrReplaceInventoryMaterial(item: InventoryMaterialItem) {
        val idx = _inventoryMaterials.value.indexOfFirst { it.id == item.id }
        if (idx >= 0) {
            _inventoryMaterials.value = _inventoryMaterials.value.map { if (it.id == item.id) item else it }
        } else {
            _inventoryMaterials.value = listOf(item) + _inventoryMaterials.value
        }
    }

    fun deleteWorkshopItem(itemId: String) {
        _workshopItems.value = _workshopItems.value.filter { it.id != itemId }
    }

    fun addOrReplaceWorkshopItem(item: WorkshopProductionItem) {
        val idx = _workshopItems.value.indexOfFirst { it.id == item.id }
        if (idx >= 0) {
            _workshopItems.value = _workshopItems.value.map { if (it.id == item.id) item else it }
        } else {
            _workshopItems.value = listOf(item) + _workshopItems.value
        }
    }

    fun deleteActivity(activityId: String) {
        _activities.value = _activities.value.filter { it.id != activityId }
    }

    fun addOrReplaceActivity(activity: StaffActivity) {
        val idx = _activities.value.indexOfFirst { it.id == activity.id }
        if (idx >= 0) {
            _activities.value = _activities.value.map { if (it.id == activity.id) activity else it }
        } else {
            _activities.value = listOf(activity) + _activities.value
        }
    }

    fun deleteFleetVehicle(registration: String) {
        _fleetGpsVehicles.value = _fleetGpsVehicles.value.filter { it.registration != registration }
    }

    fun addOrReplaceFleetVehicle(vehicle: com.example.model.FleetGpsVehicle) {
        val idx = _fleetGpsVehicles.value.indexOfFirst { it.registration == vehicle.registration }
        if (idx >= 0) {
            _fleetGpsVehicles.value = _fleetGpsVehicles.value.map { if (it.registration == vehicle.registration) vehicle else it }
        } else {
            _fleetGpsVehicles.value = _fleetGpsVehicles.value + vehicle
        }
    }

    fun deleteCustomerOrder(orderId: String) {
        _customerOrders.value = _customerOrders.value.filter { it.orderId != orderId }
    }

    fun addOrReplaceCustomerOrder(order: com.example.model.CustomerOrderRecord) {
        val idx = _customerOrders.value.indexOfFirst { it.orderId == order.orderId }
        if (idx >= 0) {
            _customerOrders.value = _customerOrders.value.map { if (it.orderId == order.orderId) order else it }
        } else {
            _customerOrders.value = listOf(order) + _customerOrders.value
        }
    }

    fun deleteBranchStatusBoard(branchName: String) {
        _branchStatusBoards.value = _branchStatusBoards.value.filter { it.branchName != branchName }
    }

    fun addOrReplaceBranchStatusBoard(board: com.example.model.BranchStatusBoard) {
        val idx = _branchStatusBoards.value.indexOfFirst { it.branchName == board.branchName }
        if (idx >= 0) {
            _branchStatusBoards.value = _branchStatusBoards.value.map { if (it.branchName == board.branchName) board else it }
        } else {
            _branchStatusBoards.value = _branchStatusBoards.value + board
        }
    }

    // =========================================================================
    // ADMIN-EDITABLE PACKAGES & ADD-ONS (ORDER & PAY)
    // =========================================================================
    private val _orderPackages = MutableStateFlow(
        listOf(
            OrderPackageItem(
                "PKG-01", "Executive Dignity", 380000.0, 2923.0,
                "Imperial Solid Mahogany",
                "Full VIP honors with Mercedes cortege, vigil hall, floral arrangements & premium lowering gear",
                listOf("Solid African Mahogany Casket", "Mercedes Hearse & Caravan Escort", "Deluxe Lowering Gear & Grass", "Chapel Vigil Hall", "Fresh Floral Wreaths", "Personalized Programs")
            ),
            OrderPackageItem(
                "PKG-02", "Traditional Heritage", 220000.0, 1692.0,
                "Traditional Pine Heritage",
                "Standard dignified community farewell with hearse transit and gravesite equipment",
                listOf("Traditional Pine Casket", "Standard Hearse Escort", "Lowering Gear Set", "Burial Wreath", "Condolence Registration Book")
            ),
            OrderPackageItem(
                "PKG-03", "Artisan Casket", 160000.0, 1230.0,
                "Artisan Cedar Carved",
                "Specialized hand-crafted woodwork tribute celebrating African heritage",
                listOf("Artisan Cedar Carved Casket", "Ceremonial Hearse Escort", "Church Trolley Bier", "Gravesite Carpet")
            ),
            OrderPackageItem(
                "PKG-04", "Eco-Bio", 110000.0, 846.0,
                "Eco-Bio Bamboo Woven",
                "Environmentally conscious green farewell with 100% biodegradable artisan bamboo",
                listOf("Handwoven Bamboo Casket", "Eco-friendly Linen Shroud", "Standard Hearse Transport", "Tree Planting Memorial Seedlings")
            ),
            OrderPackageItem(
                "PKG-05", "Pre-Need Trust", 95000.0, 730.0,
                "Traditional Pine Heritage",
                "Advanced pre-need planning protection locking in today's rates with flexible payments",
                listOf("Pre-Selected Guaranteed Casket", "Locked-In Logistics Costs", "Family Counseling Trustee Certificate", "24/7 Priority Emergency Claim")
            )
        )
    )
    val orderPackages: StateFlow<List<OrderPackageItem>> = _orderPackages.asStateFlow()

    private val _orderAddons = MutableStateFlow(
        listOf(
            OrderAddonItem("ADD-01", "VIP Caravan Escort", 45000.0, "Fleet"),
            OrderAddonItem("ADD-02", "Automatic Lowering Gear & Green Turf", 15000.0, "Gravesite"),
            OrderAddonItem("ADD-03", "50m VIP Red Carpet Runner", 5000.0, "Ceremonial"),
            OrderAddonItem("ADD-04", "Polished Brass Stunchions (Set of 6)", 6000.0, "Ceremonial"),
            OrderAddonItem("ADD-05", "Fresh Floral Tribute Wreaths", 7500.0, "Florals"),
            OrderAddonItem("ADD-06", "Burial Suit 3-Piece Tailored", 18000.0, "Apparel"),
            OrderAddonItem("ADD-07", "Lowering Gear Hire (Event Rate)", 5000.0, "Grave Equipment"),
            OrderAddonItem("ADD-08", "Church Trolley Hire (Event Rate)", 1500.0, "Church Equipment"),
            OrderAddonItem("ADD-09", "Grave Side Carpet (Event Rate)", 3000.0, "Grave Equipment"),
            OrderAddonItem("ADD-10", "Gazebo Carpet (Event Rate)", 4000.0, "Grave Equipment"),
            OrderAddonItem("ADD-11", "Walk Way Carpet (Event Rate)", 4000.0, "Grave Equipment"),
            OrderAddonItem("ADD-12", "Stanchions Crowd Control (Event Rate)", 1000.0, "Ground Control")
        )
    )
    val orderAddons: StateFlow<List<OrderAddonItem>> = _orderAddons.asStateFlow()

    fun updateOrderPackagePrice(packageId: String, newPriceKes: Double, updatedBy: String = "Fredrick Hayoyo (CEO)") {
        _orderPackages.value = _orderPackages.value.map { pkg ->
            if (pkg.id == packageId) {
                val audit = PriceUpdateRecord(
                    id = "PRC-" + UUID.randomUUID().toString().take(6).uppercase(),
                    itemId = packageId,
                    itemName = pkg.name,
                    itemType = "Funeral Package",
                    previousPriceKes = pkg.priceKes,
                    newPriceKes = newPriceKes,
                    updatedByStaffName = updatedBy,
                    dateUpdated = shortDateFormat.format(Date()),
                    notes = "Order & Pay package price adjusted by $updatedBy"
                )
                _priceUpdateHistory.value = listOf(audit) + _priceUpdateHistory.value
                pkg.copy(priceKes = newPriceKes, priceUsd = Math.round(newPriceKes / 130.0).toDouble())
            } else pkg
        }
    }

    fun updateOrderAddonPrice(addonId: String, newPriceKes: Double, updatedBy: String = "Fredrick Hayoyo (CEO)") {
        _orderAddons.value = _orderAddons.value.map { addon ->
            if (addon.id == addonId) {
                val audit = PriceUpdateRecord(
                    id = "PRC-" + UUID.randomUUID().toString().take(6).uppercase(),
                    itemId = addonId,
                    itemName = addon.name,
                    itemType = "Order Add-On",
                    previousPriceKes = addon.priceKes,
                    newPriceKes = newPriceKes,
                    updatedByStaffName = updatedBy,
                    dateUpdated = shortDateFormat.format(Date()),
                    notes = "Add-on price adjusted by $updatedBy"
                )
                _priceUpdateHistory.value = listOf(audit) + _priceUpdateHistory.value
                addon.copy(priceKes = newPriceKes)
            } else addon
        }
    }

    // =========================================================================
    // RAW MATERIAL PURCHASE -> UPGRADE / DOWNGRADE -> STORE PIPELINE
    // =========================================================================
    fun purchaseRawMaterial(
        materialId: String?,
        name: String,
        categoryId: String,
        quantity: Int,
        unit: String,
        unitCostKes: Double,
        minThreshold: Int,
        branch: String,
        purchasedBy: String
    ): InventoryMaterialItem {
        val cat = _materialCategories.value.firstOrNull { it.id == categoryId } ?: _materialCategories.value.first()
        val existing = materialId?.let { id -> _inventoryMaterials.value.firstOrNull { it.id == id } }
        val resultItem = if (existing != null) {
            val nextQty = existing.quantity + quantity.coerceAtLeast(1)
            val updated = existing.copy(
                quantity = nextQty,
                unitCostKes = unitCostKes,
                status = if (nextQty <= existing.minThreshold) "LOW_STOCK" else "IN_STOCK"
            )
            _inventoryMaterials.value = _inventoryMaterials.value.map { if (it.id == existing.id) updated else it }
            updated
        } else {
            val newMat = InventoryMaterialItem(
                id = "MAT-" + (100 + _inventoryMaterials.value.size + 1),
                name = name.trim(),
                categoryId = cat.id,
                categoryName = cat.name,
                quantity = quantity.coerceAtLeast(1),
                unit = unit.ifBlank { cat.unitOfMeasure },
                unitCostKes = unitCostKes,
                minThreshold = minThreshold.coerceAtLeast(1),
                branchWarehouse = branch,
                status = "IN_STOCK"
            )
            _inventoryMaterials.value = listOf(newMat) + _inventoryMaterials.value
            newMat
        }

        _dashboardDailyKpis.value = _dashboardDailyKpis.value.copy(
            totalMaterialCostsToday = _dashboardDailyKpis.value.totalMaterialCostsToday + (quantity * unitCostKes)
        )
        return resultItem
    }

    fun adjustInventoryMaterialQuantity(
        materialId: String,
        delta: Int
    ): InventoryMaterialItem? {
        var updatedItem: InventoryMaterialItem? = null
        _inventoryMaterials.value = _inventoryMaterials.value.map { mat ->
            if (mat.id == materialId) {
                val nextQty = (mat.quantity + delta).coerceAtLeast(0)
                val nextStatus = when {
                    nextQty == 0 -> "OUT_OF_STOCK"
                    nextQty <= mat.minThreshold -> "LOW_STOCK"
                    else -> "IN_STOCK"
                }
                val next = mat.copy(quantity = nextQty, status = nextStatus)
                updatedItem = next
                next
            } else {
                mat
            }
        }
        return updatedItem
    }

    private val _upgradeDowngradeLogs = MutableStateFlow<List<StoreUpgradeDowngradeRecord>>(
        listOf(
            StoreUpgradeDowngradeRecord(
                id = "UDG-101",
                storeCategory = "Casket Catalog",
                itemId = "CSK-02",
                itemName = "Imperial Solid Mahogany",
                actionType = "UPGRADE",
                unitCostDeltaKes = 18000.0,
                quantity = 2,
                totalCostDeltaKes = 36000.0,
                reason = "Upgraded interior satin to diamond quilted velvet + brass corner plates",
                date = "08 Oct 2026",
                processedBy = "Fredrick Hayoyo"
            )
        )
    )
    val upgradeDowngradeLogs: StateFlow<List<StoreUpgradeDowngradeRecord>> = _upgradeDowngradeLogs.asStateFlow()

    fun applyStoreItemUpgradeDowngrade(
        storeCategory: String,
        itemId: String,
        itemName: String,
        isUpgrade: Boolean,
        quantity: Int,
        costDeltaPerUnitKes: Double,
        reason: String,
        processedBy: String
    ): StoreUpgradeDowngradeRecord {
        val qty = quantity.coerceAtLeast(1)
        val deltaSign = if (isUpgrade) 1.0 else -1.0
        val signedUnitDelta = deltaSign * costDeltaPerUnitKes
        val totalDelta = signedUnitDelta * qty

        when (storeCategory) {
            "Raw Material" -> {
                _inventoryMaterials.value = _inventoryMaterials.value.map { mat ->
                    if (mat.id == itemId) {
                        mat.copy(unitCostKes = (mat.unitCostKes + signedUnitDelta).coerceAtLeast(100.0))
                    } else mat
                }
            }
            "Finished Product" -> {
                _inventoryProducts.value = _inventoryProducts.value.map { prod ->
                    if (prod.id == itemId) {
                        prod.copy(
                            costPriceKes = (prod.costPriceKes + signedUnitDelta * 0.6).coerceAtLeast(500.0),
                            sellingPriceKes = (prod.sellingPriceKes + signedUnitDelta).coerceAtLeast(1000.0)
                        )
                    } else prod
                }
            }
            "Uploaded Stock" -> {
                _uploadedStockItems.value = _uploadedStockItems.value.map { st ->
                    if (st.id == itemId) {
                        st.copy(
                            costPriceKes = (st.costPriceKes + signedUnitDelta * 0.6).coerceAtLeast(500.0),
                            sellingPriceKes = (st.sellingPriceKes + signedUnitDelta).coerceAtLeast(1000.0)
                        )
                    } else st
                }
            }
            "Casket Catalog" -> {
                _caskets.value = _caskets.value.map { csk ->
                    if (csk.id == itemId) {
                        val nextPrice = (csk.priceKes + signedUnitDelta).coerceAtLeast(5000.0)
                        csk.copy(
                            priceKes = nextPrice,
                            priceUsd = Math.round(nextPrice / 130.0).toDouble()
                        )
                    } else csk
                }
            }
        }

        val record = StoreUpgradeDowngradeRecord(
            id = "UDG-" + UUID.randomUUID().toString().take(5).uppercase(),
            storeCategory = storeCategory,
            itemId = itemId,
            itemName = itemName,
            actionType = if (isUpgrade) "UPGRADE" else "DOWNGRADE",
            unitCostDeltaKes = costDeltaPerUnitKes,
            quantity = qty,
            totalCostDeltaKes = totalDelta,
            reason = reason.ifBlank { if (isUpgrade) "Store specification upgrade" else "Store specification downgrade" },
            date = shortDateFormat.format(Date()),
            processedBy = processedBy
        )
        _upgradeDowngradeLogs.value = listOf(record) + _upgradeDowngradeLogs.value
        return record
    }

    // =========================================================================
    // STAFF ALERTS, AUTO-ASSIGNMENT & ADMIN TASK PRICING
    // =========================================================================
    private val _staffAlerts = MutableStateFlow(
        listOf(
            StaffAlertNotification(
                id = "ALT-SHF-101",
                recipientStaffId = "DRV-001",
                recipientName = "Victor Owino",
                title = "Shift Readiness Alert: Dawn Cortege Escort (KDG 705Y)",
                message = "VIP Lead Hearse departure at 08:30 AM from Siaya Referral Care Center to Bondo Central Church.",
                category = "SHIFT_ALERT",
                timestamp = "Today, 07:45",
                isRead = false,
                relatedEntityId = "ACT-109",
                priority = TaskPriority.URGENT,
                shiftId = "SH-ACT-001",
                scheduledTimeLabel = "08:30 AM",
                smsDispatched = true,
                branch = "Siaya Referral (Opposite Morgue)"
            ),
            StaffAlertNotification(
                id = "ALT-SHF-102",
                recipientStaffId = "DRV-003",
                recipientName = "Fredrick Ochieng",
                title = "Upcoming Evening Vigil & Lowering Gear Standby",
                message = "Stage Lowering Gear #LG-01 and KCT 871D readiness check 60 min ahead of Bondo & Rangala duties.",
                category = "SHIFT_ALERT",
                timestamp = "Today, 08:15",
                isRead = false,
                relatedEntityId = "ACT-126",
                priority = TaskPriority.HIGH,
                shiftId = "SH-UPC-003",
                scheduledTimeLabel = "11:30 AM",
                smsDispatched = false,
                branch = "Bondo / Rangala"
            ),
            StaffAlertNotification(
                id = "ALT-101",
                recipientStaffId = "CEO-001",
                recipientName = "Fredrick Hayoyo",
                title = "System Live Alert Center Ready",
                message = "Automatic role assignments, shift alerts, task price approvals & operator wages appear here.",
                category = "TASK_ASSIGNED",
                timestamp = "Today, 08:00",
                priority = TaskPriority.NORMAL
            ),
            StaffAlertNotification(
                id = "ALT-102",
                recipientStaffId = "OPR-001",
                recipientName = "Peter Erkundi",
                title = "Operator Daily Wage & Transport Allocated",
                message = "Transport Fee KES 1,200 + Daily Wage KES 1,800 allocated by Admin for Bama Branch gravesite duty.",
                category = "OPERATOR_WAGE",
                timestamp = "Today, 07:30",
                priority = TaskPriority.NORMAL,
                branch = "Bama Branch"
            )
        )
    )
    val staffAlerts: StateFlow<List<StaffAlertNotification>> = _staffAlerts.asStateFlow()

    fun dispatchStaffAlert(
        recipientStaffId: String,
        recipientName: String,
        title: String,
        message: String,
        category: String,
        relatedEntityId: String? = null,
        priority: TaskPriority = TaskPriority.NORMAL,
        shiftId: String? = null,
        scheduledTimeLabel: String? = null,
        smsDispatched: Boolean = false,
        branch: String? = null
    ): StaffAlertNotification {
        val alert = StaffAlertNotification(
            id = "ALT-" + UUID.randomUUID().toString().take(5).uppercase(),
            recipientStaffId = recipientStaffId,
            recipientName = recipientName,
            title = title,
            message = message,
            category = category,
            timestamp = dateFormat.format(Date()),
            isRead = false,
            relatedEntityId = relatedEntityId,
            priority = priority,
            shiftId = shiftId,
            scheduledTimeLabel = scheduledTimeLabel,
            smsDispatched = smsDispatched,
            branch = branch
        )
        _staffAlerts.value = listOf(alert) + _staffAlerts.value
        return alert
    }

    fun dispatchShiftAlert(
        recipientStaffId: String,
        recipientName: String,
        title: String,
        message: String,
        priority: TaskPriority = TaskPriority.HIGH,
        shiftId: String? = null,
        scheduledTimeLabel: String? = null,
        branch: String? = null,
        relatedEntityId: String? = null,
        smsDispatched: Boolean = false
    ): StaffAlertNotification {
        return dispatchStaffAlert(
            recipientStaffId = recipientStaffId,
            recipientName = recipientName,
            title = title,
            message = message,
            category = "SHIFT_ALERT",
            relatedEntityId = relatedEntityId,
            priority = priority,
            shiftId = shiftId,
            scheduledTimeLabel = scheduledTimeLabel,
            smsDispatched = smsDispatched,
            branch = branch
        )
    }

    /**
     * Scans active/upcoming shift rosters and due funeral tasks to generate non-duplicate
     * shift handover and standby readiness alerts.
     */
    fun scanAndTriggerDueShiftAlerts(targetDate: String = "23 Sep 2026"): Int {
        val existingShiftIds = _staffAlerts.value.mapNotNull { it.shiftId }.toSet()
        val existingEntityIds = _staffAlerts.value.mapNotNull { it.relatedEntityId }.toSet()
        var triggeredCount = 0

        _staffShiftSchedules.value
            .filter {
                (it.shiftPeriod == ShiftPeriod.UPCOMING || it.shiftPeriod == ShiftPeriod.ACTIVE) &&
                    (targetDate.isBlank() || it.dateFormatted == targetDate)
            }
            .forEach { shift ->
                if (shift.id !in existingShiftIds) {
                    val priority = if (shift.shiftPeriod == ShiftPeriod.ACTIVE || shift.hearseAssigned != null) {
                        TaskPriority.HIGH
                    } else {
                        TaskPriority.NORMAL
                    }
                    dispatchShiftAlert(
                        recipientStaffId = shift.staffId,
                        recipientName = shift.staffName,
                        title = if (shift.shiftPeriod == ShiftPeriod.ACTIVE) {
                            "Active Duty Check-In Reminder: ${shift.shiftType}"
                        } else {
                            "Upcoming Shift Callout: ${shift.shiftType}"
                        },
                        message = buildString {
                            append("${shift.assignedBranch} (${shift.startTime}–${shift.endTime}). ")
                            if (!shift.hearseAssigned.isNullOrBlank()) append("Hearse: ${shift.hearseAssigned}. ")
                            if (!shift.destination.isNullOrBlank()) append("Destination: ${shift.destination}.")
                        },
                        priority = priority,
                        shiftId = shift.id,
                        scheduledTimeLabel = "${shift.startTime}–${shift.endTime}",
                        branch = shift.assignedBranch,
                        relatedEntityId = shift.caseReference
                    )
                    triggeredCount++
                }
            }

        _activities.value
            .filter {
                (it.status == ActivityStatus.SCHEDULED || it.status == ActivityStatus.ON_HOLD) &&
                    (targetDate.isBlank() || it.date == targetDate)
            }
            .forEach { act ->
                if (act.id !in existingEntityIds) {
                    dispatchShiftAlert(
                        recipientStaffId = act.staffId,
                        recipientName = act.staffName,
                        title = "Due Task Alert (${act.time}): ${act.title}",
                        message = "${act.status.label} • ${act.caseReference} (${act.clientFamily}) at ${act.location}.",
                        priority = act.priority,
                        shiftId = "TASK-${act.id}",
                        scheduledTimeLabel = act.time,
                        branch = act.location,
                        relatedEntityId = act.id
                    )
                    triggeredCount++
                }
            }

        return triggeredCount
    }

    fun markStaffAlertRead(alertId: String) {
        acknowledgeShiftAlert(alertId)
    }

    fun acknowledgeShiftAlert(alertId: String) {
        val ackTime = dateFormat.format(Date())
        _staffAlerts.value = _staffAlerts.value.map {
            if (it.id == alertId) it.copy(isRead = true, acknowledgedAt = it.acknowledgedAt ?: ackTime) else it
        }
    }

    fun markAllShiftAlertsRead() {
        val ackTime = dateFormat.format(Date())
        _staffAlerts.value = _staffAlerts.value.map {
            if (!it.isRead) it.copy(isRead = true, acknowledgedAt = it.acknowledgedAt ?: ackTime) else it
        }
    }

    fun dismissShiftAlert(alertId: String) {
        _staffAlerts.value = _staffAlerts.value.filterNot { it.id == alertId }
    }

    fun autoAssignAndAlertTask(
        category: ActivityCategory,
        title: String,
        caseReference: String,
        clientFamily: String,
        location: String,
        priority: TaskPriority,
        paymentPriceKes: Double,
        notes: String
    ): Pair<StaffActivity, StaffAccount> {
        val targetDept = when (category) {
            ActivityCategory.WORKSHOP_PRODUCTION, ActivityCategory.CASKET_FITTING -> Department.WORKSHOP
            ActivityCategory.FLEET_TRANSPORT -> Department.DRIVERS
            ActivityCategory.GRAVESITE_SETUP, ActivityCategory.OPERATOR_SETUP, ActivityCategory.CHAPEL_SERVICE -> Department.OPERATORS
            ActivityCategory.SALES_CONSULTATION, ActivityCategory.CASE_HANDLING -> Department.SALES_MARKETING
            else -> Department.ADMINISTRATION
        }
        val activeCandidates = _accounts.value.filter { it.isActive }
        val chosenStaff = activeCandidates.firstOrNull {
            it.department == targetDept && it.branch.contains(location, ignoreCase = true)
        } ?: activeCandidates.firstOrNull {
            it.department == targetDept
        } ?: activeCandidates.first()

        val activity = StaffActivity(
            id = "ACT-" + (300 + _activities.value.size + 1),
            staffId = chosenStaff.id,
            staffName = chosenStaff.fullName,
            department = chosenStaff.department,
            category = category,
            title = title.trim(),
            caseReference = caseReference.trim().ifBlank { "JFD-AUTO-" + (100..999).random() },
            clientFamily = clientFamily.trim().ifBlank { "Client Family" },
            location = location.trim().ifBlank { chosenStaff.branch },
            date = shortDateFormat.format(Date()),
            time = SimpleDateFormat("hh:mm a", Locale.getDefault()).format(Date()),
            durationMinutes = 90,
            status = ActivityStatus.SCHEDULED,
            notes = notes.trim().ifBlank { "Auto-assigned by system (${chosenStaff.role.title})" },
            allowanceEarned = paymentPriceKes,
            verifiedByAdmin = false,
            priority = priority
        )
        _activities.value = listOf(activity) + _activities.value

        dispatchStaffAlert(
            recipientStaffId = chosenStaff.id,
            recipientName = chosenStaff.fullName,
            title = "Auto-Assigned Task: ${activity.title}",
            message = "Role: ${chosenStaff.role.title} @ ${activity.location}. Assessed Pay: KES ${String.format("%,.0f", paymentPriceKes)}.",
            category = "TASK_ASSIGNED",
            relatedEntityId = activity.id
        )

        return Pair(activity, chosenStaff)
    }

    fun adminAssessAndPriceActivity(
        activityId: String,
        paymentPriceKes: Double,
        approveAndCredit: Boolean,
        assessmentNotes: String,
        adminName: String
    ) {
        var creditedActivity: StaffActivity? = null
        _activities.value = _activities.value.map { act ->
            if (act.id == activityId) {
                val shouldCredit = approveAndCredit && !act.verifiedByAdmin && paymentPriceKes > 0
                val updated = act.copy(
                    allowanceEarned = paymentPriceKes,
                    verifiedByAdmin = if (approveAndCredit) true else act.verifiedByAdmin,
                    status = if (approveAndCredit) ActivityStatus.VERIFIED_BY_ADMIN else act.status,
                    notes = if (assessmentNotes.isNotBlank()) "${act.notes} | Admin Assessment: $assessmentNotes" else act.notes
                )
                if (shouldCredit) creditedActivity = updated
                updated
            } else act
        }

        val target = _activities.value.firstOrNull { it.id == activityId } ?: return
        if (creditedActivity != null) {
            val txn = WalletTransaction(
                id = "TXN-" + UUID.randomUUID().toString().take(6).uppercase(),
                staffId = target.staffId,
                type = TransactionType.ACTIVITY_ALLOWANCE,
                title = "Admin Assessed Pay: ${target.title}",
                referenceNumber = "ASSESS-" + target.id,
                amount = paymentPriceKes,
                date = dateFormat.format(Date()),
                status = PaymentStatus.DISBURSED,
                notes = "Assessed & approved by $adminName (${target.caseReference})"
            )
            _transactions.value = listOf(txn) + _transactions.value
        }

        dispatchStaffAlert(
            recipientStaffId = target.staffId,
            recipientName = target.staffName,
            title = "Task Assessed & Priced: ${target.title}",
            message = "Admin $adminName set payment KES ${String.format("%,.0f", paymentPriceKes)}${if (approveAndCredit) " (Verified & Credited to Wallet)" else ""}.",
            category = "TASK_PRICED",
            relatedEntityId = target.id
        )
    }

    // =========================================================================
    // STAFF BREAKAGES COST & DEDUCTIONS
    // =========================================================================
    private val _breakageRecords = MutableStateFlow(
        listOf(
            StaffBreakageRecord(
                id = "BRK-101",
                staffId = "WRK-003",
                staffName = "John Hayoyo",
                department = Department.WORKSHOP,
                itemBroken = "Tempered Viewing Glass Dome Panel",
                description = "Cracked during brass latch installation on Half Glass Dome unit",
                breakageCostKes = 3500.0,
                date = "07 Oct 2026",
                loggedBy = "Fredrick Hayoyo",
                isDeducted = true,
                walletTransactionId = "TXN-BRK-101"
            ),
            StaffBreakageRecord(
                id = "BRK-102",
                staffId = "OPR-002",
                staffName = "Victor Ojow",
                department = Department.OPERATORS,
                itemBroken = "Polished Brass Stunchion Post",
                description = "Bent base post during unloading at Bondo burial site",
                breakageCostKes = 1500.0,
                date = "08 Oct 2026",
                loggedBy = "Fredrick Hayoyo",
                isDeducted = false,
                walletTransactionId = null
            )
        )
    )
    val breakageRecords: StateFlow<List<StaffBreakageRecord>> = _breakageRecords.asStateFlow()

    fun recordAndDeductBreakage(
        staffId: String,
        itemBroken: String,
        description: String,
        costKes: Double,
        deductImmediately: Boolean,
        loggedBy: String
    ): StaffBreakageRecord {
        val staff = _accounts.value.firstOrNull { it.id == staffId } ?: _accounts.value.first()
        val brkId = "BRK-" + (200 + _breakageRecords.value.size + 1)
        var txnId: String? = null

        if (deductImmediately && costKes > 0) {
            txnId = "TXN-BRK-" + UUID.randomUUID().toString().take(5).uppercase()
            val txn = WalletTransaction(
                id = txnId,
                staffId = staff.id,
                type = TransactionType.BREAKAGE_DEDUCTION,
                title = "Breakage Deduction: $itemBroken",
                referenceNumber = brkId,
                amount = -costKes,
                date = dateFormat.format(Date()),
                status = PaymentStatus.DISBURSED,
                notes = "$description (Executed by $loggedBy)"
            )
            _transactions.value = listOf(txn) + _transactions.value
            _accounts.value = _accounts.value.map { acc ->
                if (acc.id == staff.id) acc.copy(totalBreakageDeductionsKes = acc.totalBreakageDeductionsKes + costKes) else acc
            }
        }

        val record = StaffBreakageRecord(
            id = brkId,
            staffId = staff.id,
            staffName = staff.fullName,
            department = staff.department,
            itemBroken = itemBroken.trim(),
            description = description.trim(),
            breakageCostKes = costKes,
            date = shortDateFormat.format(Date()),
            loggedBy = loggedBy,
            isDeducted = deductImmediately,
            walletTransactionId = txnId
        )
        _breakageRecords.value = listOf(record) + _breakageRecords.value

        dispatchStaffAlert(
            recipientStaffId = staff.id,
            recipientName = staff.fullName,
            title = if (deductImmediately) "Breakage Deduction Executed" else "Breakage Cost Logged",
            message = "Item: $itemBroken • Cost: KES ${String.format("%,.0f", costKes)}. ${if (deductImmediately) "Deducted from wallet." else "Pending deduction."}",
            category = "BREAKAGE_DEDUCTION",
            relatedEntityId = brkId
        )
        return record
    }

    fun executePendingBreakageDeduction(breakageId: String, executedBy: String): Boolean {
        val record = _breakageRecords.value.firstOrNull { it.id == breakageId && !it.isDeducted } ?: return false
        val txnId = "TXN-BRK-" + UUID.randomUUID().toString().take(5).uppercase()
        val txn = WalletTransaction(
            id = txnId,
            staffId = record.staffId,
            type = TransactionType.BREAKAGE_DEDUCTION,
            title = "Breakage Deduction: ${record.itemBroken}",
            referenceNumber = record.id,
            amount = -record.breakageCostKes,
            date = dateFormat.format(Date()),
            status = PaymentStatus.DISBURSED,
            notes = "${record.description} (Executed by $executedBy)"
        )
        _transactions.value = listOf(txn) + _transactions.value
        _accounts.value = _accounts.value.map { acc ->
            if (acc.id == record.staffId) acc.copy(totalBreakageDeductionsKes = acc.totalBreakageDeductionsKes + record.breakageCostKes) else acc
        }
        _breakageRecords.value = _breakageRecords.value.map {
            if (it.id == breakageId) it.copy(isDeducted = true, walletTransactionId = txnId) else it
        }
        dispatchStaffAlert(
            recipientStaffId = record.staffId,
            recipientName = record.staffName,
            title = "Breakage Deduction Executed",
            message = "KES ${String.format("%,.0f", record.breakageCostKes)} deducted for ${record.itemBroken}.",
            category = "BREAKAGE_DEDUCTION",
            relatedEntityId = breakageId
        )
        return true
    }

    // =========================================================================
    // OPERATORS TRANSPORT FEE & DAILY WAGES ALLOCATION
    // =========================================================================
    private val _operatorWageAllocations = MutableStateFlow(
        listOf(
            OperatorWageAllocation(
                id = "OPW-101",
                staffId = "OPR-001",
                staffName = "Peter Erkundi",
                branch = "Bama Branch",
                transportFeeKes = 1200.0,
                dailyWageKes = 1800.0,
                totalPaidKes = 3000.0,
                dutyAssignment = "Lowering Gear & Canopy Setup — Bondo Cortege",
                date = "09 Oct 2026",
                allocatedBy = "Fredrick Hayoyo",
                isDisbursed = true
            ),
            OperatorWageAllocation(
                id = "OPW-102",
                staffId = "OPR-002",
                staffName = "Victor Ojow",
                branch = "Bama Branch",
                transportFeeKes = 1200.0,
                dailyWageKes = 1800.0,
                totalPaidKes = 3000.0,
                dutyAssignment = "Church Trolley Bier & Red Carpet — Siaya Referral",
                date = "09 Oct 2026",
                allocatedBy = "Fredrick Hayoyo",
                isDisbursed = false
            ),
            OperatorWageAllocation(
                id = "OPW-103",
                staffId = "OPR-003",
                staffName = "Stephen Ooko",
                branch = "Bama Branch",
                transportFeeKes = 1000.0,
                dailyWageKes = 1650.0,
                totalPaidKes = 2650.0,
                dutyAssignment = "Grounds & Stanchions Crew — Ukwala Parish",
                date = "09 Oct 2026",
                allocatedBy = "Fredrick Hayoyo",
                isDisbursed = false
            )
        )
    )
    val operatorWageAllocations: StateFlow<List<OperatorWageAllocation>> = _operatorWageAllocations.asStateFlow()

    fun allocateOperatorTransportAndWage(
        staffId: String,
        transportFeeKes: Double,
        dailyWageKes: Double,
        dutyAssignment: String,
        disburseNow: Boolean,
        adminName: String
    ): OperatorWageAllocation {
        val staff = _accounts.value.firstOrNull { it.id == staffId } ?: _accounts.value.first()
        _accounts.value = _accounts.value.map { acc ->
            if (acc.id == staff.id) {
                acc.copy(transportFeeKes = transportFeeKes, dailyWageKes = dailyWageKes)
            } else acc
        }

        val total = transportFeeKes + dailyWageKes
        val allocId = "OPW-" + (200 + _operatorWageAllocations.value.size + 1)
        val record = OperatorWageAllocation(
            id = allocId,
            staffId = staff.id,
            staffName = staff.fullName,
            branch = staff.branch,
            transportFeeKes = transportFeeKes,
            dailyWageKes = dailyWageKes,
            totalPaidKes = total,
            dutyAssignment = dutyAssignment.ifBlank { "24/7 Operator Field & Gravesite Duty" },
            date = shortDateFormat.format(Date()),
            allocatedBy = adminName,
            isDisbursed = disburseNow
        )
        _operatorWageAllocations.value = listOf(record) + _operatorWageAllocations.value

        if (disburseNow) {
            creditOperatorTransportAndWage(record, adminName)
        }

        dispatchStaffAlert(
            recipientStaffId = staff.id,
            recipientName = staff.fullName,
            title = "Operator Transport & Daily Wage Updated",
            message = "Transport Fee: KES ${String.format("%,.0f", transportFeeKes)} + Daily Wage: KES ${String.format("%,.0f", dailyWageKes)}${if (disburseNow) " (Paid to Wallet)" else ""}.",
            category = "OPERATOR_WAGE",
            relatedEntityId = allocId
        )
        return record
    }

    fun disburseOperatorWageAllocation(allocationId: String, adminName: String): Boolean {
        val alloc = _operatorWageAllocations.value.firstOrNull { it.id == allocationId && !it.isDisbursed } ?: return false
        creditOperatorTransportAndWage(alloc, adminName)
        _operatorWageAllocations.value = _operatorWageAllocations.value.map {
            if (it.id == allocationId) it.copy(isDisbursed = true) else it
        }
        return true
    }

    private fun creditOperatorTransportAndWage(alloc: OperatorWageAllocation, adminName: String) {
        val today = dateFormat.format(Date())
        if (alloc.transportFeeKes > 0) {
            _transactions.value = listOf(
                WalletTransaction(
                    id = "TXN-TRN-" + UUID.randomUUID().toString().take(5).uppercase(),
                    staffId = alloc.staffId,
                    type = TransactionType.OPERATOR_TRANSPORT_FEE,
                    title = "Operator Transport Fee: ${alloc.dutyAssignment}",
                    referenceNumber = "${alloc.id}-TRN",
                    amount = alloc.transportFeeKes,
                    date = today,
                    status = PaymentStatus.DISBURSED,
                    notes = "Allocated by $adminName (${alloc.branch})"
                )
            ) + _transactions.value
        }
        if (alloc.dailyWageKes > 0) {
            _transactions.value = listOf(
                WalletTransaction(
                    id = "TXN-WGE-" + UUID.randomUUID().toString().take(5).uppercase(),
                    staffId = alloc.staffId,
                    type = TransactionType.OPERATOR_DAILY_WAGE,
                    title = "Operator Daily Wage: ${alloc.dutyAssignment}",
                    referenceNumber = "${alloc.id}-WGE",
                    amount = alloc.dailyWageKes,
                    date = today,
                    status = PaymentStatus.DISBURSED,
                    notes = "Allocated by $adminName (${alloc.branch})"
                )
            ) + _transactions.value
        }
    }

    // =========================================================================
    // AUTOMATED BATCH PAYROLL RUN & FIRESTORE CLOUD SYNC MERGE HELPERS
    // =========================================================================
    fun runBatchMonthlyPayroll(periodLabel: String, executedBy: String): BatchPayrollRunSummary {
        val summary = PayrollRulesEngine.generateMonthlyPayrollRun(
            periodLabel = periodLabel,
            dateFormatted = shortDateFormat.format(Date()),
            staffAccounts = _accounts.value,
            existingTransactions = _transactions.value,
            breakageRecords = _breakageRecords.value
        )
        if (summary.items.isNotEmpty()) {
            val newTxns = summary.items.map { it.generatedTransaction }
            _transactions.value = newTxns + _transactions.value
            summary.items.forEach { item ->
                if (item.breakageDeductionsKes > 0) {
                    _breakageRecords.value = _breakageRecords.value.map { brk ->
                        if (brk.staffId == item.staffId && !brk.isDeducted) {
                            brk.copy(isDeducted = true, walletTransactionId = item.generatedTransaction.id)
                        } else brk
                    }
                }
                dispatchStaffAlert(
                    recipientStaffId = item.staffId,
                    recipientName = item.staffName,
                    title = "Monthly Payroll Credited ($periodLabel)",
                    message = "Net KES ${String.format("%,.0f", item.netPayableKes)} credited by $executedBy.",
                    category = "PAYROLL_RUN",
                    relatedEntityId = item.generatedTransaction.referenceNumber
                )
            }
        }
        return summary
    }

    fun mergeCloudTransactions(cloudTxns: List<WalletTransaction>) {
        if (cloudTxns.isEmpty()) return
        val existingById = _transactions.value.associateBy { it.id }.toMutableMap()
        cloudTxns.forEach { cloud -> existingById[cloud.id] = cloud }
        _transactions.value = existingById.values.sortedByDescending { it.timestamp }
    }

    fun mergeCloudOrders(cloudOrders: List<CustomerOrderRecord>) {
        if (cloudOrders.isEmpty()) return
        val existingById = _customerOrders.value.associateBy { it.orderId }.toMutableMap()
        cloudOrders.forEach { cloud -> existingById[cloud.orderId] = cloud }
        _customerOrders.value = existingById.values.toList()
    }

    fun mergeCloudActivities(cloudActivities: List<StaffActivity>) {
        if (cloudActivities.isEmpty()) return
        val existingById = _activities.value.associateBy { it.id }.toMutableMap()
        cloudActivities.forEach { cloud ->
            val existing = existingById[cloud.id]
            existingById[cloud.id] = if (existing != null) {
                cloud.copy(
                    clientFamily = cloud.clientFamily.ifBlank { existing.clientFamily },
                    date = cloud.date.ifBlank { existing.date },
                    time = cloud.time.ifBlank { existing.time },
                    durationMinutes = if (cloud.durationMinutes > 0) cloud.durationMinutes else existing.durationMinutes,
                    notes = cloud.notes.ifBlank { existing.notes },
                    checklistItems = existing.checklistItems,
                    completedChecklistItems = existing.completedChecklistItems
                )
            } else {
                cloud
            }
        }
        _activities.value = existingById.values.sortedByDescending { it.timestamp }
    }

    fun mergeCloudBreakages(cloudBreakages: List<StaffBreakageRecord>) {
        if (cloudBreakages.isEmpty()) return
        val existingById = _breakageRecords.value.associateBy { it.id }.toMutableMap()
        cloudBreakages.forEach { cloud -> existingById[cloud.id] = cloud }
        _breakageRecords.value = existingById.values.toList()
    }

    fun mergeCloudShiftAttendance(cloudLogs: List<ShiftAttendanceRecord>) {
        if (cloudLogs.isEmpty()) return
        val existingById = _shiftAttendanceLogs.value.associateBy { it.id }.toMutableMap()
        cloudLogs.forEach { cloud -> existingById[cloud.id] = cloud }
        _shiftAttendanceLogs.value = existingById.values.sortedByDescending { it.timestampMillis }
    }

    fun mergeCloudBurialSchedules(cloudSchedules: List<BurialScheduleEvent>) {
        if (cloudSchedules.isEmpty()) return
        val existingById = _burialSchedules.value.associateBy { it.id }.toMutableMap()
        cloudSchedules.forEach { cloud ->
            val existing = existingById[cloud.id]
            existingById[cloud.id] = if (existing != null) {
                cloud.copy(
                    assignedOperators = if (existing.assignedOperators.isNotEmpty()) existing.assignedOperators else cloud.assignedOperators,
                    timings = if (existing.timings.isNotEmpty()) existing.timings else cloud.timings
                )
            } else {
                cloud
            }
        }
        _burialSchedules.value = existingById.values.toList()
    }

    fun mergeCloudWorkshopJobs(cloudJobs: List<WorkshopProductionItem>) {
        if (cloudJobs.isEmpty()) return
        val existingById = _workshopItems.value.associateBy { it.id }.toMutableMap()
        cloudJobs.forEach { cloud ->
            val existing = existingById[cloud.id]
            existingById[cloud.id] = if (existing != null) {
                cloud.copy(
                    woodType = existing.woodType,
                    startedDate = existing.startedDate,
                    targetCompletionDate = existing.targetCompletionDate,
                    branch = existing.branch,
                    allocatedMaterials = existing.allocatedMaterials,
                    autoBomDeductedStages = existing.autoBomDeductedStages,
                    isCustomDesign = existing.isCustomDesign,
                    qrTagCode = existing.qrTagCode
                )
            } else {
                cloud
            }
        }
        _workshopItems.value = existingById.values.toList()
    }

    fun mergeCloudInventoryMaterials(cloudMaterials: List<InventoryMaterialItem>) {
        if (cloudMaterials.isEmpty()) return
        val existingById = _inventoryMaterials.value.associateBy { it.id }.toMutableMap()
        cloudMaterials.forEach { cloud -> existingById[cloud.id] = cloud }
        _inventoryMaterials.value = existingById.values.toList()
    }

    fun mergeCloudCaskets(cloudCaskets: List<CasketItem>) {
        if (cloudCaskets.isEmpty()) return
        val existingById = _caskets.value.associateBy { it.id }.toMutableMap()
        cloudCaskets.forEach { cloud ->
            val existing = existingById[cloud.id]
            existingById[cloud.id] = if (existing != null) {
                cloud.copy(
                    features = if (cloud.features.isNotEmpty()) cloud.features else existing.features
                )
            } else {
                cloud
            }
        }
        _caskets.value = existingById.values.toList()
    }

    // =========================================================================
    // 6. CASE PAPERWORK & PERMIT CLOUD VAULT
    // =========================================================================
    private val _caseDocuments = MutableStateFlow(
        listOf(
            CaseDocumentRecord(
                id = "DOC-101",
                caseReference = "JFD-2026-841",
                deceasedName = "Late Mzee Harrison Ouma",
                documentType = CaseDocumentType.BURIAL_PERMIT,
                title = "Siaya County Statutory Burial Permit #BP-4920",
                notes = "Stamped & cleared at Siaya Referal Registrar Office",
                fileName = "burial_permit_4920.pdf",
                mimeType = "application/pdf",
                thumbnailBase64 = "",
                uploadedByStaffId = "CEO-001",
                uploadedByStaffName = "Fredrick Hayoyo",
                uploadedAt = "09 Oct 2026, 11:20 EAT",
                verifiedByAdmin = true,
                timestampMillis = System.currentTimeMillis() - 86_400_000L
            ),
            CaseDocumentRecord(
                id = "DOC-102",
                caseReference = "JFD-2026-842",
                deceasedName = "Late Mama Grace Anyango",
                documentType = CaseDocumentType.MORTUARY_RELEASE,
                title = "Mortuary Release Clearance & Cold Room Sign-off",
                notes = "Verified by Bama Cold Room Duty Attendant",
                fileName = "mortuary_release_842.pdf",
                mimeType = "application/pdf",
                thumbnailBase64 = "",
                uploadedByStaffId = "OPR-001",
                uploadedByStaffName = "Duncan Odhiambo",
                uploadedAt = "10 Oct 2026, 08:15 EAT",
                verifiedByAdmin = false,
                timestampMillis = System.currentTimeMillis() - 7_200_000L
            )
        )
    )
    val caseDocuments: StateFlow<List<CaseDocumentRecord>> = _caseDocuments.asStateFlow()

    fun addOrReplaceCaseDocument(doc: CaseDocumentRecord) {
        val idx = _caseDocuments.value.indexOfFirst { it.id == doc.id }
        if (idx >= 0) {
            _caseDocuments.value = _caseDocuments.value.map { if (it.id == doc.id) doc else it }
        } else {
            _caseDocuments.value = listOf(doc) + _caseDocuments.value
        }
    }

    fun verifyCaseDocument(docId: String, verified: Boolean = true) {
        _caseDocuments.value = _caseDocuments.value.map {
            if (it.id == docId) it.copy(verifiedByAdmin = verified) else it
        }
    }

    fun deleteCaseDocument(docId: String) {
        _caseDocuments.value = _caseDocuments.value.filter { it.id != docId }
    }

    fun mergeCloudCaseDocuments(cloudDocs: List<CaseDocumentRecord>) {
        if (cloudDocs.isEmpty()) return
        val existingById = _caseDocuments.value.associateBy { it.id }.toMutableMap()
        cloudDocs.forEach { cloud -> existingById[cloud.id] = cloud }
        _caseDocuments.value = existingById.values.sortedByDescending { it.timestampMillis }
    }

    fun mergeCloudStaffDirectory(entries: List<com.example.data.firebase.FirestoreStaffDirectoryEntry>) {
        if (entries.isEmpty()) return
        val existingById = _accounts.value.associateBy { it.id }.toMutableMap()
        entries.forEach { cloud ->
            val targetId = cloud.staffId.ifBlank { cloud.id }
            val existing = existingById[targetId]
            val parsedRole = runCatching { StaffRole.valueOf(cloud.roleName) }
                .getOrDefault(existing?.role ?: StaffRole.OPERATOR)
            val parsedDept = runCatching { Department.valueOf(cloud.departmentName) }
                .getOrDefault(existing?.department ?: Department.OPERATORS)
            if (existing != null) {
                existingById[targetId] = existing.copy(
                    fullName = cloud.fullName.ifBlank { existing.fullName },
                    email = cloud.email.ifBlank { existing.email },
                    phone = cloud.phone.ifBlank { existing.phone },
                    role = parsedRole,
                    department = parsedDept,
                    branch = cloud.branch.ifBlank { existing.branch },
                    assignedVehicle = cloud.assignedVehicle.ifBlank { null },
                    isActive = cloud.active,
                    baseSalaryKes = if (cloud.baseSalaryKes > 0.0) cloud.baseSalaryKes else existing.baseSalaryKes,
                    allowanceKes = if (cloud.allowanceKes >= 0.0) cloud.allowanceKes else existing.allowanceKes,
                    commissionRatePercent = if (cloud.commissionRatePercent >= 0.0) cloud.commissionRatePercent else existing.commissionRatePercent,
                    defaultMpesaNumber = cloud.defaultMpesaNumber.ifBlank { existing.defaultMpesaNumber },
                    defaultBankDetails = cloud.defaultBankDetails.ifBlank { existing.defaultBankDetails }
                )
            } else {
                existingById[targetId] = StaffAccount(
                    id = targetId,
                    fullName = cloud.fullName.ifBlank { "Jabima Staff" },
                    email = cloud.email,
                    phone = cloud.phone,
                    password = "",
                    passwordHash = PasswordSecurityHelper.hashPassword("123456"),
                    mustRotatePassword = true,
                    role = parsedRole,
                    department = parsedDept,
                    branch = cloud.branch.ifBlank { "Bama Branch" },
                    nationalId = "PENDING",
                    assignedVehicle = cloud.assignedVehicle.ifBlank { null },
                    avatarColor = 0xFF1D4E7B,
                    isActive = cloud.active,
                    baseSalaryKes = cloud.baseSalaryKes,
                    allowanceKes = cloud.allowanceKes,
                    commissionRatePercent = cloud.commissionRatePercent,
                    defaultMpesaNumber = cloud.defaultMpesaNumber,
                    defaultBankDetails = cloud.defaultBankDetails
                )
            }
        }
        _accounts.value = existingById.values.toList()
    }

    fun mergeCloudBranchBoards(cloudBoards: List<BranchStatusBoard>) {
        if (cloudBoards.isEmpty()) return
        val existingByBranch = _branchStatusBoards.value.associateBy { it.branchName }.toMutableMap()
        cloudBoards.forEach { cloud ->
            val existing = existingByBranch[cloud.branchName]
            existingByBranch[cloud.branchName] = if (existing != null) {
                cloud.copy(
                    hearseFleetStationed = if (cloud.hearseFleetStationed.isNotEmpty()) cloud.hearseFleetStationed else existing.hearseFleetStationed,
                    hearseFleetInTransit = if (cloud.hearseFleetInTransit.isNotEmpty()) cloud.hearseFleetInTransit else existing.hearseFleetInTransit,
                    activeAdvisories = if (cloud.activeAdvisories.isNotEmpty()) cloud.activeAdvisories else existing.activeAdvisories
                )
            } else {
                cloud
            }
        }
        _branchStatusBoards.value = existingByBranch.values.toList()
    }

    fun mergeCloudLeaveRequests(cloudLeaves: List<com.example.model.LeaveRequest>) {
        if (cloudLeaves.isEmpty()) return
        val existingById = _leaveRequests.value.associateBy { it.id }.toMutableMap()
        cloudLeaves.forEach { cloud -> existingById[cloud.id] = cloud }
        _leaveRequests.value = existingById.values.toList()
    }

    fun mergeCloudFleetVehicles(cloudVehicles: List<FleetGpsVehicle>) {
        if (cloudVehicles.isEmpty()) return
        val existingByReg = _fleetGpsVehicles.value.associateBy { it.registration }.toMutableMap()
        cloudVehicles.forEach { cloud ->
            val existing = existingByReg[cloud.registration]
            existingByReg[cloud.registration] = if (existing != null) {
                cloud.copy(routeBreadcrumbs = existing.routeBreadcrumbs)
            } else {
                cloud
            }
        }
        _fleetGpsVehicles.value = existingByReg.values.toList()
    }

    fun mergeCloudCompanyAssets(cloudAssets: List<com.example.model.CompanyAsset>) {
        if (cloudAssets.isEmpty()) return
        val existingById = _companyAssets.value.associateBy { it.id }.toMutableMap()
        cloudAssets.forEach { cloud -> existingById[cloud.id] = cloud }
        _companyAssets.value = existingById.values.toList()
    }

    // =========================================================================
    // 1. QR / BARCODE CUSTODY LOGS FOR CASKETS & GROUNDS GEAR
    // =========================================================================
    private val _assetCustodyLogs = MutableStateFlow(
        listOf(
            AssetCustodyLog(
                id = "CST-101",
                assetId = "AST-07",
                assetName = "Heavy Duty Lowering Gear #1",
                qrTagCode = "JFD-AST-AST-07",
                custodyStatus = CustodyStatus.IN_DEPOT,
                caseReference = "REF-2026-99",
                staffId = "OPR-001",
                staffName = "Duncan Odhiambo",
                branch = "Bama Branch",
                conditionNotes = "Straps inspected and stowed cleanly",
                timestamp = "09 Oct 2026, 17:45 EAT"
            )
        )
    )
    val assetCustodyLogs: StateFlow<List<AssetCustodyLog>> = _assetCustodyLogs.asStateFlow()

    fun scanAssetCustody(
        qrOrTag: String,
        actionCheckOut: Boolean,
        caseReference: String,
        staffId: String,
        staffName: String,
        isDamagedOrMissing: Boolean,
        conditionNotes: String,
        breakageCostKes: Double = 2500.0
    ): AssetCustodyLog? {
        val cleanCode = qrOrTag.trim()
        val matchedAsset = _companyAssets.value.firstOrNull {
            it.qrTagCode.equals(cleanCode, ignoreCase = true) ||
                it.registrationOrTag.equals(cleanCode, ignoreCase = true) ||
                it.id.equals(cleanCode, ignoreCase = true)
        }

        val targetStatus = when {
            isDamagedOrMissing && actionCheckOut -> CustodyStatus.MISSING_FLAGGED
            isDamagedOrMissing -> CustodyStatus.DAMAGED
            actionCheckOut -> CustodyStatus.CHECKED_OUT
            else -> CustodyStatus.IN_DEPOT
        }

        var breakageId: String? = null
        if (isDamagedOrMissing) {
            val itemName = matchedAsset?.name ?: "QR Tag $cleanCode"
            val brk = recordAndDeductBreakage(
                staffId = staffId,
                itemBroken = itemName,
                description = "QR Custody Flag (${targetStatus.label}) on $cleanCode: ${conditionNotes.ifBlank { "Missing / damaged on return" }}",
                costKes = breakageCostKes.coerceAtLeast(500.0),
                deductImmediately = true,
                loggedBy = "QR Custody Gate ($staffName)"
            )
            breakageId = brk.id
        }

        val nowLabel = dateFormat.format(Date()) + " EAT"
        if (matchedAsset != null) {
            _companyAssets.value = _companyAssets.value.map { asset ->
                if (asset.id == matchedAsset.id) {
                    asset.copy(
                        custodyStatus = targetStatus,
                        checkedOutCaseRef = if (actionCheckOut) caseReference else null,
                        custodianStaffName = staffName,
                        lastInspected = shortDateFormat.format(Date()),
                        condition = when (targetStatus) {
                            CustodyStatus.DAMAGED, CustodyStatus.MISSING_FLAGGED -> "Under Maintenance"
                            CustodyStatus.CHECKED_OUT -> "In Use"
                            CustodyStatus.IN_DEPOT -> "Operational"
                        }
                    )
                } else asset
            }
        }

        val log = AssetCustodyLog(
            id = "CST-" + (200 + _assetCustodyLogs.value.size + 1),
            assetId = matchedAsset?.id ?: cleanCode,
            assetName = matchedAsset?.name ?: "Tagged Item ($cleanCode)",
            qrTagCode = matchedAsset?.qrTagCode ?: cleanCode,
            custodyStatus = targetStatus,
            caseReference = caseReference.ifBlank { "DEPOT-AUDIT" },
            staffId = staffId,
            staffName = staffName,
            branch = matchedAsset?.branchAssigned ?: "Bama Branch",
            conditionNotes = conditionNotes.ifBlank { targetStatus.label },
            timestamp = nowLabel,
            breakageRecordId = breakageId
        )
        _assetCustodyLogs.value = listOf(log) + _assetCustodyLogs.value
        return log
    }

    // =========================================================================
    // 2. FAMILY CORTEGE MILESTONE UPDATES
    // =========================================================================
    fun advanceCortegeMilestone(
        burialScheduleId: String,
        milestone: FamilyCortegeMilestone
    ): BurialScheduleEvent? {
        val nowLabel = dateFormat.format(Date()) + " EAT"
        var updatedEvent: BurialScheduleEvent? = null
        _burialSchedules.value = _burialSchedules.value.map { ev ->
            if (ev.id == burialScheduleId) {
                val next = ev.copy(
                    currentMilestone = milestone,
                    milestoneUpdatedAt = nowLabel
                )
                updatedEvent = next
                next
            } else ev
        }
        return updatedEvent
    }

    // =========================================================================
    // 3. BOM MARGIN GUARD ALERT DISPATCHER
    // =========================================================================
    fun raiseMarginGuardAlert(
        casketName: String,
        warningMessage: String,
        relatedEntityId: String? = null
    ) {
        val ceo = _accounts.value.firstOrNull { it.role == StaffRole.MANAGING_DIRECTOR_CEO }
            ?: _accounts.value.firstOrNull()
            ?: return
        dispatchStaffAlert(
            recipientStaffId = ceo.id,
            recipientName = ceo.fullName,
            title = "Margin Guard Warning: $casketName",
            message = warningMessage,
            category = "MARGIN_GUARD",
            relatedEntityId = relatedEntityId
        )
    }

    fun evaluateAndDispatchOperationalAlerts(): Int {
        var newAlerts = 0
        val recipients = _accounts.value.filter {
            it.isActive && (
                it.role == StaffRole.MANAGING_DIRECTOR_CEO ||
                    it.role == StaffRole.INVENTORY_MANAGER ||
                    it.role == StaffRole.OPERATIONS_ADMIN
                )
        }.ifEmpty { listOfNotNull(_accounts.value.firstOrNull()) }
        val primaryRecipient = recipients.firstOrNull() ?: return 0

        _inventoryMaterials.value.forEach { mat ->
            if (mat.quantity <= mat.minThreshold) {
                val alreadyRaised = _staffAlerts.value.any {
                    it.category == "LOW_STOCK_ALERT" && it.relatedEntityId == mat.id
                }
                if (!alreadyRaised) {
                    val levelTag = if (mat.quantity == 0) "OUT OF STOCK" else "Low Stock (${mat.quantity}/${mat.minThreshold})"
                    dispatchStaffAlert(
                        recipientStaffId = primaryRecipient.id,
                        recipientName = primaryRecipient.fullName,
                        title = "Stock Alert: ${mat.name} — $levelTag",
                        message = "${mat.name} at ${mat.branchWarehouse} is at ${mat.quantity} ${mat.unit} (Min threshold: ${mat.minThreshold}). Reorder required.",
                        category = "LOW_STOCK_ALERT",
                        relatedEntityId = mat.id,
                        priority = TaskPriority.URGENT,
                        branch = mat.branchWarehouse
                    )
                    newAlerts++
                }
            }
        }

        _branchStatusBoards.value.forEach { board ->
            if (board.coldRoomCapacity > 0) {
                val occupancyPct = ((board.coldRoomOccupancy * 100.0) / board.coldRoomCapacity)
                if (occupancyPct >= 85.0) {
                    val alreadyRaised = _staffAlerts.value.any {
                        it.category == "COLD_ROOM_CAPACITY" && it.relatedEntityId == board.branchName
                    }
                    if (!alreadyRaised) {
                        dispatchStaffAlert(
                            recipientStaffId = primaryRecipient.id,
                            recipientName = primaryRecipient.fullName,
                            title = "Cold Room Capacity Alert: ${board.branchName} (${occupancyPct.toInt()}%)",
                            message = "${board.branchName} cold room is at ${board.coldRoomOccupancy}/${board.coldRoomCapacity} bays occupied (${occupancyPct.toInt()}%). Coordinate overflow transfer or cortege dispatch.",
                            category = "COLD_ROOM_CAPACITY",
                            relatedEntityId = board.branchName,
                            priority = TaskPriority.URGENT,
                            branch = board.branchName
                        )
                        newAlerts++
                    }
                }
            }
        }
        return newAlerts
    }

    // =========================================================================
    // 4. BIOMETRIC SHIFT & VEHICLE HANDOVER LOGGING
    // =========================================================================
    private val _shiftHandovers = MutableStateFlow(
        listOf(
            ShiftVehicleHandover(
                id = "HND-201",
                vehicleReg = "KDG 705Y",
                branch = "Bama Branch",
                outgoingStaffId = "DRV-002",
                outgoingStaffName = "James Mwangi",
                incomingStaffId = "DRV-001",
                incomingStaffName = "Erick Omondi",
                fuelPercent = 82,
                odometerKm = 148220,
                loweringGearCount = 2,
                churchTrolleyOk = true,
                velvetDeckClean = true,
                spareTireAndJackOk = true,
                conditionNotes = "Velvet bier sanitized, 2 hydraulic straps checked, ready for Bondo cortege.",
                outgoingBiometricSigned = true,
                incomingBiometricSigned = true,
                timestamp = "09 Oct 2026, 18:10 EAT"
            )
        )
    )
    val shiftHandovers: StateFlow<List<ShiftVehicleHandover>> = _shiftHandovers.asStateFlow()

    fun recordShiftHandover(handover: ShiftVehicleHandover) {
        _shiftHandovers.value = listOf(handover) + _shiftHandovers.value
        _fleetGpsVehicles.value = _fleetGpsVehicles.value.map { v ->
            if (v.registration.equals(handover.vehicleReg, ignoreCase = true)) {
                v.copy(
                    driverName = handover.incomingStaffName,
                    fuelPercent = handover.fuelPercent,
                    statusLabel = "Handover Verified (${handover.incomingStaffName})"
                )
            } else v
        }
        val act = StaffActivity(
            id = "ACT-HND-" + UUID.randomUUID().toString().take(5).uppercase(),
            staffId = handover.incomingStaffId,
            staffName = handover.incomingStaffName,
            department = Department.DRIVERS,
            category = ActivityCategory.FLEET_TRANSPORT,
            title = "Biometric Shift Handover: ${handover.vehicleReg}",
            caseReference = handover.id,
            clientFamily = "Fleet Depot Transfer",
            location = handover.branch,
            date = shortDateFormat.format(Date()),
            time = SimpleDateFormat("HH:mm", Locale.getDefault()).format(Date()),
            durationMinutes = 15,
            status = ActivityStatus.COMPLETED,
            notes = "Outgoing: ${handover.outgoingStaffName} -> Incoming: ${handover.incomingStaffName} • Fuel ${handover.fuelPercent}% • Odo ${handover.odometerKm}km • Lowering gear x${handover.loweringGearCount}. ${handover.conditionNotes}",
            verifiedByAdmin = true
        )
        _activities.value = listOf(act) + _activities.value
    }

    // =========================================================================
    // 5. 24/7 STAFF QR SHIFT ATTENDANCE VERIFICATION LEDGER
    // =========================================================================
    private val _shiftAttendanceLogs = MutableStateFlow(
        listOf(
            ShiftAttendanceRecord(
                id = "ATT-9001",
                staffId = "DRV-001",
                staffName = "Victor Owino",
                roleTitle = StaffRole.DRIVER.title,
                department = Department.DRIVERS,
                branch = "Bama Branch",
                scannedQrPayload = "JFD-STF|DRV-001|DRIVERS|Bama Branch|DRIVER",
                shiftId = null,
                shiftWindowLabel = "Night Vigil & 24/7 Shift (18:00 - 06:00)",
                action = ShiftAttendanceAction.CHECK_IN,
                checkpointLocation = "Bama Branch Dispatch Bay",
                verifiedByStaffId = "INV-001",
                verifiedByName = "Silas Hayoyo",
                timestampFormatted = "23 Sep 2026, 18:04",
                dateFormatted = "23 Sep 2026",
                notes = "QR badge verified prior to 24/7 night vigil cortege standby.",
                timestampMillis = System.currentTimeMillis() - 1_800_000L
            ),
            ShiftAttendanceRecord(
                id = "ATT-9002",
                staffId = "WRK-001",
                staffName = "Brian Adoche",
                roleTitle = StaffRole.WORKSHOP_WORKER.title,
                department = Department.WORKSHOP,
                branch = "Workshop",
                scannedQrPayload = "JFD-STF|WRK-001|WORKSHOP|Workshop|WORKSHOP_WORKER",
                shiftId = null,
                shiftWindowLabel = "Day Shift (06:00 - 18:00)",
                action = ShiftAttendanceAction.CHECK_IN,
                checkpointLocation = "Main Casket Workshop Gate",
                verifiedByStaffId = "CEO-001",
                verifiedByName = "Fredrick Hayoyo",
                timestampFormatted = "23 Sep 2026, 06:58",
                dateFormatted = "23 Sep 2026",
                notes = "Morning shift workshop attendance confirmed via QR pass.",
                timestampMillis = System.currentTimeMillis() - 7_200_000L
            )
        )
    )
    val shiftAttendanceLogs: StateFlow<List<ShiftAttendanceRecord>> = _shiftAttendanceLogs.asStateFlow()

    fun verifyStaffShiftAttendance(
        staff: StaffAccount,
        scannedQrPayload: String,
        action: ShiftAttendanceAction,
        checkpointLocation: String,
        shiftId: String? = null,
        shiftWindowLabel: String,
        verifiedByStaffId: String,
        verifiedByName: String,
        notes: String = ""
    ): ShiftAttendanceRecord {
        val now = Date()
        val nowTimeStr = SimpleDateFormat("HH:mm", Locale.getDefault()).format(now)
        val nowFullStr = dateFormat.format(now)
        val nowDateStr = shortDateFormat.format(now)
        val normalizedCheckpoint = checkpointLocation.ifBlank { "${staff.branch} Checkpoint" }

        // Resolve matching roster shift if any
        val currentRoster = _staffShiftSchedules.value.toMutableList()
        val matchedShiftIndex = when {
            !shiftId.isNullOrBlank() -> currentRoster.indexOfFirst { it.id == shiftId }
            else -> currentRoster.indexOfFirst {
                it.staffId.equals(staff.id, ignoreCase = true) &&
                    (it.shiftPeriod == ShiftPeriod.ACTIVE || it.shiftPeriod == ShiftPeriod.UPCOMING)
            }
        }
        val resolvedShiftId = if (matchedShiftIndex != -1) currentRoster[matchedShiftIndex].id else shiftId

        if (matchedShiftIndex != -1) {
            val targetShift = currentRoster[matchedShiftIndex]
            val updatedShift = when (action) {
                ShiftAttendanceAction.CHECK_IN -> targetShift.copy(
                    availabilityStatus = "On Duty (QR Verified)",
                    shiftPeriod = ShiftPeriod.ACTIVE,
                    checkInStatus = "QR Verified In at $nowTimeStr • $normalizedCheckpoint"
                )
                ShiftAttendanceAction.CHECK_OUT -> targetShift.copy(
                    availabilityStatus = "Shift Completed",
                    shiftPeriod = ShiftPeriod.PAST,
                    checkInStatus = "QR Verified Out at $nowTimeStr • $normalizedCheckpoint"
                )
            }
            currentRoster[matchedShiftIndex] = updatedShift
            _staffShiftSchedules.value = currentRoster
        }

        val record = ShiftAttendanceRecord(
            id = "ATT-" + UUID.randomUUID().toString().take(6).uppercase(),
            staffId = staff.id,
            staffName = staff.fullName,
            roleTitle = staff.role.title,
            department = staff.department,
            branch = staff.branch,
            scannedQrPayload = scannedQrPayload.ifBlank { StaffQrIdentityCodec.encodeStaffQrPayload(staff) },
            shiftId = resolvedShiftId,
            shiftWindowLabel = shiftWindowLabel,
            action = action,
            checkpointLocation = normalizedCheckpoint,
            verifiedByStaffId = verifiedByStaffId,
            verifiedByName = verifiedByName,
            timestampFormatted = nowFullStr,
            dateFormatted = nowDateStr,
            notes = notes.ifBlank { "${action.label} verified via staff QR badge." },
            timestampMillis = now.time
        )
        _shiftAttendanceLogs.value = listOf(record) + _shiftAttendanceLogs.value

        val act = StaffActivity(
            id = "ACT-QR-" + UUID.randomUUID().toString().take(5).uppercase(),
            staffId = staff.id,
            staffName = staff.fullName,
            department = staff.department,
            category = ActivityCategory.ADMIN_INVENTORY,
            title = "${action.label}: ${staff.fullName} ($shiftWindowLabel)",
            caseReference = record.id,
            clientFamily = "24/7 Shift Attendance Control",
            location = normalizedCheckpoint,
            date = nowDateStr,
            time = nowTimeStr,
            durationMinutes = 5,
            status = ActivityStatus.VERIFIED_BY_ADMIN,
            notes = "Verified by $verifiedByName ($verifiedByStaffId) • QR Payload: ${record.scannedQrPayload}. ${record.notes}",
            verifiedByAdmin = true
        )
        _activities.value = listOf(act) + _activities.value
        return record
    }
}




