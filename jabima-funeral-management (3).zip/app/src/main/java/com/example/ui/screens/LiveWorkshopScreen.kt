package com.example.ui.screens

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.AttachMoney
import androidx.compose.material.icons.filled.Build
import androidx.compose.material.icons.filled.Check
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.Handyman
import androidx.compose.material.icons.filled.Inventory2
import androidx.compose.material.icons.filled.Lock
import androidx.compose.material.icons.filled.PrecisionManufacturing
import androidx.compose.material.icons.filled.QrCode2
import androidx.compose.material.icons.filled.Schedule
import androidx.compose.material.icons.filled.Storefront
import androidx.compose.material.icons.filled.Warning
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.ExposedDropdownMenuBox
import androidx.compose.material3.ExposedDropdownMenuDefaults
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.MenuAnchorType
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.domain.CasketCostingEngine
import com.example.domain.PayrollRulesEngine
import com.example.model.Department
import com.example.model.JABIMA_BRANCHES
import com.example.model.JABIMA_CASKET_TYPES
import com.example.model.MarginStatus
import com.example.model.WorkshopProductionItem
import com.example.model.WorkshopProductionStage
import com.example.ui.StaffPortalViewModel
import com.example.ui.theme.AmberLight
import com.example.ui.theme.AmberWarning
import com.example.ui.theme.BorderLight
import com.example.ui.theme.EmeraldLight
import com.example.ui.theme.EmeraldSuccess
import com.example.ui.theme.Navy800
import com.example.ui.theme.Navy900
import com.example.ui.theme.PureWhite
import com.example.ui.theme.RoyalCobaltBlue
import com.example.ui.theme.RoyalCobaltIce
import com.example.ui.theme.TextSecondary

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun LiveWorkshopScreen(
    viewModel: StaffPortalViewModel
) {
    val workshopItems by viewModel.workshopItems.collectAsState()
    val allAccounts by viewModel.allAccounts.collectAsState()
    val caskets by viewModel.caskets.collectAsState()
    val materials by viewModel.inventoryMaterials.collectAsState()
    val isAdmin = viewModel.isAuthorizedForAdminChanges()

    val craftsmen = remember(allAccounts) {
        allAccounts.filter {
            it.department == Department.WORKSHOP ||
                it.role.name.contains("WORKSHOP") ||
                it.role.name.contains("ARTISAN")
        }.ifEmpty { allAccounts.take(5) }
    }

    val combinedCasketModels = remember(caskets) {
        (JABIMA_CASKET_TYPES + caskets.map { it.name }).distinct()
    }

    var selectedStageFilter by remember { mutableStateOf<WorkshopProductionStage?>(null) }
    var showNewJobDialog by remember { mutableStateOf(false) }
    var showCustomCasketDialog by remember { mutableStateOf(false) }
    var selectedItemForCraftsmanAssign by remember { mutableStateOf<WorkshopProductionItem?>(null) }
    var selectedItemForProgressUpdate by remember { mutableStateOf<WorkshopProductionItem?>(null) }
    var selectedItemForMaterialAlloc by remember { mutableStateOf<WorkshopProductionItem?>(null) }
    var selectedItemForStageCost by remember { mutableStateOf<WorkshopProductionItem?>(null) }

    val itemsInProduction = workshopItems.filter { !it.isCompleted }
    val doneForDay = workshopItems.filter { it.isDoneForDay }
    val totalDone = workshopItems.filter { it.isCompleted }
    val totalProdCostActive = itemsInProduction.sumOf { it.totalProductionCostKes }

    val filteredItems = remember(workshopItems, selectedStageFilter) {
        if (selectedStageFilter == null) workshopItems
        else workshopItems.filter { it.currentStage == selectedStageFilter }
    }

    LazyColumn(
        modifier = Modifier
            .fillMaxSize()
            .background(MaterialTheme.colorScheme.background)
            .padding(16.dp)
            .testTag("live_workshop_screen"),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        // ==========================================
        // 1. LIVE WORKSHOP OVERVIEW HERO CARD
        // ==========================================
        item {
            Card(
                shape = RoundedCornerShape(16.dp),
                colors = CardDefaults.cardColors(containerColor = Color.Transparent),
                modifier = Modifier
                    .fillMaxWidth()
                    .testTag("live_workshop_hero_card")
            ) {
                Box(
                    modifier = Modifier
                        .fillMaxWidth()
                        .background(
                            brush = Brush.linearGradient(
                                colors = listOf(Navy900, Navy800, RoyalCobaltBlue)
                            )
                        )
                        .padding(20.dp)
                ) {
                    Column {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Row(
                                verticalAlignment = Alignment.CenterVertically,
                                modifier = Modifier.weight(1f)
                            ) {
                                Box(
                                    modifier = Modifier
                                        .size(38.dp)
                                        .clip(CircleShape)
                                        .background(Color.White.copy(alpha = 0.15f)),
                                    contentAlignment = Alignment.Center
                                ) {
                                    Icon(
                                        imageVector = Icons.Default.PrecisionManufacturing,
                                        contentDescription = "Live Workshop",
                                        tint = Color.White,
                                        modifier = Modifier.size(22.dp)
                                    )
                                }
                                Spacer(modifier = Modifier.width(10.dp))
                                Column {
                                    Text(
                                        text = "LIVE WORKSHOP OVERVIEW",
                                        color = Color.White,
                                        fontSize = 15.sp,
                                        fontWeight = FontWeight.Bold,
                                        letterSpacing = 0.5.sp
                                    )
                                    Text(
                                        text = "Bama Branch Crafting • Per-Item Costing & Store Sync",
                                        color = Color(0xFF93C5FD),
                                        fontSize = 11.sp
                                    )
                                }
                            }

                            Button(
                                onClick = { showNewJobDialog = true },
                                colors = ButtonDefaults.buttonColors(containerColor = EmeraldSuccess),
                                shape = RoundedCornerShape(8.dp),
                                contentPadding = PaddingValues(horizontal = 12.dp, vertical = 6.dp),
                                modifier = Modifier.testTag("btn_start_new_casket_job")
                            ) {
                                Icon(Icons.Default.Add, contentDescription = null, modifier = Modifier.size(16.dp))
                                Spacer(modifier = Modifier.width(4.dp))
                                Text("New Job", fontSize = 12.sp, fontWeight = FontWeight.Bold)
                            }
                        }

                        Spacer(modifier = Modifier.height(10.dp))

                        // Admin Custom New Casket Type & Selling Price Button
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Surface(
                                color = Color.White.copy(alpha = 0.12f),
                                shape = RoundedCornerShape(8.dp)
                            ) {
                                Text(
                                    text = "Active Costing: KES ${String.format("%,.0f", totalProdCostActive)}",
                                    color = Color(0xFFFDE68A),
                                    fontSize = 11.sp,
                                    fontWeight = FontWeight.Bold,
                                    modifier = Modifier.padding(horizontal = 10.dp, vertical = 6.dp)
                                )
                            }

                            if (isAdmin) {
                                Button(
                                    onClick = { showCustomCasketDialog = true },
                                    colors = ButtonDefaults.buttonColors(
                                        containerColor = Color(0xFFF59E0B),
                                        contentColor = Navy900
                                    ),
                                    shape = RoundedCornerShape(8.dp),
                                    contentPadding = PaddingValues(horizontal = 12.dp, vertical = 6.dp),
                                    modifier = Modifier.testTag("btn_custom_new_casket_type")
                                ) {
                                    Icon(Icons.Default.Add, contentDescription = "Custom Casket Type", modifier = Modifier.size(15.dp))
                                    Spacer(modifier = Modifier.width(4.dp))
                                    Text("New Casket Type & Price", fontSize = 11.sp, fontWeight = FontWeight.ExtraBold)
                                }
                            } else {
                                Surface(
                                    color = Color.White.copy(alpha = 0.12f),
                                    shape = RoundedCornerShape(8.dp)
                                ) {
                                    Row(
                                        modifier = Modifier.padding(horizontal = 8.dp, vertical = 5.dp),
                                        verticalAlignment = Alignment.CenterVertically
                                    ) {
                                        Icon(Icons.Default.Lock, contentDescription = null, tint = Color(0xFFCBD5E1), modifier = Modifier.size(12.dp))
                                        Spacer(modifier = Modifier.width(4.dp))
                                        Text("Custom Type Price: Admin", color = Color(0xFFCBD5E1), fontSize = 10.sp)
                                    }
                                }
                            }
                        }

                        Spacer(modifier = Modifier.height(14.dp))

                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.spacedBy(10.dp)
                        ) {
                            WorkshopMetricBadge(
                                title = "In Production",
                                value = "${itemsInProduction.size}",
                                subtitle = "Active crafting jobs",
                                color = Color(0xFF60A5FA),
                                modifier = Modifier.weight(1f)
                            )
                            WorkshopMetricBadge(
                                title = "Done for the Day",
                                value = "${doneForDay.size}",
                                subtitle = "Daily target outputs",
                                color = EmeraldLight,
                                modifier = Modifier.weight(1f)
                            )
                            WorkshopMetricBadge(
                                title = "Total Done",
                                value = "${totalDone.size + 142}",
                                subtitle = "Finished to store",
                                color = Color(0xFFFDE68A),
                                modifier = Modifier.weight(1f)
                            )
                        }
                    }
                }
            }
        }

        // ==========================================
        // 2. THE 4 MANDATORY PRODUCTION STAGES PIPELINE
        // ==========================================
        item {
            Card(
                shape = RoundedCornerShape(14.dp),
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                border = BorderStroke(1.dp, BorderLight),
                modifier = Modifier
                    .fillMaxWidth()
                    .testTag("workshop_stages_pipeline_card")
            ) {
                Column(modifier = Modifier.padding(16.dp)) {
                    Text(
                        text = "Crafting Stages & Seamless Store Pipeline",
                        fontWeight = FontWeight.Bold,
                        fontSize = 14.sp,
                        color = MaterialTheme.colorScheme.onSurface
                    )
                    Text(
                        text = "Raw Material Issue -> 4 Assembly Stages -> Per-Item Costing -> Store & Casket Catalog",
                        fontSize = 11.sp,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )

                    Spacer(modifier = Modifier.height(12.dp))

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        WorkshopProductionStage.values().forEach { stage ->
                            val count = workshopItems.count { it.currentStage == stage && !it.isCompleted }
                            val isSelected = selectedStageFilter == stage

                            Surface(
                                shape = RoundedCornerShape(10.dp),
                                color = if (isSelected) Color(stage.colorHex).copy(alpha = 0.15f) else MaterialTheme.colorScheme.surfaceVariant,
                                border = BorderStroke(
                                    if (isSelected) 2.dp else 1.dp,
                                    if (isSelected) Color(stage.colorHex) else BorderLight
                                ),
                                modifier = Modifier
                                    .weight(1f)
                                    .clickable {
                                        selectedStageFilter = if (isSelected) null else stage
                                    }
                            ) {
                                Column(
                                    modifier = Modifier.padding(8.dp),
                                    horizontalAlignment = Alignment.CenterHorizontally
                                ) {
                                    Text(
                                        text = "Stage ${stage.stageNumber}",
                                        fontSize = 9.sp,
                                        fontWeight = FontWeight.Bold,
                                        color = Color(stage.colorHex)
                                    )
                                    Spacer(modifier = Modifier.height(2.dp))
                                    Text(
                                        text = stage.title,
                                        fontSize = 10.sp,
                                        fontWeight = FontWeight.SemiBold,
                                        color = MaterialTheme.colorScheme.onSurface,
                                        maxLines = 2,
                                        lineHeight = 11.sp
                                    )
                                    Spacer(modifier = Modifier.height(4.dp))
                                    Text(
                                        text = "$count Jobs",
                                        fontSize = 12.sp,
                                        fontWeight = FontWeight.ExtraBold,
                                        color = Color(stage.colorHex)
                                    )
                                }
                            }
                        }
                    }
                }
            }
        }

        // ==========================================
        // 3. PRODUCTION JOBS LIST
        // ==========================================
        item {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(
                    text = if (selectedStageFilter == null) "All Workshop Jobs (${filteredItems.size})" else "${selectedStageFilter?.title} (${filteredItems.size})",
                    fontSize = 15.sp,
                    fontWeight = FontWeight.Bold,
                    color = MaterialTheme.colorScheme.onBackground
                )

                if (selectedStageFilter != null) {
                    TextButton(onClick = { selectedStageFilter = null }) {
                        Text("Show All Stages", fontSize = 11.sp, color = RoyalCobaltBlue)
                    }
                }
            }
        }

        items(filteredItems, key = { it.id }) { item ->
            WorkshopJobCard(
                item = item,
                onAssignCraftsman = { selectedItemForCraftsmanAssign = item },
                onUpdateProgress = { selectedItemForProgressUpdate = item },
                onToggleDoneForDay = { viewModel.markWorkshopItemDoneForDay(item.id, !item.isDoneForDay) },
                onAdvanceStage = {
                    val nextStage = when (item.currentStage) {
                        WorkshopProductionStage.FRAME_AND_ASSEMBLY -> WorkshopProductionStage.SANDING_AND_PAINTING
                        WorkshopProductionStage.SANDING_AND_PAINTING -> WorkshopProductionStage.CLOTH_LINING_AND_FINAL_ASSEMBLY
                        WorkshopProductionStage.CLOTH_LINING_AND_FINAL_ASSEMBLY -> WorkshopProductionStage.GLASS_FITTING
                        WorkshopProductionStage.GLASS_FITTING -> WorkshopProductionStage.GLASS_FITTING
                    }
                    val nextPct = when (nextStage) {
                        WorkshopProductionStage.FRAME_AND_ASSEMBLY -> 25
                        WorkshopProductionStage.SANDING_AND_PAINTING -> 50
                        WorkshopProductionStage.CLOTH_LINING_AND_FINAL_ASSEMBLY -> 75
                        WorkshopProductionStage.GLASS_FITTING -> 100
                    }
                    viewModel.updateWorkshopStage(item.id, nextStage, nextPct)
                },
                onAllocateMaterial = { selectedItemForMaterialAlloc = item },
                onAddStageCost = { selectedItemForStageCost = item },
                onCompleteToStore = { viewModel.completeWorkshopJobToStore(item.id) }
            )
        }

        item {
            Spacer(modifier = Modifier.height(80.dp))
        }
    }

    // ==========================================
    // DIALOG: ADMIN CUSTOM NEW CASKET TYPE & PRICE
    // ==========================================
    if (showCustomCasketDialog) {
        var name by remember { mutableStateOf("") }
        var woodType by remember { mutableStateOf("Hardwood Mahogany") }
        var tier by remember { mutableStateOf("VIP Custom") }
        var finish by remember { mutableStateOf("High-Gloss Cherry Walnut") }
        var interiorLining by remember { mutableStateOf("Quilted Cream Velvet Silk") }
        var sellingPriceStr by remember { mutableStateOf("145000") }
        var materialCostStr by remember { mutableStateOf("45000") }
        var laborCostStr by remember { mutableStateOf("14000") }
        var finishingCostStr by remember { mutableStateOf("8000") }
        var branch by remember { mutableStateOf(JABIMA_BRANCHES.first()) }
        var selectedCraftsman by remember { mutableStateOf(craftsmen.firstOrNull()) }
        var notes by remember { mutableStateOf("") }
        var craftExpanded by remember { mutableStateOf(false) }

        val matVal = materialCostStr.toDoubleOrNull() ?: 0.0
        val labVal = laborCostStr.toDoubleOrNull() ?: 0.0
        val finVal = finishingCostStr.toDoubleOrNull() ?: 0.0
        val sellVal = sellingPriceStr.toDoubleOrNull() ?: 0.0
        val totalCost = matVal + labVal + finVal
        val estMargin = sellVal - totalCost

        AlertDialog(
            onDismissRequest = { showCustomCasketDialog = false },
            title = {
                Text("Customize New Casket Type (Admin)", fontWeight = FontWeight.Bold, fontSize = 16.sp)
            },
            text = {
                Column(
                    modifier = Modifier.verticalScroll(rememberScrollState()),
                    verticalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    Text(
                        "Adds the new design to Live Workshop Production AND syncs its selling price into Casket Order & Checkout.",
                        fontSize = 11.sp,
                        color = TextSecondary
                    )
                    OutlinedTextField(
                        value = name,
                        onValueChange = { name = it },
                        label = { Text("New Casket Type Name *") },
                        placeholder = { Text("e.g. Royal Sovereign Dome") },
                        modifier = Modifier.fillMaxWidth().testTag("input_custom_prod_casket_name")
                    )
                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        OutlinedTextField(
                            value = woodType,
                            onValueChange = { woodType = it },
                            label = { Text("Wood / Timber") },
                            modifier = Modifier.weight(1f)
                        )
                        OutlinedTextField(
                            value = tier,
                            onValueChange = { tier = it },
                            label = { Text("Tier") },
                            modifier = Modifier.weight(1f)
                        )
                    }
                    OutlinedTextField(
                        value = finish,
                        onValueChange = { finish = it },
                        label = { Text("Polish & Finish") },
                        modifier = Modifier.fillMaxWidth()
                    )
                    OutlinedTextField(
                        value = interiorLining,
                        onValueChange = { interiorLining = it },
                        label = { Text("Interior Lining") },
                        modifier = Modifier.fillMaxWidth()
                    )
                    OutlinedTextField(
                        value = sellingPriceStr,
                        onValueChange = { sellingPriceStr = it },
                        label = { Text("Admin Selling Price (KES) *") },
                        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                        modifier = Modifier.fillMaxWidth().testTag("input_custom_prod_selling_price")
                    )
                    Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                        OutlinedTextField(
                            value = materialCostStr,
                            onValueChange = { materialCostStr = it },
                            label = { Text("Material Cost") },
                            keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                            modifier = Modifier.weight(1f)
                        )
                        OutlinedTextField(
                            value = laborCostStr,
                            onValueChange = { laborCostStr = it },
                            label = { Text("Labor Cost") },
                            keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                            modifier = Modifier.weight(1f)
                        )
                        OutlinedTextField(
                            value = finishingCostStr,
                            onValueChange = { finishingCostStr = it },
                            label = { Text("Finish Cost") },
                            keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                            modifier = Modifier.weight(1f)
                        )
                    }
                    val dialogMarginEval = PayrollRulesEngine.evaluateBomMargin(
                        sellingPriceKes = sellVal,
                        materialCostKes = matVal,
                        laborCostKes = labVal,
                        finishingCostKes = finVal
                    )
                    Surface(
                        color = when (dialogMarginEval.status) {
                            MarginStatus.HEALTHY -> RoyalCobaltIce
                            MarginStatus.LOW_MARGIN -> AmberLight
                            MarginStatus.BELOW_COST -> com.example.ui.theme.StrokeRedLight
                        },
                        shape = RoundedCornerShape(8.dp),
                        border = BorderStroke(
                            1.dp,
                            when (dialogMarginEval.status) {
                                MarginStatus.HEALTHY -> RoyalCobaltBlue.copy(alpha = 0.25f)
                                MarginStatus.LOW_MARGIN -> AmberWarning
                                MarginStatus.BELOW_COST -> com.example.ui.theme.StrokeRed
                            }
                        ),
                        modifier = Modifier.fillMaxWidth().testTag("custom_casket_margin_guard_box")
                    ) {
                        Column(modifier = Modifier.padding(10.dp), verticalArrangement = Arrangement.spacedBy(3.dp)) {
                            Text(
                                text = "Total Production Cost: KES ${String.format("%,.0f", totalCost)}",
                                fontSize = 11.sp,
                                fontWeight = FontWeight.Bold,
                                color = Navy900
                            )
                            Text(
                                text = "Projected Profit Margin: KES ${String.format("%,.0f", estMargin)} (${dialogMarginEval.marginPercent}%)",
                                fontSize = 11.sp,
                                fontWeight = FontWeight.ExtraBold,
                                color = when (dialogMarginEval.status) {
                                    MarginStatus.HEALTHY -> EmeraldSuccess
                                    MarginStatus.LOW_MARGIN -> Color(0xFFB45309)
                                    MarginStatus.BELOW_COST -> com.example.ui.theme.StrokeRed
                                }
                            )
                            dialogMarginEval.warningMessage?.let { warn ->
                                Text(
                                    text = warn,
                                    fontSize = 10.sp,
                                    fontWeight = FontWeight.SemiBold,
                                    color = if (dialogMarginEval.status == MarginStatus.BELOW_COST) com.example.ui.theme.StrokeRedDark else Color(0xFF92400E)
                                )
                            }
                        }
                    }

                    ExposedDropdownMenuBox(
                        expanded = craftExpanded,
                        onExpandedChange = { craftExpanded = it }
                    ) {
                        OutlinedTextField(
                            value = selectedCraftsman?.fullName ?: "Select Craftsman",
                            onValueChange = {},
                            readOnly = true,
                            label = { Text("Assign Craftsman") },
                            trailingIcon = { ExposedDropdownMenuDefaults.TrailingIcon(expanded = craftExpanded) },
                            modifier = Modifier
                                .fillMaxWidth()
                                .menuAnchor(MenuAnchorType.PrimaryNotEditable)
                        )
                        ExposedDropdownMenu(
                            expanded = craftExpanded,
                            onDismissRequest = { craftExpanded = false }
                        ) {
                            craftsmen.forEach { craft ->
                                DropdownMenuItem(
                                    text = { Text("${craft.fullName} (${craft.branch})") },
                                    onClick = {
                                        selectedCraftsman = craft
                                        craftExpanded = false
                                    }
                                )
                            }
                        }
                    }

                    OutlinedTextField(
                        value = notes,
                        onValueChange = { notes = it },
                        label = { Text("Production Specs / Notes") },
                        modifier = Modifier.fillMaxWidth()
                    )
                }
            },
            confirmButton = {
                Button(
                    onClick = {
                        val craft = selectedCraftsman ?: craftsmen.first()
                        val cleanName = name.trim().ifBlank { "Custom Artisan Casket" }
                        viewModel.createCustomProductionCasketType(
                            name = cleanName,
                            woodType = woodType.ifBlank { "Mahogany" },
                            tier = tier.ifBlank { "Custom" },
                            finish = finish.ifBlank { "Gloss" },
                            interiorLining = interiorLining.ifBlank { "Quilted Silk" },
                            sellingPriceKes = sellVal.coerceAtLeast(1000.0),
                            materialCostKes = matVal,
                            laborCostKes = labVal,
                            finishingCostKes = finVal,
                            craftsmanId = craft.id,
                            craftsmanName = craft.fullName,
                            branch = branch,
                            notes = notes
                        )
                        showCustomCasketDialog = false
                    },
                    colors = ButtonDefaults.buttonColors(containerColor = EmeraldSuccess),
                    modifier = Modifier.testTag("btn_confirm_custom_prod_casket")
                ) {
                    Text("Create & Price Casket")
                }
            },
            dismissButton = {
                TextButton(onClick = { showCustomCasketDialog = false }) {
                    Text("Cancel")
                }
            }
        )
    }

    // ==========================================
    // DIALOG: CREATE NEW CASKET PRODUCTION JOB
    // ==========================================
    if (showNewJobDialog) {
        var selectedCasket by remember { mutableStateOf(combinedCasketModels.firstOrNull() ?: JABIMA_CASKET_TYPES.first()) }
        var selectedCraftsman by remember { mutableStateOf(craftsmen.firstOrNull()) }
        var initialStage by remember { mutableStateOf(WorkshopProductionStage.FRAME_AND_ASSEMBLY) }
        val initialSpec = CasketCostingEngine.findModelForCasketName(selectedCasket)
        var sellingPriceStr by remember {
            val match = caskets.firstOrNull { it.name.equals(selectedCasket, ignoreCase = true) }
            val fallback = initialSpec?.recommendedOrderPriceKes ?: 95000.0
            mutableStateOf((match?.priceKes ?: fallback).toInt().toString())
        }
        var matCostStr by remember { mutableStateOf((initialSpec?.baseBodyMaterialCostKes ?: 28000.0).toInt().toString()) }
        var laborCostStr by remember { mutableStateOf((initialSpec?.crewLaborCostKes ?: 9000.0).toInt().toString()) }
        var finishCostStr by remember { mutableStateOf(((initialSpec?.finishingMaterialCostKes ?: 3000.0) + (initialSpec?.paintAndAbrasivesCostKes ?: 1500.0)).toInt().toString()) }
        var jobNotes by remember { mutableStateOf("") }

        var casketExpanded by remember { mutableStateOf(false) }
        var craftsmanExpanded by remember { mutableStateOf(false) }

        AlertDialog(
            onDismissRequest = { showNewJobDialog = false },
            title = {
                Text("Start New Casket Production Job", fontWeight = FontWeight.Bold, fontSize = 16.sp)
            },
            text = {
                Column(
                    modifier = Modifier.verticalScroll(rememberScrollState()),
                    verticalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    Text("Select casket model, production costs, and craftsman.", fontSize = 12.sp, color = TextSecondary)

                    ExposedDropdownMenuBox(
                        expanded = casketExpanded,
                        onExpandedChange = { casketExpanded = it }
                    ) {
                        OutlinedTextField(
                            value = selectedCasket,
                            onValueChange = {},
                            readOnly = true,
                            label = { Text("Casket Type") },
                            trailingIcon = { ExposedDropdownMenuDefaults.TrailingIcon(expanded = casketExpanded) },
                            modifier = Modifier
                                .fillMaxWidth()
                                .menuAnchor(MenuAnchorType.PrimaryNotEditable)
                        )
                        ExposedDropdownMenu(
                            expanded = casketExpanded,
                            onDismissRequest = { casketExpanded = false }
                        ) {
                            combinedCasketModels.forEach { casketName ->
                                DropdownMenuItem(
                                    text = { Text(casketName) },
                                    onClick = {
                                        selectedCasket = casketName
                                        val match = caskets.firstOrNull { it.name.equals(casketName, ignoreCase = true) }
                                        val spec = CasketCostingEngine.findModelForCasketName(casketName)
                                        if (match != null) {
                                            sellingPriceStr = match.priceKes.toInt().toString()
                                        } else if (spec != null) {
                                            sellingPriceStr = spec.recommendedOrderPriceKes.toInt().toString()
                                        }
                                        if (spec != null) {
                                            matCostStr = spec.baseBodyMaterialCostKes.toInt().toString()
                                            laborCostStr = spec.crewLaborCostKes.toInt().toString()
                                            finishCostStr = (spec.finishingMaterialCostKes + spec.paintAndAbrasivesCostKes).toInt().toString()
                                        }
                                        casketExpanded = false
                                    }
                                )
                            }
                        }
                    }

                    ExposedDropdownMenuBox(
                        expanded = craftsmanExpanded,
                        onExpandedChange = { craftsmanExpanded = it }
                    ) {
                        OutlinedTextField(
                            value = selectedCraftsman?.fullName ?: "Select Craftsman",
                            onValueChange = {},
                            readOnly = true,
                            label = { Text("Assigned Craftsman") },
                            trailingIcon = { ExposedDropdownMenuDefaults.TrailingIcon(expanded = craftsmanExpanded) },
                            modifier = Modifier
                                .fillMaxWidth()
                                .menuAnchor(MenuAnchorType.PrimaryNotEditable)
                        )
                        ExposedDropdownMenu(
                            expanded = craftsmanExpanded,
                            onDismissRequest = { craftsmanExpanded = false }
                        ) {
                            craftsmen.forEach { craft ->
                                DropdownMenuItem(
                                    text = { Text("${craft.fullName} (${craft.id})") },
                                    onClick = {
                                        selectedCraftsman = craft
                                        craftsmanExpanded = false
                                    }
                                )
                            }
                        }
                    }

                    OutlinedTextField(
                        value = sellingPriceStr,
                        onValueChange = { sellingPriceStr = it },
                        label = { Text("Target Selling Price (KES)") },
                        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                        modifier = Modifier.fillMaxWidth()
                    )

                    Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                        OutlinedTextField(
                            value = matCostStr,
                            onValueChange = { matCostStr = it },
                            label = { Text("Mat Cost") },
                            keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                            modifier = Modifier.weight(1f)
                        )
                        OutlinedTextField(
                            value = laborCostStr,
                            onValueChange = { laborCostStr = it },
                            label = { Text("Labor Cost") },
                            keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                            modifier = Modifier.weight(1f)
                        )
                        OutlinedTextField(
                            value = finishCostStr,
                            onValueChange = { finishCostStr = it },
                            label = { Text("Finish") },
                            keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                            modifier = Modifier.weight(1f)
                        )
                    }

                    OutlinedTextField(
                        value = jobNotes,
                        onValueChange = { jobNotes = it },
                        label = { Text("Special Specifications / Notes") },
                        placeholder = { Text("e.g. Quilted white silk, double swing bars") },
                        modifier = Modifier.fillMaxWidth()
                    )
                }
            },
            confirmButton = {
                Button(
                    onClick = {
                        val craft = selectedCraftsman ?: craftsmen.first()
                        viewModel.createWorkshopItem(
                            casketType = selectedCasket,
                            craftsmanId = craft.id,
                            craftsmanName = craft.fullName,
                            initialStage = initialStage,
                            notes = jobNotes,
                            sellingPriceKes = sellingPriceStr.toDoubleOrNull() ?: 95000.0,
                            materialCostKes = matCostStr.toDoubleOrNull() ?: 25000.0,
                            laborCostKes = laborCostStr.toDoubleOrNull() ?: 8000.0,
                            finishingCostKes = finishCostStr.toDoubleOrNull() ?: 4000.0
                        )
                        showNewJobDialog = false
                    },
                    colors = ButtonDefaults.buttonColors(containerColor = EmeraldSuccess)
                ) {
                    Text("Create Job")
                }
            },
            dismissButton = {
                TextButton(onClick = { showNewJobDialog = false }) {
                    Text("Cancel")
                }
            }
        )
    }

    // ==========================================
    // DIALOG: ALLOCATE RAW MATERIAL TO JOB
    // ==========================================
    selectedItemForMaterialAlloc?.let { job ->
        val availableMaterials = materials.filter { it.quantity > 0 }
        var chosenMaterial by remember { mutableStateOf(availableMaterials.firstOrNull()) }
        var qtyStr by remember { mutableStateOf("2") }
        var matExpanded by remember { mutableStateOf(false) }

        AlertDialog(
            onDismissRequest = { selectedItemForMaterialAlloc = null },
            title = {
                Text("Allocate Raw Material to #${job.id}", fontWeight = FontWeight.Bold, fontSize = 15.sp)
            },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                    Text(
                        "Deducts directly from Central Store and adds cost to ${job.casketType} production.",
                        fontSize = 11.sp,
                        color = TextSecondary
                    )
                    if (availableMaterials.isEmpty()) {
                        Text("No raw materials in stock. Purchase materials in Inventory Management first.", color = com.example.ui.theme.StrokeRed, fontSize = 12.sp)
                    } else {
                        ExposedDropdownMenuBox(
                            expanded = matExpanded,
                            onExpandedChange = { matExpanded = it }
                        ) {
                            OutlinedTextField(
                                value = chosenMaterial?.let { "${it.name} (${it.quantity} ${it.unit} @ KES ${it.unitCostKes.toInt()})" } ?: "Select Material",
                                onValueChange = {},
                                readOnly = true,
                                label = { Text("Store Material") },
                                trailingIcon = { ExposedDropdownMenuDefaults.TrailingIcon(expanded = matExpanded) },
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .menuAnchor(MenuAnchorType.PrimaryNotEditable)
                            )
                            ExposedDropdownMenu(
                                expanded = matExpanded,
                                onDismissRequest = { matExpanded = false }
                            ) {
                                availableMaterials.forEach { mat ->
                                    DropdownMenuItem(
                                        text = { Text("${mat.name} • ${mat.quantity} ${mat.unit} @ KES ${String.format("%,.0f", mat.unitCostKes)}") },
                                        onClick = {
                                            chosenMaterial = mat
                                            matExpanded = false
                                        }
                                    )
                                }
                            }
                        }

                        OutlinedTextField(
                            value = qtyStr,
                            onValueChange = { qtyStr = it },
                            label = { Text("Quantity to Issue (${chosenMaterial?.unit ?: "Units"})") },
                            keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                            modifier = Modifier.fillMaxWidth()
                        )

                        val qtyVal = qtyStr.toIntOrNull() ?: 0
                        val unitCost = chosenMaterial?.unitCostKes ?: 0.0
                        Text(
                            text = "Material Allocation Cost: KES ${String.format("%,.0f", qtyVal * unitCost)}",
                            fontSize = 12.sp,
                            fontWeight = FontWeight.Bold,
                            color = RoyalCobaltBlue
                        )
                    }
                }
            },
            confirmButton = {
                Button(
                    enabled = chosenMaterial != null && (qtyStr.toIntOrNull() ?: 0) > 0,
                    onClick = {
                        val mat = chosenMaterial ?: return@Button
                        val qty = qtyStr.toIntOrNull() ?: 1
                        viewModel.allocateMaterialToWorkshopJob(job.id, mat.id, qty)
                        selectedItemForMaterialAlloc = null
                    },
                    colors = ButtonDefaults.buttonColors(containerColor = RoyalCobaltBlue),
                    modifier = Modifier.testTag("btn_confirm_allocate_material")
                ) {
                    Text("Allocate & Add Cost")
                }
            },
            dismissButton = {
                TextButton(onClick = { selectedItemForMaterialAlloc = null }) {
                    Text("Cancel")
                }
            }
        )
    }

    // ==========================================
    // DIALOG: LOG STAGE PRODUCTION COST
    // ==========================================
    selectedItemForStageCost?.let { job ->
        var laborAddStr by remember { mutableStateOf("2500") }
        var finishingAddStr by remember { mutableStateOf("1500") }

        AlertDialog(
            onDismissRequest = { selectedItemForStageCost = null },
            title = {
                Text("Log Stage Production Cost (#${job.id})", fontWeight = FontWeight.Bold, fontSize = 15.sp)
            },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                    Text(
                        "Current stage: ${job.currentStage.title} • Current total cost: KES ${String.format("%,.0f", job.totalProductionCostKes)}",
                        fontSize = 11.sp,
                        color = TextSecondary
                    )
                    OutlinedTextField(
                        value = laborAddStr,
                        onValueChange = { laborAddStr = it },
                        label = { Text("Additional Labor Cost (KES)") },
                        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                        modifier = Modifier.fillMaxWidth()
                    )
                    OutlinedTextField(
                        value = finishingAddStr,
                        onValueChange = { finishingAddStr = it },
                        label = { Text("Additional Finishing / Polish / Fittings Cost (KES)") },
                        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                        modifier = Modifier.fillMaxWidth()
                    )
                }
            },
            confirmButton = {
                Button(
                    onClick = {
                        viewModel.addWorkshopProductionStageCost(
                            itemId = job.id,
                            laborAddKes = laborAddStr.toDoubleOrNull() ?: 0.0,
                            finishingAddKes = finishingAddStr.toDoubleOrNull() ?: 0.0
                        )
                        selectedItemForStageCost = null
                    },
                    colors = ButtonDefaults.buttonColors(containerColor = EmeraldSuccess),
                    modifier = Modifier.testTag("btn_confirm_stage_cost")
                ) {
                    Text("Log Cost")
                }
            },
            dismissButton = {
                TextButton(onClick = { selectedItemForStageCost = null }) {
                    Text("Cancel")
                }
            }
        )
    }

    // ==========================================
    // DIALOG: ASSIGN CRAFTSMAN
    // ==========================================
    selectedItemForCraftsmanAssign?.let { item ->
        var selectedCraftsman by remember { mutableStateOf(craftsmen.firstOrNull { it.id == item.assignedCraftsmanId } ?: craftsmen.first()) }
        var dropdownExpanded by remember { mutableStateOf(false) }

        AlertDialog(
            onDismissRequest = { selectedItemForCraftsmanAssign = null },
            title = {
                Text("Assign Craftsman to ${item.casketType}", fontWeight = FontWeight.Bold, fontSize = 16.sp)
            },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                    Text("Job #${item.id} • Current: ${item.assignedCraftsmanName}", fontSize = 12.sp, color = TextSecondary)

                    ExposedDropdownMenuBox(
                        expanded = dropdownExpanded,
                        onExpandedChange = { dropdownExpanded = it }
                    ) {
                        OutlinedTextField(
                            value = selectedCraftsman.fullName,
                            onValueChange = {},
                            readOnly = true,
                            label = { Text("Select Craftsman") },
                            trailingIcon = { ExposedDropdownMenuDefaults.TrailingIcon(expanded = dropdownExpanded) },
                            modifier = Modifier
                                .fillMaxWidth()
                                .menuAnchor(MenuAnchorType.PrimaryNotEditable)
                        )
                        ExposedDropdownMenu(
                            expanded = dropdownExpanded,
                            onDismissRequest = { dropdownExpanded = false }
                        ) {
                            craftsmen.forEach { craft ->
                                DropdownMenuItem(
                                    text = { Text("${craft.fullName} (${craft.branch})") },
                                    onClick = {
                                        selectedCraftsman = craft
                                        dropdownExpanded = false
                                    }
                                )
                            }
                        }
                    }
                }
            },
            confirmButton = {
                Button(
                    onClick = {
                        viewModel.assignCraftsmanToWorkshopItem(item.id, selectedCraftsman.id, selectedCraftsman.fullName)
                        selectedItemForCraftsmanAssign = null
                    },
                    colors = ButtonDefaults.buttonColors(containerColor = RoyalCobaltBlue)
                ) {
                    Text("Assign & Alert")
                }
            },
            dismissButton = {
                TextButton(onClick = { selectedItemForCraftsmanAssign = null }) {
                    Text("Cancel")
                }
            }
        )
    }

    // ==========================================
    // DIALOG: UPDATE STAGE & PERCENTAGE DONE
    // ==========================================
    selectedItemForProgressUpdate?.let { item ->
        var selectedStage by remember { mutableStateOf(item.currentStage) }
        var progressPercent by remember { mutableStateOf(item.percentageDone) }

        AlertDialog(
            onDismissRequest = { selectedItemForProgressUpdate = null },
            title = {
                Text("Update Production Stage (${item.casketType})", fontWeight = FontWeight.Bold, fontSize = 16.sp)
            },
            text = {
                Column(
                    modifier = Modifier.verticalScroll(rememberScrollState()),
                    verticalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    Text("Job #${item.id} • Assigned: ${item.assignedCraftsmanName}", fontSize = 12.sp, color = TextSecondary)
                    Text("Choose Stage:", fontWeight = FontWeight.Bold, fontSize = 13.sp)

                    WorkshopProductionStage.values().forEach { stg ->
                        Surface(
                            shape = RoundedCornerShape(8.dp),
                            color = if (selectedStage == stg) Color(stg.colorHex).copy(alpha = 0.15f) else MaterialTheme.colorScheme.surfaceVariant,
                            border = BorderStroke(if (selectedStage == stg) 2.dp else 1.dp, if (selectedStage == stg) Color(stg.colorHex) else BorderLight),
                            modifier = Modifier
                                .fillMaxWidth()
                                .clickable {
                                    selectedStage = stg
                                    progressPercent = stg.defaultPercentage
                                }
                        ) {
                            Row(
                                modifier = Modifier.padding(10.dp),
                                verticalAlignment = Alignment.CenterVertically,
                                horizontalArrangement = Arrangement.SpaceBetween
                            ) {
                                Column(modifier = Modifier.weight(1f)) {
                                    Text("Stage ${stg.stageNumber}: ${stg.title}", fontWeight = FontWeight.Bold, fontSize = 12.sp, color = Color(stg.colorHex))
                                    Text(stg.description, fontSize = 10.sp, color = TextSecondary)
                                }
                                Text("${stg.defaultPercentage}%", fontWeight = FontWeight.Bold, fontSize = 13.sp, color = Color(stg.colorHex))
                            }
                        }
                    }

                    Text("Current Progress: $progressPercent%", fontWeight = FontWeight.Bold, fontSize = 13.sp)
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(6.dp)
                    ) {
                        listOf(25, 50, 75, 90, 100).forEach { pct ->
                            Button(
                                onClick = { progressPercent = pct },
                                colors = ButtonDefaults.buttonColors(
                                    containerColor = if (progressPercent == pct) RoyalCobaltBlue else Color(0xFFE2E8F0),
                                    contentColor = if (progressPercent == pct) Color.White else Navy900
                                ),
                                shape = RoundedCornerShape(6.dp),
                                contentPadding = PaddingValues(horizontal = 6.dp, vertical = 4.dp),
                                modifier = Modifier.weight(1f)
                            ) {
                                Text("$pct%", fontSize = 11.sp, fontWeight = FontWeight.Bold)
                            }
                        }
                    }
                }
            },
            confirmButton = {
                Button(
                    onClick = {
                        viewModel.updateWorkshopStage(item.id, selectedStage, progressPercent)
                        selectedItemForProgressUpdate = null
                    },
                    colors = ButtonDefaults.buttonColors(containerColor = EmeraldSuccess)
                ) {
                    Text("Save Progress")
                }
            },
            dismissButton = {
                TextButton(onClick = { selectedItemForProgressUpdate = null }) {
                    Text("Cancel")
                }
            }
        )
    }
}

@Composable
private fun WorkshopMetricBadge(
    title: String,
    value: String,
    subtitle: String,
    color: Color,
    modifier: Modifier = Modifier
) {
    Surface(
        color = Color.White.copy(alpha = 0.12f),
        shape = RoundedCornerShape(12.dp),
        border = BorderStroke(1.dp, Color.White.copy(alpha = 0.2f)),
        modifier = modifier
    ) {
        Column(modifier = Modifier.padding(12.dp)) {
            Text(text = title, fontSize = 10.sp, color = color, fontWeight = FontWeight.SemiBold)
            Spacer(modifier = Modifier.height(2.dp))
            Text(text = value, fontSize = 22.sp, fontWeight = FontWeight.ExtraBold, color = Color.White)
            Spacer(modifier = Modifier.height(2.dp))
            Text(text = subtitle, fontSize = 9.sp, color = Color.White.copy(alpha = 0.7f))
        }
    }
}

@Composable
private fun WorkshopJobCard(
    item: WorkshopProductionItem,
    onAssignCraftsman: () -> Unit,
    onUpdateProgress: () -> Unit,
    onToggleDoneForDay: () -> Unit,
    onAdvanceStage: () -> Unit,
    onAllocateMaterial: () -> Unit,
    onAddStageCost: () -> Unit,
    onCompleteToStore: () -> Unit
) {
    Card(
        shape = RoundedCornerShape(14.dp),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
        border = BorderStroke(1.dp, BorderLight),
        modifier = Modifier
            .fillMaxWidth()
            .testTag("workshop_job_card_${item.id}")
    ) {
        Column(modifier = Modifier.padding(16.dp)) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Row(verticalAlignment = Alignment.CenterVertically, modifier = Modifier.weight(1f)) {
                    Box(
                        modifier = Modifier
                            .size(10.dp)
                            .clip(CircleShape)
                            .background(Color(item.currentStage.colorHex))
                    )
                    Spacer(modifier = Modifier.width(8.dp))
                    Text(
                        text = item.casketType,
                        fontWeight = FontWeight.Bold,
                        fontSize = 15.sp,
                        color = MaterialTheme.colorScheme.onSurface,
                        maxLines = 1,
                        overflow = TextOverflow.Ellipsis
                    )
                    Spacer(modifier = Modifier.width(6.dp))
                    Text(
                        text = "#${item.id}",
                        fontSize = 11.sp,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                }

                Surface(
                    shape = RoundedCornerShape(12.dp),
                    color = Color(item.currentStage.colorHex).copy(alpha = 0.12f),
                    border = BorderStroke(1.dp, Color(item.currentStage.colorHex).copy(alpha = 0.4f))
                ) {
                    Text(
                        text = "Stage ${item.currentStage.stageNumber}: ${item.currentStage.title}",
                        color = Color(item.currentStage.colorHex),
                        fontSize = 10.sp,
                        fontWeight = FontWeight.Bold,
                        modifier = Modifier.padding(horizontal = 8.dp, vertical = 3.dp)
                    )
                }
            }

            Spacer(modifier = Modifier.height(8.dp))

            Row(
                modifier = Modifier.fillMaxWidth(),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                Text(
                    text = "${item.percentageDone}% Completed",
                    fontSize = 12.sp,
                    fontWeight = FontWeight.Bold,
                    color = Color(item.currentStage.colorHex)
                )

                Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                    if (item.isCustomDesign) {
                        Surface(
                            shape = RoundedCornerShape(6.dp),
                            color = Color(0xFFFEF3C7)
                        ) {
                            Text(
                                text = "Custom Design",
                                fontSize = 10.sp,
                                fontWeight = FontWeight.Bold,
                                color = Color(0xFFB45309),
                                modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp)
                            )
                        }
                    }

                    if (item.isDoneForDay || item.isCompleted) {
                        Surface(
                            shape = RoundedCornerShape(6.dp),
                            color = EmeraldLight
                        ) {
                            Row(
                                verticalAlignment = Alignment.CenterVertically,
                                modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp)
                            ) {
                                Icon(Icons.Default.CheckCircle, contentDescription = null, tint = EmeraldSuccess, modifier = Modifier.size(12.dp))
                                Spacer(modifier = Modifier.width(4.dp))
                                Text(
                                    text = if (item.isCompleted) "In Store" else "Done Today",
                                    fontSize = 10.sp,
                                    fontWeight = FontWeight.Bold,
                                    color = EmeraldSuccess
                                )
                            }
                        }
                    }
                }
            }

            Spacer(modifier = Modifier.height(6.dp))

            LinearProgressIndicator(
                progress = { item.percentageDone / 100f },
                modifier = Modifier
                    .fillMaxWidth()
                    .height(8.dp)
                    .clip(RoundedCornerShape(4.dp)),
                color = Color(item.currentStage.colorHex),
                trackColor = Color(0xFFE2E8F0)
            )

            Spacer(modifier = Modifier.height(10.dp))

            // Per-Item Production Cost Breakdown + BOM Margin Guard
            val marginEval = PayrollRulesEngine.evaluateBomMargin(
                sellingPriceKes = item.sellingPriceKes,
                materialCostKes = item.materialCostKes,
                laborCostKes = item.laborCostKes,
                finishingCostKes = item.finishingCostKes
            )
            Surface(
                color = RoyalCobaltIce.copy(alpha = 0.5f),
                shape = RoundedCornerShape(10.dp),
                border = BorderStroke(1.dp, RoyalCobaltBlue.copy(alpha = 0.2f)),
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(modifier = Modifier.padding(10.dp), verticalArrangement = Arrangement.spacedBy(4.dp)) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Text("Mat: KES ${String.format("%,.0f", item.materialCostKes)}", fontSize = 10.sp, color = Navy900, fontWeight = FontWeight.Medium)
                        Text("Labor: KES ${String.format("%,.0f", item.laborCostKes)}", fontSize = 10.sp, color = Navy900, fontWeight = FontWeight.Medium)
                        Text("Finish: KES ${String.format("%,.0f", item.finishingCostKes)}", fontSize = 10.sp, color = Navy900, fontWeight = FontWeight.Medium)
                    }
                    HorizontalDivider(color = BorderLight, thickness = 0.6.dp)
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Column {
                            Text("Total Prod Cost", fontSize = 9.sp, color = TextSecondary)
                            Text("KES ${String.format("%,.0f", item.totalProductionCostKes)}", fontSize = 11.sp, fontWeight = FontWeight.Bold, color = Navy900)
                        }
                        Column(horizontalAlignment = Alignment.CenterHorizontally) {
                            Text("Selling Price", fontSize = 9.sp, color = TextSecondary)
                            Text("KES ${String.format("%,.0f", item.sellingPriceKes)}", fontSize = 11.sp, fontWeight = FontWeight.Bold, color = RoyalCobaltBlue)
                        }
                        Column(horizontalAlignment = Alignment.End) {
                            Text("Est. Margin (${marginEval.marginPercent}%)", fontSize = 9.sp, color = TextSecondary)
                            Text(
                                text = "KES ${String.format("%,.0f", item.profitMarginKes)}",
                                fontSize = 11.sp,
                                fontWeight = FontWeight.ExtraBold,
                                color = when (marginEval.status) {
                                    MarginStatus.HEALTHY -> EmeraldSuccess
                                    MarginStatus.LOW_MARGIN -> Color(0xFFB45309)
                                    MarginStatus.BELOW_COST -> com.example.ui.theme.StrokeRed
                                }
                            )
                        }
                    }
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Icon(Icons.Default.QrCode2, contentDescription = "QR Tag", tint = Navy900, modifier = Modifier.size(12.dp))
                            Spacer(modifier = Modifier.width(3.dp))
                            Text(item.qrTagCode, fontSize = 9.sp, fontWeight = FontWeight.Bold, color = Navy900)
                        }
                        if (item.autoBomDeductedStages.isNotEmpty()) {
                            Surface(color = EmeraldLight, shape = RoundedCornerShape(4.dp)) {
                                Text(
                                    text = "Auto-BOM (${item.autoBomDeductedStages.size}/4)",
                                    fontSize = 9.sp,
                                    fontWeight = FontWeight.Bold,
                                    color = EmeraldSuccess,
                                    modifier = Modifier.padding(horizontal = 5.dp, vertical = 1.dp)
                                )
                            }
                        }
                    }
                }
            }

            if (marginEval.status != MarginStatus.HEALTHY && marginEval.warningMessage != null) {
                Spacer(modifier = Modifier.height(6.dp))
                Surface(
                    color = if (marginEval.status == MarginStatus.BELOW_COST) com.example.ui.theme.StrokeRedLight else AmberLight,
                    shape = RoundedCornerShape(8.dp),
                    border = BorderStroke(
                        1.dp,
                        if (marginEval.status == MarginStatus.BELOW_COST) com.example.ui.theme.StrokeRed else AmberWarning
                    ),
                    modifier = Modifier.fillMaxWidth().testTag("workshop_margin_warning_${item.id}")
                ) {
                    Row(
                        modifier = Modifier.padding(horizontal = 10.dp, vertical = 6.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Icon(
                            imageVector = Icons.Default.Warning,
                            contentDescription = "Margin Guard Alert",
                            tint = if (marginEval.status == MarginStatus.BELOW_COST) com.example.ui.theme.StrokeRed else Color(0xFFB45309),
                            modifier = Modifier.size(16.dp)
                        )
                        Spacer(modifier = Modifier.width(6.dp))
                        Text(
                            text = marginEval.warningMessage,
                            fontSize = 10.sp,
                            fontWeight = FontWeight.SemiBold,
                            color = if (marginEval.status == MarginStatus.BELOW_COST) com.example.ui.theme.StrokeRedDark else Color(0xFF92400E)
                        )
                    }
                }
            }

            if (item.allocatedMaterials.isNotEmpty()) {
                Spacer(modifier = Modifier.height(6.dp))
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .horizontalScroll(rememberScrollState()),
                    horizontalArrangement = Arrangement.spacedBy(6.dp)
                ) {
                    item.allocatedMaterials.forEach { alloc ->
                        Surface(
                            color = EmeraldLight.copy(alpha = 0.65f),
                            shape = RoundedCornerShape(6.dp)
                        ) {
                            Text(
                                text = "${alloc.materialName} x${alloc.quantity} (KES ${String.format("%,.0f", alloc.totalCostKes)})",
                                fontSize = 10.sp,
                                fontWeight = FontWeight.SemiBold,
                                color = Color(0xFF065F46),
                                maxLines = 1,
                                softWrap = false,
                                modifier = Modifier.padding(horizontal = 6.dp, vertical = 3.dp)
                            )
                        }
                    }
                }
            }

            Spacer(modifier = Modifier.height(10.dp))

            Row(
                modifier = Modifier.fillMaxWidth(),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Icon(Icons.Default.Handyman, contentDescription = null, tint = RoyalCobaltBlue, modifier = Modifier.size(16.dp))
                    Spacer(modifier = Modifier.width(6.dp))
                    Text(
                        text = "Craftsman: ${item.assignedCraftsmanName}",
                        fontWeight = FontWeight.SemiBold,
                        fontSize = 12.sp,
                        color = MaterialTheme.colorScheme.onSurface
                    )
                }

                Text(
                    text = "Reassign",
                    fontSize = 11.sp,
                    color = RoyalCobaltBlue,
                    fontWeight = FontWeight.Bold,
                    modifier = Modifier.clickable { onAssignCraftsman() }
                )
            }

            if (item.notes.isNotBlank()) {
                Spacer(modifier = Modifier.height(6.dp))
                Text(
                    text = "Specs: ${item.notes}",
                    fontSize = 11.sp,
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                    maxLines = 2
                )
            }

            Spacer(modifier = Modifier.height(10.dp))

            // Material Allocation + Stage Cost + Complete -> Store
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(6.dp)
            ) {
                OutlinedButton(
                    onClick = onAllocateMaterial,
                    shape = RoundedCornerShape(8.dp),
                    modifier = Modifier.weight(1f).height(34.dp).testTag("btn_alloc_mat_${item.id}"),
                    contentPadding = PaddingValues(horizontal = 6.dp)
                ) {
                    Icon(Icons.Default.Inventory2, contentDescription = null, modifier = Modifier.size(13.dp))
                    Spacer(modifier = Modifier.width(3.dp))
                    Text("Material", fontSize = 10.sp, fontWeight = FontWeight.Bold, maxLines = 1, softWrap = false)
                }

                OutlinedButton(
                    onClick = onAddStageCost,
                    shape = RoundedCornerShape(8.dp),
                    modifier = Modifier.weight(1f).height(34.dp).testTag("btn_add_cost_${item.id}"),
                    contentPadding = PaddingValues(horizontal = 6.dp)
                ) {
                    Icon(Icons.Default.AttachMoney, contentDescription = null, modifier = Modifier.size(13.dp))
                    Spacer(modifier = Modifier.width(2.dp))
                    Text("+ Cost", fontSize = 10.sp, fontWeight = FontWeight.Bold, maxLines = 1, softWrap = false)
                }

                if (!item.isCompleted) {
                    Button(
                        onClick = onCompleteToStore,
                        colors = ButtonDefaults.buttonColors(containerColor = Navy900),
                        shape = RoundedCornerShape(8.dp),
                        modifier = Modifier.weight(1.2f).height(34.dp).testTag("btn_complete_store_${item.id}"),
                        contentPadding = PaddingValues(horizontal = 6.dp)
                    ) {
                        Icon(Icons.Default.Storefront, contentDescription = null, modifier = Modifier.size(13.dp))
                        Spacer(modifier = Modifier.width(3.dp))
                        Text("Complete->Store", fontSize = 10.sp, fontWeight = FontWeight.Bold, maxLines = 1, softWrap = false)
                    }
                }
            }

            Spacer(modifier = Modifier.height(8.dp))

            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                OutlinedButton(
                    onClick = onUpdateProgress,
                    shape = RoundedCornerShape(8.dp),
                    modifier = Modifier.weight(1f).height(36.dp),
                    contentPadding = PaddingValues(horizontal = 8.dp)
                ) {
                    Icon(Icons.Default.Schedule, contentDescription = null, modifier = Modifier.size(14.dp))
                    Spacer(modifier = Modifier.width(4.dp))
                    Text("Update %", fontSize = 11.sp, fontWeight = FontWeight.Bold, maxLines = 1, softWrap = false)
                }

                Button(
                    onClick = onToggleDoneForDay,
                    colors = ButtonDefaults.buttonColors(
                        containerColor = if (item.isDoneForDay) Color(0xFFE2E8F0) else EmeraldSuccess,
                        contentColor = if (item.isDoneForDay) Navy900 else Color.White
                    ),
                    shape = RoundedCornerShape(8.dp),
                    modifier = Modifier.weight(1f).height(36.dp),
                    contentPadding = PaddingValues(horizontal = 8.dp)
                ) {
                    Icon(Icons.Default.Check, contentDescription = null, modifier = Modifier.size(14.dp))
                    Spacer(modifier = Modifier.width(4.dp))
                    Text(if (item.isDoneForDay) "Mark Active" else "Done Today", fontSize = 11.sp, fontWeight = FontWeight.Bold, maxLines = 1, softWrap = false)
                }

                if (item.currentStage != WorkshopProductionStage.GLASS_FITTING) {
                    Button(
                        onClick = onAdvanceStage,
                        colors = ButtonDefaults.buttonColors(containerColor = RoyalCobaltBlue),
                        shape = RoundedCornerShape(8.dp),
                        modifier = Modifier.weight(1f).height(36.dp),
                        contentPadding = PaddingValues(horizontal = 8.dp)
                    ) {
                        Text("Next Stage", fontSize = 11.sp, fontWeight = FontWeight.Bold, maxLines = 1, softWrap = false)
                    }
                }
            }
        }
    }
}
