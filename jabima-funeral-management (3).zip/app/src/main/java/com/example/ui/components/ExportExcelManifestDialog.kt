package com.example.ui.components

import android.content.Context
import android.content.Intent
import android.widget.Toast
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.ContentCopy
import androidx.compose.material.icons.filled.DirectionsCar
import androidx.compose.material.icons.filled.FileDownload
import androidx.compose.material.icons.filled.Inventory2
import androidx.compose.material.icons.filled.People
import androidx.compose.material.icons.filled.PrecisionManufacturing
import androidx.compose.material.icons.filled.Share
import androidx.compose.material.icons.filled.TableChart
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.ScrollableTabRow
import androidx.compose.material3.Surface
import androidx.compose.material3.Tab
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.LocalClipboardManager
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.AnnotatedString
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.window.Dialog
import com.example.model.BurialScheduleEvent
import com.example.model.CasketItem
import com.example.model.FleetGpsVehicle
import com.example.model.StaffAccount
import com.example.ui.theme.CyanPrimary
import com.example.ui.theme.EmeraldSuccess
import com.example.ui.theme.Navy900
import com.example.ui.theme.PureWhite

enum class ManifestType(val title: String, val icon: ImageVector) {
    CORTEGE_ROUTE("Hearse Route Sheet", Icons.Default.DirectionsCar),
    GRAVESITE_EQUIPMENT("Gravesite Gear Manifest", Icons.Default.PrecisionManufacturing),
    STAFF_COMMISSIONS("Staff Duty & Commission", Icons.Default.People),
    CASKET_INVENTORY("Casket Stock Inventory", Icons.Default.Inventory2)
}

@Composable
fun ExportExcelManifestDialog(
    burialSchedules: List<BurialScheduleEvent>,
    fleetVehicles: List<FleetGpsVehicle>,
    staffAccounts: List<StaffAccount>,
    caskets: List<CasketItem>,
    onDismiss: () -> Unit
) {
    val context = LocalContext.current
    val clipboardManager = LocalClipboardManager.current
    var selectedTab by remember { mutableIntStateOf(0) }

    val activeManifestType = ManifestType.entries[selectedTab]

    val generatedCsvContent = remember(selectedTab, burialSchedules, fleetVehicles, staffAccounts, caskets) {
        generateManifestCsv(activeManifestType, burialSchedules, fleetVehicles, staffAccounts, caskets)
    }

    Dialog(onDismissRequest = onDismiss) {
        Surface(
            shape = RoundedCornerShape(16.dp),
            color = PureWhite,
            tonalElevation = 8.dp,
            modifier = Modifier
                .fillMaxWidth()
                .padding(vertical = 16.dp)
                .testTag("export_excel_manifest_dialog")
        ) {
            Column(
                modifier = Modifier
                    .padding(16.dp)
                    .verticalScroll(rememberScrollState())
            ) {
                // Header
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Surface(
                            shape = CircleShape,
                            color = Color(0xFF107C41).copy(alpha = 0.15f),
                            modifier = Modifier.size(36.dp)
                        ) {
                            Box(contentAlignment = Alignment.Center) {
                                Icon(
                                    imageVector = Icons.Default.TableChart,
                                    contentDescription = null,
                                    tint = Color(0xFF107C41),
                                    modifier = Modifier.size(20.dp)
                                )
                            }
                        }
                        Spacer(modifier = Modifier.width(10.dp))
                        Column {
                            Text(
                                text = "Export Excel & Manifests",
                                fontSize = 15.sp,
                                fontWeight = FontWeight.Bold,
                                color = Navy900
                            )
                            Text(
                                text = "Jabima ERP Microsoft Excel / CSV Generators",
                                fontSize = 11.sp,
                                color = Color(0xFF64748B)
                            )
                        }
                    }
                    IconButton(onClick = onDismiss, modifier = Modifier.size(32.dp)) {
                        Icon(Icons.Default.Close, contentDescription = "Close", tint = Color.Gray)
                    }
                }

                Spacer(modifier = Modifier.height(12.dp))

                // Scrollable Tabs
                ScrollableTabRow(
                    selectedTabIndex = selectedTab,
                    containerColor = Color(0xFFF8FAFC),
                    contentColor = Color(0xFF107C41),
                    edgePadding = 6.dp
                ) {
                    ManifestType.entries.forEachIndexed { index, type ->
                        Tab(
                            selected = selectedTab == index,
                            onClick = { selectedTab = index },
                            text = {
                                Row(verticalAlignment = Alignment.CenterVertically) {
                                    Icon(type.icon, contentDescription = null, modifier = Modifier.size(13.dp))
                                    Spacer(modifier = Modifier.width(4.dp))
                                    Text(
                                        text = type.title,
                                        fontSize = 11.sp,
                                        fontWeight = if (selectedTab == index) FontWeight.Bold else FontWeight.Normal,
                                        maxLines = 1,
                                        softWrap = false,
                                        overflow = androidx.compose.ui.text.style.TextOverflow.Ellipsis
                                    )
                                }
                            }
                        )
                    }
                }

                Spacer(modifier = Modifier.height(14.dp))

                // Preview Info Card
                Surface(
                    color = Color(0xFFF1F5F9),
                    shape = RoundedCornerShape(8.dp),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Column(modifier = Modifier.padding(10.dp)) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Text(
                                text = "${activeManifestType.title} (.csv / .xlsx format)",
                                fontSize = 11.sp,
                                fontWeight = FontWeight.Bold,
                                color = Navy900
                            )
                            Text(
                                text = "${generatedCsvContent.lines().size - 1} Records",
                                fontSize = 10.sp,
                                color = Color(0xFF107C41),
                                fontWeight = FontWeight.Bold
                            )
                        }
                        Spacer(modifier = Modifier.height(6.dp))
                        Text(
                            text = generatedCsvContent.take(450) + if (generatedCsvContent.length > 450) "\n..." else "",
                            fontSize = 9.sp,
                            fontFamily = FontFamily.Monospace,
                            color = Color(0xFF334155),
                            lineHeight = 13.sp
                        )
                    }
                }

                Spacer(modifier = Modifier.height(16.dp))

                // Actions: Copy, Share, and Instant Export
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    OutlinedButton(
                        onClick = {
                            clipboardManager.setText(AnnotatedString(generatedCsvContent))
                            Toast.makeText(context, "Copied ${activeManifestType.title} table to clipboard!", Toast.LENGTH_SHORT).show()
                        },
                        shape = RoundedCornerShape(8.dp),
                        modifier = Modifier.weight(1f).testTag("btn_copy_manifest_csv")
                    ) {
                        Icon(Icons.Default.ContentCopy, contentDescription = null, modifier = Modifier.size(15.dp))
                        Spacer(modifier = Modifier.width(4.dp))
                        Text("Copy Table", fontSize = 11.sp, fontWeight = FontWeight.Bold)
                    }

                    Button(
                        onClick = {
                            shareManifestContent(context, activeManifestType.title, generatedCsvContent)
                        },
                        colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF107C41)),
                        shape = RoundedCornerShape(8.dp),
                        modifier = Modifier.weight(1.3f).testTag("btn_share_export_excel")
                    ) {
                        Icon(Icons.Default.Share, contentDescription = null, modifier = Modifier.size(15.dp))
                        Spacer(modifier = Modifier.width(4.dp))
                        Text("Share / Export", fontSize = 11.sp, fontWeight = FontWeight.Bold)
                    }
                }
            }
        }
    }
}

private fun generateManifestCsv(
    type: ManifestType,
    burialSchedules: List<BurialScheduleEvent>,
    fleetVehicles: List<FleetGpsVehicle>,
    staffAccounts: List<StaffAccount>,
    caskets: List<CasketItem>
): String {
    val sb = StringBuilder()
    when (type) {
        ManifestType.CORTEGE_ROUTE -> {
            sb.append("Case_Reference,Deceased_Name,Hearse_Plate,Driver_Name,Church_Venue,Gravesite_Location,Departure_Time,Status\n")
            burialSchedules.forEach { s ->
                val departure = s.timings.firstOrNull()?.timeFormatted ?: "09:30 AM"
                sb.append("${s.caseReference},\"${s.deceasedName}\",${s.assignedHearseReg},\"${s.assignedDriverName}\",\"${s.churchVenue}\",\"${s.gravesiteLocation}\",$departure,${s.status}\n")
            }
        }
        ManifestType.GRAVESITE_EQUIPMENT -> {
            sb.append("Case_Reference,Family_Rep,Gravesite_Location,Hydraulic_Gear_Status,Canopy_Status,Stunchions_RedCarpet,Lead_Operators\n")
            burialSchedules.forEach { s ->
                val ops = s.assignedOperators.joinToString(" & ")
                sb.append("${s.caseReference},\"${s.familyRepresentative}\",\"${s.gravesiteLocation}\",Ready,10x10 Dome Tent Verified,16 Brass Stunchions Rigged,\"$ops\"\n")
            }
        }
        ManifestType.STAFF_COMMISSIONS -> {
            sb.append("Staff_ID,Full_Name,Department,Role,Phone,Base_Salary_KES,Commission_Rate_Percent,Status\n")
            staffAccounts.forEach { a ->
                sb.append("${a.id},\"${a.fullName}\",${a.department.displayName},\"${a.role.title}\",${a.phone},${a.baseSalaryKes},${a.commissionRatePercent}%,Active\n")
            }
        }
        ManifestType.CASKET_INVENTORY -> {
            sb.append("Casket_ID,Model_Name,Material_Wood,Selling_Price_KES,In_Stock_Units,Reorder_Level,Branch_Location\n")
            caskets.forEach { c ->
                sb.append("${c.id},\"${c.name}\",\"${c.woodType}\",${c.priceKes},${c.stockCount},3,Bama Branch Workshop\n")
            }
        }
    }
    return sb.toString()
}

private fun shareManifestContent(context: Context, title: String, content: String) {
    val sendIntent = Intent().apply {
        action = Intent.ACTION_SEND
        putExtra(Intent.EXTRA_TITLE, "Jabima ERP - $title")
        putExtra(Intent.EXTRA_TEXT, content)
        type = "text/plain"
    }
    context.startActivity(Intent.createChooser(sendIntent, "Export $title"))
}
