package com.example.utils

import com.example.data.StaffPortalRepository
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertNotEquals
import org.junit.Assert.assertNotNull
import org.junit.Assert.assertNull
import org.junit.Assert.assertTrue
import org.junit.Test

class PasswordSecurityTest {

    @Test
    fun hashAndVerifyPasswordUsesUniqueSaltAndRejectsWrongPassword() {
        val hashA = PasswordSecurityHelper.hashPassword("Jabima#2026")
        val hashB = PasswordSecurityHelper.hashPassword("Jabima#2026")

        assertTrue(hashA.startsWith("sha256$"))
        assertNotEquals("Salted hashes must differ", hashA, hashB)
        assertTrue(PasswordSecurityHelper.verifyPassword("Jabima#2026", hashA))
        assertTrue(PasswordSecurityHelper.verifyPassword("Jabima#2026", hashB))
        assertFalse(PasswordSecurityHelper.verifyPassword("password123", hashA))
        assertFalse(PasswordSecurityHelper.verifyPassword("admin", hashA))
    }

    @Test
    fun repositoryScrubsPlaintextAndEnforcesForcedRotationOnDefaultCredentials() {
        val repo = StaffPortalRepository()
        val ceo = repo.accounts.value.first { it.id == "CEO-001" }

        assertEquals("Plaintext password must be scrubbed", "", ceo.password)
        assertTrue(ceo.passwordHash.startsWith("sha256$"))
        assertTrue("Factory password should require rotation", ceo.mustRotatePassword)

        // Cross-account backdoor passwords must fail authentication
        assertNull(repo.authenticate("CEO-001", "password123"))
        assertNull(repo.authenticate("CEO-001", "admin123"))
        assertNull(repo.authenticate("WRK-001", "admin"))

        // Initial seed password still authenticates via hash and clears after rotation
        val loggedIn = repo.authenticate("CEO-001", "admin")
        assertNotNull(loggedIn)
        assertTrue(loggedIn!!.mustRotatePassword)

        repo.updatePassword("CEO-001", "JabimaStrong!99")

        assertNull(repo.authenticate("CEO-001", "admin"))
        assertNull(repo.authenticate("CEO-001", "password123"))
        val rotated = repo.authenticate("CEO-001", "JabimaStrong!99")
        assertNotNull(rotated)
        assertFalse("Forced rotation flag must clear after personal password update", rotated!!.mustRotatePassword)
        assertEquals("", rotated.password)
    }

    @Test
    fun defaultOrWeakPasswordDetectsDefaultsAndShortStrings() {
        assertTrue(PasswordSecurityHelper.isDefaultOrWeakPassword("1234"))
        assertTrue(PasswordSecurityHelper.isDefaultOrWeakPassword("password123"))
        assertTrue(PasswordSecurityHelper.isDefaultOrWeakPassword("admin123"))
        assertFalse(PasswordSecurityHelper.isDefaultOrWeakPassword("BamaBranch#88"))
    }
}
