package com.example.domain

import com.example.model.MarginStatus
import org.junit.Assert.assertEquals
import org.junit.Assert.assertNotNull
import org.junit.Assert.assertTrue
import org.junit.Test

class CasketCostingEngineTest {

    @Test
    fun catalogAndDirectoryMetadata_matchSourcePdfSpecifications() {
        assertEquals(32, CasketCostingEngine.rawMaterialCatalog.size)
        assertEquals(1883.28, CasketCostingEngine.catalogAverageMaterialPriceKes, 0.01)
        assertEquals(11000.0, CasketCostingEngine.catalogHighestPricedMaterialKes, 0.01)

        val actualComputedAvg = CasketCostingEngine.rawMaterialCatalog.map { it.unitPriceKes }.average()
        assertEquals(1883.28, actualComputedAvg, 0.05)

        val bulkGlue = CasketCostingEngine.rawMaterialCatalog.first { it.isBulkDiscountOption }
        assertEquals(900.0, bulkGlue.unitPriceKes, 0.01)

        assertEquals(6, CasketCostingEngine.equipmentHireRates.size)
        val ratesById = CasketCostingEngine.equipmentHireRates.associateBy { it.id }
        assertEquals(5000.0, ratesById.getValue("EQP-01").rateKes, 0.01)
        assertEquals(1500.0, ratesById.getValue("EQP-02").rateKes, 0.01)
        assertEquals(3000.0, ratesById.getValue("EQP-03").rateKes, 0.01)
        assertEquals(4000.0, ratesById.getValue("EQP-04").rateKes, 0.01)
        assertEquals(4000.0, ratesById.getValue("EQP-05").rateKes, 0.01)
        assertEquals(1000.0, ratesById.getValue("EQP-06").rateKes, 0.01)

        assertEquals(7, CasketCostingEngine.workshopPersonnelDirectory.size)
        assertEquals(8, CasketCostingEngine.shopBranchNetwork.size)
        assertEquals("SH-01", CasketCostingEngine.shopBranchNetwork.first().shopId)
        assertEquals("SH-08", CasketCostingEngine.shopBranchNetwork.last().shopId)
        assertEquals(10, CasketCostingEngine.salesDressingAndTransportItems.size)
    }

    @Test
    fun allNineCasketModels_produceConsistentCostAndHealthyGuideMargins() {
        val models = CasketCostingEngine.casketProductionModels
        assertEquals(9, models.size)

        models.forEach { model ->
            assertTrue("${model.id} must have BOM items", model.bomItems.isNotEmpty())
            assertTrue("${model.id} direct material cost must be positive", model.directMaterialCostKes > 0.0)
            assertTrue("${model.id} crew labor cost must be positive", model.crewLaborCostKes > 0.0)
            assertTrue("${model.id} total production cost must be positive", model.totalProductionCostKes > 0.0)
            assertTrue(
                "${model.id} recommended order guide price (${model.recommendedOrderPriceKes}) must exceed production cost (${model.totalProductionCostKes})",
                model.recommendedOrderPriceKes > model.totalProductionCostKes
            )
            assertTrue(
                "${model.id} floor price (${model.floorOrderPriceKes}) must exceed production cost (${model.totalProductionCostKes})",
                model.floorOrderPriceKes > model.totalProductionCostKes
            )
            assertTrue("${model.id} gross margin must be positive", model.grossMarginPercent > 20.0)
            assertEquals(model.recommendedOrderPriceKes * 0.05, model.salesCommissionAtGuideKes, 0.01)
        }
    }

    @Test
    fun calculateModelWithOptions_appliesBulkGlueSpindlesAndSwingBarHandlesAccurately() {
        val baseSimple = CasketCostingEngine.casketProductionModels.first { it.id == "MOD-SIMPLE" }

        // 1. Bulk Glue saves KES 100/Ltr (Simple uses 1.0 Ltr -> saves KES 100)
        val bulkSimple = CasketCostingEngine.calculateModelWithOptions(
            modelId = "MOD-SIMPLE",
            useBulkGlue = true
        )
        assertEquals(
            baseSimple.totalProductionCostKes - 100.0,
            bulkSimple.totalProductionCostKes,
            0.01
        )

        // Executive Dome uses 3.0 Ltrs -> Bulk Glue saves KES 300
        val baseExec = CasketCostingEngine.casketProductionModels.first { it.id == "MOD-EXEC-DOME" }
        val bulkExec = CasketCostingEngine.calculateModelWithOptions(
            modelId = "MOD-EXEC-DOME",
            useBulkGlue = true
        )
        assertEquals(
            baseExec.totalProductionCostKes - 300.0,
            bulkExec.totalProductionCostKes,
            0.01
        )

        // 2. Adding Spindles Set (+KES 3,000) to Simple
        val spindleSimple = CasketCostingEngine.calculateModelWithOptions(
            modelId = "MOD-SIMPLE",
            includeSpindlesSet = true
        )
        assertEquals(
            baseSimple.finishingMaterialCostKes + 3000.0,
            spindleSimple.finishingMaterialCostKes,
            0.01
        )

        // 3. Upgrading H4 Handles (2,000) to Swing Bar Handles (6,500) adds KES 4,500
        val swingSimple = CasketCostingEngine.calculateModelWithOptions(
            modelId = "MOD-SIMPLE",
            upgradeToSwingBarHandles = true
        )
        assertEquals(
            baseSimple.finishingMaterialCostKes + 4500.0,
            swingSimple.finishingMaterialCostKes,
            0.01
        )
    }

    @Test
    fun buildOrderQuoteBreakdown_combinesEquipmentHireAndFlagsMarginGuard() {
        val miniDome = CasketCostingEngine.casketProductionModels.first { it.id == "MOD-MINI-DOME" }

        // Healthy quote with Lowering Gear (5,000) + Church Trolley (1,500) + Grave Side Carpet (3,000) = 9,500
        val quote = CasketCostingEngine.buildOrderQuoteBreakdown(
            model = miniDome,
            casketQuantity = 2,
            selectedEquipmentIds = setOf("EQP-01", "EQP-02", "EQP-03")
        )
        assertEquals(9500.0, quote.equipmentHireTotalKes, 0.01)
        assertEquals(miniDome.recommendedOrderPriceKes * 2 + 9500.0, quote.clientOrderTotalKes, 0.01)
        assertEquals(miniDome.recommendedOrderPriceKes * 2 * 0.05, quote.expectedSalesCommissionKes, 0.01)
        assertEquals(MarginStatus.HEALTHY, quote.marginEvaluation.status)

        // Below-cost override triggers BELOW_COST margin guard
        val underpricedQuote = CasketCostingEngine.buildOrderQuoteBreakdown(
            model = miniDome,
            casketQuantity = 1,
            overrideUnitSellingPriceKes = 12000.0
        )
        assertEquals(MarginStatus.BELOW_COST, underpricedQuote.marginEvaluation.status)
        assertNotNull(underpricedQuote.marginEvaluation.warningMessage)
    }

    @Test
    fun findModelForCasketName_mapsBranchCatalogAndVariantNamesAccurately() {
        val cases = mapOf(
            "Executive" to "MOD-EXEC-DOME",
            "VIP" to "MOD-EXEC-DOME",
            "Saitoti" to "MOD-EXEC-DOME",
            "Modern High Roof" to "MOD-HIGH-ROOF",
            "Dragon" to "MOD-MINI-DOME",
            "Kupa" to "MOD-MINI-DOME",
            "English Coffin" to "MOD-MINI-DOME",
            "Reagan" to "MOD-DOME",
            "Half Glass Dome" to "MOD-DOME",
            "Half Glass" to "MOD-HALF-GLASS",
            "Giraffe Flat" to "MOD-HALF-GLASS",
            "Simple" to "MOD-SIMPLE",
            "Kids" to "MOD-KIDS-45",
            "Spindles 3.5 Junior" to "MOD-SPINDLE-35",
            "Spindles 2.5 Infant" to "MOD-SPINDLE-25"
        )

        cases.forEach { (displayName, expectedId) ->
            val resolved = CasketCostingEngine.findModelForCasketName(displayName)
            assertNotNull("Expected match for $displayName", resolved)
            assertEquals("Mismatch for $displayName", expectedId, resolved?.id)
        }
    }
}
