package com.example.ui.components

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.AttachMoney
import androidx.compose.material.icons.filled.Check
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.Edit
import androidx.compose.material.icons.filled.History
import androidx.compose.material.icons.filled.Inventory
import androidx.compose.material.icons.filled.LocalShipping
import androidx.compose.material.icons.filled.Search
import androidx.compose.material.icons.filled.Tune
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.FilterChip
import androidx.compose.material3.FilterChipDefaults
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.ScrollableTabRow
import androidx.compose.material3.Surface
import androidx.compose.material3.Switch
import androidx.compose.material3.SwitchDefaults
import androidx.compose.material3.Tab
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.window.Dialog
import com.example.model.CasketItem
import com.example.model.OrderAddonItem
import com.example.model.OrderPackageItem
import com.example.model.PriceUpdateRecord
import com.example.model.SalesServiceItem
import com.example.ui.theme.AmberLight
import com.example.ui.theme.AmberWarning
import com.example.ui.theme.CyanContainer
import com.example.ui.theme.CyanPrimary
import com.example.ui.theme.EmeraldLight
import com.example.ui.theme.EmeraldSuccess
import com.example.ui.theme.Navy900

enum class PriceEditorTab(val label: String) {
    CASKETS("Caskets & Coffins"),
    PACKAGES_AND_ADDONS("Packages & Add-ons"),
    SALES_SERVICES("Authorized Services"),
    PRICE_AUDIT_LOG("Price Audit History")
}

@Composable
fun AdminPriceEditorDialog(
    caskets: List<CasketItem>,
    salesServices: List<SalesServiceItem>,
    priceAuditLog: List<PriceUpdateRecord>,
    onDismiss: () -> Unit,
    onUpdateCasketPrice: (casketId: String, newPriceKes: Double, newStock: Int, inStock: Boolean, notes: String) -> Unit,
    onUpdateServicePrice: (serviceId: String, newPriceKes: Double, notes: String) -> Unit,
    orderPackages: List<OrderPackageItem> = emptyList(),
    orderAddons: List<OrderAddonItem> = emptyList(),
    onUpdatePackagePrice: (packageId: String, newPriceKes: Double) -> Unit = { _, _ -> },
    onUpdateAddonPrice: (addonId: String, newPriceKes: Double) -> Unit = { _, _ -> },
    onUpdateCasketDetails: ((CasketItem) -> Unit)? = null
) {
    var selectedTab by remember { mutableStateOf(PriceEditorTab.CASKETS) }
    var searchQuery by remember { mutableStateOf("") }

    // Item being currently edited in sub-card
    var editingCasket by remember { mutableStateOf<CasketItem?>(null) }
    var editingService by remember { mutableStateOf<SalesServiceItem?>(null) }
    var editingPackage by remember { mutableStateOf<OrderPackageItem?>(null) }
    var editingAddon by remember { mutableStateOf<OrderAddonItem?>(null) }

    Dialog(onDismissRequest = onDismiss) {
        Card(
            shape = RoundedCornerShape(20.dp),
            colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
            modifier = Modifier
                .fillMaxWidth()
                .height(640.dp)
                .padding(vertical = 12.dp)
                .testTag("admin_price_editor_dialog")
        ) {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(16.dp)
            ) {
                // Header
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Box(
                            modifier = Modifier
                                .size(38.dp)
                                .clip(CircleShape)
                                .background(EmeraldLight),
                            contentAlignment = Alignment.Center
                        ) {
                            Icon(
                                imageVector = Icons.Default.AttachMoney,
                                contentDescription = null,
                                tint = EmeraldSuccess,
                                modifier = Modifier.size(22.dp)
                            )
                        }
                        Spacer(modifier = Modifier.width(10.dp))
                        Column {
                            Text(
                                text = "Admin Price & Tariff Master",
                                style = MaterialTheme.typography.titleMedium,
                                fontWeight = FontWeight.Bold
                            )
                            Text(
                                text = "Executive Fee Schedules & Price Adjustments",
                                fontSize = 11.sp,
                                color = MaterialTheme.colorScheme.onSurfaceVariant
                            )
                        }
                    }

                    IconButton(onClick = onDismiss) {
                        Icon(imageVector = Icons.Default.Close, contentDescription = "Close")
                    }
                }

                Spacer(modifier = Modifier.height(10.dp))

                // Tabs
                ScrollableTabRow(
                    selectedTabIndex = selectedTab.ordinal,
                    edgePadding = 0.dp,
                    containerColor = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.5f),
                    modifier = Modifier
                        .fillMaxWidth()
                        .clip(RoundedCornerShape(10.dp))
                ) {
                    PriceEditorTab.entries.forEach { tab ->
                        Tab(
                            selected = selectedTab == tab,
                            onClick = { selectedTab = tab },
                            text = {
                                Text(
                                    text = tab.label,
                                    fontSize = 11.sp,
                                    fontWeight = if (selectedTab == tab) FontWeight.Bold else FontWeight.Normal,
                                    maxLines = 1,
                                    softWrap = false,
                                    overflow = TextOverflow.Ellipsis
                                )
                            }
                        )
                    }
                }

                Spacer(modifier = Modifier.height(10.dp))

                // Search Bar
                if (selectedTab != PriceEditorTab.PRICE_AUDIT_LOG) {
                    OutlinedTextField(
                        value = searchQuery,
                        onValueChange = { searchQuery = it },
                        placeholder = { Text("Search items to edit prices...", fontSize = 12.sp) },
                        leadingIcon = { Icon(Icons.Default.Search, contentDescription = null, modifier = Modifier.size(18.dp)) },
                        trailingIcon = {
                            if (searchQuery.isNotBlank()) {
                                IconButton(onClick = { searchQuery = "" }) {
                                    Icon(Icons.Default.Close, contentDescription = "Clear", modifier = Modifier.size(16.dp))
                                }
                            }
                        },
                        singleLine = true,
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(50.dp)
                            .testTag("price_editor_search")
                    )
                    Spacer(modifier = Modifier.height(8.dp))
                }

                // TAB CONTENT
                when (selectedTab) {
                    PriceEditorTab.CASKETS -> {
                        val filteredCaskets = caskets.filter {
                            searchQuery.isBlank() || it.name.contains(searchQuery, ignoreCase = true) || it.woodType.contains(searchQuery, ignoreCase = true)
                        }

                        LazyColumn(
                            modifier = Modifier.weight(1f),
                            verticalArrangement = Arrangement.spacedBy(8.dp)
                        ) {
                            items(filteredCaskets, key = { it.id }) { casket ->
                                CasketPriceRow(
                                    casket = casket,
                                    onEditClick = { editingCasket = casket }
                                )
                            }
                        }
                    }

                    PriceEditorTab.PACKAGES_AND_ADDONS -> {
                        val filteredPackages = orderPackages.filter {
                            searchQuery.isBlank() || it.name.contains(searchQuery, ignoreCase = true)
                        }
                        val filteredAddons = orderAddons.filter {
                            searchQuery.isBlank() || it.name.contains(searchQuery, ignoreCase = true) || it.category.contains(searchQuery, ignoreCase = true)
                        }

                        LazyColumn(
                            modifier = Modifier.weight(1f),
                            verticalArrangement = Arrangement.spacedBy(8.dp)
                        ) {
                            item {
                                Text(
                                    text = "FUNERAL PACKAGES (${filteredPackages.size})",
                                    fontSize = 10.sp,
                                    fontWeight = FontWeight.Bold,
                                    color = CyanPrimary
                                )
                            }
                            items(filteredPackages, key = { it.id }) { pkg ->
                                Surface(
                                    color = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.4f),
                                    shape = RoundedCornerShape(10.dp),
                                    border = androidx.compose.foundation.BorderStroke(1.dp, MaterialTheme.colorScheme.outline.copy(alpha = 0.15f)),
                                    modifier = Modifier.fillMaxWidth()
                                ) {
                                    Row(
                                        modifier = Modifier.padding(12.dp).fillMaxWidth(),
                                        horizontalArrangement = Arrangement.SpaceBetween,
                                        verticalAlignment = Alignment.CenterVertically
                                    ) {
                                        Column(modifier = Modifier.weight(1f)) {
                                            Text(pkg.name, fontWeight = FontWeight.Bold, fontSize = 13.sp)
                                            Text("Default: ${pkg.defaultCasket}", fontSize = 10.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
                                        }
                                        Text(
                                            text = "KES ${String.format("%,.0f", pkg.priceKes)}",
                                            fontWeight = FontWeight.ExtraBold,
                                            fontSize = 13.sp,
                                            color = EmeraldSuccess
                                        )
                                        Spacer(modifier = Modifier.width(8.dp))
                                        IconButton(
                                            onClick = { editingPackage = pkg },
                                            modifier = Modifier
                                                .size(32.dp)
                                                .background(CyanContainer, CircleShape)
                                                .testTag("edit_package_price_${pkg.id}")
                                        ) {
                                            Icon(Icons.Default.Edit, contentDescription = "Edit Package Price", tint = CyanPrimary, modifier = Modifier.size(16.dp))
                                        }
                                    }
                                }
                            }

                            item {
                                Spacer(modifier = Modifier.height(6.dp))
                                Text(
                                    text = "ORDER ADD-ONS (${filteredAddons.size})",
                                    fontSize = 10.sp,
                                    fontWeight = FontWeight.Bold,
                                    color = CyanPrimary
                                )
                            }
                            items(filteredAddons, key = { it.id }) { addon ->
                                Surface(
                                    color = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.4f),
                                    shape = RoundedCornerShape(10.dp),
                                    border = androidx.compose.foundation.BorderStroke(1.dp, MaterialTheme.colorScheme.outline.copy(alpha = 0.15f)),
                                    modifier = Modifier.fillMaxWidth()
                                ) {
                                    Row(
                                        modifier = Modifier.padding(12.dp).fillMaxWidth(),
                                        horizontalArrangement = Arrangement.SpaceBetween,
                                        verticalAlignment = Alignment.CenterVertically
                                    ) {
                                        Column(modifier = Modifier.weight(1f)) {
                                            Text(addon.name, fontWeight = FontWeight.Bold, fontSize = 12.sp)
                                            Text(addon.category, fontSize = 10.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
                                        }
                                        Text(
                                            text = "KES ${String.format("%,.0f", addon.priceKes)}",
                                            fontWeight = FontWeight.ExtraBold,
                                            fontSize = 13.sp,
                                            color = CyanPrimary
                                        )
                                        Spacer(modifier = Modifier.width(8.dp))
                                        IconButton(
                                            onClick = { editingAddon = addon },
                                            modifier = Modifier
                                                .size(32.dp)
                                                .background(CyanContainer, CircleShape)
                                                .testTag("edit_addon_price_${addon.id}")
                                        ) {
                                            Icon(Icons.Default.Edit, contentDescription = "Edit Add-on Price", tint = CyanPrimary, modifier = Modifier.size(16.dp))
                                        }
                                    }
                                }
                            }
                        }
                    }

                    PriceEditorTab.SALES_SERVICES -> {
                        val filteredServices = salesServices.filter {
                            searchQuery.isBlank() || it.name.contains(searchQuery, ignoreCase = true) || it.category.contains(searchQuery, ignoreCase = true)
                        }

                        LazyColumn(
                            modifier = Modifier.weight(1f),
                            verticalArrangement = Arrangement.spacedBy(8.dp)
                        ) {
                            items(filteredServices, key = { it.id }) { srv ->
                                ServicePriceRow(
                                    service = srv,
                                    onEditClick = { editingService = srv }
                                )
                            }
                        }
                    }

                    PriceEditorTab.PRICE_AUDIT_LOG -> {
                        LazyColumn(
                            modifier = Modifier.weight(1f),
                            verticalArrangement = Arrangement.spacedBy(8.dp)
                        ) {
                            if (priceAuditLog.isEmpty()) {
                                item {
                                    Box(
                                        modifier = Modifier
                                            .fillMaxWidth()
                                            .padding(32.dp),
                                        contentAlignment = Alignment.Center
                                    ) {
                                        Text("No price adjustments logged yet.", color = Color.Gray, fontSize = 12.sp)
                                    }
                                }
                            } else {
                                items(priceAuditLog, key = { it.id }) { record ->
                                    PriceAuditRow(record = record)
                                }
                            }
                        }
                    }
                }

                Spacer(modifier = Modifier.height(10.dp))
                HorizontalDivider(color = MaterialTheme.colorScheme.outline.copy(alpha = 0.2f))
                Spacer(modifier = Modifier.height(8.dp))

                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.End
                ) {
                    Button(
                        onClick = onDismiss,
                        colors = ButtonDefaults.buttonColors(containerColor = CyanPrimary),
                        shape = RoundedCornerShape(8.dp)
                    ) {
                        Text("Done / Close", fontWeight = FontWeight.Bold, fontSize = 12.sp)
                    }
                }
            }
        }
    }

    // SUB-DIALOG: EDIT CASKET TYPE & PRICE
    editingCasket?.let { casket ->
        EditCasketPriceSubDialog(
            casket = casket,
            onDismiss = { editingCasket = null },
            onSave = { updatedCasket, notes ->
                if (onUpdateCasketDetails != null) {
                    onUpdateCasketDetails(updatedCasket)
                }
                onUpdateCasketPrice(casket.id, updatedCasket.priceKes, updatedCasket.stockCount, updatedCasket.inStock, notes)
                editingCasket = null
            }
        )
    }

    // SUB-DIALOG: EDIT SERVICE PRICE
    editingService?.let { srv ->
        EditServicePriceSubDialog(
            service = srv,
            onDismiss = { editingService = null },
            onSave = { newPriceKes, notes ->
                onUpdateServicePrice(srv.id, newPriceKes, notes)
                editingService = null
            }
        )
    }

    // SUB-DIALOG: EDIT PACKAGE PRICE
    editingPackage?.let { pkg ->
        EditSimplePriceDialog(
            title = "Edit Package Price",
            itemName = pkg.name,
            initialPriceKes = pkg.priceKes,
            onDismiss = { editingPackage = null },
            onSave = { newPrice ->
                onUpdatePackagePrice(pkg.id, newPrice)
                editingPackage = null
            }
        )
    }

    // SUB-DIALOG: EDIT ADD-ON PRICE
    editingAddon?.let { addon ->
        EditSimplePriceDialog(
            title = "Edit Add-On Price",
            itemName = addon.name,
            initialPriceKes = addon.priceKes,
            onDismiss = { editingAddon = null },
            onSave = { newPrice ->
                onUpdateAddonPrice(addon.id, newPrice)
                editingAddon = null
            }
        )
    }
}

@Composable
private fun CasketPriceRow(
    casket: CasketItem,
    onEditClick: () -> Unit
) {
    Surface(
        color = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.4f),
        shape = RoundedCornerShape(10.dp),
        border = androidx.compose.foundation.BorderStroke(1.dp, MaterialTheme.colorScheme.outline.copy(alpha = 0.15f)),
        modifier = Modifier.fillMaxWidth()
    ) {
        Row(
            modifier = Modifier
                .padding(12.dp)
                .fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Column(modifier = Modifier.weight(1f)) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Text(
                        text = casket.name,
                        fontWeight = FontWeight.Bold,
                        fontSize = 13.sp
                    )
                    Spacer(modifier = Modifier.width(6.dp))
                    Surface(
                        color = if (casket.inStock) EmeraldLight else Color(0xFFFFE4E6),
                        shape = RoundedCornerShape(4.dp)
                    ) {
                        Text(
                            text = if (casket.inStock) "${casket.stockCount} in stock" else "Out of stock",
                            fontSize = 9.sp,
                            fontWeight = FontWeight.Bold,
                            color = if (casket.inStock) EmeraldSuccess else com.example.ui.theme.StrokeRed,
                            modifier = Modifier.padding(horizontal = 4.dp, vertical = 1.dp)
                        )
                    }
                }
                Text(
                    text = "${casket.woodType} • ${casket.tier}",
                    fontSize = 11.sp,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
            }

            Column(horizontalAlignment = Alignment.End) {
                Text(
                    text = "KES ${String.format("%,.0f", casket.priceKes)}",
                    fontWeight = FontWeight.ExtraBold,
                    fontSize = 13.sp,
                    color = EmeraldSuccess
                )
                Text(
                    text = "USD $${String.format("%,.0f", casket.priceUsd)}",
                    fontSize = 10.sp,
                    color = Color.Gray
                )
            }

            Spacer(modifier = Modifier.width(8.dp))

            IconButton(
                onClick = onEditClick,
                modifier = Modifier
                    .size(32.dp)
                    .background(CyanContainer, CircleShape)
                    .testTag("edit_casket_price_${casket.id}")
            ) {
                Icon(
                    imageVector = Icons.Default.Edit,
                    contentDescription = "Edit Price",
                    tint = CyanPrimary,
                    modifier = Modifier.size(16.dp)
                )
            }
        }
    }
}

@Composable
private fun ServicePriceRow(
    service: SalesServiceItem,
    onEditClick: () -> Unit
) {
    Surface(
        color = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.4f),
        shape = RoundedCornerShape(10.dp),
        border = androidx.compose.foundation.BorderStroke(1.dp, MaterialTheme.colorScheme.outline.copy(alpha = 0.15f)),
        modifier = Modifier.fillMaxWidth()
    ) {
        Row(
            modifier = Modifier
                .padding(12.dp)
                .fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Column(modifier = Modifier.weight(1f)) {
                Text(
                    text = service.name,
                    fontWeight = FontWeight.Bold,
                    fontSize = 13.sp
                )
                Text(
                    text = "${service.category} • ${service.unit}",
                    fontSize = 11.sp,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
            }

            Column(horizontalAlignment = Alignment.End) {
                Text(
                    text = "KES ${String.format("%,.0f", service.priceKes)}",
                    fontWeight = FontWeight.ExtraBold,
                    fontSize = 13.sp,
                    color = CyanPrimary
                )
            }

            Spacer(modifier = Modifier.width(8.dp))

            IconButton(
                onClick = onEditClick,
                modifier = Modifier
                    .size(32.dp)
                    .background(CyanContainer, CircleShape)
                    .testTag("edit_service_price_${service.id}")
            ) {
                Icon(
                    imageVector = Icons.Default.Edit,
                    contentDescription = "Edit Price",
                    tint = CyanPrimary,
                    modifier = Modifier.size(16.dp)
                )
            }
        }
    }
}

@Composable
private fun PriceAuditRow(record: PriceUpdateRecord) {
    Surface(
        color = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.4f),
        shape = RoundedCornerShape(10.dp),
        border = androidx.compose.foundation.BorderStroke(1.dp, MaterialTheme.colorScheme.outline.copy(alpha = 0.15f)),
        modifier = Modifier.fillMaxWidth()
    ) {
        Column(modifier = Modifier.padding(12.dp)) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                Text(
                    text = record.itemName,
                    fontWeight = FontWeight.Bold,
                    fontSize = 12.sp
                )
                Text(
                    text = record.dateUpdated,
                    fontSize = 10.sp,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
            }

            Spacer(modifier = Modifier.height(4.dp))

            Row(verticalAlignment = Alignment.CenterVertically) {
                Text(
                    text = "KES ${String.format("%,.0f", record.previousPriceKes)}",
                    fontSize = 11.sp,
                    color = Color.Gray,
                    style = androidx.compose.ui.text.TextStyle(textDecoration = androidx.compose.ui.text.style.TextDecoration.LineThrough)
                )
                Text(text = " → ", fontSize = 11.sp, fontWeight = FontWeight.Bold)
                Text(
                    text = "KES ${String.format("%,.0f", record.newPriceKes)}",
                    fontSize = 12.sp,
                    fontWeight = FontWeight.Bold,
                    color = EmeraldSuccess
                )
            }

            Spacer(modifier = Modifier.height(2.dp))

            Text(
                text = "Authorized by ${record.updatedByStaffName} • ${record.notes}",
                fontSize = 10.sp,
                color = MaterialTheme.colorScheme.onSurfaceVariant
            )
        }
    }
}

@Composable
private fun EditCasketPriceSubDialog(
    casket: CasketItem,
    onDismiss: () -> Unit,
    onSave: (updatedCasket: CasketItem, notes: String) -> Unit
) {
    var nameText by remember { mutableStateOf(casket.name) }
    var woodTypeText by remember { mutableStateOf(casket.woodType) }
    var tierText by remember { mutableStateOf(casket.tier) }
    var finishText by remember { mutableStateOf(casket.finish) }
    var liningText by remember { mutableStateOf(casket.interiorLining) }
    var priceText by remember { mutableStateOf(casket.priceKes.toLong().toString()) }
    var stockText by remember { mutableStateOf(casket.stockCount.toString()) }
    var inStock by remember { mutableStateOf(casket.inStock) }
    var notes by remember { mutableStateOf("") }

    Dialog(onDismissRequest = onDismiss) {
        Card(
            shape = RoundedCornerShape(16.dp),
            colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
            modifier = Modifier
                .fillMaxWidth()
                .padding(16.dp)
        ) {
            Column(modifier = Modifier.padding(18.dp)) {
                Text(
                    text = "Edit Coffin Type, Specs & Price",
                    fontWeight = FontWeight.Bold,
                    fontSize = 15.sp
                )
                Text(
                    text = casket.id,
                    fontSize = 11.sp,
                    color = CyanPrimary,
                    fontWeight = FontWeight.Medium
                )

                Spacer(modifier = Modifier.height(10.dp))

                OutlinedTextField(
                    value = nameText,
                    onValueChange = { nameText = it },
                    label = { Text("Coffin / Casket Model Name", fontSize = 11.sp) },
                    singleLine = true,
                    modifier = Modifier.fillMaxWidth().testTag("casket_name_input")
                )

                Spacer(modifier = Modifier.height(6.dp))

                Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                    OutlinedTextField(
                        value = woodTypeText,
                        onValueChange = { woodTypeText = it },
                        label = { Text("Wood / Material", fontSize = 11.sp) },
                        singleLine = true,
                        modifier = Modifier.weight(1f)
                    )
                    OutlinedTextField(
                        value = tierText,
                        onValueChange = { tierText = it },
                        label = { Text("Tier", fontSize = 11.sp) },
                        singleLine = true,
                        modifier = Modifier.weight(0.8f)
                    )
                }

                Spacer(modifier = Modifier.height(6.dp))

                Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                    OutlinedTextField(
                        value = finishText,
                        onValueChange = { finishText = it },
                        label = { Text("Finish", fontSize = 11.sp) },
                        singleLine = true,
                        modifier = Modifier.weight(1f)
                    )
                    OutlinedTextField(
                        value = liningText,
                        onValueChange = { liningText = it },
                        label = { Text("Lining", fontSize = 11.sp) },
                        singleLine = true,
                        modifier = Modifier.weight(1f)
                    )
                }

                Spacer(modifier = Modifier.height(6.dp))

                Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                    OutlinedTextField(
                        value = priceText,
                        onValueChange = { priceText = it },
                        label = { Text("Selling Price (KES)", fontSize = 11.sp) },
                        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                        singleLine = true,
                        modifier = Modifier
                            .weight(1.2f)
                            .testTag("casket_price_input")
                    )

                    OutlinedTextField(
                        value = stockText,
                        onValueChange = {
                            stockText = it
                            val count = it.toIntOrNull() ?: 0
                            inStock = count > 0
                        },
                        label = { Text("Stock Qty", fontSize = 11.sp) },
                        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                        singleLine = true,
                        modifier = Modifier.weight(0.8f)
                    )
                }

                Spacer(modifier = Modifier.height(6.dp))

                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text("In Stock Status", fontSize = 12.sp, fontWeight = FontWeight.Medium)
                    Switch(
                        checked = inStock,
                        onCheckedChange = { inStock = it },
                        colors = SwitchDefaults.colors(checkedTrackColor = EmeraldSuccess)
                    )
                }

                OutlinedTextField(
                    value = notes,
                    onValueChange = { notes = it },
                    label = { Text("Price / Spec Adjustment Note", fontSize = 11.sp) },
                    placeholder = { Text("e.g. Timber cost update, custom finish...") },
                    singleLine = true,
                    modifier = Modifier.fillMaxWidth()
                )

                Spacer(modifier = Modifier.height(14.dp))

                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    OutlinedButton(
                        onClick = onDismiss,
                        modifier = Modifier.weight(1f)
                    ) {
                        Text("Cancel")
                    }

                    Button(
                        onClick = {
                            val newPrice = priceText.toDoubleOrNull() ?: casket.priceKes
                            val newStock = stockText.toIntOrNull() ?: casket.stockCount
                            val updated = casket.copy(
                                name = nameText.trim().ifBlank { casket.name },
                                woodType = woodTypeText.trim().ifBlank { casket.woodType },
                                tier = tierText.trim().ifBlank { casket.tier },
                                finish = finishText.trim().ifBlank { casket.finish },
                                interiorLining = liningText.trim().ifBlank { casket.interiorLining },
                                priceKes = newPrice,
                                priceUsd = newPrice / 130.0,
                                stockCount = newStock,
                                inStock = inStock
                            )
                            onSave(updated, notes)
                        },
                        colors = ButtonDefaults.buttonColors(containerColor = CyanPrimary),
                        modifier = Modifier
                            .weight(1f)
                            .testTag("save_casket_price_button")
                    ) {
                        Text("Save Changes", fontWeight = FontWeight.Bold)
                    }
                }
            }
        }
    }
}

@Composable
private fun EditSimplePriceDialog(
    title: String,
    itemName: String,
    initialPriceKes: Double,
    onDismiss: () -> Unit,
    onSave: (newPriceKes: Double) -> Unit
) {
    var priceText by remember { mutableStateOf(initialPriceKes.toLong().toString()) }
    Dialog(onDismissRequest = onDismiss) {
        Card(
            shape = RoundedCornerShape(16.dp),
            colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
            modifier = Modifier.fillMaxWidth().padding(16.dp)
        ) {
            Column(modifier = Modifier.padding(18.dp)) {
                Text(text = title, fontWeight = FontWeight.Bold, fontSize = 15.sp)
                Text(text = itemName, fontSize = 12.sp, color = CyanPrimary, fontWeight = FontWeight.Medium)
                Spacer(modifier = Modifier.height(12.dp))
                OutlinedTextField(
                    value = priceText,
                    onValueChange = { priceText = it },
                    label = { Text("Price (KES)") },
                    keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                    singleLine = true,
                    modifier = Modifier.fillMaxWidth()
                )
                Spacer(modifier = Modifier.height(14.dp))
                Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    OutlinedButton(onClick = onDismiss, modifier = Modifier.weight(1f)) {
                        Text("Cancel")
                    }
                    Button(
                        onClick = { onSave(priceText.toDoubleOrNull() ?: initialPriceKes) },
                        colors = ButtonDefaults.buttonColors(containerColor = EmeraldSuccess),
                        modifier = Modifier.weight(1f)
                    ) {
                        Text("Save Price", fontWeight = FontWeight.Bold)
                    }
                }
            }
        }
    }
}

@Composable
private fun EditServicePriceSubDialog(
    service: SalesServiceItem,
    onDismiss: () -> Unit,
    onSave: (newPriceKes: Double, notes: String) -> Unit
) {
    var priceText by remember { mutableStateOf(service.priceKes.toLong().toString()) }
    var notes by remember { mutableStateOf("") }

    Dialog(onDismissRequest = onDismiss) {
        Card(
            shape = RoundedCornerShape(16.dp),
            colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
            modifier = Modifier
                .fillMaxWidth()
                .padding(16.dp)
        ) {
            Column(modifier = Modifier.padding(18.dp)) {
                Text(
                    text = "Edit Service / Equipment Tariff",
                    fontWeight = FontWeight.Bold,
                    fontSize = 15.sp
                )
                Text(
                    text = service.name,
                    fontSize = 12.sp,
                    color = CyanPrimary,
                    fontWeight = FontWeight.Medium
                )

                Spacer(modifier = Modifier.height(14.dp))

                OutlinedTextField(
                    value = priceText,
                    onValueChange = { priceText = it },
                    label = { Text("Standard Tariff Fee (KES)") },
                    keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                    modifier = Modifier
                        .fillMaxWidth()
                        .testTag("service_price_input")
                )

                Spacer(modifier = Modifier.height(8.dp))

                OutlinedTextField(
                    value = notes,
                    onValueChange = { notes = it },
                    label = { Text("Revision Notes") },
                    placeholder = { Text("e.g. Fuel rate surcharge, equipment overhaul...") },
                    modifier = Modifier.fillMaxWidth()
                )

                Spacer(modifier = Modifier.height(16.dp))

                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    OutlinedButton(
                        onClick = onDismiss,
                        modifier = Modifier.weight(1f)
                    ) {
                        Text("Cancel")
                    }

                    Button(
                        onClick = {
                            val newPrice = priceText.toDoubleOrNull() ?: service.priceKes
                            onSave(newPrice, notes)
                        },
                        colors = ButtonDefaults.buttonColors(containerColor = CyanPrimary),
                        modifier = Modifier
                            .weight(1f)
                            .testTag("save_service_price_button")
                    ) {
                        Text("Save Tariff", fontWeight = FontWeight.Bold)
                    }
                }
            }
        }
    }
}
