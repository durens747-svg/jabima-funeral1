package com.example.ui.screens

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.expandVertically
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.shrinkVertically
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowForward
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.AddLocationAlt
import androidx.compose.material.icons.filled.AdminPanelSettings
import androidx.compose.material.icons.filled.Assignment
import androidx.compose.material.icons.filled.AttachMoney
import androidx.compose.material.icons.filled.Build
import androidx.compose.material.icons.filled.CalendarMonth
import androidx.compose.material.icons.filled.Check
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.Clear
import androidx.compose.material.icons.filled.DirectionsCar
import androidx.compose.material.icons.filled.Done
import androidx.compose.material.icons.filled.ExpandLess
import androidx.compose.material.icons.filled.ExpandMore
import androidx.compose.material.icons.filled.FactCheck
import androidx.compose.material.icons.filled.HourglassTop
import androidx.compose.material.icons.filled.Info
import androidx.compose.material.icons.filled.LocationOn
import androidx.compose.material.icons.filled.MedicalServices
import androidx.compose.material.icons.filled.NotificationImportant
import androidx.compose.material.icons.filled.PendingActions
import androidx.compose.material.icons.filled.Person
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material.icons.filled.PrecisionManufacturing
import androidx.compose.material.icons.filled.Radio
import androidx.compose.material.icons.filled.Schedule
import androidx.compose.material.icons.filled.Search
import androidx.compose.material.icons.filled.Speed
import androidx.compose.material.icons.filled.TableChart
import androidx.compose.material.icons.filled.FileUpload
import androidx.compose.material.icons.filled.FileDownload
import androidx.compose.material.icons.filled.TaskAlt
import androidx.compose.material.icons.filled.Inventory2
import androidx.compose.material.icons.filled.Verified
import androidx.compose.material.icons.filled.Warning
import com.example.model.ExcelDatasetType
import com.example.model.BurialScheduleEvent
import com.example.model.WorkshopProductionItem
import com.example.model.FleetGpsVehicle
import com.example.ui.components.FuneralJourneyStepper
import com.example.ui.components.ManagerialOversightDashboardCard
import com.example.ui.components.OperationsAnalyticsCharts
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Checkbox
import androidx.compose.material3.CheckboxDefaults
import androidx.compose.material3.FilterChip
import androidx.compose.material3.FilterChipDefaults
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.model.ActivityCategory
import com.example.model.ActivityStatus
import com.example.model.FuneralArrangementStage
import com.example.model.NavTab
import com.example.model.StaffAccount
import com.example.model.StaffActivity
import com.example.model.StaffRole
import com.example.model.TaskPriority
import com.example.ui.theme.AmberLight
import com.example.ui.theme.AmberWarning
import com.example.ui.theme.BorderLight
import com.example.ui.theme.BorderLightGreen
import com.example.ui.theme.CyanContainer
import com.example.ui.theme.CyanDark
import com.example.ui.theme.CyanPrimary
import com.example.ui.theme.EmeraldGreenIce
import com.example.ui.theme.EmeraldLight
import com.example.ui.theme.EmeraldSuccess
import com.example.ui.theme.ForestGreenBorder
import com.example.ui.theme.ForestGreenDark
import com.example.ui.theme.ForestGreenLight
import com.example.ui.theme.ForestGreenPrimary
import com.example.ui.theme.Navy800
import com.example.ui.theme.Navy900
import com.example.ui.theme.PureWhite
import com.example.ui.theme.RoyalCobaltBlue
import com.example.ui.theme.RoyalCobaltIce
import com.example.ui.theme.StrokeRed
import com.example.ui.theme.StrokeRedLight
import com.example.ui.theme.TextMuted
import com.example.ui.theme.TextPrimary
import com.example.ui.theme.TextSecondary

enum class OperationalTabFilter(val label: String) {
    ALL("All Records"),
    CURRENT_TASKS("Current Tasks"),
    PENDING_LOGS("Pending Logs"),
    URGENT_PRIORITY("Urgent / High"),
    COMPLETED("Completed")
}

@Composable
fun StaffOperationsDashboardScreen(
    currentAccount: StaffAccount,
    activities: List<StaffActivity>,
    onUpdateActivityStatus: (activityId: String, status: ActivityStatus) -> Unit,
    onToggleChecklistItem: (activityId: String, item: String) -> Unit,
    onOpenRealtimeLogger: () -> Unit,
    onLogActivity: () -> Unit,
    onNavigateTab: (NavTab) -> Unit,
    onOpenPriceEditor: () -> Unit = {},
    onOpenStockUpload: () -> Unit = {},
    onOpenUniversalExcelImport: (ExcelDatasetType) -> Unit = {},
    onOpenExportManifest: () -> Unit = {},
    burialSchedules: List<BurialScheduleEvent> = emptyList(),
    workshopItems: List<WorkshopProductionItem> = emptyList(),
    fleetVehicles: List<FleetGpsVehicle> = emptyList(),
    allActivities: List<StaffActivity> = activities,
    allStaffAccounts: List<StaffAccount> = emptyList(),
    onDispatchTaskAlert: (StaffActivity) -> Unit = {},
    modifier: Modifier = Modifier
) {
    var searchQuery by remember { mutableStateOf("") }
    var selectedTabFilter by remember { mutableStateOf(OperationalTabFilter.ALL) }
    var selectedCategoryFilter by remember { mutableStateOf<ActivityCategory?>(null) }
    var expandedTaskId by remember { mutableStateOf<String?>(null) }

    val isAdminOrSupervisor = currentAccount.role == StaffRole.OPERATIONS_ADMIN ||
            currentAccount.role == StaffRole.MANAGING_DIRECTOR_CEO ||
            currentAccount.role == StaffRole.FUNERAL_DIRECTOR

    // Computed Operational Groups
    val currentOperationalTasks = activities.filter {
        it.status == ActivityStatus.IN_PROGRESS ||
                it.status == ActivityStatus.IN_TRANSIT ||
                it.status == ActivityStatus.SCHEDULED
    }

    val pendingFuneralLogs = activities.filter {
        !it.verifiedByAdmin && (it.status == ActivityStatus.IN_PROGRESS ||
                it.status == ActivityStatus.IN_TRANSIT ||
                it.status == ActivityStatus.COMPLETED)
    }

    val activeInProgressCount = activities.count {
        it.status == ActivityStatus.IN_PROGRESS || it.status == ActivityStatus.IN_TRANSIT
    }
    val pendingVerificationCount = pendingFuneralLogs.size
    val scheduledTodayCount = activities.count { it.status == ActivityStatus.SCHEDULED }
    val completedCount = activities.count {
        it.status == ActivityStatus.COMPLETED || it.status == ActivityStatus.VERIFIED_BY_ADMIN
    }

    // Filtered lists based on user search & tab filter
    val filteredActivities = activities.filter { act ->
        val matchesSearch = searchQuery.isBlank() ||
                act.title.contains(searchQuery, ignoreCase = true) ||
                act.caseReference.contains(searchQuery, ignoreCase = true) ||
                act.clientFamily.contains(searchQuery, ignoreCase = true) ||
                act.staffName.contains(searchQuery, ignoreCase = true) ||
                (act.assignedVehicle?.contains(searchQuery, ignoreCase = true) == true) ||
                act.location.contains(searchQuery, ignoreCase = true)

        val matchesCategory = selectedCategoryFilter == null || act.category == selectedCategoryFilter

        val matchesTab = when (selectedTabFilter) {
            OperationalTabFilter.ALL -> true
            OperationalTabFilter.CURRENT_TASKS -> act.status == ActivityStatus.IN_PROGRESS ||
                    act.status == ActivityStatus.IN_TRANSIT ||
                    act.status == ActivityStatus.SCHEDULED
            OperationalTabFilter.PENDING_LOGS -> !act.verifiedByAdmin
            OperationalTabFilter.URGENT_PRIORITY -> act.priority == TaskPriority.URGENT || act.priority == TaskPriority.HIGH
            OperationalTabFilter.COMPLETED -> act.status == ActivityStatus.COMPLETED || act.status == ActivityStatus.VERIFIED_BY_ADMIN
        }

        matchesSearch && matchesCategory && matchesTab
    }

    val activeDisplayTasks = filteredActivities.filter {
        it.status == ActivityStatus.IN_PROGRESS ||
                it.status == ActivityStatus.IN_TRANSIT ||
                it.status == ActivityStatus.SCHEDULED
    }

    val pendingDisplayLogs = filteredActivities.filter { !it.verifiedByAdmin }

    LazyColumn(
        modifier = modifier
            .fillMaxSize()
            .padding(horizontal = 14.dp),
        verticalArrangement = Arrangement.spacedBy(14.dp)
    ) {
        item {
            Spacer(modifier = Modifier.height(2.dp))

            // =========================================================================
            // OPERATIONAL COMMAND HUB HERO BANNER
            // =========================================================================
            Card(
                shape = RoundedCornerShape(16.dp),
                border = BorderStroke(1.5.dp, StrokeRed.copy(alpha = 0.55f)),
                colors = CardDefaults.cardColors(containerColor = Color.Transparent),
                modifier = Modifier
                    .fillMaxWidth()
                    .testTag("operations_dashboard_hero_card")
            ) {
                Box(
                    modifier = Modifier
                        .fillMaxWidth()
                        .background(
                            brush = Brush.linearGradient(
                                colors = listOf(ForestGreenDark, ForestGreenPrimary, ForestGreenLight)
                            )
                        )
                        .padding(18.dp)
                ) {
                    Column {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Box(
                                    modifier = Modifier
                                        .size(10.dp)
                                        .clip(CircleShape)
                                        .background(Color(0xFF4ADE80))
                                )
                                Spacer(modifier = Modifier.width(6.dp))
                                Text(
                                    text = "JABIMA OPERATIONS COMMAND HUB",
                                    color = Color(0xFF86EFAC),
                                    fontSize = 10.sp,
                                    fontWeight = FontWeight.ExtraBold,
                                    letterSpacing = 1.sp
                                )
                            }

                            Surface(
                                shape = RoundedCornerShape(12.dp),
                                color = Color.White.copy(alpha = 0.15f)
                            ) {
                                Row(
                                    modifier = Modifier.padding(horizontal = 8.dp, vertical = 3.dp),
                                    verticalAlignment = Alignment.CenterVertically
                                ) {
                                    Icon(
                                        imageVector = Icons.Default.Radio,
                                        contentDescription = null,
                                        tint = Color(0xFF4ADE80),
                                        modifier = Modifier.size(12.dp)
                                    )
                                    Spacer(modifier = Modifier.width(4.dp))
                                    Text(
                                        text = "LIVE DISPATCH SYNC",
                                        color = Color.White,
                                        fontSize = 9.sp,
                                        fontWeight = FontWeight.Bold
                                    )
                                }
                            }
                        }

                        Spacer(modifier = Modifier.height(10.dp))

                        Text(
                            text = "Operational Tasks & Funeral Activity Logs",
                            color = PureWhite,
                            fontSize = 18.sp,
                            fontWeight = FontWeight.Bold
                        )
                        Text(
                            text = "Real-time task tracking, field milestone logs & supervisor verification",
                            color = Color(0xFFD1FAE5),
                            fontSize = 12.sp
                        )

                        Spacer(modifier = Modifier.height(14.dp))

                        // Quick Action Buttons
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.spacedBy(8.dp)
                        ) {
                            Button(
                                onClick = onOpenRealtimeLogger,
                                colors = ButtonDefaults.buttonColors(
                                    containerColor = Color(0xFF22C55E),
                                    contentColor = PureWhite
                                ),
                                shape = RoundedCornerShape(10.dp),
                                contentPadding = PaddingValues(horizontal = 12.dp, vertical = 6.dp),
                                modifier = Modifier
                                    .weight(1.2f)
                                    .height(38.dp)
                                    .testTag("btn_dashboard_field_log")
                            ) {
                                Icon(
                                    imageVector = Icons.Default.DirectionsCar,
                                    contentDescription = null,
                                    modifier = Modifier.size(15.dp)
                                )
                                Spacer(modifier = Modifier.width(6.dp))
                                Text(
                                    text = "Live Field Log",
                                    fontSize = 12.sp,
                                    fontWeight = FontWeight.Bold
                                )
                            }

                            Button(
                                onClick = onLogActivity,
                                colors = ButtonDefaults.buttonColors(
                                    containerColor = PureWhite.copy(alpha = 0.2f),
                                    contentColor = PureWhite
                                ),
                                shape = RoundedCornerShape(10.dp),
                                contentPadding = PaddingValues(horizontal = 10.dp, vertical = 6.dp),
                                modifier = Modifier
                                    .weight(1f)
                                    .height(38.dp)
                                    .testTag("btn_dashboard_new_task")
                            ) {
                                Icon(
                                    imageVector = Icons.Default.Add,
                                    contentDescription = null,
                                    modifier = Modifier.size(15.dp)
                                )
                                Spacer(modifier = Modifier.width(4.dp))
                                Text(
                                    text = "Assign Task",
                                    fontSize = 11.sp,
                                    fontWeight = FontWeight.Bold
                                )
                            }

                            Button(
                                onClick = { onNavigateTab(NavTab.BURIAL_SCHEDULING) },
                                colors = ButtonDefaults.buttonColors(
                                    containerColor = PureWhite.copy(alpha = 0.2f),
                                    contentColor = PureWhite
                                ),
                                shape = RoundedCornerShape(10.dp),
                                contentPadding = PaddingValues(horizontal = 10.dp, vertical = 6.dp),
                                modifier = Modifier
                                    .weight(1f)
                                    .height(38.dp)
                                    .testTag("btn_dashboard_burial_schedule")
                            ) {
                                Icon(
                                    imageVector = Icons.Default.CalendarMonth,
                                    contentDescription = null,
                                    modifier = Modifier.size(15.dp)
                                )
                                Spacer(modifier = Modifier.width(4.dp))
                                Text(
                                    text = "Schedule",
                                    fontSize = 11.sp,
                                    fontWeight = FontWeight.Bold
                                )
                            }
                        }
                    }
                }
            }
        }

        // =========================================================================
        // EXECUTIVE SHORTCUTS: ACTIVE PRICES & UPLOAD STOCK (EXCEL)
        // =========================================================================
        item {
            Surface(
                color = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.5f),
                shape = RoundedCornerShape(14.dp),
                border = BorderStroke(1.dp, MaterialTheme.colorScheme.outline.copy(alpha = 0.2f)),
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(modifier = Modifier.padding(12.dp)) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text(
                            text = "EXECUTIVE SHORTCUTS & BULK ERP",
                            fontSize = 11.sp,
                            fontWeight = FontWeight.Bold,
                            color = CyanPrimary,
                            letterSpacing = 0.5.sp
                        )
                        Surface(
                            color = Color(0xFF107C41).copy(alpha = 0.15f),
                            shape = RoundedCornerShape(4.dp)
                        ) {
                            Text(
                                text = "Excel Sync Ready",
                                fontSize = 9.sp,
                                fontWeight = FontWeight.Bold,
                                color = Color(0xFF107C41),
                                modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp)
                            )
                        }
                    }

                    Spacer(modifier = Modifier.height(8.dp))

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        Button(
                            onClick = onOpenPriceEditor,
                            colors = ButtonDefaults.buttonColors(containerColor = EmeraldSuccess),
                            shape = RoundedCornerShape(8.dp),
                            contentPadding = PaddingValues(horizontal = 8.dp, vertical = 4.dp),
                            modifier = Modifier
                                .weight(1f)
                                .height(38.dp)
                                .testTag("dashboard_open_price_editor_button")
                        ) {
                            Icon(Icons.Default.AttachMoney, contentDescription = null, modifier = Modifier.size(15.dp))
                            Spacer(modifier = Modifier.width(4.dp))
                            Text("Prices", fontSize = 11.sp, fontWeight = FontWeight.Bold)
                        }

                        Button(
                            onClick = onOpenStockUpload,
                            colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF107C41)),
                            shape = RoundedCornerShape(8.dp),
                            contentPadding = PaddingValues(horizontal = 8.dp, vertical = 4.dp),
                            modifier = Modifier
                                .weight(1.3f)
                                .height(38.dp)
                                .testTag("dashboard_open_stock_upload_button")
                        ) {
                            Icon(Icons.Default.TableChart, contentDescription = null, modifier = Modifier.size(15.dp))
                            Spacer(modifier = Modifier.width(4.dp))
                            Text("Upload Stock (Excel)", fontSize = 11.sp, fontWeight = FontWeight.Bold)
                        }

                        Button(
                            onClick = { onNavigateTab(NavTab.INVENTORY_MANAGEMENT) },
                            colors = ButtonDefaults.buttonColors(containerColor = Navy900),
                            shape = RoundedCornerShape(8.dp),
                            contentPadding = PaddingValues(horizontal = 8.dp, vertical = 4.dp),
                            modifier = Modifier
                                .weight(1.1f)
                                .height(38.dp)
                                .testTag("dashboard_open_inventory_button")
                        ) {
                            Icon(Icons.Default.Inventory2, contentDescription = null, modifier = Modifier.size(15.dp))
                            Spacer(modifier = Modifier.width(4.dp))
                            Text("Inventory", fontSize = 11.sp, fontWeight = FontWeight.Bold)
                        }
                    }

                    Spacer(modifier = Modifier.height(8.dp))

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        Surface(
                            onClick = { onOpenUniversalExcelImport(ExcelDatasetType.INVENTORY_STOCK) },
                            shape = RoundedCornerShape(8.dp),
                            color = Color(0xFF107C41).copy(alpha = 0.1f),
                            border = BorderStroke(1.dp, Color(0xFF107C41).copy(alpha = 0.4f)),
                            modifier = Modifier
                                .weight(1f)
                                .testTag("dashboard_open_universal_excel_import_hub")
                        ) {
                            Row(
                                modifier = Modifier.padding(horizontal = 8.dp, vertical = 7.dp),
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Icon(
                                    imageVector = Icons.Default.FileUpload,
                                    contentDescription = null,
                                    tint = Color(0xFF107C41),
                                    modifier = Modifier.size(15.dp)
                                )
                                Spacer(modifier = Modifier.width(6.dp))
                                Column {
                                    Text(
                                        text = "Import Excel Hub",
                                        fontSize = 11.sp,
                                        fontWeight = FontWeight.Bold,
                                        color = Color(0xFF107C41)
                                    )
                                    Text(
                                        text = "6 Datasets",
                                        fontSize = 8.sp,
                                        color = TextSecondary
                                    )
                                }
                            }
                        }

                        Surface(
                            onClick = onOpenExportManifest,
                            shape = RoundedCornerShape(8.dp),
                            color = Color(0xFF0369A1).copy(alpha = 0.1f),
                            border = BorderStroke(1.dp, Color(0xFF0369A1).copy(alpha = 0.4f)),
                            modifier = Modifier
                                .weight(1f)
                                .testTag("dashboard_open_export_manifest_button")
                        ) {
                            Row(
                                modifier = Modifier.padding(horizontal = 8.dp, vertical = 7.dp),
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Icon(
                                    imageVector = Icons.Default.FileDownload,
                                    contentDescription = null,
                                    tint = Color(0xFF0369A1),
                                    modifier = Modifier.size(15.dp)
                                )
                                Spacer(modifier = Modifier.width(6.dp))
                                Column {
                                    Text(
                                        text = "Export Manifests",
                                        fontSize = 11.sp,
                                        fontWeight = FontWeight.Bold,
                                        color = Color(0xFF0369A1)
                                    )
                                    Text(
                                        text = "Routes & Gear",
                                        fontSize = 8.sp,
                                        color = TextSecondary
                                    )
                                }
                            }
                        }
                    }
                }
            }
        }

        // =========================================================================
        // EXECUTIVE OPERATIONAL METRICS (4 CARDS)
        // =========================================================================
        item {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                OperationalMetricCard(
                    title = "Active Tasks",
                    count = "$activeInProgressCount",
                    sub = "En route & on field",
                    icon = Icons.Default.Speed,
                    color = EmeraldSuccess,
                    bgColor = EmeraldLight,
                    modifier = Modifier.weight(1f),
                    testTag = "metric_active_tasks"
                )

                OperationalMetricCard(
                    title = "Pending Logs",
                    count = "$pendingVerificationCount",
                    sub = "Awaiting verification",
                    icon = Icons.Default.HourglassTop,
                    color = AmberWarning,
                    bgColor = AmberLight,
                    modifier = Modifier.weight(1f),
                    testTag = "metric_pending_logs"
                )

                OperationalMetricCard(
                    title = "Scheduled",
                    count = "$scheduledTodayCount",
                    sub = "Upcoming milestones",
                    icon = Icons.Default.Schedule,
                    color = ForestGreenPrimary,
                    bgColor = EmeraldGreenIce,
                    modifier = Modifier.weight(1f),
                    testTag = "metric_scheduled_tasks"
                )

                OperationalMetricCard(
                    title = "Finalized",
                    count = "$completedCount",
                    sub = "Verified duties",
                    icon = Icons.Default.TaskAlt,
                    color = ForestGreenDark,
                    bgColor = Color(0xFFDCFCE7),
                    modifier = Modifier.weight(1f),
                    testTag = "metric_finalized_tasks"
                )
            }
        }

        // =========================================================================
        // MANAGERIAL OVERSIGHT BAR CHART & PENDING SERVICE TASKS SUMMARY
        // =========================================================================
        item {
            ManagerialOversightDashboardCard(
                staffAccounts = allStaffAccounts.ifEmpty { listOf(currentAccount) },
                activities = allActivities,
                onUpdateActivityStatus = onUpdateActivityStatus,
                onDispatchTaskAlert = onDispatchTaskAlert,
                onOpenTasksTimeline = { onNavigateTab(NavTab.ACTIVITIES) }
            )
        }

        // =========================================================================
        // FUNERAL ARRANGEMENT JOURNEY STEPPER
        // =========================================================================
        item {
            FuneralJourneyStepper(
                event = burialSchedules.firstOrNull()
            )
        }

        // =========================================================================
        // EXECUTIVE OPERATIONAL ANALYTICS & GAUGES
        // =========================================================================
        item {
            OperationsAnalyticsCharts(
                workshopItems = workshopItems,
                fleetVehicles = fleetVehicles
            )
        }

        // =========================================================================
        // SEARCH & FILTER BAR
        // =========================================================================
        item {
            Surface(
                color = PureWhite,
                shape = RoundedCornerShape(12.dp),
                border = BorderStroke(1.dp, BorderLight),
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(modifier = Modifier.padding(12.dp)) {
                    OutlinedTextField(
                        value = searchQuery,
                        onValueChange = { searchQuery = it },
                        modifier = Modifier
                            .fillMaxWidth()
                            .testTag("operations_search_input"),
                        placeholder = {
                            Text(
                                "Search Case Ref (#CAS-...), Client Name, Hearse Plate, or Staff",
                                fontSize = 12.sp,
                                color = TextMuted
                            )
                        },
                        leadingIcon = {
                            Icon(
                                Icons.Default.Search,
                                contentDescription = null,
                                tint = ForestGreenPrimary,
                                modifier = Modifier.size(18.dp)
                            )
                        },
                        trailingIcon = {
                            if (searchQuery.isNotEmpty()) {
                                IconButton(onClick = { searchQuery = "" }) {
                                    Icon(
                                        Icons.Default.Clear,
                                        contentDescription = "Clear",
                                        modifier = Modifier.size(16.dp)
                                    )
                                }
                            }
                        },
                        singleLine = true,
                        shape = RoundedCornerShape(10.dp),
                        colors = OutlinedTextFieldDefaults.colors(
                            focusedBorderColor = ForestGreenPrimary,
                            unfocusedBorderColor = BorderLight,
                            focusedContainerColor = PureWhite,
                            unfocusedContainerColor = Color(0xFFF8FAFC)
                        )
                    )

                    Spacer(modifier = Modifier.height(10.dp))

                    // Tab filter chips
                    LazyRow(
                        horizontalArrangement = Arrangement.spacedBy(6.dp),
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        items(OperationalTabFilter.values()) { filter ->
                            val isSelected = selectedTabFilter == filter
                            FilterChip(
                                selected = isSelected,
                                onClick = { selectedTabFilter = filter },
                                label = {
                                    Text(
                                        text = when (filter) {
                                            OperationalTabFilter.ALL -> "All (${activities.size})"
                                            OperationalTabFilter.CURRENT_TASKS -> "Current Tasks ($activeInProgressCount)"
                                            OperationalTabFilter.PENDING_LOGS -> "Pending Logs ($pendingVerificationCount)"
                                            OperationalTabFilter.URGENT_PRIORITY -> "Urgent / High"
                                            OperationalTabFilter.COMPLETED -> "Completed ($completedCount)"
                                        },
                                        fontSize = 11.sp,
                                        fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Medium
                                    )
                                },
                                colors = FilterChipDefaults.filterChipColors(
                                    selectedContainerColor = ForestGreenPrimary,
                                    selectedLabelColor = PureWhite,
                                    containerColor = PureWhite,
                                    labelColor = TextSecondary
                                ),
                                border = BorderStroke(
                                    1.dp,
                                    if (isSelected) ForestGreenPrimary else BorderLight
                                ),
                                shape = RoundedCornerShape(8.dp),
                                modifier = Modifier.testTag("filter_chip_${filter.name}")
                            )
                        }
                    }

                    // Category filter chips
                    Spacer(modifier = Modifier.height(6.dp))
                    LazyRow(
                        horizontalArrangement = Arrangement.spacedBy(6.dp),
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        item {
                            Surface(
                                shape = RoundedCornerShape(8.dp),
                                color = if (selectedCategoryFilter == null) ForestGreenPrimary.copy(alpha = 0.15f) else Color.Transparent,
                                border = BorderStroke(
                                    1.dp,
                                    if (selectedCategoryFilter == null) ForestGreenPrimary else BorderLight
                                ),
                                modifier = Modifier
                                    .clickable { selectedCategoryFilter = null }
                                    .padding(vertical = 2.dp)
                            ) {
                                Text(
                                    text = "All Departments",
                                    fontSize = 10.sp,
                                    fontWeight = if (selectedCategoryFilter == null) FontWeight.Bold else FontWeight.Normal,
                                    color = if (selectedCategoryFilter == null) ForestGreenPrimary else TextMuted,
                                    modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp)
                                )
                            }
                        }

                        val keyCategories = listOf<Pair<ActivityCategory, String>>(
                            ActivityCategory.FLEET_TRANSPORT to "Fleet & Hearse",
                            ActivityCategory.CHAPEL_SERVICE to "Chapel & Vigils",
                            ActivityCategory.EMBALMING_PREPARATION to "Mortuary Prep",
                            ActivityCategory.GRAVESITE_SETUP to "Gravesite Lowering",
                            ActivityCategory.WORKSHOP_PRODUCTION to "Workshop Craft"
                        )

                        items(keyCategories) { (cat, label) ->
                            val isSel = selectedCategoryFilter == cat
                            Surface(
                                shape = RoundedCornerShape(8.dp),
                                color = if (isSel) ForestGreenPrimary.copy(alpha = 0.15f) else Color.Transparent,
                                border = BorderStroke(
                                    1.dp,
                                    if (isSel) ForestGreenPrimary else BorderLight
                                ),
                                modifier = Modifier
                                    .clickable {
                                        selectedCategoryFilter = if (isSel) null else cat
                                    }
                                    .padding(vertical = 2.dp)
                            ) {
                                Text(
                                    text = label,
                                    fontSize = 10.sp,
                                    fontWeight = if (isSel) FontWeight.Bold else FontWeight.Normal,
                                    color = if (isSel) ForestGreenPrimary else TextMuted,
                                    modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp)
                                )
                            }
                        }
                    }
                }
            }
        }

        // =========================================================================
        // SECTION 1: CURRENT OPERATIONAL TASKS (LIVE & IN PROGRESS)
        // =========================================================================
        if (selectedTabFilter == OperationalTabFilter.ALL || selectedTabFilter == OperationalTabFilter.CURRENT_TASKS || selectedTabFilter == OperationalTabFilter.URGENT_PRIORITY) {
            item {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Box(
                            modifier = Modifier
                                .size(8.dp)
                                .clip(CircleShape)
                                .background(ForestGreenPrimary)
                        )
                        Spacer(modifier = Modifier.width(6.dp))
                        Text(
                            text = "Current Operational Tasks",
                            fontSize = 15.sp,
                            fontWeight = FontWeight.Bold,
                            color = Navy900
                        )
                        Spacer(modifier = Modifier.width(6.dp))
                        Surface(
                            shape = RoundedCornerShape(10.dp),
                            color = ForestGreenPrimary.copy(alpha = 0.12f)
                        ) {
                            Text(
                                text = "${activeDisplayTasks.size} active",
                                fontSize = 10.sp,
                                fontWeight = FontWeight.Bold,
                                color = ForestGreenPrimary,
                                modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp)
                            )
                        }
                    }

                    Text(
                        text = "Real-time Field Operations",
                        fontSize = 11.sp,
                        color = TextMuted
                    )
                }
            }

            if (activeDisplayTasks.isEmpty()) {
                item {
                    OperationalEmptyStateCard(
                        title = "No active operational tasks found",
                        subtitle = "All assigned field duties, mortuary prep, and cortege escorts are cleared or match no filters.",
                        buttonText = "Assign New Task",
                        onAction = onLogActivity
                    )
                }
            } else {
                items(activeDisplayTasks, key = { it.id }) { task ->
                    val isExpanded = expandedTaskId == task.id
                    OperationalTaskCard(
                        task = task,
                        isExpanded = isExpanded,
                        onToggleExpand = {
                            expandedTaskId = if (isExpanded) null else task.id
                        },
                        onUpdateStatus = { newStatus ->
                            onUpdateActivityStatus(task.id, newStatus)
                        },
                        onToggleChecklist = { itemText ->
                            onToggleChecklistItem(task.id, itemText)
                        },
                        onOpenLogger = onOpenRealtimeLogger
                    )
                }
            }
        }

        // =========================================================================
        // SECTION 2: PENDING FUNERAL ACTIVITY LOGS (AWAITING VERIFICATION / REVIEW)
        // =========================================================================
        if (selectedTabFilter == OperationalTabFilter.ALL || selectedTabFilter == OperationalTabFilter.PENDING_LOGS) {
            item {
                Spacer(modifier = Modifier.height(4.dp))
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Box(
                            modifier = Modifier
                                .size(8.dp)
                                .clip(CircleShape)
                                .background(AmberWarning)
                        )
                        Spacer(modifier = Modifier.width(6.dp))
                        Text(
                            text = "Pending Funeral Activity Logs",
                            fontSize = 15.sp,
                            fontWeight = FontWeight.Bold,
                            color = Navy900
                        )
                        Spacer(modifier = Modifier.width(6.dp))
                        Surface(
                            shape = RoundedCornerShape(10.dp),
                            color = AmberLight
                        ) {
                            Text(
                                text = "${pendingDisplayLogs.size} pending review",
                                fontSize = 10.sp,
                                fontWeight = FontWeight.Bold,
                                color = AmberWarning,
                                modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp)
                            )
                        }
                    }

                    Text(
                        text = "Field Logs Awaiting Sign-Off",
                        fontSize = 11.sp,
                        color = AmberWarning,
                        fontWeight = FontWeight.SemiBold
                    )
                }
            }

            if (pendingDisplayLogs.isEmpty()) {
                item {
                    OperationalEmptyStateCard(
                        title = "No pending funeral activity logs",
                        subtitle = "All funeral service logs and field operations have been reviewed and verified by administration.",
                        buttonText = "Log Field Milestone",
                        onAction = onOpenRealtimeLogger
                    )
                }
            } else {
                items(pendingDisplayLogs, key = { "pending_${it.id}" }) { pendingLog ->
                    PendingFuneralLogCard(
                        activity = pendingLog,
                        isAdminOrSupervisor = isAdminOrSupervisor,
                        onVerifyAndApprove = {
                            onUpdateActivityStatus(pendingLog.id, ActivityStatus.VERIFIED_BY_ADMIN)
                        },
                        onMarkCompleted = {
                            onUpdateActivityStatus(pendingLog.id, ActivityStatus.COMPLETED)
                        },
                        onOpenLogger = onOpenRealtimeLogger
                    )
                }
            }
        }

        // Bottom padding for navigation comfort
        item {
            Spacer(modifier = Modifier.height(70.dp))
        }
    }
}

// =============================================================================
// SUB-COMPONENT: OPERATIONAL TASK CARD (LIVE & INTERACTIVE)
// =============================================================================
@Composable
fun OperationalTaskCard(
    task: StaffActivity,
    isExpanded: Boolean,
    onToggleExpand: () -> Unit,
    onUpdateStatus: (ActivityStatus) -> Unit,
    onToggleChecklist: (String) -> Unit,
    onOpenLogger: () -> Unit,
    modifier: Modifier = Modifier
) {
    val totalChecklist = task.checklistItems.size
    val completedChecklist = task.completedChecklistItems.size
    val progressFraction = if (totalChecklist > 0) completedChecklist.toFloat() / totalChecklist else 1f

    Card(
        shape = RoundedCornerShape(14.dp),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
        border = BorderStroke(
            1.dp,
            if (task.priority == TaskPriority.URGENT) StrokeRed.copy(alpha = 0.5f) else MaterialTheme.colorScheme.outline.copy(alpha = 0.3f)
        ),
        elevation = CardDefaults.cardElevation(defaultElevation = 1.dp),
        modifier = modifier
            .fillMaxWidth()
            .testTag("operational_task_card_${task.id}")
    ) {
        Column(modifier = Modifier.padding(14.dp)) {
            // TOP ROW: Priority Badge + Stage + Status
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(6.dp)
                ) {
                    // Priority Pill
                    Surface(
                        shape = RoundedCornerShape(6.dp),
                        color = when (task.priority) {
                            TaskPriority.URGENT -> StrokeRedLight
                            TaskPriority.HIGH -> AmberLight
                            TaskPriority.NORMAL -> EmeraldGreenIce
                        }
                    ) {
                        Text(
                            text = task.priority.label.uppercase(),
                            fontSize = 9.sp,
                            fontWeight = FontWeight.ExtraBold,
                            color = when (task.priority) {
                                TaskPriority.URGENT -> StrokeRed
                                TaskPriority.HIGH -> AmberWarning
                                TaskPriority.NORMAL -> ForestGreenPrimary
                            },
                            modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp)
                        )
                    }

                    // Stage Pill
                    Surface(
                        shape = RoundedCornerShape(6.dp),
                        color = Color(0xFFF1F5F9)
                    ) {
                        Text(
                            text = task.arrangementStage.label,
                            fontSize = 9.sp,
                            fontWeight = FontWeight.SemiBold,
                            color = Navy900,
                            modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp)
                        )
                    }
                }

                // Live Status Pill
                Surface(
                    shape = RoundedCornerShape(6.dp),
                    color = when (task.status) {
                        ActivityStatus.IN_PROGRESS -> EmeraldLight
                        ActivityStatus.IN_TRANSIT -> RoyalCobaltIce
                        ActivityStatus.SCHEDULED -> Color(0xFFF8FAFC)
                        ActivityStatus.ON_HOLD -> AmberLight
                        ActivityStatus.COMPLETED, ActivityStatus.VERIFIED_BY_ADMIN -> Color(0xFFDCFCE7)
                    },
                    border = BorderStroke(
                        1.dp,
                        when (task.status) {
                            ActivityStatus.IN_PROGRESS -> ForestGreenBorder
                            ActivityStatus.IN_TRANSIT -> RoyalCobaltBlue.copy(alpha = 0.5f)
                            ActivityStatus.SCHEDULED -> BorderLight
                            ActivityStatus.ON_HOLD -> AmberWarning.copy(alpha = 0.5f)
                            ActivityStatus.COMPLETED, ActivityStatus.VERIFIED_BY_ADMIN -> EmeraldSuccess.copy(alpha = 0.5f)
                        }
                    )
                ) {
                    Row(
                        modifier = Modifier.padding(horizontal = 8.dp, vertical = 2.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        if (task.status == ActivityStatus.IN_PROGRESS || task.status == ActivityStatus.IN_TRANSIT) {
                            Box(
                                modifier = Modifier
                                    .size(6.dp)
                                    .clip(CircleShape)
                                    .background(if (task.status == ActivityStatus.IN_PROGRESS) ForestGreenPrimary else RoyalCobaltBlue)
                            )
                            Spacer(modifier = Modifier.width(4.dp))
                        }
                        Text(
                            text = task.status.label,
                            fontSize = 10.sp,
                            fontWeight = FontWeight.Bold,
                            color = when (task.status) {
                                ActivityStatus.IN_PROGRESS -> ForestGreenPrimary
                                ActivityStatus.IN_TRANSIT -> RoyalCobaltBlue
                                ActivityStatus.SCHEDULED -> TextSecondary
                                ActivityStatus.ON_HOLD -> AmberWarning
                                ActivityStatus.COMPLETED, ActivityStatus.VERIFIED_BY_ADMIN -> EmeraldSuccess
                            }
                        )
                    }
                }
            }

            Spacer(modifier = Modifier.height(8.dp))

            // TITLE & CASE REFERENCE
            Text(
                text = task.title,
                fontWeight = FontWeight.Bold,
                fontSize = 14.sp,
                color = Navy900
            )

            Row(
                modifier = Modifier.fillMaxWidth(),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                Text(
                    text = "Ref: ${task.caseReference}",
                    fontFamily = FontFamily.Monospace,
                    fontWeight = FontWeight.Bold,
                    fontSize = 11.sp,
                    color = ForestGreenPrimary
                )
                Text(
                    text = "•",
                    color = TextMuted,
                    fontSize = 10.sp
                )
                Text(
                    text = task.clientFamily,
                    fontSize = 11.sp,
                    fontWeight = FontWeight.Medium,
                    color = TextSecondary
                )
            }

            Spacer(modifier = Modifier.height(10.dp))

            // LOGISTICS / ASSIGNED RESOURCES ROW
            Surface(
                color = Color(0xFFF8FAFC),
                shape = RoundedCornerShape(10.dp),
                border = BorderStroke(1.dp, Color(0xFFF1F5F9)),
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(modifier = Modifier.padding(10.dp), verticalArrangement = Arrangement.spacedBy(4.dp)) {
                    // Location
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Icon(
                            imageVector = Icons.Default.LocationOn,
                            contentDescription = null,
                            tint = ForestGreenPrimary,
                            modifier = Modifier.size(13.dp)
                        )
                        Spacer(modifier = Modifier.width(4.dp))
                        Text(
                            text = task.location,
                            fontSize = 10.sp,
                            color = Navy900,
                            fontWeight = FontWeight.Medium
                        )
                    }

                    // Assigned Staff & Hearse
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Icon(
                                imageVector = Icons.Default.Person,
                                contentDescription = null,
                                tint = TextMuted,
                                modifier = Modifier.size(13.dp)
                            )
                            Spacer(modifier = Modifier.width(4.dp))
                            Text(
                                text = "${task.staffName} (${task.department.displayName})",
                                fontSize = 10.sp,
                                color = TextSecondary
                            )
                        }

                        if (!task.assignedVehicle.isNullOrBlank()) {
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Icon(
                                    imageVector = Icons.Default.DirectionsCar,
                                    contentDescription = null,
                                    tint = ForestGreenPrimary,
                                    modifier = Modifier.size(13.dp)
                                )
                                Spacer(modifier = Modifier.width(3.dp))
                                Text(
                                    text = task.assignedVehicle,
                                    fontSize = 10.sp,
                                    fontWeight = FontWeight.Bold,
                                    color = Navy900
                                )
                            }
                        }
                    }

                    // Date & Time
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Icon(
                                imageVector = Icons.Default.Schedule,
                                contentDescription = null,
                                tint = TextMuted,
                                modifier = Modifier.size(13.dp)
                            )
                            Spacer(modifier = Modifier.width(4.dp))
                            Text(
                                text = "${task.date} • ${task.time} (${task.durationMinutes} min)",
                                fontSize = 10.sp,
                                color = TextMuted
                            )
                        }

                        if (task.allowanceEarned > 0) {
                            Text(
                                text = "+ KES ${String.format("%,.0f", task.allowanceEarned)}",
                                fontSize = 10.sp,
                                fontWeight = FontWeight.Bold,
                                color = EmeraldSuccess
                            )
                        }
                    }
                }
            }

            // CHECKLIST & LIVE PROGRESS BAR
            if (totalChecklist > 0) {
                Spacer(modifier = Modifier.height(8.dp))

                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text(
                        text = "Field Checklist ($completedChecklist of $totalChecklist completed)",
                        fontSize = 10.sp,
                        fontWeight = FontWeight.Bold,
                        color = if (completedChecklist == totalChecklist) EmeraldSuccess else Navy900
                    )
                    Text(
                        text = "${(progressFraction * 100).toInt()}%",
                        fontSize = 10.sp,
                        fontWeight = FontWeight.ExtraBold,
                        color = if (completedChecklist == totalChecklist) EmeraldSuccess else ForestGreenPrimary
                    )
                }

                Spacer(modifier = Modifier.height(4.dp))
                LinearProgressIndicator(
                    progress = { progressFraction },
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(6.dp)
                        .clip(RoundedCornerShape(3.dp)),
                    color = if (completedChecklist == totalChecklist) EmeraldSuccess else ForestGreenPrimary,
                    trackColor = Color(0xFFE2E8F0)
                )

                // Expand/Collapse Interactive Checklist items
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .clickable { onToggleExpand() }
                        .padding(vertical = 4.dp),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text(
                        text = if (isExpanded) "Hide Checklist Items" else "View & Tap Checklist Items",
                        fontSize = 10.sp,
                        color = ForestGreenPrimary,
                        fontWeight = FontWeight.SemiBold
                    )
                    Icon(
                        imageVector = if (isExpanded) Icons.Default.ExpandLess else Icons.Default.ExpandMore,
                        contentDescription = null,
                        tint = ForestGreenPrimary,
                        modifier = Modifier.size(16.dp)
                    )
                }

                AnimatedVisibility(
                    visible = isExpanded,
                    enter = expandVertically() + fadeIn(),
                    exit = shrinkVertically() + fadeOut()
                ) {
                    Column(
                        modifier = Modifier
                            .fillMaxWidth()
                            .background(Color(0xFFF8FAFC), RoundedCornerShape(8.dp))
                            .padding(8.dp),
                        verticalArrangement = Arrangement.spacedBy(4.dp)
                    ) {
                        task.checklistItems.forEach { item ->
                            val isChecked = task.completedChecklistItems.contains(item)
                            Row(
                                verticalAlignment = Alignment.CenterVertically,
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .clickable { onToggleChecklist(item) }
                                    .padding(vertical = 2.dp)
                            ) {
                                Checkbox(
                                    checked = isChecked,
                                    onCheckedChange = { onToggleChecklist(item) },
                                    colors = CheckboxDefaults.colors(
                                        checkedColor = ForestGreenPrimary,
                                        uncheckedColor = Color(0xFF94A3B8)
                                    ),
                                    modifier = Modifier.size(20.dp)
                                )
                                Spacer(modifier = Modifier.width(6.dp))
                                Text(
                                    text = item,
                                    fontSize = 10.sp,
                                    color = if (isChecked) TextMuted else Navy900,
                                    fontWeight = if (isChecked) FontWeight.Normal else FontWeight.Medium
                                )
                            }
                        }
                    }
                }
            }

            // NOTES
            if (task.notes.isNotBlank()) {
                Spacer(modifier = Modifier.height(6.dp))
                Surface(
                    color = Color(0xFFEFF6FF),
                    shape = RoundedCornerShape(6.dp),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Row(modifier = Modifier.padding(6.dp)) {
                        Icon(
                            imageVector = Icons.Default.Info,
                            contentDescription = null,
                            tint = Color(0xFF2563EB),
                            modifier = Modifier.size(13.dp)
                        )
                        Spacer(modifier = Modifier.width(4.dp))
                        Text(
                            text = task.notes,
                            fontSize = 10.sp,
                            color = Color(0xFF1E3A8A)
                        )
                    }
                }
            }

            Spacer(modifier = Modifier.height(10.dp))

            // ACTION BUTTONS ROW
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.End,
                verticalAlignment = Alignment.CenterVertically
            ) {
                // If scheduled -> allow Start
                if (task.status == ActivityStatus.SCHEDULED) {
                    Button(
                        onClick = { onUpdateStatus(ActivityStatus.IN_PROGRESS) },
                        colors = ButtonDefaults.buttonColors(containerColor = ForestGreenPrimary),
                        shape = RoundedCornerShape(8.dp),
                        modifier = Modifier
                            .height(32.dp)
                            .testTag("btn_start_task_${task.id}")
                    ) {
                        Icon(Icons.Default.PlayArrow, contentDescription = null, modifier = Modifier.size(13.dp))
                        Spacer(modifier = Modifier.width(4.dp))
                        Text("Start Task", fontSize = 11.sp, fontWeight = FontWeight.Bold)
                    }
                    Spacer(modifier = Modifier.width(6.dp))
                }

                // If in progress -> allow En Route or Complete
                if (task.status == ActivityStatus.IN_PROGRESS) {
                    OutlinedButton(
                        onClick = { onUpdateStatus(ActivityStatus.IN_TRANSIT) },
                        colors = ButtonDefaults.outlinedButtonColors(contentColor = RoyalCobaltBlue),
                        border = BorderStroke(1.dp, RoyalCobaltBlue),
                        shape = RoundedCornerShape(8.dp),
                        modifier = Modifier
                            .height(32.dp)
                            .testTag("btn_transit_task_${task.id}")
                    ) {
                        Icon(Icons.Default.DirectionsCar, contentDescription = null, modifier = Modifier.size(13.dp))
                        Spacer(modifier = Modifier.width(4.dp))
                        Text("Mark En Route", fontSize = 10.sp)
                    }
                    Spacer(modifier = Modifier.width(6.dp))

                    Button(
                        onClick = { onUpdateStatus(ActivityStatus.COMPLETED) },
                        colors = ButtonDefaults.buttonColors(containerColor = EmeraldSuccess),
                        shape = RoundedCornerShape(8.dp),
                        modifier = Modifier
                            .height(32.dp)
                            .testTag("btn_complete_task_${task.id}")
                    ) {
                        Icon(Icons.Default.Check, contentDescription = null, modifier = Modifier.size(13.dp))
                        Spacer(modifier = Modifier.width(4.dp))
                        Text("Complete", fontSize = 11.sp, fontWeight = FontWeight.Bold)
                    }
                    Spacer(modifier = Modifier.width(6.dp))
                }

                if (task.status == ActivityStatus.IN_TRANSIT) {
                    Button(
                        onClick = { onUpdateStatus(ActivityStatus.COMPLETED) },
                        colors = ButtonDefaults.buttonColors(containerColor = EmeraldSuccess),
                        shape = RoundedCornerShape(8.dp),
                        modifier = Modifier
                            .height(32.dp)
                            .testTag("btn_arrived_task_${task.id}")
                    ) {
                        Icon(Icons.Default.Done, contentDescription = null, modifier = Modifier.size(13.dp))
                        Spacer(modifier = Modifier.width(4.dp))
                        Text("Arrived & Complete", fontSize = 10.sp, fontWeight = FontWeight.Bold)
                    }
                    Spacer(modifier = Modifier.width(6.dp))
                }

                // Quick Field Log launcher
                OutlinedButton(
                    onClick = onOpenLogger,
                    colors = ButtonDefaults.outlinedButtonColors(contentColor = Navy900),
                    border = BorderStroke(1.dp, BorderLight),
                    shape = RoundedCornerShape(8.dp),
                    modifier = Modifier
                        .height(32.dp)
                        .testTag("btn_log_update_${task.id}")
                ) {
                    Icon(Icons.Default.AddLocationAlt, contentDescription = null, modifier = Modifier.size(13.dp))
                    Spacer(modifier = Modifier.width(3.dp))
                    Text("Field Log", fontSize = 10.sp)
                }
            }
        }
    }
}

// =============================================================================
// SUB-COMPONENT: PENDING FUNERAL LOG CARD (AWAITING VERIFICATION / REVIEW)
// =============================================================================
@Composable
fun PendingFuneralLogCard(
    activity: StaffActivity,
    isAdminOrSupervisor: Boolean,
    onVerifyAndApprove: () -> Unit,
    onMarkCompleted: () -> Unit,
    onOpenLogger: () -> Unit,
    modifier: Modifier = Modifier
) {
    Card(
        shape = RoundedCornerShape(14.dp),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
        border = BorderStroke(1.5.dp, AmberWarning.copy(alpha = 0.7f)),
        elevation = CardDefaults.cardElevation(defaultElevation = 1.dp),
        modifier = modifier
            .fillMaxWidth()
            .testTag("pending_funeral_log_card_${activity.id}")
    ) {
        Column(modifier = Modifier.padding(14.dp)) {
            // TOP HEADER: Submitter + Awaiting Verification Badge
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Box(
                        modifier = Modifier
                            .size(28.dp)
                            .clip(CircleShape)
                            .background(AmberLight),
                        contentAlignment = Alignment.Center
                    ) {
                        Icon(
                            imageVector = Icons.Default.PendingActions,
                            contentDescription = null,
                            tint = AmberWarning,
                            modifier = Modifier.size(15.dp)
                        )
                    }
                    Spacer(modifier = Modifier.width(8.dp))
                    Column {
                        Text(
                            text = "Logged by ${activity.staffName}",
                            fontWeight = FontWeight.Bold,
                            fontSize = 11.sp,
                            color = Navy900
                        )
                        Text(
                            text = "${activity.date} • ${activity.time}",
                            fontSize = 9.sp,
                            color = TextMuted
                        )
                    }
                }

                Surface(
                    shape = RoundedCornerShape(8.dp),
                    color = AmberLight,
                    border = BorderStroke(1.dp, AmberWarning.copy(alpha = 0.5f))
                ) {
                    Row(
                        modifier = Modifier.padding(horizontal = 8.dp, vertical = 3.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Icon(
                            imageVector = Icons.Default.HourglassTop,
                            contentDescription = null,
                            tint = AmberWarning,
                            modifier = Modifier.size(11.dp)
                        )
                        Spacer(modifier = Modifier.width(4.dp))
                        Text(
                            text = "Awaiting Verification",
                            fontSize = 9.sp,
                            fontWeight = FontWeight.ExtraBold,
                            color = AmberWarning
                        )
                    }
                }
            }

            Spacer(modifier = Modifier.height(10.dp))

            // TITLE & STAGE
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.Top
            ) {
                Column(modifier = Modifier.weight(1f)) {
                    Text(
                        text = activity.title,
                        fontWeight = FontWeight.Bold,
                        fontSize = 13.sp,
                        color = Navy900
                    )
                    Text(
                        text = "${activity.caseReference} • ${activity.clientFamily}",
                        fontWeight = FontWeight.SemiBold,
                        fontSize = 11.sp,
                        color = ForestGreenPrimary
                    )
                }

                Surface(
                    shape = RoundedCornerShape(6.dp),
                    color = ForestGreenPrimary.copy(alpha = 0.1f)
                ) {
                    Text(
                        text = activity.arrangementStage.label,
                        fontSize = 9.sp,
                        fontWeight = FontWeight.Bold,
                        color = ForestGreenPrimary,
                        modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp)
                    )
                }
            }

            Spacer(modifier = Modifier.height(8.dp))

            // FIELD DETAILS BOX
            Surface(
                color = Color(0xFFFFFBEB),
                shape = RoundedCornerShape(8.dp),
                border = BorderStroke(1.dp, Color(0xFFFDE68A)),
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(modifier = Modifier.padding(8.dp), verticalArrangement = Arrangement.spacedBy(4.dp)) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Icon(
                            imageVector = Icons.Default.LocationOn,
                            contentDescription = null,
                            tint = AmberWarning,
                            modifier = Modifier.size(12.dp)
                        )
                        Spacer(modifier = Modifier.width(4.dp))
                        Text(
                            text = activity.location,
                            fontSize = 10.sp,
                            color = Color(0xFF78350F),
                            fontWeight = FontWeight.Medium
                        )
                    }

                    if (!activity.assignedVehicle.isNullOrBlank()) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Icon(
                                imageVector = Icons.Default.DirectionsCar,
                                contentDescription = null,
                                tint = AmberWarning,
                                modifier = Modifier.size(12.dp)
                            )
                            Spacer(modifier = Modifier.width(4.dp))
                            Text(
                                text = "Vehicle: ${activity.assignedVehicle}",
                                fontSize = 10.sp,
                                color = Color(0xFF78350F)
                            )
                        }
                    }

                    if (!activity.assignedEquipment.isNullOrBlank()) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Icon(
                                imageVector = Icons.Default.Build,
                                contentDescription = null,
                                tint = AmberWarning,
                                modifier = Modifier.size(12.dp)
                            )
                            Spacer(modifier = Modifier.width(4.dp))
                            Text(
                                text = "Equipment: ${activity.assignedEquipment}",
                                fontSize = 10.sp,
                                color = Color(0xFF78350F)
                            )
                        }
                    }

                    if (activity.notes.isNotBlank()) {
                        HorizontalDivider(color = Color(0xFFFDE68A), thickness = 0.5.dp)
                        Text(
                            text = "Field Notes: \"${activity.notes}\"",
                            fontSize = 10.sp,
                            fontStyle = androidx.compose.ui.text.font.FontStyle.Italic,
                            color = Color(0xFF92400E)
                        )
                    }
                }
            }

            Spacer(modifier = Modifier.height(10.dp))

            // ACTION BUTTONS: One-tap Verify & Approve + Complete
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(
                    text = "Allowance: KES ${String.format("%,.0f", activity.allowanceEarned)}",
                    fontSize = 11.sp,
                    fontWeight = FontWeight.ExtraBold,
                    color = EmeraldSuccess
                )

                Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                    // Fast Verify & Approve button for supervisor/admin
                    Button(
                        onClick = onVerifyAndApprove,
                        colors = ButtonDefaults.buttonColors(containerColor = EmeraldSuccess),
                        shape = RoundedCornerShape(8.dp),
                        modifier = Modifier
                            .height(32.dp)
                            .testTag("btn_verify_log_${activity.id}")
                    ) {
                        Icon(
                            imageVector = Icons.Default.Verified,
                            contentDescription = null,
                            modifier = Modifier.size(13.dp)
                        )
                        Spacer(modifier = Modifier.width(4.dp))
                        Text(
                            text = if (isAdminOrSupervisor) "Verify & Sign Off" else "Verify Milestone",
                            fontSize = 10.sp,
                            fontWeight = FontWeight.Bold
                        )
                    }

                    if (activity.status != ActivityStatus.COMPLETED) {
                        OutlinedButton(
                            onClick = onMarkCompleted,
                            colors = ButtonDefaults.outlinedButtonColors(contentColor = ForestGreenPrimary),
                            border = BorderStroke(1.dp, ForestGreenPrimary),
                            shape = RoundedCornerShape(8.dp),
                            modifier = Modifier
                                .height(32.dp)
                                .testTag("btn_mark_complete_${activity.id}")
                        ) {
                            Text("Mark Done", fontSize = 10.sp)
                        }
                    }
                }
            }
        }
    }
}

// =============================================================================
// SUB-COMPONENT: OPERATIONAL STAT CARD
// =============================================================================
@Composable
fun OperationalMetricCard(
    title: String,
    count: String,
    sub: String,
    icon: ImageVector,
    color: Color,
    bgColor: Color,
    modifier: Modifier = Modifier,
    testTag: String = ""
) {
    Surface(
        color = bgColor,
        shape = RoundedCornerShape(12.dp),
        border = BorderStroke(1.dp, color.copy(alpha = 0.2f)),
        modifier = modifier.testTag(testTag)
    ) {
        Column(modifier = Modifier.padding(10.dp)) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(
                    text = title,
                    fontSize = 9.sp,
                    color = color,
                    fontWeight = FontWeight.Bold
                )
                Icon(
                    imageVector = icon,
                    contentDescription = null,
                    tint = color,
                    modifier = Modifier.size(12.dp)
                )
            }
            Spacer(modifier = Modifier.height(2.dp))
            Text(
                text = count,
                fontSize = 16.sp,
                fontWeight = FontWeight.ExtraBold,
                color = color
            )
            Text(
                text = sub,
                fontSize = 8.sp,
                color = color.copy(alpha = 0.85f),
                maxLines = 1
            )
        }
    }
}

// =============================================================================
// SUB-COMPONENT: OPERATIONAL EMPTY STATE
// =============================================================================
@Composable
fun OperationalEmptyStateCard(
    title: String,
    subtitle: String,
    buttonText: String,
    onAction: () -> Unit,
    modifier: Modifier = Modifier
) {
    Card(
        shape = RoundedCornerShape(12.dp),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
        border = BorderStroke(1.dp, MaterialTheme.colorScheme.outline.copy(alpha = 0.3f)),
        modifier = modifier.fillMaxWidth()
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(20.dp),
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.Center
        ) {
            Box(
                modifier = Modifier
                    .size(44.dp)
                    .clip(CircleShape)
                    .background(EmeraldGreenIce),
                contentAlignment = Alignment.Center
            ) {
                Icon(
                    imageVector = Icons.Default.TaskAlt,
                    contentDescription = null,
                    tint = ForestGreenPrimary,
                    modifier = Modifier.size(24.dp)
                )
            }
            Spacer(modifier = Modifier.height(10.dp))
            Text(
                text = title,
                fontWeight = FontWeight.Bold,
                fontSize = 13.sp,
                color = Navy900
            )
            Spacer(modifier = Modifier.height(4.dp))
            Text(
                text = subtitle,
                fontSize = 10.sp,
                color = TextMuted,
                modifier = Modifier.padding(horizontal = 16.dp)
            )
            Spacer(modifier = Modifier.height(12.dp))
            Button(
                onClick = onAction,
                colors = ButtonDefaults.buttonColors(containerColor = ForestGreenPrimary),
                shape = RoundedCornerShape(8.dp),
                modifier = Modifier.height(34.dp)
            ) {
                Icon(Icons.Default.Add, contentDescription = null, modifier = Modifier.size(14.dp))
                Spacer(modifier = Modifier.width(4.dp))
                Text(buttonText, fontSize = 11.sp, fontWeight = FontWeight.Bold)
            }
        }
    }
}
