package com.example.domain

import com.example.model.StaffAccount
import com.example.model.StaffRole

sealed class StaffQrParseResult {
    data class Matched(
        val staff: StaffAccount,
        val rawCode: String,
        val encodedPayload: String
    ) : StaffQrParseResult()

    data class NotFound(
        val rawCode: String,
        val reason: String
    ) : StaffQrParseResult()
}

object StaffQrIdentityCodec {
    private const val PREFIX = "JFD-STF"

    /**
     * Generates a deterministic QR code payload for a Jabima staff member.
     * Example: JFD-STF|DRV-01|DRIVERS|Bama Branch|DRIVER
     */
    fun encodeStaffQrPayload(staff: StaffAccount): String {
        val cleanId = staff.id.trim()
        val cleanDept = staff.department.name
        val cleanBranch = staff.branch.trim().replace("|", "-")
        val cleanRole = staff.role.name
        return "$PREFIX|$cleanId|$cleanDept|$cleanBranch|$cleanRole"
    }

    /**
     * Parses either a full structured QR payload (JFD-STF|<id>|...) or a raw
     * badge ID / email / national ID / staff name entered manually or scanned.
     */
    fun parseScannedStaffCode(
        rawCode: String,
        allStaff: List<StaffAccount>
    ): StaffQrParseResult {
        val trimmed = rawCode.trim()
        if (trimmed.isBlank()) {
            return StaffQrParseResult.NotFound(
                rawCode = rawCode,
                reason = "Scanned QR code is empty."
            )
        }

        val extractedStaffId = if (trimmed.startsWith("$PREFIX|", ignoreCase = true)) {
            val parts = trimmed.split("|")
            parts.getOrNull(1)?.trim().orEmpty()
        } else {
            trimmed
        }

        val matched = allStaff.firstOrNull { it.id.equals(extractedStaffId, ignoreCase = true) }
            ?: allStaff.firstOrNull { it.email.equals(trimmed, ignoreCase = true) }
            ?: allStaff.firstOrNull { it.nationalId.equals(trimmed, ignoreCase = true) }
            ?: allStaff.firstOrNull { it.fullName.equals(trimmed, ignoreCase = true) }

        return if (matched != null) {
            StaffQrParseResult.Matched(
                staff = matched,
                rawCode = trimmed,
                encodedPayload = encodeStaffQrPayload(matched)
            )
        } else {
            StaffQrParseResult.NotFound(
                rawCode = trimmed,
                reason = "No active Jabima staff member matches badge/QR code '$trimmed'."
            )
        }
    }

    /**
     * Maps current 24-hour clock hour to Jabima's 24/7 operational shift windows.
     */
    fun resolve24HourShiftWindow(hourOfDay24: Int): String {
        val normalized = ((hourOfDay24 % 24) + 24) % 24
        return if (normalized in 6..17) {
            "Day Shift (06:00 - 18:00)"
        } else {
            "Night Vigil & 24/7 Shift (18:00 - 06:00)"
        }
    }

    /**
     * Determines whether a staff role is authorized as a manager/supervisor
     * to scan and verify staff QR attendance badges on 24/7 shifts.
     */
    fun canVerifyShiftAttendance(role: StaffRole?): Boolean {
        return role == StaffRole.MANAGING_DIRECTOR_CEO ||
            role == StaffRole.OPERATIONS_ADMIN ||
            role == StaffRole.INVENTORY_MANAGER ||
            role == StaffRole.FUNERAL_DIRECTOR ||
            role == StaffRole.ADMINISTRATIVE_STAFF ||
            role == StaffRole.CHAPEL_COORDINATOR
    }
}
