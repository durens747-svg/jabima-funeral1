package com.example.ui.components

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.tween
import androidx.compose.animation.expandVertically
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.shrinkVertically
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.AttachMoney
import androidx.compose.material.icons.filled.AutoAwesome
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.DirectionsCar
import androidx.compose.material.icons.filled.FileDownload
import androidx.compose.material.icons.filled.FileUpload
import androidx.compose.material.icons.filled.FlashOn
import androidx.compose.material.icons.filled.Search
import androidx.compose.material.icons.filled.TableChart
import androidx.compose.material3.FloatingActionButton
import androidx.compose.material3.FloatingActionButtonDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.SmallFloatingActionButton
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.rotate
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.ui.theme.CyanPrimary
import com.example.ui.theme.EmeraldSuccess
import com.example.ui.theme.Navy900
import com.example.ui.theme.PureWhite

data class SpeedDialActionItem(
    val id: String,
    val label: String,
    val icon: ImageVector,
    val containerColor: Color,
    val contentColor: Color = PureWhite,
    val onClick: () -> Unit
)

@Composable
fun SpeedDialActionFab(
    isExpanded: Boolean,
    onToggleExpand: () -> Unit,
    onOpenExcelImport: () -> Unit,
    onOpenExportManifest: () -> Unit,
    onOpenPriceEditor: () -> Unit,
    onOpenRealtimeLogger: () -> Unit,
    onOpenSpotlight: () -> Unit,
    onOpenGeminiAi: (() -> Unit)? = null,
    modifier: Modifier = Modifier
) {
    val rotation by animateFloatAsState(
        targetValue = if (isExpanded) 135f else 0f,
        animationSpec = tween(durationMillis = 250),
        label = "fab_rotation"
    )

    val actionItems = listOfNotNull(
        onOpenGeminiAi?.let { openAi ->
            SpeedDialActionItem(
                id = "action_gemini_ai",
                label = "Jabima Gemini AI Copilot",
                icon = Icons.Default.AutoAwesome,
                containerColor = Color(0xFF145A32),
                onClick = {
                    onToggleExpand()
                    openAi()
                }
            )
        },
        SpeedDialActionItem(
            id = "action_spotlight_search",
            label = "Spotlight Search (All Data)",
            icon = Icons.Default.Search,
            containerColor = Navy900,
            onClick = {
                onToggleExpand()
                onOpenSpotlight()
            }
        ),
        SpeedDialActionItem(
            id = "action_excel_import",
            label = "Import Excel Hub (6 Datasets)",
            icon = Icons.Default.FileUpload,
            containerColor = Color(0xFF107C41),
            onClick = {
                onToggleExpand()
                onOpenExcelImport()
            }
        ),
        SpeedDialActionItem(
            id = "action_excel_export",
            label = "Export Excel / Manifests",
            icon = Icons.Default.FileDownload,
            containerColor = Color(0xFF0369A1),
            onClick = {
                onToggleExpand()
                onOpenExportManifest()
            }
        ),
        SpeedDialActionItem(
            id = "action_price_editor",
            label = "Prices & Stock Adjustments",
            icon = Icons.Default.AttachMoney,
            containerColor = Color(0xFFD97706),
            onClick = {
                onToggleExpand()
                onOpenPriceEditor()
            }
        ),
        SpeedDialActionItem(
            id = "action_quick_task",
            label = "Quick Field Task Log",
            icon = Icons.Default.FlashOn,
            containerColor = EmeraldSuccess,
            onClick = {
                onToggleExpand()
                onOpenRealtimeLogger()
            }
        )
    )

    Box(
        modifier = modifier,
        contentAlignment = Alignment.BottomEnd
    ) {
        Column(
            horizontalAlignment = Alignment.End,
            verticalArrangement = Arrangement.spacedBy(10.dp)
        ) {
            AnimatedVisibility(
                visible = isExpanded,
                enter = fadeIn(tween(180)) + expandVertically(tween(220), expandFrom = Alignment.Bottom),
                exit = fadeOut(tween(140)) + shrinkVertically(tween(180), shrinkTowards = Alignment.Bottom)
            ) {
                Column(
                    horizontalAlignment = Alignment.End,
                    verticalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    actionItems.forEach { item ->
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.End,
                            modifier = Modifier
                                .clickable(
                                    interactionSource = remember { MutableInteractionSource() },
                                    indication = null,
                                    onClick = item.onClick
                                )
                                .padding(end = 4.dp)
                        ) {
                            Surface(
                                shape = RoundedCornerShape(8.dp),
                                color = Navy900.copy(alpha = 0.92f),
                                shadowElevation = 4.dp,
                                modifier = Modifier.testTag("speed_dial_label_${item.id}")
                            ) {
                                Text(
                                    text = item.label,
                                    fontSize = 12.sp,
                                    fontWeight = FontWeight.SemiBold,
                                    color = PureWhite,
                                    modifier = Modifier.padding(horizontal = 10.dp, vertical = 6.dp)
                                )
                            }
                            Spacer(modifier = Modifier.width(10.dp))
                            SmallFloatingActionButton(
                                onClick = item.onClick,
                                shape = CircleShape,
                                containerColor = item.containerColor,
                                contentColor = item.contentColor,
                                elevation = FloatingActionButtonDefaults.elevation(4.dp),
                                modifier = Modifier
                                    .size(42.dp)
                                    .testTag("speed_dial_btn_${item.id}")
                            ) {
                                Icon(
                                    imageVector = item.icon,
                                    contentDescription = item.label,
                                    modifier = Modifier.size(18.dp)
                                )
                            }
                        }
                    }
                }
            }

            // Main Primary FAB
            FloatingActionButton(
                onClick = onToggleExpand,
                shape = CircleShape,
                containerColor = if (isExpanded) Navy900 else Color(0xFF107C41),
                contentColor = PureWhite,
                elevation = FloatingActionButtonDefaults.elevation(6.dp),
                modifier = Modifier
                    .size(56.dp)
                    .testTag("main_speed_dial_fab")
            ) {
                Icon(
                    imageVector = Icons.Default.Add,
                    contentDescription = if (isExpanded) "Close actions" else "Open speed dial actions",
                    modifier = Modifier
                        .size(26.dp)
                        .rotate(rotation)
                )
            }
        }
    }
}
