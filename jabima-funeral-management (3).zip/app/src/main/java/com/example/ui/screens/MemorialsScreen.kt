package com.example.ui.screens

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.CalendarToday
import androidx.compose.material.icons.filled.Check
import androidx.compose.material.icons.filled.Church
import androidx.compose.material.icons.filled.Favorite
import androidx.compose.material.icons.filled.LocationOn
import androidx.compose.material.icons.filled.Videocam
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.FilterChip
import androidx.compose.material3.FilterChipDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateListOf
import androidx.compose.runtime.mutableStateMapOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.ui.theme.EmeraldLight
import com.example.ui.theme.EmeraldSuccess
import com.example.ui.theme.ForestGreenDark
import com.example.ui.theme.ForestGreenPrimary
import com.example.ui.theme.PlusJakartaSansFontFamily
import com.example.ui.theme.PureWhite
import com.example.ui.theme.StrokeRed
import com.example.ui.theme.StrokeRedBorder
import com.example.ui.theme.StrokeRedLight
import com.example.ui.theme.TextMuted

data class MemorialServiceItem(
    val id: String,
    val deceasedName: String,
    val ageSpan: String,
    val caseRef: String,
    val chapelVenue: String,
    val vigilTime: String,
    val burialLocation: String,
    val cortegeDeparture: String,
    val isLiveStreaming: Boolean = true
)

private data class MemorialCondolenceNote(
    val author: String,
    val message: String,
    val memorialCase: String
)

@Composable
fun MemorialsScreen(
    onNavigateToStaffPortal: () -> Unit
) {
    val cornerDp = 14.dp

    var selectedFilter by remember { mutableStateOf("ALL") }
    var tributeAuthor by remember { mutableStateOf("") }
    var tributeMessage by remember { mutableStateOf("") }

    val candlesPerMemorial = remember {
        mutableStateMapOf("MEM-01" to 24, "MEM-02" to 19, "MEM-03" to 11)
    }
    val litByVisitor = remember { mutableStateMapOf<String, Boolean>() }
    val rsvpAttending = remember { mutableStateMapOf<String, Boolean>() }

    val guestbookNotes = remember {
        mutableStateListOf(
            MemorialCondolenceNote("Rev. Dr. Karanja", "May the Lord grant eternal rest and peace to the Kiptoo family.", "JFD-2025-089"),
            MemorialCondolenceNote("Nairobi Choir Guild", "Forever remembered for her gentle spirit and grace.", "JFD-2025-091")
        )
    }

    val memorials = remember {
        listOf(
            MemorialServiceItem(
                id = "MEM-01",
                deceasedName = "Late Dr. Martin Kiptoo",
                ageSpan = "1954 – 2025 (71 Yrs)",
                caseRef = "JFD-2025-089",
                chapelVenue = "Jabima Lee Memorial Chapel (Hall A)",
                vigilTime = "Friday, 4:00 PM – 7:00 PM",
                burialLocation = "Kabarak Memorial Grounds, Nakuru",
                cortegeDeparture = "Saturday 7:00 AM from Lee Mortuary",
                isLiveStreaming = true
            ),
            MemorialServiceItem(
                id = "MEM-02",
                deceasedName = "Late Mama Grace Wambui Kamau",
                ageSpan = "1942 – 2025 (83 Yrs)",
                caseRef = "JFD-2025-091",
                chapelVenue = "All Saints Memorial Chapel, Nairobi",
                vigilTime = "Thursday, 2:00 PM – 5:00 PM",
                burialLocation = "Lang'ata Memorial Cemetery, Nairobi",
                cortegeDeparture = "Friday 9:30 AM from Jabima Depot",
                isLiveStreaming = true
            ),
            MemorialServiceItem(
                id = "MEM-03",
                deceasedName = "Late Elder Samuel Otieno",
                ageSpan = "1960 – 2025 (65 Yrs)",
                caseRef = "JFD-2025-093",
                chapelVenue = "St. Stephen's Memorial Hall, Kisumu",
                vigilTime = "Saturday, 11:00 AM – 2:00 PM",
                burialLocation = "Kendu Bay Family Grounds, Homa Bay",
                cortegeDeparture = "Saturday 6:00 AM Long-Distance Escort",
                isLiveStreaming = false
            )
        )
    }

    val filteredMemorials = remember(selectedFilter, memorials) {
        when (selectedFilter) {
            "LIVE" -> memorials.filter { it.isLiveStreaming }
            "EARLY" -> memorials.filter { it.cortegeDeparture.contains("6:00 AM") || it.cortegeDeparture.contains("7:00 AM") }
            else -> memorials
        }
    }

    LazyColumn(
        modifier = Modifier
            .fillMaxSize()
            .background(MaterialTheme.colorScheme.background)
            .padding(horizontal = 16.dp)
            .testTag("memorials_screen"),
        verticalArrangement = Arrangement.spacedBy(14.dp)
    ) {
        item {
            Spacer(modifier = Modifier.height(4.dp))

            // SANCTUARY TITLE BANNER (Forest Green + Pure White + Stroke of Red)
            Card(
                shape = RoundedCornerShape(cornerDp + 2.dp),
                colors = CardDefaults.cardColors(containerColor = ForestGreenDark),
                border = BorderStroke(1.5.dp, StrokeRed.copy(alpha = 0.7f)),
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .background(
                            Brush.linearGradient(listOf(ForestGreenDark, ForestGreenPrimary, ForestGreenDark))
                        )
                        .padding(16.dp)
                ) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Box(
                            modifier = Modifier
                                .size(38.dp)
                                .clip(CircleShape)
                                .background(StrokeRed)
                                .border(1.dp, PureWhite.copy(alpha = 0.8f), CircleShape),
                            contentAlignment = Alignment.Center
                        ) {
                            Icon(Icons.Default.Church, contentDescription = null, tint = PureWhite, modifier = Modifier.size(19.dp))
                        }
                        Spacer(modifier = Modifier.width(10.dp))
                        Column {
                            Text(
                                text = "MEMORIAL SERVICES & VIGILS",
                                fontSize = 10.sp,
                                fontWeight = FontWeight.ExtraBold,
                                color = StrokeRedLight,
                                letterSpacing = 0.7.sp
                            )
                            Text(
                                text = "Celebration of Life & Funeral Ceremonies",
                                fontFamily = PlusJakartaSansFontFamily,
                                fontSize = 18.sp,
                                fontWeight = FontWeight.Bold,
                                color = PureWhite
                            )
                        }
                    }
                    Spacer(modifier = Modifier.height(6.dp))
                    Text(
                        text = "Follow cortege departure schedules, light remembrance candles, RSVP for chapel vigils, or leave tributes.",
                        fontSize = 11.sp,
                        color = PureWhite.copy(alpha = 0.85f)
                    )
                }
            }
        }

        // INTERACTIVE MEMORIAL FILTER STRIP
        item {
            Row(
                modifier = Modifier.fillMaxWidth().horizontalScroll(rememberScrollState()),
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                listOf(
                    "ALL" to "All Memorials (${memorials.size})",
                    "LIVE" to "Livestream Active",
                    "EARLY" to "Early Cortege"
                ).forEach { (key, label) ->
                    FilterChip(
                        selected = selectedFilter == key,
                        onClick = { selectedFilter = key },
                        label = { Text(label, fontSize = 11.sp, maxLines = 1, softWrap = false) },
                        colors = FilterChipDefaults.filterChipColors(
                            selectedContainerColor = MaterialTheme.colorScheme.secondary,
                            selectedLabelColor = MaterialTheme.colorScheme.onSecondary
                        ),
                        modifier = Modifier.testTag("memorial_filter_${key.lowercase()}")
                    )
                }
            }
        }

        // INTERACTIVE MEMORIAL CARDS
        items(filteredMemorials, key = { it.id }) { item ->
            val candles = candlesPerMemorial[item.id] ?: 10
            val isLit = litByVisitor[item.id] == true
            val isAttending = rsvpAttending[item.id] == true

            Card(
                shape = RoundedCornerShape(cornerDp),
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                border = BorderStroke(1.dp, MaterialTheme.colorScheme.outline),
                modifier = Modifier.fillMaxWidth().testTag("memorial_card_${item.id}")
            ) {
                Column(modifier = Modifier.padding(16.dp)) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Column(modifier = Modifier.weight(1f)) {
                            Text(
                                text = item.deceasedName,
                                fontFamily = PlusJakartaSansFontFamily,
                                fontSize = 18.sp,
                                fontWeight = FontWeight.Bold,
                                color = MaterialTheme.colorScheme.onSurface
                            )
                            Text(
                                text = "${item.ageSpan} • Case #${item.caseRef}",
                                fontSize = 11.sp,
                                color = MaterialTheme.colorScheme.secondary,
                                fontWeight = FontWeight.SemiBold
                            )
                        }

                        if (item.isLiveStreaming) {
                            Surface(
                                color = EmeraldLight,
                                shape = RoundedCornerShape(6.dp)
                            ) {
                                Row(
                                    modifier = Modifier.padding(horizontal = 7.dp, vertical = 4.dp),
                                    verticalAlignment = Alignment.CenterVertically
                                ) {
                                    Icon(Icons.Default.Videocam, contentDescription = null, tint = EmeraldSuccess, modifier = Modifier.size(12.dp))
                                    Spacer(modifier = Modifier.width(4.dp))
                                    Text("LIVESTREAM", fontSize = 9.sp, fontWeight = FontWeight.Bold, color = EmeraldSuccess)
                                }
                            }
                        }
                    }

                    Spacer(modifier = Modifier.height(10.dp))

                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Icon(Icons.Default.Church, contentDescription = null, tint = MaterialTheme.colorScheme.primary, modifier = Modifier.size(15.dp))
                        Spacer(modifier = Modifier.width(6.dp))
                        Text(item.chapelVenue, fontSize = 12.sp, fontWeight = FontWeight.SemiBold)
                    }

                    Spacer(modifier = Modifier.height(4.dp))

                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Icon(Icons.Default.CalendarToday, contentDescription = null, tint = MaterialTheme.colorScheme.onSurfaceVariant, modifier = Modifier.size(15.dp))
                        Spacer(modifier = Modifier.width(6.dp))
                        Text(item.vigilTime, fontSize = 11.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
                    }

                    Spacer(modifier = Modifier.height(4.dp))

                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Icon(Icons.Default.LocationOn, contentDescription = null, tint = MaterialTheme.colorScheme.onSurfaceVariant, modifier = Modifier.size(15.dp))
                        Spacer(modifier = Modifier.width(6.dp))
                        Text("Burial: ${item.burialLocation}", fontSize = 11.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
                    }

                    Spacer(modifier = Modifier.height(8.dp))

                    Surface(
                        color = MaterialTheme.colorScheme.surfaceVariant,
                        shape = RoundedCornerShape(8.dp),
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Text(
                            text = "Cortege Departure: ${item.cortegeDeparture}",
                            fontSize = 11.sp,
                            fontWeight = FontWeight.Medium,
                            modifier = Modifier.padding(horizontal = 10.dp, vertical = 6.dp)
                        )
                    }

                    Spacer(modifier = Modifier.height(10.dp))

                    // Interactive Candle & RSVP Actions
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        OutlinedButton(
                            onClick = {
                                if (!isLit) {
                                    litByVisitor[item.id] = true
                                    candlesPerMemorial[item.id] = candles + 1
                                }
                            },
                            border = BorderStroke(1.dp, if (isLit) StrokeRed else MaterialTheme.colorScheme.outline),
                            shape = RoundedCornerShape(8.dp),
                            contentPadding = PaddingValues(horizontal = 10.dp, vertical = 6.dp),
                            modifier = Modifier.weight(1f).height(36.dp).testTag("memorial_candle_${item.id}")
                        ) {
                            Icon(
                                imageVector = Icons.Default.Favorite,
                                contentDescription = null,
                                tint = if (isLit) StrokeRed else TextMuted,
                                modifier = Modifier.size(14.dp)
                            )
                            Spacer(modifier = Modifier.width(5.dp))
                            Text(
                                text = if (isLit) "Lit ($candles)" else "Light Candle ($candles)",
                                fontSize = 11.sp,
                                fontWeight = FontWeight.Bold,
                                color = if (isLit) StrokeRed else MaterialTheme.colorScheme.onSurface,
                                maxLines = 1,
                                softWrap = false
                            )
                        }

                        Button(
                            onClick = { rsvpAttending[item.id] = !isAttending },
                            colors = ButtonDefaults.buttonColors(
                                containerColor = if (isAttending) ForestGreenPrimary else MaterialTheme.colorScheme.secondary,
                                contentColor = PureWhite
                            ),
                            shape = RoundedCornerShape(8.dp),
                            contentPadding = PaddingValues(horizontal = 10.dp, vertical = 6.dp),
                            modifier = Modifier.weight(1f).height(36.dp).testTag("memorial_rsvp_${item.id}")
                        ) {
                            if (isAttending) {
                                Icon(Icons.Default.Check, contentDescription = null, modifier = Modifier.size(14.dp))
                                Spacer(modifier = Modifier.width(4.dp))
                            }
                            Text(
                                text = if (isAttending) "Vigil RSVP Sent" else "RSVP Vigil",
                                fontSize = 11.sp,
                                fontWeight = FontWeight.Bold,
                                maxLines = 1,
                                softWrap = false
                            )
                        }
                    }
                }
            }
        }

        // INTERACTIVE DIGITAL CONDOLENCE GUESTBOOK (Zero Red — Muted Burgundy Icon + Live Feed)
        item {
            Card(
                shape = RoundedCornerShape(cornerDp),
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                border = BorderStroke(1.dp, MaterialTheme.colorScheme.secondary.copy(alpha = 0.55f)),
                modifier = Modifier.fillMaxWidth().testTag("memorial_guestbook_card")
            ) {
                Column(modifier = Modifier.padding(16.dp)) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Icon(
                            imageVector = Icons.Default.Favorite,
                            contentDescription = null,
                            tint = MaterialTheme.colorScheme.secondary,
                            modifier = Modifier.size(18.dp)
                        )
                        Spacer(modifier = Modifier.width(8.dp))
                        Text(
                            text = "Digital Condolence Guestbook",
                            fontFamily = PlusJakartaSansFontFamily,
                            fontWeight = FontWeight.Bold,
                            fontSize = 18.sp,
                            color = MaterialTheme.colorScheme.onSurface
                        )
                    }
                    Spacer(modifier = Modifier.height(8.dp))

                    OutlinedTextField(
                        value = tributeAuthor,
                        onValueChange = { tributeAuthor = it },
                        label = { Text("Your Name & Relation (e.g. Colleague, Friend)", fontSize = 11.sp) },
                        modifier = Modifier.fillMaxWidth(),
                        singleLine = true
                    )
                    Spacer(modifier = Modifier.height(8.dp))
                    OutlinedTextField(
                        value = tributeMessage,
                        onValueChange = { tributeMessage = it },
                        label = { Text("Message of comfort & condolence", fontSize = 11.sp) },
                        modifier = Modifier.fillMaxWidth(),
                        maxLines = 3
                    )
                    Spacer(modifier = Modifier.height(8.dp))
                    Button(
                        onClick = {
                            if (tributeMessage.isNotBlank()) {
                                guestbookNotes.add(
                                    0,
                                    MemorialCondolenceNote(
                                        author = tributeAuthor.ifBlank { "Family Sympathizer" },
                                        message = tributeMessage.trim(),
                                        memorialCase = filteredMemorials.firstOrNull()?.caseRef ?: "General"
                                    )
                                )
                                tributeAuthor = ""
                                tributeMessage = ""
                            }
                        },
                        enabled = tributeMessage.isNotBlank(),
                        shape = RoundedCornerShape(8.dp),
                        colors = ButtonDefaults.buttonColors(
                            containerColor = MaterialTheme.colorScheme.secondary,
                            contentColor = MaterialTheme.colorScheme.onSecondary
                        ),
                        modifier = Modifier.align(Alignment.End).testTag("btn_submit_memorial_tribute")
                    ) {
                        Text("Submit Condolence", fontSize = 11.sp, fontWeight = FontWeight.Bold)
                    }

                    if (guestbookNotes.isNotEmpty()) {
                        Spacer(modifier = Modifier.height(12.dp))
                        Text(
                            text = "Recent Tributes (${guestbookNotes.size})",
                            fontSize = 11.sp,
                            fontWeight = FontWeight.Bold,
                            color = MaterialTheme.colorScheme.primary
                        )
                        Spacer(modifier = Modifier.height(6.dp))
                        guestbookNotes.take(4).forEach { note ->
                            Surface(
                                color = MaterialTheme.colorScheme.surfaceVariant,
                                shape = RoundedCornerShape(8.dp),
                                border = BorderStroke(1.dp, MaterialTheme.colorScheme.outline.copy(alpha = 0.5f)),
                                modifier = Modifier.fillMaxWidth().padding(vertical = 3.dp)
                            ) {
                                Column(modifier = Modifier.padding(10.dp)) {
                                    Text(note.message, fontSize = 11.sp, color = MaterialTheme.colorScheme.onSurface)
                                    Text(
                                        text = "${note.author} • ${note.memorialCase}",
                                        fontSize = 9.sp,
                                        fontWeight = FontWeight.SemiBold,
                                        color = MaterialTheme.colorScheme.secondary
                                    )
                                }
                            }
                        }
                    }
                }
            }
        }

        // FOOTER CALLOUT TO STAFF TAB
        item {
            Card(
                shape = RoundedCornerShape(cornerDp),
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant),
                modifier = Modifier.fillMaxWidth()
            ) {
                Row(
                    modifier = Modifier.padding(14.dp),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    Column(modifier = Modifier.weight(1f)) {
                        Text("Assigned Staff & Directors", fontWeight = FontWeight.Bold, fontSize = 12.sp)
                        Text("Log case milestones and fleet movements in Staff Ops", fontSize = 11.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
                    }
                    Button(
                        onClick = onNavigateToStaffPortal,
                        shape = RoundedCornerShape(8.dp),
                        colors = ButtonDefaults.buttonColors(containerColor = MaterialTheme.colorScheme.primary)
                    ) {
                        Text("Staff Tab", fontSize = 11.sp, fontWeight = FontWeight.Bold)
                    }
                }
            }
        }

        item {
            Spacer(modifier = Modifier.height(80.dp))
        }
    }
}
