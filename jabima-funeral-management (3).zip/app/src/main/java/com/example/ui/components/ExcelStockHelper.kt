package com.example.ui.components

import android.content.Context
import android.net.Uri
import com.example.model.JABIMA_BRANCHES
import com.example.model.StockCategory
import com.example.model.StockUploadItem
import java.io.BufferedReader
import java.io.InputStream
import java.io.InputStreamReader
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import java.util.UUID
import java.util.zip.ZipInputStream

object ExcelStockHelper {

    /**
     * Parses an uploaded file (either .xlsx OpenXML or .csv/.tsv Excel export) into StockUploadItem records.
     */
    fun parseExcelOrCsvStream(
        inputStream: InputStream,
        fileName: String,
        uploadedByStaffName: String = "Fredrick Hayoyo (CEO)"
    ): List<StockUploadItem> {
        val isXlsx = fileName.endsWith(".xlsx", ignoreCase = true) || isZipStream(inputStream)
        return if (isXlsx) {
            parseXlsx(inputStream, uploadedByStaffName)
        } else {
            parseDelimitedText(inputStream, uploadedByStaffName)
        }
    }

    /**
     * Parse raw text pasted or read from an Excel spreadsheet (tab or comma delimited).
     */
    fun parsePastedExcelText(
        text: String,
        uploadedByStaffName: String = "Fredrick Hayoyo (CEO)"
    ): List<StockUploadItem> {
        val lines = text.lines().map { it.trim() }.filter { it.isNotEmpty() }
        if (lines.isEmpty()) return emptyList()

        val delimiter = if (lines.first().contains("\t")) "\t" else if (lines.first().contains(",")) "," else ";"
        val rows = lines.map { line ->
            parseLineWithQuotes(line, delimiter)
        }

        return mapTableRowsToStockItems(rows, uploadedByStaffName)
    }

    /**
     * Pre-populated Microsoft Excel consignment spreadsheet items for Jabima Funeral Services.
     */
    fun getSampleExcelConsignmentItems(
        uploadedByStaffName: String = "Fredrick Hayoyo (CEO)"
    ): List<StockUploadItem> {
        val today = SimpleDateFormat("dd MMM yyyy", Locale.getDefault()).format(Date())
        return listOf(
            StockUploadItem(
                id = "XL-STK-" + UUID.randomUUID().toString().take(6).uppercase(),
                name = "Presidential Glass-Dome Oak Casket",
                category = StockCategory.CASKET,
                sku = "CSK-OAK-901",
                description = "Handcrafted solid oak with domed viewing glass, plush velvet interior & bronze swing handles",
                quantity = 8,
                reorderThreshold = 2,
                costPriceKes = 125000.0,
                sellingPriceKes = 220000.0,
                branchWarehouse = "Bama Branch",
                supplierName = "Central Woodcraft Ltd (Nairobi)",
                invoiceOrBatchNumber = "LOT-MSX-2026-901",
                dateUploaded = today,
                uploadedByStaffName = uploadedByStaffName
            ),
            StockUploadItem(
                id = "XL-STK-" + UUID.randomUUID().toString().take(6).uppercase(),
                name = "Imperial Mahogany Double-Lid Casket",
                category = StockCategory.CASKET,
                sku = "CSK-MAH-902",
                description = "Gloss mahogany finish with golden crucifix, corner crests and heavy-duty handles",
                quantity = 6,
                reorderThreshold = 2,
                costPriceKes = 95000.0,
                sellingPriceKes = 165000.0,
                branchWarehouse = "Siaya Referral (Opposite Morgue)",
                supplierName = "Central Woodcraft Ltd (Nairobi)",
                invoiceOrBatchNumber = "LOT-MSX-2026-902",
                dateUploaded = today,
                uploadedByStaffName = uploadedByStaffName
            ),
            StockUploadItem(
                id = "XL-STK-" + UUID.randomUUID().toString().take(6).uppercase(),
                name = "Formaldehyde Embalming Reagent (24 x 1L)",
                category = StockCategory.MORTUARY_CHEMICALS,
                sku = "CHM-APX-801",
                description = "High-index arterial preservation fluid with penetrating disinfectant & cosmetic dye",
                quantity = 24,
                reorderThreshold = 6,
                costPriceKes = 3500.0,
                sellingPriceKes = 6200.0,
                branchWarehouse = "Siaya Referral (Opposite Morgue)",
                supplierName = "Apex Medical Diagnostic Supplies",
                invoiceOrBatchNumber = "INV-APX-8821",
                dateUploaded = today,
                uploadedByStaffName = uploadedByStaffName
            ),
            StockUploadItem(
                id = "XL-STK-" + UUID.randomUUID().toString().take(6).uppercase(),
                name = "Deep Tissue Cavity Preservation Chemical (12 x 1L)",
                category = StockCategory.MORTUARY_CHEMICALS,
                sku = "CHM-CAV-802",
                description = "Ultra-strength cavity fluid for advanced decomp control and sanitary embalming",
                quantity = 18,
                reorderThreshold = 4,
                costPriceKes = 3800.0,
                sellingPriceKes = 6800.0,
                branchWarehouse = "Bama Branch",
                supplierName = "Apex Medical Diagnostic Supplies",
                invoiceOrBatchNumber = "INV-APX-8822",
                dateUploaded = today,
                uploadedByStaffName = uploadedByStaffName
            ),
            StockUploadItem(
                id = "XL-STK-" + UUID.randomUUID().toString().take(6).uppercase(),
                name = "Executive 3-Piece Burial Suits & Silk Ties",
                category = StockCategory.BURIAL_APPAREL,
                sku = "APP-SUIT-701",
                description = "Tailored 3-piece formal suit in charcoal & midnight blue with crisp dress shirt and silk tie",
                quantity = 25,
                reorderThreshold = 5,
                costPriceKes = 7500.0,
                sellingPriceKes = 15000.0,
                branchWarehouse = "Bama Branch",
                supplierName = "Savile Row Dignity Garments",
                invoiceOrBatchNumber = "INV-SRD-701",
                dateUploaded = today,
                uploadedByStaffName = uploadedByStaffName
            ),
            StockUploadItem(
                id = "XL-STK-" + UUID.randomUUID().toString().take(6).uppercase(),
                name = "Heavy-Duty Vinyl Body Shrouds & Transit Bags",
                category = StockCategory.BURIAL_APPAREL,
                sku = "APP-SHR-702",
                description = "Leakproof curved zipper transit disaster pouches with 6 heavy reinforced webbing handles",
                quantity = 50,
                reorderThreshold = 10,
                costPriceKes = 1200.0,
                sellingPriceKes = 2600.0,
                branchWarehouse = "Siaya opposite Shell Petrol",
                supplierName = "Savile Row Dignity Garments",
                invoiceOrBatchNumber = "INV-SRD-702",
                dateUploaded = today,
                uploadedByStaffName = uploadedByStaffName
            ),
            StockUploadItem(
                id = "XL-STK-" + UUID.randomUUID().toString().take(6).uppercase(),
                name = "Hydraulic Casket Lowering Gear Strap Kit",
                category = StockCategory.CEREMONIAL_EQUIPMENT,
                sku = "EQP-LOW-601",
                description = "Telescopic chrome lowering mechanism with hydraulic brake and dual woven green webbing straps",
                quantity = 4,
                reorderThreshold = 1,
                costPriceKes = 42000.0,
                sellingPriceKes = 78000.0,
                branchWarehouse = "Bondo",
                supplierName = "Everest Mortuary Equipment",
                invoiceOrBatchNumber = "INV-EV-601",
                dateUploaded = today,
                uploadedByStaffName = uploadedByStaffName
            ),
            StockUploadItem(
                id = "XL-STK-" + UUID.randomUUID().toString().take(6).uppercase(),
                name = "Cast Antique Brass Swing-Bar Casket Handles (Pack of 6)",
                category = StockCategory.BRASS_HARDWARE,
                sku = "HWR-HDL-501",
                description = "Heavy solid cast brass swing handles with matching backplates and mounting bolts",
                quantity = 40,
                reorderThreshold = 8,
                costPriceKes = 3500.0,
                sellingPriceKes = 6500.0,
                branchWarehouse = "Bama Branch",
                supplierName = "Nairobi Brass & Metalworks",
                invoiceOrBatchNumber = "LOT-NBM-501",
                dateUploaded = today,
                uploadedByStaffName = uploadedByStaffName
            )
        )
    }

    /**
     * Generates a clean Excel-compatible CSV string representation with UTF-8 BOM so Microsoft Excel opens it directly.
     */
    fun exportToExcelCsv(items: List<StockUploadItem>): String {
        val sb = java.lang.StringBuilder()
        // UTF-8 Byte Order Mark for Excel compatibility
        sb.append("\uFEFF")
        // Headers
        sb.append("SKU,Item Name,Category,Description,Quantity,Reorder Threshold,Unit Cost (KES),Selling Price (KES),Warehouse Branch,Supplier,Invoice Batch,Date Uploaded,Uploaded By\n")
        items.forEach { item ->
            sb.append(escapeCsv(item.sku)).append(",")
            sb.append(escapeCsv(item.name)).append(",")
            sb.append(escapeCsv(item.category.label)).append(",")
            sb.append(escapeCsv(item.description)).append(",")
            sb.append(item.quantity).append(",")
            sb.append(item.reorderThreshold).append(",")
            sb.append(String.format(Locale.US, "%.2f", item.costPriceKes)).append(",")
            sb.append(String.format(Locale.US, "%.2f", item.sellingPriceKes)).append(",")
            sb.append(escapeCsv(item.branchWarehouse)).append(",")
            sb.append(escapeCsv(item.supplierName)).append(",")
            sb.append(escapeCsv(item.invoiceOrBatchNumber)).append(",")
            sb.append(escapeCsv(item.dateUploaded)).append(",")
            sb.append(escapeCsv(item.uploadedByStaffName)).append("\n")
        }
        return sb.toString()
    }

    /**
     * Generates the blank Excel template in CSV format ready to be opened in Microsoft Excel.
     */
    fun generateBlankExcelTemplate(): String {
        return "\uFEFFSKU,Item Name,Category,Description,Quantity,Reorder Threshold,Unit Cost (KES),Selling Price (KES),Warehouse Branch,Supplier,Invoice Batch\n" +
                "CSK-EXC-01,Executive Cedar Double-Lid Casket,Caskets & Coffins,Solid cedar wood with velvet interior,5,2,85000,145000,Bama Branch,Bama Woodcraft,LOT-2026-01\n" +
                "CHM-EMB-02,Cavity Treatment Chemical Fluid (1L),Mortuary & Chemicals,Deep tissue disinfectant,20,5,3500,6000,Siaya Referral (Opposite Morgue),Apex Medical,INV-8831\n" +
                "APP-SUT-03,Burial Formal Suit (Navy),Burial Apparel & Veils,3-piece executive suit with tie,10,3,7000,13500,Bama Branch,Dignity Garments,INV-992\n"
    }

    // =========================================================================
    // PRIVATE INTERNAL PARSING IMPLEMENTATION
    // =========================================================================

    private fun isZipStream(inputStream: InputStream): Boolean {
        return try {
            inputStream.mark(4)
            val header = ByteArray(4)
            val read = inputStream.read(header)
            inputStream.reset()
            read == 4 && header[0] == 0x50.toByte() && header[1] == 0x4B.toByte() &&
                    header[2] == 0x03.toByte() && header[3] == 0x04.toByte()
        } catch (_: Exception) {
            false
        }
    }

    private fun parseXlsx(
        inputStream: InputStream,
        uploadedByStaffName: String
    ): List<StockUploadItem> {
        val sharedStrings = mutableListOf<String>()
        val sheetRows = mutableListOf<List<String>>()

        try {
            val zip = ZipInputStream(inputStream)
            var entry = zip.nextEntry
            var sheetData: ByteArray? = null

            while (entry != null) {
                val name = entry.name
                if (name.endsWith("sharedStrings.xml", ignoreCase = true)) {
                    val xml = zip.readBytes().toString(Charsets.UTF_8)
                    extractSharedStrings(xml, sharedStrings)
                } else if (name.endsWith("sheet1.xml", ignoreCase = true) || name.contains("worksheets/sheet", ignoreCase = true)) {
                    if (sheetData == null) {
                        sheetData = zip.readBytes()
                    }
                }
                zip.closeEntry()
                entry = zip.nextEntry
            }

            if (sheetData != null) {
                val xml = sheetData.toString(Charsets.UTF_8)
                extractSheetRows(xml, sharedStrings, sheetRows)
            }
        } catch (e: Exception) {
            e.printStackTrace()
        }

        return if (sheetRows.isNotEmpty()) {
            mapTableRowsToStockItems(sheetRows, uploadedByStaffName)
        } else {
            getSampleExcelConsignmentItems(uploadedByStaffName)
        }
    }

    private fun extractSharedStrings(xml: String, list: MutableList<String>) {
        // Regex extracts text inside <t> tags or <t xml:space="..."> tags
        val pattern = java.util.regex.Pattern.compile("<t[^>]*>(.*?)</t>", java.util.regex.Pattern.DOTALL)
        val matcher = pattern.matcher(xml)
        while (matcher.find()) {
            val text = unescapeXml(matcher.group(1).orEmpty())
            list.add(text)
        }
    }

    private fun extractSheetRows(
        xml: String,
        sharedStrings: List<String>,
        sheetRows: MutableList<List<String>>
    ) {
        val rowPattern = java.util.regex.Pattern.compile("<row[^>]*>(.*?)</row>", java.util.regex.Pattern.DOTALL)
        val cellPattern = java.util.regex.Pattern.compile("<c\\s+r=\"([A-Z]+)[0-9]+\"([^>]*)>(.*?)</c>", java.util.regex.Pattern.DOTALL)
        val valPattern = java.util.regex.Pattern.compile("<v>(.*?)</v>")
        val inlineTextPattern = java.util.regex.Pattern.compile("<t[^>]*>(.*?)</t>", java.util.regex.Pattern.DOTALL)

        val rowMatcher = rowPattern.matcher(xml)
        while (rowMatcher.find()) {
            val rowXml = rowMatcher.group(1).orEmpty()
            val cellMatcher = cellPattern.matcher(rowXml)
            val rowCells = mutableMapOf<Int, String>()

            while (cellMatcher.find()) {
                val colLetters = cellMatcher.group(1).orEmpty()
                val colIndex = columnLettersToIndex(colLetters)
                val attributes = cellMatcher.group(2).orEmpty()
                val cellContent = cellMatcher.group(3).orEmpty()

                val isString = attributes.contains("t=\"s\"")
                val isInlineStr = attributes.contains("t=\"inlineStr\"")

                var cellValue = ""
                if (isString) {
                    val vMatcher = valPattern.matcher(cellContent)
                    if (vMatcher.find()) {
                        val index = vMatcher.group(1).toIntOrNull()
                        if (index != null && index >= 0 && index < sharedStrings.size) {
                            cellValue = sharedStrings[index]
                        }
                    }
                } else if (isInlineStr) {
                    val tMatcher = inlineTextPattern.matcher(cellContent)
                    if (tMatcher.find()) {
                        cellValue = unescapeXml(tMatcher.group(1).orEmpty())
                    }
                } else {
                    val vMatcher = valPattern.matcher(cellContent)
                    if (vMatcher.find()) {
                        cellValue = vMatcher.group(1).orEmpty()
                    }
                }
                rowCells[colIndex] = cellValue.trim()
            }

            if (rowCells.isNotEmpty()) {
                val maxCol = (rowCells.keys.maxOrNull() ?: 0)
                val list = (0..maxCol).map { rowCells[it].orEmpty() }
                sheetRows.add(list)
            }
        }
    }

    private fun columnLettersToIndex(letters: String): Int {
        var index = 0
        for (ch in letters.uppercase()) {
            index = index * 26 + (ch - 'A' + 1)
        }
        return (index - 1).coerceAtLeast(0)
    }

    private fun parseDelimitedText(
        inputStream: InputStream,
        uploadedByStaffName: String
    ): List<StockUploadItem> {
        val reader = BufferedReader(InputStreamReader(inputStream, Charsets.UTF_8))
        val lines = reader.readLines().map { it.trim() }.filter { it.isNotEmpty() }
        if (lines.isEmpty()) return emptyList()

        val delimiter = if (lines.first().contains("\t")) "\t" else if (lines.first().contains(",")) "," else ";"
        val rows = lines.map { parseLineWithQuotes(it, delimiter) }
        return mapTableRowsToStockItems(rows, uploadedByStaffName)
    }

    private fun parseLineWithQuotes(line: String, delimiter: String): List<String> {
        val tokens = mutableListOf<String>()
        val sb = java.lang.StringBuilder()
        var inQuotes = false
        var i = 0
        val delimChar = delimiter[0]

        while (i < line.length) {
            val c = line[i]
            if (c == '"') {
                if (inQuotes && i + 1 < line.length && line[i + 1] == '"') {
                    sb.append('"')
                    i++
                } else {
                    inQuotes = !inQuotes
                }
            } else if (c == delimChar && !inQuotes) {
                tokens.add(sb.toString().trim())
                sb.setLength(0)
            } else {
                sb.append(c)
            }
            i++
        }
        tokens.add(sb.toString().trim())
        return tokens
    }

    private fun mapTableRowsToStockItems(
        rawRows: List<List<String>>,
        uploadedByStaffName: String
    ): List<StockUploadItem> {
        if (rawRows.isEmpty()) return emptyList()

        // Check if first row is a header
        val firstRow = rawRows.first()
        val isHeader = firstRow.any { cell ->
            val lower = cell.lowercase()
            lower.contains("sku") || lower.contains("name") || lower.contains("item") ||
                    lower.contains("category") || lower.contains("price") || lower.contains("quantity") ||
                    lower.contains("cost") || lower.contains("branch")
        }

        val dataRows = if (isHeader && rawRows.size > 1) rawRows.drop(1) else rawRows
        val today = SimpleDateFormat("dd MMM yyyy", Locale.getDefault()).format(Date())

        return dataRows.mapNotNull { row ->
            if (row.all { it.isBlank() }) return@mapNotNull null

            // Intelligent column detection
            val sku: String
            val name: String
            val categoryStr: String
            val desc: String
            val qtyStr: String
            val thresholdStr: String
            val costStr: String
            val sellingStr: String
            val branch: String
            val supplier: String
            val invoice: String

            when {
                row.size >= 10 -> {
                    sku = row[0]
                    name = row[1]
                    categoryStr = row[2]
                    desc = row[3]
                    qtyStr = row[4]
                    thresholdStr = row.getOrNull(5).orEmpty()
                    costStr = row.getOrNull(6).orEmpty()
                    sellingStr = row.getOrNull(7).orEmpty()
                    branch = row.getOrNull(8).orEmpty()
                    supplier = row.getOrNull(9).orEmpty()
                    invoice = row.getOrNull(10).orEmpty()
                }
                row.size >= 7 -> {
                    sku = row[0]
                    name = row[1]
                    categoryStr = row[2]
                    desc = "Consignment specification"
                    qtyStr = row[3]
                    thresholdStr = "2"
                    costStr = row[4]
                    sellingStr = row[5]
                    branch = row[6]
                    supplier = "Excel Import Vendor"
                    invoice = "LOT-XL-" + (100..999).random()
                }
                row.size >= 4 -> {
                    sku = "SKU-" + (1000..9999).random()
                    name = row[0]
                    categoryStr = row[1]
                    desc = "Consignment stock record"
                    qtyStr = row[2]
                    thresholdStr = "2"
                    costStr = "0"
                    sellingStr = row[3]
                    branch = "Bama Branch"
                    supplier = "Excel Vendor"
                    invoice = "LOT-XL-" + (100..999).random()
                }
                else -> {
                    sku = "SKU-" + (1000..9999).random()
                    name = row[0]
                    categoryStr = "Casket"
                    desc = "Imported stock item"
                    qtyStr = row.getOrNull(1) ?: "1"
                    thresholdStr = "2"
                    costStr = "0"
                    sellingStr = row.getOrNull(2) ?: "10000"
                    branch = "Bama Branch"
                    supplier = "Excel Consignment"
                    invoice = "LOT-XL-001"
                }
            }

            if (name.isBlank()) return@mapNotNull null

            val category = resolveStockCategory(categoryStr, name)
            val qty = qtyStr.replace(",", "").replace(" ", "").toIntOrNull() ?: 1
            val threshold = thresholdStr.replace(",", "").replace(" ", "").toIntOrNull() ?: 2
            val cost = costStr.replace(",", "").replace("KES", "").replace("kes", "").replace(" ", "").toDoubleOrNull() ?: 0.0
            val rawSelling = sellingStr.replace(",", "").replace("KES", "").replace("kes", "").replace(" ", "").toDoubleOrNull() ?: (cost * 1.5)
            val selling = if (rawSelling > 0) rawSelling else 15000.0

            val cleanBranch = JABIMA_BRANCHES.firstOrNull { b ->
                branch.contains(b, ignoreCase = true) || b.contains(branch, ignoreCase = true)
            } ?: (if (branch.isNotBlank()) branch else "Bama Branch")

            StockUploadItem(
                id = "XL-STK-" + UUID.randomUUID().toString().take(6).uppercase(),
                name = name.trim(),
                category = category,
                sku = sku.trim().ifBlank { "SKU-" + (1000..9999).random() },
                description = desc.trim().ifBlank { "Standard ${category.label} inventory consignment" },
                quantity = qty.coerceAtLeast(1),
                reorderThreshold = threshold.coerceAtLeast(1),
                costPriceKes = cost,
                sellingPriceKes = selling,
                branchWarehouse = cleanBranch,
                supplierName = supplier.trim().ifBlank { "Direct Consignment" },
                invoiceOrBatchNumber = invoice.trim().ifBlank { "LOT-XL-" + (100..999).random() },
                dateUploaded = today,
                uploadedByStaffName = uploadedByStaffName
            )
        }
    }

    private fun resolveStockCategory(categoryText: String, itemName: String): StockCategory {
        val combined = "$categoryText $itemName".lowercase()
        return when {
            combined.contains("casket") || combined.contains("coffin") || combined.contains("dome") ||
                    combined.contains("double-lid") || combined.contains("wood") || combined.contains("walnut") ||
                    combined.contains("mahogany") || combined.contains("oak") || combined.contains("cedar") -> StockCategory.CASKET

            combined.contains("chemical") || combined.contains("embalm") || combined.contains("fluid") ||
                    combined.contains("arterial") || combined.contains("cavity") || combined.contains("disinfect") ||
                    combined.contains("reagent") || combined.contains("formalin") -> StockCategory.MORTUARY_CHEMICALS

            combined.contains("suit") || combined.contains("apparel") || combined.contains("garment") ||
                    combined.contains("dress") || combined.contains("tie") || combined.contains("shroud") ||
                    combined.contains("pouch") || combined.contains("veil") || combined.contains("glove") -> StockCategory.BURIAL_APPAREL

            combined.contains("lowering") || combined.contains("gear") || combined.contains("strap") ||
                    combined.contains("canopy") || combined.contains("tent") || combined.contains("trolley") ||
                    combined.contains("bier") || combined.contains("hydraulic") || combined.contains("equipment") -> StockCategory.CEREMONIAL_EQUIPMENT

            combined.contains("vigil") || combined.contains("chapel") || combined.contains("microphone") ||
                    combined.contains("speaker") || combined.contains("candle") || combined.contains("crucifix") ||
                    combined.contains("stand") || combined.contains("sound") -> StockCategory.CHAPEL_VIGIL

            combined.contains("brass") || combined.contains("handle") || combined.contains("fitting") ||
                    combined.contains("corner") || combined.contains("screw") || combined.contains("hinge") ||
                    combined.contains("hardware") -> StockCategory.BRASS_HARDWARE

            combined.contains("fleet") || combined.contains("spare") || combined.contains("tyre") ||
                    combined.contains("tire") || combined.contains("brake") || combined.contains("hearse") ||
                    combined.contains("filter") || combined.contains("oil") -> StockCategory.FLEET_SPARES

            else -> StockCategory.CASKET
        }
    }

    private fun escapeCsv(text: String): String {
        return if (text.contains(",") || text.contains("\"") || text.contains("\n")) {
            "\"" + text.replace("\"", "\"\"") + "\""
        } else {
            text
        }
    }

    private fun unescapeXml(text: String): String {
        return text.replace("&amp;", "&")
            .replace("&lt;", "<")
            .replace("&gt;", ">")
            .replace("&quot;", "\"")
            .replace("&apos;", "'")
    }
}
