package com.example.ui.screens

import androidx.compose.animation.core.Spring
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.spring
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.AddShoppingCart
import androidx.compose.material.icons.filled.Analytics
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.Clear
import androidx.compose.material.icons.filled.ReceiptLong
import androidx.compose.material.icons.filled.Search
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.FilterChip
import androidx.compose.material3.FilterChipDefaults
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.CornerRadius
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.domain.OperationsAnalyticsEngine
import com.example.domain.OrderStatusFilter
import com.example.model.CustomerOrderRecord
import com.example.model.JABIMA_BRANCHES
import com.example.model.MainAppTab
import com.example.ui.StaffPortalViewModel
import com.example.ui.theme.AmberLight
import com.example.ui.theme.AmberWarning
import com.example.ui.theme.BorderLight
import com.example.ui.theme.EmeraldLight
import com.example.ui.theme.EmeraldSuccess
import com.example.ui.theme.ForestGreenDark
import com.example.ui.theme.ForestGreenLight
import com.example.ui.theme.ForestGreenPrimary
import com.example.ui.theme.Navy900
import com.example.ui.theme.PureWhite
import com.example.ui.theme.RoyalCobaltBlue
import com.example.ui.theme.RoyalCobaltIce
import com.example.ui.theme.StrokeRed
import com.example.ui.theme.TextMuted
import com.example.ui.theme.TextSecondary
import java.util.Locale

@Composable
fun OrderDashboardScreen(
    viewModel: StaffPortalViewModel,
    onCreateNewOrderClick: () -> Unit = { viewModel.setMainAppTab(MainAppTab.ORDERS_PAYMENTS) },
    onOpenCostAnalyticsClick: () -> Unit = { viewModel.setMainAppTab(MainAppTab.COST_ANALYTICS) }
) {
    val orders by viewModel.customerOrders.collectAsState()
    var currencyMode by remember { mutableStateOf("KES") }
    var selectedBranch by remember { mutableStateOf("All Branches") }
    var selectedStatus by remember { mutableStateOf(OrderStatusFilter.ALL) }
    var searchQuery by remember { mutableStateOf("") }

    val summary = remember(orders, selectedBranch, selectedStatus, searchQuery) {
        OperationsAnalyticsEngine.buildOrderDashboardSummary(
            orders = orders,
            branchFilter = selectedBranch,
            statusFilter = selectedStatus,
            searchQuery = searchQuery
        )
    }

    val fmt: (Double) -> String = { amountKes ->
        if (currencyMode == "KES") {
            "KES ${String.format(Locale.US, "%,.0f", amountKes)}"
        } else {
            "$ ${String.format(Locale.US, "%,.0f", amountKes / 130.0)}"
        }
    }

    LazyColumn(
        modifier = Modifier
            .fillMaxSize()
            .background(MaterialTheme.colorScheme.background)
            .testTag("order_dashboard_screen"),
        contentPadding = PaddingValues(14.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        // 1. Hero Header + Actions
        item(key = "order_dash_hero") {
            Card(
                shape = RoundedCornerShape(16.dp),
                border = BorderStroke(1.5.dp, StrokeRed.copy(alpha = 0.5f)),
                colors = CardDefaults.cardColors(containerColor = PureWhite),
                modifier = Modifier.fillMaxWidth()
            ) {
                Column {
                    Box(
                        modifier = Modifier
                            .fillMaxWidth()
                            .background(Brush.linearGradient(listOf(ForestGreenDark, ForestGreenPrimary, ForestGreenLight)))
                            .padding(16.dp)
                    ) {
                        Column {
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Column(modifier = Modifier.weight(1f)) {
                                    Text(
                                        text = "EXECUTIVE ORDER DASHBOARD",
                                        fontSize = 10.sp,
                                        fontWeight = FontWeight.ExtraBold,
                                        color = Color(0xFFA7F3D0),
                                        letterSpacing = 0.8.sp
                                    )
                                    Text(
                                        text = "Client Bookings, Collections & Channel Mix",
                                        fontSize = 16.sp,
                                        fontWeight = FontWeight.Bold,
                                        color = Color.White,
                                        maxLines = 1,
                                        overflow = TextOverflow.Ellipsis
                                    )
                                }

                                Surface(
                                    shape = RoundedCornerShape(16.dp),
                                    color = Color.White.copy(alpha = 0.16f)
                                ) {
                                    Row(modifier = Modifier.padding(3.dp)) {
                                        listOf("KES", "USD").forEach { curr ->
                                            val active = currencyMode == curr
                                            Surface(
                                                shape = RoundedCornerShape(12.dp),
                                                color = if (active) Color.White else Color.Transparent,
                                                modifier = Modifier
                                                    .clickable { currencyMode = curr }
                                                    .testTag("order_dash_currency_$curr")
                                            ) {
                                                Text(
                                                    text = curr,
                                                    fontSize = 10.sp,
                                                    fontWeight = FontWeight.ExtraBold,
                                                    color = if (active) Navy900 else Color.White,
                                                    modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp)
                                                )
                                            }
                                        }
                                    }
                                }
                            }

                            Spacer(modifier = Modifier.height(10.dp))

                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.spacedBy(8.dp)
                            ) {
                                Button(
                                    onClick = onCreateNewOrderClick,
                                    colors = ButtonDefaults.buttonColors(containerColor = EmeraldSuccess),
                                    shape = RoundedCornerShape(8.dp),
                                    contentPadding = PaddingValues(horizontal = 10.dp),
                                    modifier = Modifier.weight(1f).height(38.dp).testTag("order_dash_new_order_btn")
                                ) {
                                    Icon(Icons.Default.AddShoppingCart, contentDescription = null, modifier = Modifier.size(15.dp))
                                    Spacer(modifier = Modifier.width(5.dp))
                                    Text("New Order", fontSize = 11.sp, fontWeight = FontWeight.Bold, maxLines = 1, softWrap = false)
                                }
                                OutlinedButton(
                                    onClick = onOpenCostAnalyticsClick,
                                    colors = ButtonDefaults.outlinedButtonColors(contentColor = Color.White),
                                    border = BorderStroke(1.dp, Color.White.copy(alpha = 0.45f)),
                                    shape = RoundedCornerShape(8.dp),
                                    contentPadding = PaddingValues(horizontal = 10.dp),
                                    modifier = Modifier.weight(1f).height(38.dp).testTag("order_dash_cost_analytics_btn")
                                ) {
                                    Icon(Icons.Default.Analytics, contentDescription = null, modifier = Modifier.size(15.dp))
                                    Spacer(modifier = Modifier.width(5.dp))
                                    Text("Cost Analytics", fontSize = 11.sp, fontWeight = FontWeight.Bold, maxLines = 1, softWrap = false)
                                }
                            }
                        }
                    }

                    // 4 Summary KPI Tiles
                    Column(
                        modifier = Modifier.padding(12.dp),
                        verticalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.spacedBy(8.dp)
                        ) {
                            OrderDashKpiTile(
                                title = "Total Order Volume",
                                value = fmt(summary.totalRevenueKes),
                                sub = "${summary.totalOrders} Client Orders",
                                fg = RoyalCobaltBlue,
                                bg = RoyalCobaltIce,
                                modifier = Modifier.weight(1f)
                            )
                            OrderDashKpiTile(
                                title = "Collection Rate",
                                value = "${summary.collectionRatePercent}%",
                                sub = "${summary.confirmedOrders} Confirmed • ${summary.installmentOrders} Installment",
                                fg = EmeraldSuccess,
                                bg = EmeraldLight,
                                modifier = Modifier.weight(1f)
                            )
                        }
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.spacedBy(8.dp)
                        ) {
                            OrderDashKpiTile(
                                title = "Average Order Value",
                                value = fmt(summary.averageOrderValueKes),
                                sub = "${summary.pendingOrders} Pending Verification",
                                fg = Navy900,
                                bg = Color(0xFFF1F5F9),
                                modifier = Modifier.weight(1f)
                            )
                            OrderDashKpiTile(
                                title = "5% Commission Pool",
                                value = fmt(summary.totalCommissionPoolKes),
                                sub = "Sales agent casket payouts",
                                fg = Color(0xFFD97706),
                                bg = AmberLight,
                                modifier = Modifier.weight(1f)
                            )
                        }
                    }
                }
            }
        }

        // 2. Payment Channel Split Canvas Ring + Legend
        if (summary.channelMetrics.isNotEmpty()) {
            item(key = "order_dash_channel_mix") {
                Card(
                    shape = RoundedCornerShape(14.dp),
                    colors = CardDefaults.cardColors(containerColor = PureWhite),
                    border = BorderStroke(1.dp, BorderLight),
                    modifier = Modifier.fillMaxWidth().testTag("order_channel_mix_card")
                ) {
                    Column(modifier = Modifier.padding(14.dp)) {
                        Text(
                            text = "Collections by Payment Channel",
                            fontSize = 13.sp,
                            fontWeight = FontWeight.ExtraBold,
                            color = Navy900
                        )
                        Spacer(modifier = Modifier.height(10.dp))

                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.spacedBy(14.dp)
                        ) {
                            val totalChKes = summary.channelMetrics.sumOf { it.totalKes }.coerceAtLeast(1.0)
                            Box(
                                contentAlignment = Alignment.Center,
                                modifier = Modifier.size(110.dp)
                            ) {
                                Canvas(modifier = Modifier.size(104.dp)) {
                                    val strokeWidth = 18.dp.toPx()
                                    val arcSize = Size(size.width - strokeWidth, size.height - strokeWidth)
                                    val topLeft = Offset(strokeWidth / 2f, strokeWidth / 2f)
                                    var startAngle = -90f
                                    summary.channelMetrics.forEach { ch ->
                                        val sweep = ((ch.totalKes / totalChKes) * 360.0).toFloat()
                                        drawArc(
                                            color = Color(ch.colorHex),
                                            startAngle = startAngle,
                                            sweepAngle = (sweep - 2f).coerceAtLeast(4f),
                                            useCenter = false,
                                            topLeft = topLeft,
                                            size = arcSize,
                                            style = Stroke(width = strokeWidth, cap = StrokeCap.Butt)
                                        )
                                        startAngle += sweep
                                    }
                                }
                                Column(horizontalAlignment = Alignment.CenterHorizontally) {
                                    Text("${summary.totalOrders}", fontSize = 16.sp, fontWeight = FontWeight.ExtraBold, color = Navy900)
                                    Text("Orders", fontSize = 9.sp, color = TextMuted)
                                }
                            }

                            Column(
                                modifier = Modifier.weight(1f),
                                verticalArrangement = Arrangement.spacedBy(8.dp)
                            ) {
                                summary.channelMetrics.forEach { ch ->
                                    Row(
                                        modifier = Modifier.fillMaxWidth(),
                                        verticalAlignment = Alignment.CenterVertically,
                                        horizontalArrangement = Arrangement.SpaceBetween
                                    ) {
                                        Row(verticalAlignment = Alignment.CenterVertically, modifier = Modifier.weight(1f)) {
                                            Box(
                                                modifier = Modifier
                                                    .size(10.dp)
                                                    .clip(CircleShape)
                                                    .background(Color(ch.colorHex))
                                            )
                                            Spacer(modifier = Modifier.width(6.dp))
                                            Column {
                                                Text(ch.channelLabel, fontSize = 11.sp, fontWeight = FontWeight.Bold, color = Navy900)
                                                Text("${ch.orderCount} orders • ${ch.sharePercent}%", fontSize = 10.sp, color = TextMuted)
                                            }
                                        }
                                        Text(fmt(ch.totalKes), fontSize = 11.sp, fontWeight = FontWeight.ExtraBold, color = Navy900)
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }

        // 3. Branch Revenue Bars & Top Casket Models
        if (summary.branchMetrics.isNotEmpty()) {
            item(key = "order_dash_branch_ranking") {
                val maxBranchRev = summary.branchMetrics.maxOfOrNull { it.revenueKes }?.coerceAtLeast(1.0) ?: 1.0
                Card(
                    shape = RoundedCornerShape(14.dp),
                    colors = CardDefaults.cardColors(containerColor = PureWhite),
                    border = BorderStroke(1.dp, BorderLight),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Column(modifier = Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                        Text(
                            text = "Branch Order Volume & Revenue Leaderboard",
                            fontSize = 13.sp,
                            fontWeight = FontWeight.ExtraBold,
                            color = Navy900
                        )
                        summary.branchMetrics.forEach { b ->
                            val ratio by animateFloatAsState(
                                targetValue = (b.revenueKes / maxBranchRev).toFloat().coerceIn(0.06f, 1f),
                                animationSpec = spring(stiffness = Spring.StiffnessMediumLow),
                                label = "brRev_${b.branchName}"
                            )
                            Column {
                                Row(
                                    modifier = Modifier.fillMaxWidth(),
                                    horizontalArrangement = Arrangement.SpaceBetween
                                ) {
                                    Text("${b.branchName} (${b.orderCount} orders)", fontSize = 11.sp, fontWeight = FontWeight.SemiBold, color = Navy900)
                                    Text(fmt(b.revenueKes), fontSize = 11.sp, fontWeight = FontWeight.Bold, color = RoyalCobaltBlue)
                                }
                                Spacer(modifier = Modifier.height(3.dp))
                                Canvas(modifier = Modifier.fillMaxWidth().height(7.dp)) {
                                    drawRoundRect(color = Color(0xFFE2E8F0), cornerRadius = CornerRadius(4.dp.toPx()))
                                    drawRoundRect(
                                        color = RoyalCobaltBlue,
                                        size = Size(size.width * ratio, size.height),
                                        cornerRadius = CornerRadius(4.dp.toPx())
                                    )
                                }
                            }
                        }

                        if (summary.topCasketModels.isNotEmpty()) {
                            Spacer(modifier = Modifier.height(4.dp))
                            HorizontalDivider(color = BorderLight)
                            Spacer(modifier = Modifier.height(4.dp))
                            Text("Top Ordered Casket Lines", fontSize = 12.sp, fontWeight = FontWeight.Bold, color = Navy900)
                            summary.topCasketModels.take(4).forEach { m ->
                                Row(
                                    modifier = Modifier.fillMaxWidth(),
                                    horizontalArrangement = Arrangement.SpaceBetween
                                ) {
                                    Text(
                                        text = "• ${m.casketModel} (${m.unitsSold}x)",
                                        fontSize = 11.sp,
                                        color = TextSecondary,
                                        maxLines = 1,
                                        overflow = TextOverflow.Ellipsis,
                                        modifier = Modifier.weight(1f)
                                    )
                                    Text(fmt(m.revenueKes), fontSize = 11.sp, fontWeight = FontWeight.Bold, color = EmeraldSuccess)
                                }
                            }
                        }
                    }
                }
            }
        }

        // 4. Filter Controls
        item(key = "order_dash_filters") {
            Card(
                shape = RoundedCornerShape(14.dp),
                colors = CardDefaults.cardColors(containerColor = PureWhite),
                border = BorderStroke(1.dp, BorderLight),
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(modifier = Modifier.padding(12.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    OutlinedTextField(
                        value = searchQuery,
                        onValueChange = { searchQuery = it },
                        placeholder = { Text("Search Order ID, Client, Deceased, Casket or Agent...", fontSize = 12.sp) },
                        leadingIcon = { Icon(Icons.Default.Search, contentDescription = null, tint = RoyalCobaltBlue) },
                        trailingIcon = {
                            if (searchQuery.isNotEmpty()) {
                                IconButton(onClick = { searchQuery = "" }) {
                                    Icon(Icons.Default.Clear, contentDescription = "Clear search")
                                }
                            }
                        },
                        singleLine = true,
                        shape = RoundedCornerShape(10.dp),
                        modifier = Modifier.fillMaxWidth().testTag("order_dash_search_input")
                    )

                    Row(
                        modifier = Modifier.fillMaxWidth().horizontalScroll(rememberScrollState()),
                        horizontalArrangement = Arrangement.spacedBy(6.dp)
                    ) {
                        OrderStatusFilter.entries.forEach { st ->
                            FilterChip(
                                selected = selectedStatus == st,
                                onClick = { selectedStatus = st },
                                label = { Text(st.label, fontSize = 11.sp, maxLines = 1, softWrap = false) },
                                colors = FilterChipDefaults.filterChipColors(
                                    selectedContainerColor = Navy900,
                                    selectedLabelColor = Color.White
                                ),
                                modifier = Modifier.testTag("order_dash_status_${st.name.lowercase()}")
                            )
                        }
                    }

                    Row(
                        modifier = Modifier.fillMaxWidth().horizontalScroll(rememberScrollState()),
                        horizontalArrangement = Arrangement.spacedBy(6.dp)
                    ) {
                        (listOf("All Branches") + JABIMA_BRANCHES).forEach { branch ->
                            FilterChip(
                                selected = selectedBranch == branch,
                                onClick = { selectedBranch = branch },
                                label = { Text(branch, fontSize = 11.sp, maxLines = 1, softWrap = false) },
                                colors = FilterChipDefaults.filterChipColors(
                                    selectedContainerColor = RoyalCobaltBlue,
                                    selectedLabelColor = Color.White
                                ),
                                modifier = Modifier.testTag("order_dash_branch_${branch.lowercase().replace(" ", "_")}")
                            )
                        }
                    }
                }
            }
        }

        // 5. Filtered Order Cards
        if (summary.filteredOrders.isEmpty()) {
            item(key = "order_dash_empty") {
                Surface(
                    color = MaterialTheme.colorScheme.surfaceVariant,
                    shape = RoundedCornerShape(12.dp),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Column(
                        modifier = Modifier.padding(20.dp),
                        horizontalAlignment = Alignment.CenterHorizontally
                    ) {
                        Icon(Icons.Default.ReceiptLong, contentDescription = null, tint = TextMuted, modifier = Modifier.size(28.dp))
                        Spacer(modifier = Modifier.height(6.dp))
                        Text("No matching orders found", fontSize = 13.sp, fontWeight = FontWeight.Bold, color = Navy900)
                        Text("Adjust search or status filter, or create a new order.", fontSize = 11.sp, color = TextMuted)
                    }
                }
            }
        } else {
            items(summary.filteredOrders, key = { "od_${it.orderId}" }) { order ->
                OrderPipelineCard(
                    order = order,
                    formattedAmount = fmt(order.totalAmountKes),
                    onConfirmFullPayment = {
                        viewModel.updateCustomerOrderPaymentStatus(
                            orderId = order.orderId,
                            newStatus = "Confirmed (${order.paymentMethod} Verified)"
                        )
                    }
                )
            }
        }
    }
}

@Composable
private fun OrderDashKpiTile(
    title: String,
    value: String,
    sub: String,
    fg: Color,
    bg: Color,
    modifier: Modifier = Modifier
) {
    Surface(
        color = bg,
        shape = RoundedCornerShape(10.dp),
        border = BorderStroke(1.dp, fg.copy(alpha = 0.25f)),
        modifier = modifier
    ) {
        Column(modifier = Modifier.padding(10.dp)) {
            Text(title, fontSize = 10.sp, fontWeight = FontWeight.SemiBold, color = fg, maxLines = 1, overflow = TextOverflow.Ellipsis)
            Spacer(modifier = Modifier.height(2.dp))
            Text(value, fontSize = 14.sp, fontWeight = FontWeight.ExtraBold, color = Navy900, maxLines = 1, overflow = TextOverflow.Ellipsis)
            Text(sub, fontSize = 10.sp, color = TextSecondary, maxLines = 1, overflow = TextOverflow.Ellipsis)
        }
    }
}

@Composable
private fun OrderPipelineCard(
    order: CustomerOrderRecord,
    formattedAmount: String,
    onConfirmFullPayment: () -> Unit
) {
    val isConfirmed = order.paymentStatus.contains("confirmed", ignoreCase = true) ||
        order.paymentStatus.contains("settled", ignoreCase = true)

    Card(
        shape = RoundedCornerShape(12.dp),
        colors = CardDefaults.cardColors(containerColor = PureWhite),
        border = BorderStroke(1.dp, BorderLight),
        modifier = Modifier.fillMaxWidth().testTag("order_dash_card_${order.orderId}")
    ) {
        Column(modifier = Modifier.padding(12.dp)) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text("${order.orderId} • ${order.branch}", fontSize = 12.sp, fontWeight = FontWeight.ExtraBold, color = RoyalCobaltBlue)
                Surface(
                    color = if (isConfirmed) EmeraldLight else AmberLight,
                    shape = RoundedCornerShape(8.dp)
                ) {
                    Text(
                        text = order.paymentStatus,
                        fontSize = 9.sp,
                        fontWeight = FontWeight.Bold,
                        color = if (isConfirmed) EmeraldSuccess else AmberWarning,
                        modifier = Modifier.padding(horizontal = 7.dp, vertical = 3.dp)
                    )
                }
            }

            Spacer(modifier = Modifier.height(6.dp))
            Text("${order.clientName} (${order.clientPhone})", fontSize = 13.sp, fontWeight = FontWeight.Bold, color = Navy900)
            Text("Deceased: ${order.deceasedName} • ${order.selectedCasket}", fontSize = 11.sp, color = TextSecondary)
            Text("Package: ${order.selectedPackage} • Agent: ${order.salesAgentName}", fontSize = 10.sp, color = TextMuted)

            Spacer(modifier = Modifier.height(8.dp))
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Column {
                    Text(formattedAmount, fontSize = 14.sp, fontWeight = FontWeight.ExtraBold, color = Navy900)
                    Text("${order.paymentMethod} • Ref ${order.referenceCode}", fontSize = 10.sp, color = EmeraldSuccess, fontWeight = FontWeight.SemiBold)
                }

                if (!isConfirmed) {
                    Button(
                        onClick = onConfirmFullPayment,
                        colors = ButtonDefaults.buttonColors(containerColor = EmeraldSuccess),
                        shape = RoundedCornerShape(8.dp),
                        contentPadding = PaddingValues(horizontal = 10.dp, vertical = 4.dp),
                        modifier = Modifier.height(34.dp).testTag("btn_confirm_order_${order.orderId}")
                    ) {
                        Icon(Icons.Default.CheckCircle, contentDescription = null, modifier = Modifier.size(14.dp))
                        Spacer(modifier = Modifier.width(4.dp))
                        Text("Confirm Settled", fontSize = 10.sp, fontWeight = FontWeight.Bold, maxLines = 1, softWrap = false)
                    }
                }
            }
        }
    }
}
