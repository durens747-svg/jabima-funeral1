package com.example

import android.os.Bundle
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.remember
import androidx.fragment.app.FragmentActivity
import androidx.lifecycle.ViewModel
import androidx.lifecycle.ViewModelProvider
import androidx.lifecycle.viewmodel.compose.viewModel
import com.example.data.PreferencesManager
import com.example.data.StaffPortalRepository
import com.example.data.firebase.FirestoreSyncRepository
import com.example.data.firebase.configureAppCheck
import com.example.data.jabimaDataStore
import com.example.network.ExternalServiceBridge
import com.example.ui.StaffPortalMainScreen
import com.example.ui.StaffPortalViewModel
import com.example.ui.screens.GoogleCloudAuthHelper
import com.example.ui.theme.JabimaTheme
import com.example.utils.NetworkConnectivityObserver

class MainActivity : FragmentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        // STEP 1: Configure App Check with launch intent before any UI, ViewModels, or Firebase calls
        configureAppCheck(this, intent)

        enableEdgeToEdge()
        val appContext = applicationContext
        setContent {
            val factory = remember {
                object : ViewModelProvider.Factory {
                    @Suppress("UNCHECKED_CAST")
                    override fun <T : ViewModel> create(modelClass: Class<T>): T {
                        return StaffPortalViewModel(
                            repository = StaffPortalRepository(),
                            preferencesManager = PreferencesManager(appContext.jabimaDataStore),
                            firestoreSyncRepository = runCatching { FirestoreSyncRepository.create(appContext) }.getOrNull(),
                            externalServiceBridge = ExternalServiceBridge(),
                            connectivityObserver = NetworkConnectivityObserver(appContext)
                        ) as T
                    }
                }
            }
            val portalViewModel: StaffPortalViewModel = viewModel(factory = factory)
            val isDarkMode by portalViewModel.isDarkMode.collectAsState()

            LaunchedEffect(Unit) {
                val res = GoogleCloudAuthHelper.attemptAutoSignIn(appContext)
                res.getOrNull()?.let { user ->
                    portalViewModel.onCloudSignedIn(user)
                }
            }

            JabimaTheme(darkTheme = isDarkMode) {
                StaffPortalMainScreen(viewModel = portalViewModel)
            }
        }
    }
}
