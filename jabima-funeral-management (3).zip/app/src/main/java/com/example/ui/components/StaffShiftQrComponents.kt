package com.example.ui.components

import android.Manifest
import android.content.pm.PackageManager
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.camera.mlkit.vision.MlKitAnalyzer
import androidx.camera.view.CameraController
import androidx.camera.view.LifecycleCameraController
import androidx.camera.view.PreviewView
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ExperimentalLayoutApi
import androidx.compose.foundation.layout.FlowRow
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Badge
import androidx.compose.material.icons.filled.CameraAlt
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.ContentCopy
import androidx.compose.material.icons.filled.ErrorOutline
import androidx.compose.material.icons.filled.Fullscreen
import androidx.compose.material.icons.filled.Login
import androidx.compose.material.icons.filled.Logout
import androidx.compose.material.icons.filled.QrCode2
import androidx.compose.material.icons.filled.QrCodeScanner
import androidx.compose.material.icons.filled.Refresh
import androidx.compose.material.icons.filled.Schedule
import androidx.compose.material.icons.filled.VerifiedUser
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.AssistChip
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.FilterChip
import androidx.compose.material3.FilterChipDefaults
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.platform.LocalClipboardManager
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.AnnotatedString
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.viewinterop.AndroidView
import androidx.core.content.ContextCompat
import androidx.lifecycle.compose.LocalLifecycleOwner
import com.example.domain.StaffQrIdentityCodec
import com.example.domain.StaffQrParseResult
import com.example.model.ShiftAttendanceAction
import com.example.model.ShiftAttendanceRecord
import com.example.model.ShiftPeriod
import com.example.model.StaffAccount
import com.example.model.StaffShiftSchedule
import com.example.ui.theme.BorderLightGreen
import com.example.ui.theme.EmeraldGreenIce
import com.example.ui.theme.EmeraldLight
import com.example.ui.theme.EmeraldSuccess
import com.example.ui.theme.ForestGreenDark
import com.example.ui.theme.ForestGreenPrimary
import com.example.ui.theme.Navy900
import com.example.ui.theme.PureWhite
import com.example.ui.theme.StrokeRed
import com.example.ui.theme.StrokeRedBorder
import com.example.ui.theme.StrokeRedLight
import com.google.mlkit.vision.barcode.BarcodeScannerOptions
import com.google.mlkit.vision.barcode.BarcodeScanning
import com.google.mlkit.vision.barcode.common.Barcode
import java.util.Calendar

@Composable
fun StaffProfileQrPassCard(
    staffAccount: StaffAccount,
    attendanceLogs: List<ShiftAttendanceRecord>,
    canVerifyAttendance: Boolean,
    onOpenShiftQrScanner: () -> Unit,
    modifier: Modifier = Modifier
) {
    val qrPayload = remember(staffAccount.id, staffAccount.department, staffAccount.branch, staffAccount.role) {
        StaffQrIdentityCodec.encodeStaffQrPayload(staffAccount)
    }
    val qrBitmap = remember(qrPayload) {
        QrCodeBitmapHelper.generateQrBitmap(
            content = qrPayload,
            sizePx = 380
        ).asImageBitmap()
    }
    val myAttendanceLogs = remember(attendanceLogs, staffAccount.id) {
        attendanceLogs.filter { it.staffId.equals(staffAccount.id, ignoreCase = true) }.take(3)
    }
    val latestLog = myAttendanceLogs.firstOrNull()
    val clipboardManager = LocalClipboardManager.current
    var copiedNotice by remember { mutableStateOf(false) }
    var showEnlargedQrPass by remember { mutableStateOf(false) }

    Card(
        shape = RoundedCornerShape(18.dp),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
        border = BorderStroke(1.5.dp, ForestGreenPrimary.copy(alpha = 0.65f)),
        elevation = CardDefaults.cardElevation(defaultElevation = 2.dp),
        modifier = modifier
            .fillMaxWidth()
            .testTag("profile_staff_qr_pass_card")
    ) {
        Column(modifier = Modifier.padding(16.dp)) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Row(verticalAlignment = Alignment.CenterVertically, modifier = Modifier.weight(1f)) {
                    Box(
                        modifier = Modifier
                            .size(38.dp)
                            .clip(CircleShape)
                            .background(EmeraldGreenIce),
                        contentAlignment = Alignment.Center
                    ) {
                        Icon(
                            imageVector = Icons.Default.QrCode2,
                            contentDescription = "Staff Shift QR Identity",
                            tint = ForestGreenPrimary,
                            modifier = Modifier.size(22.dp)
                        )
                    }
                    Spacer(modifier = Modifier.width(10.dp))
                    Column {
                        Text(
                            text = "24/7 Digital Staff QR Pass",
                            style = MaterialTheme.typography.titleMedium,
                            fontWeight = FontWeight.Bold,
                            color = MaterialTheme.colorScheme.onSurface
                        )
                        Text(
                            text = "ZXing Verified Shift Identity • ${staffAccount.id}",
                            fontSize = 11.sp,
                            color = ForestGreenPrimary,
                            fontWeight = FontWeight.SemiBold
                        )
                    }
                }

                Surface(
                    color = StrokeRedLight,
                    border = BorderStroke(1.dp, StrokeRedBorder),
                    shape = RoundedCornerShape(8.dp)
                ) {
                    Text(
                        text = "24/7 PASS",
                        fontSize = 9.sp,
                        fontWeight = FontWeight.ExtraBold,
                        color = StrokeRed,
                        modifier = Modifier.padding(horizontal = 7.dp, vertical = 3.dp)
                    )
                }
            }

            Spacer(modifier = Modifier.height(14.dp))

            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(14.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                // Always Pure White high-contrast QR container for reliable dark/day scanning
                Surface(
                    onClick = { showEnlargedQrPass = true },
                    shape = RoundedCornerShape(14.dp),
                    color = PureWhite,
                    border = BorderStroke(2.dp, ForestGreenPrimary),
                    shadowElevation = 2.dp,
                    modifier = Modifier.testTag("btn_enlarge_staff_qr_pass")
                ) {
                    Column(
                        modifier = Modifier.padding(8.dp),
                        horizontalAlignment = Alignment.CenterHorizontally
                    ) {
                        Image(
                            bitmap = qrBitmap,
                            contentDescription = "Staff QR Code for ${staffAccount.fullName} (${staffAccount.id})",
                            modifier = Modifier.size(126.dp)
                        )
                        Spacer(modifier = Modifier.height(4.dp))
                        Text(
                            text = staffAccount.id,
                            fontSize = 10.sp,
                            fontWeight = FontWeight.ExtraBold,
                            fontFamily = FontFamily.Monospace,
                            color = ForestGreenDark
                        )
                    }
                }

                Column(
                    modifier = Modifier.weight(1f),
                    verticalArrangement = Arrangement.spacedBy(6.dp)
                ) {
                    Text(
                        text = "Present this QR badge to your Operations Manager or Branch Supervisor when checking in or out of Day & Night Vigil shifts.",
                        fontSize = 11.sp,
                        lineHeight = 15.sp,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )

                    Surface(
                        color = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.55f),
                        shape = RoundedCornerShape(8.dp),
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Text(
                            text = qrPayload,
                            fontSize = 9.5.sp,
                            fontFamily = FontFamily.Monospace,
                            fontWeight = FontWeight.SemiBold,
                            color = MaterialTheme.colorScheme.onSurface,
                            maxLines = 2,
                            overflow = TextOverflow.Ellipsis,
                            modifier = Modifier.padding(horizontal = 8.dp, vertical = 6.dp)
                        )
                    }

                    if (latestLog != null) {
                        val isCheckIn = latestLog.action == ShiftAttendanceAction.CHECK_IN
                        Surface(
                            color = if (isCheckIn) EmeraldLight.copy(alpha = 0.7f) else MaterialTheme.colorScheme.surfaceVariant,
                            border = BorderStroke(
                                1.dp,
                                if (isCheckIn) EmeraldSuccess.copy(alpha = 0.5f) else BorderLightGreen
                            ),
                            shape = RoundedCornerShape(8.dp),
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            Row(
                                modifier = Modifier.padding(horizontal = 8.dp, vertical = 5.dp),
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Icon(
                                    imageVector = Icons.Default.VerifiedUser,
                                    contentDescription = null,
                                    tint = if (isCheckIn) EmeraldSuccess else ForestGreenPrimary,
                                    modifier = Modifier.size(14.dp)
                                )
                                Spacer(modifier = Modifier.width(6.dp))
                                Text(
                                    text = "${latestLog.action.label} • ${latestLog.timestampFormatted}",
                                    fontSize = 10.sp,
                                    fontWeight = FontWeight.Bold,
                                    color = Navy900,
                                    maxLines = 1,
                                    overflow = TextOverflow.Ellipsis
                                )
                            }
                        }
                    }
                }
            }

            Spacer(modifier = Modifier.height(12.dp))

            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                OutlinedButton(
                    onClick = { showEnlargedQrPass = true },
                    border = BorderStroke(1.dp, ForestGreenPrimary),
                    shape = RoundedCornerShape(10.dp),
                    contentPadding = PaddingValues(horizontal = 10.dp, vertical = 6.dp),
                    modifier = Modifier
                        .weight(1f)
                        .height(40.dp)
                        .testTag("btn_open_fullscreen_qr_pass")
                ) {
                    Icon(
                        imageVector = Icons.Default.Fullscreen,
                        contentDescription = null,
                        tint = ForestGreenPrimary,
                        modifier = Modifier.size(16.dp)
                    )
                    Spacer(modifier = Modifier.width(4.dp))
                    Text(
                        text = "Enlarge Pass",
                        fontSize = 11.5.sp,
                        fontWeight = FontWeight.Bold,
                        color = ForestGreenPrimary,
                        maxLines = 1,
                        softWrap = false
                    )
                }

                OutlinedButton(
                    onClick = {
                        clipboardManager.setText(AnnotatedString(qrPayload))
                        copiedNotice = true
                    },
                    shape = RoundedCornerShape(10.dp),
                    contentPadding = PaddingValues(horizontal = 10.dp, vertical = 6.dp),
                    modifier = Modifier
                        .weight(1f)
                        .height(40.dp)
                        .testTag("btn_copy_staff_qr_payload")
                ) {
                    Icon(
                        imageVector = Icons.Default.ContentCopy,
                        contentDescription = null,
                        modifier = Modifier.size(15.dp)
                    )
                    Spacer(modifier = Modifier.width(4.dp))
                    Text(
                        text = if (copiedNotice) "Copied ✓" else "Copy ID Code",
                        fontSize = 11.5.sp,
                        fontWeight = FontWeight.SemiBold,
                        maxLines = 1,
                        softWrap = false
                    )
                }
            }

            if (canVerifyAttendance) {
                Spacer(modifier = Modifier.height(8.dp))
                Button(
                    onClick = onOpenShiftQrScanner,
                    colors = ButtonDefaults.buttonColors(
                        containerColor = ForestGreenPrimary,
                        contentColor = Color.White
                    ),
                    shape = RoundedCornerShape(10.dp),
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(44.dp)
                        .testTag("btn_profile_open_manager_qr_scanner")
                ) {
                    Icon(
                        imageVector = Icons.Default.QrCodeScanner,
                        contentDescription = null,
                        modifier = Modifier.size(18.dp)
                    )
                    Spacer(modifier = Modifier.width(8.dp))
                    Text(
                        text = "Scan & Verify Staff 24/7 Shift Attendance",
                        fontSize = 12.sp,
                        fontWeight = FontWeight.Bold
                    )
                }
            }

            if (myAttendanceLogs.isNotEmpty()) {
                Spacer(modifier = Modifier.height(12.dp))
                HorizontalDivider(color = MaterialTheme.colorScheme.outline.copy(alpha = 0.25f))
                Spacer(modifier = Modifier.height(8.dp))
                Text(
                    text = "RECENT QR ATTENDANCE LOGS",
                    fontSize = 10.sp,
                    fontWeight = FontWeight.Bold,
                    color = MaterialTheme.colorScheme.primary,
                    letterSpacing = 0.5.sp
                )
                Spacer(modifier = Modifier.height(6.dp))
                Column(verticalArrangement = Arrangement.spacedBy(6.dp)) {
                    myAttendanceLogs.forEach { rec ->
                        val isCheckIn = rec.action == ShiftAttendanceAction.CHECK_IN
                        Surface(
                            color = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.45f),
                            shape = RoundedCornerShape(8.dp),
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            Row(
                                modifier = Modifier.padding(horizontal = 10.dp, vertical = 7.dp),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Column(modifier = Modifier.weight(1f)) {
                                    Text(
                                        text = "${rec.action.label} • ${rec.checkpointLocation}",
                                        fontSize = 11.sp,
                                        fontWeight = FontWeight.Bold,
                                        color = if (isCheckIn) EmeraldSuccess else MaterialTheme.colorScheme.onSurface
                                    )
                                    Text(
                                        text = "${rec.shiftWindowLabel} • By ${rec.verifiedByName}",
                                        fontSize = 9.5.sp,
                                        color = MaterialTheme.colorScheme.onSurfaceVariant
                                    )
                                }
                                Text(
                                    text = rec.timestampFormatted,
                                    fontSize = 9.5.sp,
                                    fontWeight = FontWeight.SemiBold,
                                    color = MaterialTheme.colorScheme.onSurfaceVariant
                                )
                            }
                        }
                    }
                }
            }
        }
    }

    if (showEnlargedQrPass) {
        val largeBitmap = remember(qrPayload) {
            QrCodeBitmapHelper.generateQrBitmap(qrPayload, 560).asImageBitmap()
        }
        AlertDialog(
            onDismissRequest = { showEnlargedQrPass = false },
            containerColor = PureWhite,
            title = {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Icon(Icons.Default.Badge, contentDescription = null, tint = ForestGreenPrimary)
                        Spacer(modifier = Modifier.width(8.dp))
                        Text(
                            text = "Jabima 24/7 Staff Pass",
                            fontWeight = FontWeight.Bold,
                            fontSize = 16.sp,
                            color = ForestGreenDark
                        )
                    }
                    IconButton(onClick = { showEnlargedQrPass = false }) {
                        Icon(Icons.Default.Close, contentDescription = "Close enlarged QR pass", tint = Navy900)
                    }
                }
            },
            text = {
                Column(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalAlignment = Alignment.CenterHorizontally,
                    verticalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    Surface(
                        color = StrokeRedLight,
                        border = BorderStroke(1.dp, StrokeRed),
                        shape = RoundedCornerShape(6.dp)
                    ) {
                        Text(
                            text = "ACTIVE CREDENTIAL • ${staffAccount.department.displayName.uppercase()}",
                            fontSize = 10.sp,
                            fontWeight = FontWeight.ExtraBold,
                            color = StrokeRed,
                            modifier = Modifier.padding(horizontal = 10.dp, vertical = 4.dp)
                        )
                    }

                    Surface(
                        color = PureWhite,
                        border = BorderStroke(2.5.dp, ForestGreenPrimary),
                        shape = RoundedCornerShape(16.dp),
                        shadowElevation = 4.dp
                    ) {
                        Image(
                            bitmap = largeBitmap,
                            contentDescription = "High contrast enlarged staff QR badge for ${staffAccount.fullName}",
                            modifier = Modifier
                                .padding(14.dp)
                                .size(220.dp)
                        )
                    }

                    Text(
                        text = staffAccount.fullName,
                        fontWeight = FontWeight.ExtraBold,
                        fontSize = 17.sp,
                        color = Navy900,
                        textAlign = TextAlign.Center
                    )
                    Text(
                        text = "${staffAccount.id} • ${staffAccount.role.title} • ${staffAccount.branch}",
                        fontSize = 11.5.sp,
                        fontWeight = FontWeight.SemiBold,
                        color = ForestGreenPrimary,
                        textAlign = TextAlign.Center
                    )
                    Text(
                        text = qrPayload,
                        fontSize = 10.sp,
                        fontFamily = FontFamily.Monospace,
                        color = Color(0xFF475569),
                        textAlign = TextAlign.Center
                    )
                }
            },
            confirmButton = {
                Button(
                    onClick = { showEnlargedQrPass = false },
                    colors = ButtonDefaults.buttonColors(containerColor = ForestGreenPrimary),
                    modifier = Modifier.testTag("btn_close_enlarged_qr_pass")
                ) {
                    Text("Done", fontWeight = FontWeight.Bold)
                }
            }
        )
    }
}

@OptIn(ExperimentalLayoutApi::class)
@Composable
fun ManagerShiftQrAttendanceDialog(
    verifierAccount: StaffAccount,
    allStaff: List<StaffAccount>,
    shiftSchedules: List<StaffShiftSchedule>,
    recentLogs: List<ShiftAttendanceRecord>,
    onVerifyAttendance: (
        scannedCode: String,
        action: ShiftAttendanceAction,
        checkpointLocation: String,
        shiftId: String?,
        shiftWindowLabel: String,
        notes: String
    ) -> Result<ShiftAttendanceRecord>,
    onDismiss: () -> Unit
) {
    val context = LocalContext.current
    val lifecycleOwner = LocalLifecycleOwner.current
    var hasCameraPermission by remember {
        mutableStateOf(
            ContextCompat.checkSelfPermission(context, Manifest.permission.CAMERA) == PackageManager.PERMISSION_GRANTED
        )
    }
    var permissionDeniedOnce by remember { mutableStateOf(false) }

    var scannedOrEnteredCode by remember { mutableStateOf("") }
    var selectedAction by remember { mutableStateOf(ShiftAttendanceAction.CHECK_IN) }

    val autoShiftWindow = remember {
        StaffQrIdentityCodec.resolve24HourShiftWindow(Calendar.getInstance().get(Calendar.HOUR_OF_DAY))
    }
    val shiftWindowOptions = remember(autoShiftWindow) {
        listOf(
            autoShiftWindow,
            "Day Shift (06:00 - 18:00)",
            "Night Vigil & 24/7 Shift (18:00 - 06:00)",
            "Emergency 24/7 Cortege Standby"
        ).distinct()
    }
    var selectedShiftWindow by remember { mutableStateOf(autoShiftWindow) }

    val defaultCheckpoints = remember(verifierAccount.branch) {
        listOf(
            "${verifierAccount.branch} 24/7 Gate",
            "Bama Branch Dispatch Bay",
            "Siaya Referal Mortuary Desk",
            "Main Casket Workshop Gate",
            "Rangala / Bondo Field Site"
        ).distinct()
    }
    var checkpointInput by remember { mutableStateOf(defaultCheckpoints.first()) }
    var notesInput by remember { mutableStateOf("") }

    var lastVerifiedRecord by remember { mutableStateOf<ShiftAttendanceRecord?>(null) }
    var parseErrorMessage by remember { mutableStateOf<String?>(null) }

    val permissionLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.RequestPermission()
    ) { granted ->
        hasCameraPermission = granted
        if (!granted) permissionDeniedOnce = true
    }

    LaunchedEffect(Unit) {
        if (!hasCameraPermission) {
            permissionLauncher.launch(Manifest.permission.CAMERA)
        }
    }

    val liveParseResult = remember(scannedOrEnteredCode, allStaff) {
        if (scannedOrEnteredCode.isBlank()) null
        else StaffQrIdentityCodec.parseScannedStaffCode(scannedOrEnteredCode, allStaff)
    }

    val matchedStaff = (liveParseResult as? StaffQrParseResult.Matched)?.staff
    val matchedRosterShift = remember(matchedStaff, shiftSchedules) {
        matchedStaff?.let { staff ->
            shiftSchedules.firstOrNull {
                it.staffId.equals(staff.id, ignoreCase = true) && it.shiftPeriod == ShiftPeriod.ACTIVE
            } ?: shiftSchedules.firstOrNull {
                it.staffId.equals(staff.id, ignoreCase = true) && it.shiftPeriod == ShiftPeriod.UPCOMING
            }
        }
    }

    AlertDialog(
        onDismissRequest = onDismiss,
        containerColor = MaterialTheme.colorScheme.surface,
        title = {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Row(verticalAlignment = Alignment.CenterVertically, modifier = Modifier.weight(1f)) {
                    Icon(
                        imageVector = Icons.Default.QrCodeScanner,
                        contentDescription = null,
                        tint = ForestGreenPrimary
                    )
                    Spacer(modifier = Modifier.width(8.dp))
                    Column {
                        Text(
                            text = "24/7 QR Attendance Verifier",
                            fontWeight = FontWeight.Bold,
                            fontSize = 15.sp
                        )
                        Text(
                            text = "Supervisor: ${verifierAccount.fullName}",
                            fontSize = 10.sp,
                            color = ForestGreenPrimary,
                            fontWeight = FontWeight.SemiBold
                        )
                    }
                }
                IconButton(onClick = onDismiss, modifier = Modifier.testTag("btn_close_shift_qr_scanner")) {
                    Icon(Icons.Default.Close, contentDescription = "Close shift QR scanner")
                }
            }
        },
        text = {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .heightIn(max = 520.dp)
                    .verticalScroll(rememberScrollState()),
                verticalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                // Live CameraX + ML Kit QR Scanner Box
                if (hasCameraPermission) {
                    var cameraBindError by remember { mutableStateOf<String?>(null) }
                    val cameraController = remember { LifecycleCameraController(context) }
                    val barcodeScanner = remember {
                        val options = BarcodeScannerOptions.Builder()
                            .setBarcodeFormats(Barcode.FORMAT_QR_CODE, Barcode.FORMAT_ALL_FORMATS)
                            .build()
                        BarcodeScanning.getClient(options)
                    }

                    DisposableEffect(lifecycleOwner) {
                        val mainExecutor = ContextCompat.getMainExecutor(context)
                        runCatching {
                            cameraController.setImageAnalysisAnalyzer(
                                mainExecutor,
                                MlKitAnalyzer(
                                    listOf(barcodeScanner),
                                    CameraController.COORDINATE_SYSTEM_VIEW_REFERENCED,
                                    mainExecutor
                                ) { result ->
                                    val detected = result?.getValue(barcodeScanner)
                                        ?.firstOrNull { !it.rawValue.isNullOrBlank() }
                                        ?.rawValue
                                        ?.trim()
                                    if (!detected.isNullOrBlank() && detected != scannedOrEnteredCode) {
                                        scannedOrEnteredCode = detected
                                        lastVerifiedRecord = null
                                        parseErrorMessage = null
                                    }
                                }
                            )
                            cameraController.bindToLifecycle(lifecycleOwner)
                        }.onFailure { err ->
                            cameraBindError = err.localizedMessage ?: "Camera preview unavailable on this device."
                        }
                        onDispose {
                            runCatching {
                                cameraController.clearImageAnalysisAnalyzer()
                                cameraController.unbind()
                                barcodeScanner.close()
                            }
                        }
                    }

                    if (cameraBindError != null) {
                        Surface(
                            color = StrokeRedLight,
                            border = BorderStroke(1.dp, StrokeRedBorder),
                            shape = RoundedCornerShape(10.dp),
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            Text(
                                text = "Live camera unavailable (${cameraBindError}). Use Staff ID entry or Quick Select below.",
                                fontSize = 11.sp,
                                color = StrokeRed,
                                modifier = Modifier.padding(10.dp)
                            )
                        }
                    } else {
                        Box(
                            modifier = Modifier
                                .fillMaxWidth()
                                .height(175.dp)
                                .clip(RoundedCornerShape(12.dp))
                                .border(2.dp, ForestGreenPrimary, RoundedCornerShape(12.dp))
                                .background(Color.Black)
                        ) {
                            AndroidView(
                                factory = { ctx ->
                                    PreviewView(ctx).apply {
                                        controller = cameraController
                                        implementationMode = PreviewView.ImplementationMode.COMPATIBLE
                                    }
                                },
                                modifier = Modifier.fillMaxSize()
                            )
                            Box(
                                modifier = Modifier
                                    .align(Alignment.Center)
                                    .size(116.dp)
                                    .border(2.dp, StrokeRed.copy(alpha = 0.85f), RoundedCornerShape(10.dp))
                            )
                            Surface(
                                color = Color.Black.copy(alpha = 0.6f),
                                shape = RoundedCornerShape(6.dp),
                                modifier = Modifier
                                    .align(Alignment.BottomCenter)
                                    .padding(bottom = 8.dp)
                            ) {
                                Text(
                                    text = "Align Staff Profile QR Badge inside frame",
                                    color = Color.White,
                                    fontSize = 10.sp,
                                    fontWeight = FontWeight.SemiBold,
                                    modifier = Modifier.padding(horizontal = 8.dp, vertical = 3.dp)
                                )
                            }
                        }
                    }
                } else {
                    Surface(
                        color = MaterialTheme.colorScheme.surfaceVariant,
                        shape = RoundedCornerShape(10.dp),
                        border = BorderStroke(1.dp, StrokeRedBorder),
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Column(
                            modifier = Modifier.padding(12.dp),
                            horizontalAlignment = Alignment.CenterHorizontally,
                            verticalArrangement = Arrangement.spacedBy(6.dp)
                        ) {
                            Icon(Icons.Default.CameraAlt, contentDescription = null, tint = ForestGreenPrimary)
                            Text(
                                text = if (permissionDeniedOnce) {
                                    "Camera permission denied — grant permission for live QR scanning or enter Staff ID below."
                                } else {
                                    "Camera permission is required to scan Staff QR Passes."
                                },
                                fontSize = 11.sp,
                                textAlign = TextAlign.Center
                            )
                            OutlinedButton(
                                onClick = { permissionLauncher.launch(Manifest.permission.CAMERA) },
                                modifier = Modifier.height(36.dp)
                            ) {
                                Text("Enable Camera", fontSize = 11.sp, fontWeight = FontWeight.Bold)
                            }
                        }
                    }
                }

                // Manual QR Payload / Staff ID entry
                OutlinedTextField(
                    value = scannedOrEnteredCode,
                    onValueChange = {
                        scannedOrEnteredCode = it
                        lastVerifiedRecord = null
                        parseErrorMessage = null
                    },
                    label = { Text("Staff ID or QR Payload", fontSize = 11.sp) },
                    placeholder = { Text("e.g. DRV-001 or JFD-STF|DRV-001|...", fontSize = 11.sp) },
                    trailingIcon = {
                        if (scannedOrEnteredCode.isNotBlank()) {
                            IconButton(onClick = {
                                scannedOrEnteredCode = ""
                                lastVerifiedRecord = null
                                parseErrorMessage = null
                            }) {
                                Icon(Icons.Default.Refresh, contentDescription = "Clear scanned code", modifier = Modifier.size(18.dp))
                            }
                        }
                    },
                    singleLine = true,
                    modifier = Modifier
                        .fillMaxWidth()
                        .testTag("input_shift_qr_code")
                )

                // Quick Staff Select Chips for instant desk verification
                Text(
                    text = "Quick Select Staff Badge:",
                    fontSize = 10.sp,
                    fontWeight = FontWeight.Bold,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .horizontalScroll(rememberScrollState()),
                    horizontalArrangement = Arrangement.spacedBy(6.dp)
                ) {
                    allStaff.take(8).forEach { staff ->
                        AssistChip(
                            onClick = {
                                scannedOrEnteredCode = StaffQrIdentityCodec.encodeStaffQrPayload(staff)
                                lastVerifiedRecord = null
                                parseErrorMessage = null
                            },
                            label = { Text("${staff.id} • ${staff.fullName.substringBefore(" ")}", fontSize = 10.sp) },
                            modifier = Modifier.testTag("chip_quick_staff_qr_${staff.id}")
                        )
                    }
                }

                // Live Match Result Feedback
                if (liveParseResult is StaffQrParseResult.NotFound) {
                    Surface(
                        color = StrokeRedLight,
                        border = BorderStroke(1.dp, StrokeRedBorder),
                        shape = RoundedCornerShape(10.dp),
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Row(
                            modifier = Modifier.padding(10.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Icon(Icons.Default.ErrorOutline, contentDescription = null, tint = StrokeRed, modifier = Modifier.size(18.dp))
                            Spacer(modifier = Modifier.width(8.dp))
                            Text(
                                text = liveParseResult.reason,
                                fontSize = 11.sp,
                                color = StrokeRed,
                                fontWeight = FontWeight.SemiBold
                            )
                        }
                    }
                } else if (matchedStaff != null) {
                    Surface(
                        color = EmeraldGreenIce,
                        border = BorderStroke(1.5.dp, ForestGreenPrimary),
                        shape = RoundedCornerShape(12.dp),
                        modifier = Modifier
                            .fillMaxWidth()
                            .testTag("matched_staff_qr_preview")
                    ) {
                        Column(modifier = Modifier.padding(10.dp), verticalArrangement = Arrangement.spacedBy(4.dp)) {
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Row(verticalAlignment = Alignment.CenterVertically) {
                                    Icon(Icons.Default.CheckCircle, contentDescription = null, tint = ForestGreenPrimary, modifier = Modifier.size(18.dp))
                                    Spacer(modifier = Modifier.width(6.dp))
                                    Text(
                                        text = "${matchedStaff.fullName} (${matchedStaff.id})",
                                        fontWeight = FontWeight.ExtraBold,
                                        fontSize = 13.sp,
                                        color = Navy900
                                    )
                                }
                                Text(
                                    text = matchedStaff.branch,
                                    fontSize = 10.sp,
                                    fontWeight = FontWeight.Bold,
                                    color = ForestGreenPrimary
                                )
                            }
                            Text(
                                text = "${matchedStaff.role.title} • ${matchedStaff.department.displayName}",
                                fontSize = 10.5.sp,
                                color = ForestGreenDark,
                                fontWeight = FontWeight.Medium
                            )
                            if (matchedRosterShift != null) {
                                Text(
                                    text = "Roster Match: ${matchedRosterShift.shiftType} (${matchedRosterShift.startTime}-${matchedRosterShift.endTime}) • ${matchedRosterShift.availabilityStatus}",
                                    fontSize = 10.sp,
                                    color = Navy900,
                                    fontWeight = FontWeight.SemiBold
                                )
                            }
                        }
                    }
                }

                // Check-In vs Check-Out Selector
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    ShiftAttendanceAction.entries.forEach { action ->
                        val isSelected = selectedAction == action
                        FilterChip(
                            selected = isSelected,
                            onClick = { selectedAction = action },
                            leadingIcon = {
                                Icon(
                                    imageVector = if (action == ShiftAttendanceAction.CHECK_IN) Icons.Default.Login else Icons.Default.Logout,
                                    contentDescription = null,
                                    modifier = Modifier.size(15.dp)
                                )
                            },
                            label = { Text(action.label, fontSize = 11.sp, fontWeight = FontWeight.Bold) },
                            colors = FilterChipDefaults.filterChipColors(
                                selectedContainerColor = if (action == ShiftAttendanceAction.CHECK_IN) ForestGreenPrimary else StrokeRed,
                                selectedLabelColor = Color.White,
                                selectedLeadingIconColor = Color.White
                            ),
                            modifier = Modifier
                                .weight(1f)
                                .testTag("chip_attendance_${action.name.lowercase()}")
                        )
                    }
                }

                // 24/7 Shift Window Selector
                Text(
                    text = "24/7 Shift Window:",
                    fontSize = 10.sp,
                    fontWeight = FontWeight.Bold,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
                FlowRow(
                    horizontalArrangement = Arrangement.spacedBy(6.dp),
                    verticalArrangement = Arrangement.spacedBy(6.dp)
                ) {
                    shiftWindowOptions.forEach { windowLabel ->
                        FilterChip(
                            selected = selectedShiftWindow == windowLabel,
                            onClick = { selectedShiftWindow = windowLabel },
                            leadingIcon = {
                                Icon(Icons.Default.Schedule, contentDescription = null, modifier = Modifier.size(13.dp))
                            },
                            label = { Text(windowLabel, fontSize = 10.sp) }
                        )
                    }
                }

                // Checkpoint & Notes
                FlowRow(
                    horizontalArrangement = Arrangement.spacedBy(6.dp),
                    verticalArrangement = Arrangement.spacedBy(4.dp)
                ) {
                    defaultCheckpoints.forEach { cp ->
                        AssistChip(
                            onClick = { checkpointInput = cp },
                            label = { Text(cp, fontSize = 9.5.sp) }
                        )
                    }
                }

                OutlinedTextField(
                    value = checkpointInput,
                    onValueChange = { checkpointInput = it },
                    label = { Text("Verification Checkpoint", fontSize = 11.sp) },
                    singleLine = true,
                    modifier = Modifier.fillMaxWidth()
                )

                OutlinedTextField(
                    value = notesInput,
                    onValueChange = { notesInput = it },
                    label = { Text("Shift Notes (Optional)", fontSize = 11.sp) },
                    placeholder = { Text("e.g. Full uniform, sober & handover checked", fontSize = 11.sp) },
                    singleLine = true,
                    modifier = Modifier.fillMaxWidth()
                )

                if (parseErrorMessage != null) {
                    Text(
                        text = parseErrorMessage!!,
                        fontSize = 11.sp,
                        color = StrokeRed,
                        fontWeight = FontWeight.Bold
                    )
                }

                if (lastVerifiedRecord != null) {
                    Surface(
                        color = EmeraldLight,
                        border = BorderStroke(1.dp, EmeraldSuccess),
                        shape = RoundedCornerShape(10.dp),
                        modifier = Modifier
                            .fillMaxWidth()
                            .testTag("qr_attendance_verified_banner")
                    ) {
                        Text(
                            text = "✅ ${lastVerifiedRecord!!.action.label} logged for ${lastVerifiedRecord!!.staffName} at ${lastVerifiedRecord!!.checkpointLocation} (${lastVerifiedRecord!!.timestampFormatted}).",
                            fontSize = 11.sp,
                            fontWeight = FontWeight.Bold,
                            color = ForestGreenDark,
                            modifier = Modifier.padding(10.dp)
                        )
                    }
                }

                if (recentLogs.isNotEmpty()) {
                    Text(
                        text = "Latest Verified Check-Ins (${recentLogs.size} total):",
                        fontSize = 10.sp,
                        fontWeight = FontWeight.Bold,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                    recentLogs.take(2).forEach { rec ->
                        Text(
                            text = "• ${rec.staffName} (${rec.staffId}) — ${rec.action.label} @ ${rec.checkpointLocation} (${rec.timestampFormatted})",
                            fontSize = 9.5.sp,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    }
                }
            }
        },
        confirmButton = {
            Button(
                onClick = {
                    val result = onVerifyAttendance(
                        scannedOrEnteredCode,
                        selectedAction,
                        checkpointInput,
                        matchedRosterShift?.id,
                        selectedShiftWindow,
                        notesInput
                    )
                    result.onSuccess { record ->
                        lastVerifiedRecord = record
                        parseErrorMessage = null
                        scannedOrEnteredCode = ""
                        notesInput = ""
                    }.onFailure { err ->
                        parseErrorMessage = err.message ?: "Unable to verify staff QR code."
                    }
                },
                enabled = matchedStaff != null,
                colors = ButtonDefaults.buttonColors(containerColor = ForestGreenPrimary),
                modifier = Modifier.testTag("btn_confirm_qr_shift_attendance")
            ) {
                Text("Verify Attendance", fontWeight = FontWeight.Bold)
            }
        },
        dismissButton = {
            TextButton(onClick = onDismiss) {
                Text("Close")
            }
        }
    )
}

@Composable
fun ShiftAttendanceVerificationSection(
    attendanceLogs: List<ShiftAttendanceRecord>,
    canVerifyAttendance: Boolean,
    onOpenScanner: () -> Unit,
    modifier: Modifier = Modifier
) {
    Card(
        shape = RoundedCornerShape(14.dp),
        colors = CardDefaults.cardColors(containerColor = PureWhite),
        border = BorderStroke(1.2.dp, ForestGreenPrimary.copy(alpha = 0.45f)),
        modifier = modifier
            .fillMaxWidth()
            .testTag("roster_qr_attendance_ledger_card")
    ) {
        Column(modifier = Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Row(verticalAlignment = Alignment.CenterVertically, modifier = Modifier.weight(1f)) {
                    Icon(
                        imageVector = Icons.Default.VerifiedUser,
                        contentDescription = null,
                        tint = ForestGreenPrimary,
                        modifier = Modifier.size(20.dp)
                    )
                    Spacer(modifier = Modifier.width(8.dp))
                    Column {
                        Text(
                            text = "24/7 QR Shift Attendance Ledger",
                            fontWeight = FontWeight.Bold,
                            fontSize = 13.5.sp,
                            color = Navy900
                        )
                        Text(
                            text = "${attendanceLogs.size} ZXing badge scan(s) logged across Day & Night Vigils",
                            fontSize = 10.sp,
                            color = Color(0xFF475569)
                        )
                    }
                }

                if (canVerifyAttendance) {
                    Button(
                        onClick = onOpenScanner,
                        colors = ButtonDefaults.buttonColors(containerColor = ForestGreenPrimary),
                        shape = RoundedCornerShape(8.dp),
                        contentPadding = PaddingValues(horizontal = 10.dp, vertical = 6.dp),
                        modifier = Modifier.testTag("btn_ledger_scan_staff_qr")
                    ) {
                        Icon(Icons.Default.QrCodeScanner, contentDescription = null, modifier = Modifier.size(14.dp))
                        Spacer(modifier = Modifier.width(4.dp))
                        Text("Scan QR", fontSize = 11.sp, fontWeight = FontWeight.Bold)
                    }
                }
            }

            if (attendanceLogs.isEmpty()) {
                Text(
                    text = "No QR attendance scans recorded yet for this shift cycle.",
                    fontSize = 11.sp,
                    color = Color(0xFF64748B)
                )
            } else {
                attendanceLogs.take(4).forEach { rec ->
                    val isCheckIn = rec.action == ShiftAttendanceAction.CHECK_IN
                    Surface(
                        color = if (isCheckIn) EmeraldGreenIce else Color(0xFFF8FAFC),
                        border = BorderStroke(
                            1.dp,
                            if (isCheckIn) BorderLightGreen else Color(0xFFE2E8F0)
                        ),
                        shape = RoundedCornerShape(8.dp),
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Row(
                            modifier = Modifier.padding(horizontal = 10.dp, vertical = 7.dp),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Column(modifier = Modifier.weight(1f)) {
                                Text(
                                    text = "${rec.staffName} (${rec.staffId}) • ${rec.action.label}",
                                    fontSize = 11.sp,
                                    fontWeight = FontWeight.Bold,
                                    color = Navy900
                                )
                                Text(
                                    text = "${rec.shiftWindowLabel} • ${rec.checkpointLocation}",
                                    fontSize = 9.5.sp,
                                    color = Color(0xFF475569)
                                )
                                Text(
                                    text = "Verified by ${rec.verifiedByName} • ${rec.timestampFormatted}",
                                    fontSize = 9.sp,
                                    color = ForestGreenPrimary,
                                    fontWeight = FontWeight.SemiBold
                                )
                            }
                            Surface(
                                color = if (isCheckIn) EmeraldSuccess else StrokeRed,
                                shape = RoundedCornerShape(6.dp)
                            ) {
                                Text(
                                    text = if (isCheckIn) "IN ✓" else "OUT",
                                    color = Color.White,
                                    fontSize = 9.sp,
                                    fontWeight = FontWeight.ExtraBold,
                                    modifier = Modifier.padding(horizontal = 7.dp, vertical = 3.dp)
                                )
                            }
                        }
                    }
                }
            }
        }
    }
}
