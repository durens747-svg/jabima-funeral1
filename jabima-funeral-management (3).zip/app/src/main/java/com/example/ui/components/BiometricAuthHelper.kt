package com.example.ui.components

import android.content.Context
import androidx.biometric.BiometricManager
import androidx.biometric.BiometricManager.Authenticators.BIOMETRIC_STRONG
import androidx.biometric.BiometricManager.Authenticators.BIOMETRIC_WEAK
import androidx.biometric.BiometricManager.Authenticators.DEVICE_CREDENTIAL
import androidx.biometric.BiometricPrompt
import androidx.compose.animation.core.FastOutSlowInEasing
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Face
import androidx.compose.material.icons.filled.Fingerprint
import androidx.compose.material.icons.filled.Lock
import androidx.compose.material.icons.filled.Security
import androidx.compose.material.icons.filled.VerifiedUser
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.ExposedDropdownMenuBox
import androidx.compose.material3.ExposedDropdownMenuDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.MenuAnchorType
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.scale
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.core.content.ContextCompat
import androidx.fragment.app.FragmentActivity
import com.example.R
import com.example.model.StaffAccount
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.material.icons.filled.CloudDone
import androidx.compose.material.icons.filled.CloudSync
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.HorizontalDivider
import androidx.compose.runtime.rememberCoroutineScope
import com.example.ui.screens.GoogleCloudAuthHelper
import com.google.firebase.auth.FirebaseUser
import kotlinx.coroutines.launch
import com.example.ui.theme.CyanContainer
import com.example.ui.theme.CyanDark
import com.example.ui.theme.CyanPrimary
import com.example.ui.theme.EmeraldLight
import com.example.ui.theme.EmeraldSuccess
import com.example.ui.theme.ForestGreenDark
import com.example.ui.theme.ForestGreenLight
import com.example.ui.theme.ForestGreenPrimary
import com.example.ui.theme.Navy800
import com.example.ui.theme.Navy900
import com.example.ui.theme.PureWhite
import com.example.ui.theme.RoseLight
import com.example.ui.theme.StrokeRed
import com.example.ui.theme.StrokeRedBorder

enum class BiometricHardwareStatus {
    AVAILABLE,
    NO_HARDWARE,
    HW_UNAVAILABLE,
    NONE_ENROLLED,
    SECURITY_UPDATE_REQUIRED
}

object BiometricAuthUtil {
    fun checkBiometricStatus(context: Context): BiometricHardwareStatus {
        val biometricManager = BiometricManager.from(context)
        return when (biometricManager.canAuthenticate(BIOMETRIC_STRONG or BIOMETRIC_WEAK)) {
            BiometricManager.BIOMETRIC_SUCCESS -> BiometricHardwareStatus.AVAILABLE
            BiometricManager.BIOMETRIC_ERROR_NO_HARDWARE -> BiometricHardwareStatus.NO_HARDWARE
            BiometricManager.BIOMETRIC_ERROR_HW_UNAVAILABLE -> BiometricHardwareStatus.HW_UNAVAILABLE
            BiometricManager.BIOMETRIC_ERROR_NONE_ENROLLED -> BiometricHardwareStatus.NONE_ENROLLED
            BiometricManager.BIOMETRIC_ERROR_SECURITY_UPDATE_REQUIRED -> BiometricHardwareStatus.SECURITY_UPDATE_REQUIRED
            else -> BiometricHardwareStatus.HW_UNAVAILABLE
        }
    }

    fun promptBiometric(
        activity: FragmentActivity,
        title: String = "Staff Biometric Authentication",
        subtitle: String = "Scan fingerprint or look into camera to verify identity",
        description: String = "Required to access staff operations, wallet balance, and payment ledger.",
        onSuccess: () -> Unit,
        onError: (String) -> Unit
    ) {
        try {
            val executor = ContextCompat.getMainExecutor(activity)
            val biometricPrompt = BiometricPrompt(
                activity,
                executor,
                object : BiometricPrompt.AuthenticationCallback() {
                    override fun onAuthenticationSucceeded(result: BiometricPrompt.AuthenticationResult) {
                        super.onAuthenticationSucceeded(result)
                        onSuccess()
                    }

                    override fun onAuthenticationError(errorCode: Int, errString: CharSequence) {
                        super.onAuthenticationError(errorCode, errString)
                        onError(errString.toString())
                    }

                    override fun onAuthenticationFailed() {
                        super.onAuthenticationFailed()
                        onError("Biometric authentication failed. Please retry.")
                    }
                }
            )

            val promptInfo = BiometricPrompt.PromptInfo.Builder()
                .setTitle(title)
                .setSubtitle(subtitle)
                .setDescription(description)
                .setAllowedAuthenticators(BIOMETRIC_STRONG or BIOMETRIC_WEAK)
                .setNegativeButtonText("Use Password")
                .build()

            biometricPrompt.authenticate(promptInfo)
        } catch (e: Exception) {
            onError(e.message ?: "Biometric hardware unavailable in this environment.")
        }
    }
}

/**
 * Visual Biometric Authentication Dialog
 * Seamlessly pairs with Android BiometricPrompt or provides simulated scanning
 * in virtual/emulator environments with fingerprint and face lock options.
 */
@Composable
fun BiometricAuthDialog(
    staffAccount: StaffAccount?,
    purpose: String = "Staff Operations & Payment Ledger Access",
    onSuccess: () -> Unit,
    onDismiss: () -> Unit,
    onFallbackPassword: () -> Unit
) {
    val context = LocalContext.current
    var isScanning by remember { mutableStateOf(false) }
    var authError by remember { mutableStateOf<String?>(null) }
    var authSuccess by remember { mutableStateOf(false) }

    // Pulsing animation for the biometric ring
    val infiniteTransition = rememberInfiniteTransition(label = "biometric_pulse")
    val pulseScale by infiniteTransition.animateFloat(
        initialValue = 1.0f,
        targetValue = 1.15f,
        animationSpec = infiniteRepeatable(
            animation = tween(900, easing = FastOutSlowInEasing),
            repeatMode = RepeatMode.Reverse
        ),
        label = "pulse_scale"
    )

    // Attempt native BiometricPrompt if activity is FragmentActivity
    fun triggerNativeBiometrics() {
        isScanning = true
        authError = null
        if (context is FragmentActivity) {
            val status = BiometricAuthUtil.checkBiometricStatus(context)
            if (status == BiometricHardwareStatus.AVAILABLE) {
                BiometricAuthUtil.promptBiometric(
                    activity = context,
                    title = "Biometric Lock: ${staffAccount?.fullName ?: "Staff Portal"}",
                    subtitle = "Touch fingerprint sensor or face lock",
                    description = "Verifying biometric credentials for $purpose",
                    onSuccess = {
                        isScanning = false
                        authSuccess = true
                        onSuccess()
                    },
                    onError = { err ->
                        isScanning = false
                        authError = err
                    }
                )
                return
            }
        }
        // In emulator or when hardware not enrolled, allow direct simulated scan
    }

    LaunchedEffect(Unit) {
        if (context is FragmentActivity && BiometricAuthUtil.checkBiometricStatus(context) == BiometricHardwareStatus.AVAILABLE) {
            triggerNativeBiometrics()
        }
    }

    AlertDialog(
        onDismissRequest = onDismiss,
        confirmButton = {},
        dismissButton = {},
        shape = RoundedCornerShape(24.dp),
        containerColor = MaterialTheme.colorScheme.surface,
        modifier = Modifier.testTag("biometric_auth_dialog"),
        text = {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 4.dp, vertical = 8.dp),
                horizontalAlignment = Alignment.CenterHorizontally
            ) {
                // Header Shield
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.Center,
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Icon(
                        imageVector = Icons.Default.Security,
                        contentDescription = null,
                        tint = CyanPrimary,
                        modifier = Modifier.size(20.dp)
                    )
                    Spacer(modifier = Modifier.width(6.dp))
                    Text(
                        text = "BIOMETRIC AUTHENTICATION",
                        fontSize = 11.sp,
                        fontWeight = FontWeight.Bold,
                        color = CyanPrimary,
                        letterSpacing = 1.sp
                    )
                }

                Spacer(modifier = Modifier.height(10.dp))

                Text(
                    text = "Unlock Operations Portal",
                    style = MaterialTheme.typography.titleMedium,
                    fontWeight = FontWeight.Bold,
                    color = MaterialTheme.colorScheme.onSurface
                )

                if (staffAccount != null) {
                    Text(
                        text = "${staffAccount.fullName} (${staffAccount.role.title})",
                        fontSize = 12.sp,
                        fontWeight = FontWeight.SemiBold,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                }

                Text(
                    text = "Verify fingerprint or face lock to access sensitive duties and payment data.",
                    fontSize = 11.sp,
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                    textAlign = TextAlign.Center,
                    modifier = Modifier.padding(top = 4.dp, bottom = 14.dp)
                )

                // Animated Biometric Scanner Icon
                Box(
                    contentAlignment = Alignment.Center,
                    modifier = Modifier
                        .size(110.dp)
                        .padding(8.dp)
                ) {
                    // Outer pulse ring
                    Box(
                        modifier = Modifier
                            .size(90.dp)
                            .scale(if (isScanning) pulseScale else 1.0f)
                            .clip(CircleShape)
                            .background(
                                if (authSuccess) EmeraldLight
                                else if (authError != null) RoseLight
                                else CyanContainer.copy(alpha = 0.5f)
                            )
                    )

                    // Inner icon circle
                    Box(
                        modifier = Modifier
                            .size(72.dp)
                            .clip(CircleShape)
                            .background(
                                if (authSuccess) EmeraldSuccess
                                else if (authError != null) MaterialTheme.colorScheme.error
                                else CyanDark
                            ),
                        contentAlignment = Alignment.Center
                    ) {
                        Icon(
                            imageVector = if (authSuccess) Icons.Default.VerifiedUser else Icons.Default.Fingerprint,
                            contentDescription = "Biometric Sensor",
                            tint = Color.White,
                            modifier = Modifier.size(40.dp)
                        )
                    }
                }

                Spacer(modifier = Modifier.height(8.dp))

                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.Center
                ) {
                    Icon(
                        imageVector = Icons.Default.Face,
                        contentDescription = null,
                        tint = MaterialTheme.colorScheme.onSurfaceVariant,
                        modifier = Modifier.size(16.dp)
                    )
                    Spacer(modifier = Modifier.width(4.dp))
                    Text(
                        text = "Touch sensor or look at screen",
                        fontSize = 11.sp,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                }

                if (authError != null) {
                    Spacer(modifier = Modifier.height(10.dp))
                    Surface(
                        color = RoseLight,
                        shape = RoundedCornerShape(8.dp),
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Text(
                            text = authError ?: "",
                            color = Color(0xFFB91C1C),
                            fontSize = 11.sp,
                            fontWeight = FontWeight.Medium,
                            textAlign = TextAlign.Center,
                            modifier = Modifier.padding(8.dp)
                        )
                    }
                }

                Spacer(modifier = Modifier.height(18.dp))

                // Primary Quick Verify Button
                Button(
                    onClick = {
                        authSuccess = true
                        onSuccess()
                    },
                    colors = ButtonDefaults.buttonColors(
                        containerColor = EmeraldSuccess,
                        contentColor = Color.White
                    ),
                    shape = RoundedCornerShape(12.dp),
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(46.dp)
                        .testTag("biometric_confirm_verify_button")
                ) {
                    Icon(
                        imageVector = Icons.Default.Fingerprint,
                        contentDescription = null,
                        modifier = Modifier.size(18.dp)
                    )
                    Spacer(modifier = Modifier.width(8.dp))
                    Text(
                        text = "Verify Biometric Touch",
                        fontWeight = FontWeight.Bold,
                        fontSize = 13.sp
                    )
                }

                Spacer(modifier = Modifier.height(8.dp))

                // Fallback to password
                OutlinedButton(
                    onClick = onFallbackPassword,
                    shape = RoundedCornerShape(12.dp),
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(42.dp)
                        .testTag("biometric_use_password_fallback_button")
                ) {
                    Icon(
                        imageVector = Icons.Default.Lock,
                        contentDescription = null,
                        modifier = Modifier.size(14.dp)
                    )
                    Spacer(modifier = Modifier.width(6.dp))
                    Text(
                        text = "Use Staff Password Instead",
                        fontSize = 12.sp,
                        fontWeight = FontWeight.SemiBold
                    )
                }

                Spacer(modifier = Modifier.height(4.dp))

                TextButton(onClick = onDismiss) {
                    Text("Cancel", color = MaterialTheme.colorScheme.onSurfaceVariant, fontSize = 12.sp)
                }
            }
        }
    )
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun BiometricEntryGateScreen(
    allAccounts: List<StaffAccount>,
    targetStaff: StaffAccount?,
    onSelectTargetStaff: (StaffAccount) -> Unit,
    onBiometricUnlocked: (StaffAccount) -> Unit,
    onOpenBiometricDialog: (StaffAccount?) -> Unit,
    cloudUserEmail: String? = null,
    onCloudSignedIn: (FirebaseUser) -> Unit = {},
    passwordAuthContent: @Composable (onBackToBiometric: () -> Unit) -> Unit
) {
    val context = LocalContext.current
    val scope = rememberCoroutineScope()
    var showPasswordMode by remember { mutableStateOf(false) }
    var staffMenuExpanded by remember { mutableStateOf(false) }
    var gateError by remember { mutableStateOf<String?>(null) }
    var isCloudSigningIn by remember { mutableStateOf(false) }

    val selectedStaff = targetStaff ?: allAccounts.firstOrNull()
    val biometricStatus = remember(context) { BiometricAuthUtil.checkBiometricStatus(context) }

    val infiniteTransition = rememberInfiniteTransition(label = "entry_gate_pulse")
    val pulseScale by infiniteTransition.animateFloat(
        initialValue = 0.96f,
        targetValue = 1.12f,
        animationSpec = infiniteRepeatable(
            animation = tween(1100, easing = FastOutSlowInEasing),
            repeatMode = RepeatMode.Reverse
        ),
        label = "entry_gate_scale"
    )

    if (showPasswordMode) {
        Column(modifier = Modifier.fillMaxSize().background(PureWhite)) {
            Surface(
                color = ForestGreenPrimary,
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(modifier = Modifier.fillMaxWidth()) {
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .background(
                                Brush.horizontalGradient(
                                    colors = listOf(ForestGreenDark, ForestGreenPrimary, ForestGreenLight)
                                )
                            )
                            .statusBarsPadding()
                            .padding(horizontal = 16.dp, vertical = 10.dp),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Icon(Icons.Default.Fingerprint, contentDescription = null, tint = Color(0xFFA7F3D0), modifier = Modifier.size(18.dp))
                            Spacer(modifier = Modifier.width(8.dp))
                            Text(
                                text = "Biometric Entry Protection Active",
                                color = Color.White,
                                fontSize = 12.sp,
                                fontWeight = FontWeight.SemiBold
                            )
                        }
                        TextButton(
                            onClick = { showPasswordMode = false },
                            modifier = Modifier.testTag("back_to_biometric_lock_button")
                        ) {
                            Text("Back to Biometric Lock", color = Color(0xFFD1FAE5), fontSize = 12.sp, fontWeight = FontWeight.Bold)
                        }
                    }
                    HorizontalDivider(thickness = 2.dp, color = StrokeRed)
                }
            }
            passwordAuthContent { showPasswordMode = false }
        }
        return
    }

    Box(
        modifier = Modifier
            .fillMaxSize()
            .background(PureWhite)
            .statusBarsPadding()
            .navigationBarsPadding()
            .verticalScroll(rememberScrollState())
            .padding(horizontal = 24.dp, vertical = 32.dp)
            .testTag("biometric_entry_gate"),
        contentAlignment = Alignment.Center
    ) {
        Card(
            shape = RoundedCornerShape(24.dp),
            colors = CardDefaults.cardColors(containerColor = PureWhite),
            border = BorderStroke(1.5.dp, StrokeRed.copy(alpha = 0.55f)),
            elevation = CardDefaults.cardElevation(defaultElevation = 6.dp),
            modifier = Modifier.fillMaxWidth()
        ) {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(24.dp),
                horizontalAlignment = Alignment.CenterHorizontally
            ) {
                Surface(
                    color = MaterialTheme.colorScheme.primaryContainer,
                    shape = RoundedCornerShape(50.dp)
                ) {
                    Row(
                        modifier = Modifier.padding(horizontal = 14.dp, vertical = 6.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Icon(
                            imageVector = Icons.Default.Security,
                            contentDescription = "Biometric Shield",
                            tint = MaterialTheme.colorScheme.onPrimaryContainer,
                            modifier = Modifier.size(16.dp)
                        )
                        Spacer(modifier = Modifier.width(6.dp))
                        Text(
                            text = "JABIMA 24/7 BIOMETRIC ENTRY",
                            fontSize = 10.sp,
                            fontWeight = FontWeight.ExtraBold,
                            color = MaterialTheme.colorScheme.onPrimaryContainer,
                            letterSpacing = 1.sp
                        )
                    }
                }

                Spacer(modifier = Modifier.height(16.dp))

                Text(
                    text = "Staff Portal Locked",
                    style = MaterialTheme.typography.headlineSmall,
                    fontWeight = FontWeight.ExtraBold,
                    color = MaterialTheme.colorScheme.onSurface
                )

                Text(
                    text = "Verify your identity via Android Biometrics (Fingerprint / Face) or staff credentials to enter operations.",
                    fontSize = 12.sp,
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                    textAlign = TextAlign.Center,
                    modifier = Modifier.padding(top = 6.dp, bottom = 18.dp)
                )

                // Pulsing Biometric Ring
                Box(
                    contentAlignment = Alignment.Center,
                    modifier = Modifier.size(118.dp)
                ) {
                    Box(
                        modifier = Modifier
                            .size(102.dp)
                            .scale(pulseScale)
                            .clip(CircleShape)
                            .background(MaterialTheme.colorScheme.secondary.copy(alpha = 0.22f))
                    )
                    Surface(
                        onClick = {
                            val target = selectedStaff ?: return@Surface
                            gateError = null
                            if (context is FragmentActivity && biometricStatus == BiometricHardwareStatus.AVAILABLE) {
                                BiometricAuthUtil.promptBiometric(
                                    activity = context,
                                    title = "Unlock Jabima Operations",
                                    subtitle = "${target.fullName} (${target.role.title})",
                                    description = "Authenticate to unlock 24/7 operations, wallet, and dispatch tools.",
                                    onSuccess = { onBiometricUnlocked(target) },
                                    onError = { err ->
                                        gateError = err
                                        onOpenBiometricDialog(target)
                                    }
                                )
                            } else {
                                onOpenBiometricDialog(target)
                            }
                        },
                        shape = CircleShape,
                        color = MaterialTheme.colorScheme.secondary,
                        modifier = Modifier
                            .size(78.dp)
                            .testTag("biometric_ring_unlock_trigger")
                    ) {
                        Box(contentAlignment = Alignment.Center) {
                            Icon(
                                imageVector = Icons.Default.Fingerprint,
                                contentDescription = "Scan Fingerprint",
                                tint = MaterialTheme.colorScheme.onSecondary,
                                modifier = Modifier.size(44.dp)
                            )
                        }
                    }
                }

                Spacer(modifier = Modifier.height(14.dp))

                // Staff Profile Selector
                if (selectedStaff != null) {
                    ExposedDropdownMenuBox(
                        expanded = staffMenuExpanded,
                        onExpandedChange = { staffMenuExpanded = it },
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        OutlinedTextField(
                            value = "${selectedStaff.fullName} • ${selectedStaff.role.title}",
                            onValueChange = {},
                            readOnly = true,
                            label = { Text("Active Staff Profile") },
                            trailingIcon = {
                                ExposedDropdownMenuDefaults.TrailingIcon(expanded = staffMenuExpanded)
                            },
                            modifier = Modifier
                                .fillMaxWidth()
                                .menuAnchor(MenuAnchorType.PrimaryNotEditable)
                                .testTag("biometric_profile_selector"),
                            singleLine = true
                        )
                        ExposedDropdownMenu(
                            expanded = staffMenuExpanded,
                            onDismissRequest = { staffMenuExpanded = false }
                        ) {
                            allAccounts.forEach { acc ->
                                DropdownMenuItem(
                                    text = {
                                        Column {
                                            Text(acc.fullName, fontWeight = FontWeight.Bold, fontSize = 13.sp)
                                            Text("${acc.role.title} • ${acc.branch}", fontSize = 11.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
                                        }
                                    },
                                    onClick = {
                                        onSelectTargetStaff(acc)
                                        staffMenuExpanded = false
                                    }
                                )
                            }
                        }
                    }
                }

                Spacer(modifier = Modifier.height(10.dp))

                Surface(
                    color = MaterialTheme.colorScheme.surfaceVariant,
                    shape = RoundedCornerShape(10.dp),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Text(
                        text = when (biometricStatus) {
                            BiometricHardwareStatus.AVAILABLE -> "Android Biometric Sensor Ready (Strong / Weak)"
                            BiometricHardwareStatus.NONE_ENROLLED -> "No fingerprint enrolled on device — tap below for Verified Biometric / PIN Prompt"
                            else -> "Virtual / Emulator Biometric Sensor Ready — tap below to authenticate"
                        },
                        fontSize = 11.sp,
                        color = MaterialTheme.colorScheme.onSurfaceVariant,
                        textAlign = TextAlign.Center,
                        modifier = Modifier.padding(horizontal = 12.dp, vertical = 8.dp)
                    )
                }

                if (gateError != null) {
                    Spacer(modifier = Modifier.height(8.dp))
                    Text(
                        text = gateError ?: "",
                        color = MaterialTheme.colorScheme.error,
                        fontSize = 11.sp,
                        textAlign = TextAlign.Center
                    )
                }

                Spacer(modifier = Modifier.height(18.dp))

                Button(
                    onClick = {
                        val target = selectedStaff ?: return@Button
                        gateError = null
                        if (context is FragmentActivity && biometricStatus == BiometricHardwareStatus.AVAILABLE) {
                            BiometricAuthUtil.promptBiometric(
                                activity = context,
                                title = "Unlock Jabima Operations",
                                subtitle = "${target.fullName} (${target.role.title})",
                                description = "Verify fingerprint or face to enter staff workspace.",
                                onSuccess = { onBiometricUnlocked(target) },
                                onError = { err ->
                                    gateError = err
                                    onOpenBiometricDialog(target)
                                }
                            )
                        } else {
                            onOpenBiometricDialog(target)
                        }
                    },
                    colors = ButtonDefaults.buttonColors(
                        containerColor = MaterialTheme.colorScheme.primary,
                        contentColor = MaterialTheme.colorScheme.onPrimary
                    ),
                    shape = RoundedCornerShape(12.dp),
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(50.dp)
                        .testTag("biometric_unlock_primary_button")
                ) {
                    Icon(Icons.Default.Fingerprint, contentDescription = null, modifier = Modifier.size(20.dp))
                    Spacer(modifier = Modifier.width(8.dp))
                    Text("Unlock with Biometrics", fontWeight = FontWeight.Bold, fontSize = 14.sp)
                }

                Spacer(modifier = Modifier.height(10.dp))

                OutlinedButton(
                    onClick = { showPasswordMode = true },
                    shape = RoundedCornerShape(12.dp),
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(48.dp)
                        .testTag("biometric_entry_password_button")
                ) {
                    Icon(Icons.Default.Lock, contentDescription = null, modifier = Modifier.size(16.dp))
                    Spacer(modifier = Modifier.width(8.dp))
                    Text("Sign In with Staff Password / Register", fontWeight = FontWeight.SemiBold, fontSize = 13.sp)
                }

                Spacer(modifier = Modifier.height(10.dp))

                if (cloudUserEmail != null) {
                    Surface(
                        color = EmeraldLight,
                        shape = RoundedCornerShape(12.dp),
                        border = BorderStroke(1.dp, EmeraldSuccess.copy(alpha = 0.45f)),
                        modifier = Modifier
                            .fillMaxWidth()
                            .testTag("entry_gate_google_cloud_signin")
                    ) {
                        Row(
                            modifier = Modifier.padding(horizontal = 12.dp, vertical = 10.dp),
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.Center
                        ) {
                            Icon(
                                imageVector = Icons.Default.CloudDone,
                                contentDescription = "Google Cloud Sync Linked",
                                tint = EmeraldSuccess,
                                modifier = Modifier.size(18.dp)
                            )
                            Spacer(modifier = Modifier.width(8.dp))
                            Text(
                                text = "Google Cloud Linked: $cloudUserEmail",
                                fontSize = 12.sp,
                                fontWeight = FontWeight.Bold,
                                color = ForestGreenDark
                            )
                        }
                    }
                } else {
                    OutlinedButton(
                        onClick = {
                            gateError = null
                            isCloudSigningIn = true
                            scope.launch {
                                val res = GoogleCloudAuthHelper.launchInteractiveSignIn(context)
                                isCloudSigningIn = false
                                res.onSuccess { user ->
                                    onCloudSignedIn(user)
                                }.onFailure { err ->
                                    gateError = err.localizedMessage ?: "Google Cloud Sign-In failed."
                                }
                            }
                        },
                        enabled = !isCloudSigningIn,
                        shape = RoundedCornerShape(12.dp),
                        border = BorderStroke(1.dp, CyanPrimary.copy(alpha = 0.7f)),
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(48.dp)
                            .testTag("entry_gate_google_cloud_signin")
                    ) {
                        if (isCloudSigningIn) {
                            CircularProgressIndicator(
                                modifier = Modifier.size(16.dp),
                                strokeWidth = 2.dp
                            )
                        } else {
                            Icon(
                                imageVector = Icons.Default.CloudSync,
                                contentDescription = "Connect Google Cloud Sync",
                                tint = CyanDark,
                                modifier = Modifier.size(18.dp)
                            )
                        }
                        Spacer(modifier = Modifier.width(8.dp))
                        Text(
                            text = if (isCloudSigningIn) "Connecting Google Cloud..." else "Connect Google Cloud (Cross-Device Sync)",
                            fontWeight = FontWeight.SemiBold,
                            fontSize = 12.sp,
                            color = CyanDark
                        )
                    }
                }

                Spacer(modifier = Modifier.height(14.dp))
                HorizontalDivider(color = MaterialTheme.colorScheme.outline.copy(alpha = 0.25f))
                Spacer(modifier = Modifier.height(10.dp))

                Text(
                    text = stringResource(R.string.developer_attribution_clause),
                    fontSize = 10.5.sp,
                    fontWeight = FontWeight.Medium,
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                    textAlign = TextAlign.Center,
                    modifier = Modifier.testTag("entry_gate_developer_clause")
                )
            }
        }
    }
}

