package com.example.ui.components

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Build
import androidx.compose.material.icons.filled.Check
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.DirectionsCar
import androidx.compose.material.icons.filled.Security
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Checkbox
import androidx.compose.material3.CheckboxDefaults
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.ExposedDropdownMenuBox
import androidx.compose.material3.ExposedDropdownMenuDefaults
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.MenuAnchorType
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.window.Dialog
import com.example.model.FleetInspectionRecord
import com.example.model.JABIMA_FLEET
import com.example.ui.theme.EmeraldLight
import com.example.ui.theme.EmeraldSuccess
import com.example.ui.theme.Navy900
import com.example.ui.theme.PureWhite
import com.example.ui.theme.RoyalCobaltBlue
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import java.util.UUID

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun FleetInspectionDialog(
    initialVehicleReg: String? = null,
    defaultDriverName: String = "Peter Odhiambo (Driver)",
    onDismiss: () -> Unit,
    onSubmit: (FleetInspectionRecord) -> Unit
) {
    var selectedVehicle by remember { mutableStateOf(initialVehicleReg ?: JABIMA_FLEET.first()) }
    var vehicleDropdownExpanded by remember { mutableStateOf(false) }
    var inspectorName by remember { mutableStateOf(defaultDriverName) }
    var odometerText by remember { mutableStateOf("142850") }

    // 7 Pre-trip check items
    var checkDeckRollers by remember { mutableStateOf(true) }
    var checkHydraulicLift by remember { mutableStateOf(true) }
    var checkCeremonialFlags by remember { mutableStateOf(true) }
    var checkEngineFluids by remember { mutableStateOf(true) }
    var checkTires by remember { mutableStateOf(true) }
    var checkInteriorSanitized by remember { mutableStateOf(true) }
    var checkDriverUniform by remember { mutableStateOf(true) }

    var notesText by remember { mutableStateOf("Deck polished, velvet clean, hydraulic casket locks lubricated.") }

    val passedCount = listOf(
        checkDeckRollers,
        checkHydraulicLift,
        checkCeremonialFlags,
        checkEngineFluids,
        checkTires,
        checkInteriorSanitized,
        checkDriverUniform
    ).count { it }

    Dialog(onDismissRequest = onDismiss) {
        Card(
            shape = RoundedCornerShape(20.dp),
            colors = CardDefaults.cardColors(containerColor = PureWhite),
            modifier = Modifier
                .fillMaxWidth()
                .padding(vertical = 16.dp)
                .testTag("fleet_inspection_dialog")
        ) {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .verticalScroll(rememberScrollState())
                    .padding(20.dp)
            ) {
                // Header
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Surface(
                            color = RoyalCobaltBlue,
                            shape = CircleShape,
                            modifier = Modifier.size(40.dp)
                        ) {
                            Box(contentAlignment = Alignment.Center) {
                                Icon(
                                    imageVector = Icons.Default.Security,
                                    contentDescription = null,
                                    tint = Color.White,
                                    modifier = Modifier.size(22.dp)
                                )
                            }
                        }
                        Spacer(modifier = Modifier.width(10.dp))
                        Column {
                            Text(
                                text = "Pre-Cortege Inspection",
                                fontSize = 16.sp,
                                fontWeight = FontWeight.Bold,
                                color = Navy900
                            )
                            Text(
                                text = "7-Point Hearse Readiness & Safety Checklist",
                                fontSize = 11.sp,
                                color = Color(0xFF64748B)
                            )
                        }
                    }
                    IconButton(onClick = onDismiss, modifier = Modifier.size(32.dp)) {
                        Icon(Icons.Default.Close, contentDescription = "Close", tint = Color(0xFF64748B))
                    }
                }

                Spacer(modifier = Modifier.height(14.dp))

                // Vehicle Selector
                Text(
                    text = "Hearse Registration*",
                    fontSize = 12.sp,
                    fontWeight = FontWeight.Bold,
                    color = Color(0xFF334155)
                )
                Spacer(modifier = Modifier.height(6.dp))
                ExposedDropdownMenuBox(
                    expanded = vehicleDropdownExpanded,
                    onExpandedChange = { vehicleDropdownExpanded = it }
                ) {
                    OutlinedTextField(
                        value = selectedVehicle,
                        onValueChange = {},
                        readOnly = true,
                        trailingIcon = { ExposedDropdownMenuDefaults.TrailingIcon(expanded = vehicleDropdownExpanded) },
                        modifier = Modifier
                            .fillMaxWidth()
                            .menuAnchor(MenuAnchorType.PrimaryNotEditable),
                        shape = RoundedCornerShape(10.dp)
                    )
                    ExposedDropdownMenu(
                        expanded = vehicleDropdownExpanded,
                        onDismissRequest = { vehicleDropdownExpanded = false }
                    ) {
                        JABIMA_FLEET.forEach { fleetReg ->
                            DropdownMenuItem(
                                text = { Text(fleetReg, fontWeight = FontWeight.Bold) },
                                onClick = {
                                    selectedVehicle = fleetReg
                                    vehicleDropdownExpanded = false
                                }
                            )
                        }
                    }
                }

                Spacer(modifier = Modifier.height(12.dp))

                // Driver & Odometer Row
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    Column(modifier = Modifier.weight(1.3f)) {
                        Text(
                            text = "Inspector Driver*",
                            fontSize = 11.sp,
                            fontWeight = FontWeight.Bold,
                            color = Color(0xFF334155)
                        )
                        Spacer(modifier = Modifier.height(4.dp))
                        OutlinedTextField(
                            value = inspectorName,
                            onValueChange = { inspectorName = it },
                            modifier = Modifier.fillMaxWidth(),
                            shape = RoundedCornerShape(10.dp)
                        )
                    }
                    Column(modifier = Modifier.weight(1f)) {
                        Text(
                            text = "Odometer (km)*",
                            fontSize = 11.sp,
                            fontWeight = FontWeight.Bold,
                            color = Color(0xFF334155)
                        )
                        Spacer(modifier = Modifier.height(4.dp))
                        OutlinedTextField(
                            value = odometerText,
                            onValueChange = { odometerText = it.filter { ch -> ch.isDigit() } },
                            keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                            modifier = Modifier.fillMaxWidth(),
                            shape = RoundedCornerShape(10.dp)
                        )
                    }
                }

                Spacer(modifier = Modifier.height(14.dp))

                // 7 Checkbox Points
                Text(
                    text = "7-Point Verification ($passedCount/7 Completed)",
                    fontSize = 12.sp,
                    fontWeight = FontWeight.Bold,
                    color = if (passedCount == 7) EmeraldSuccess else RoyalCobaltBlue
                )
                Spacer(modifier = Modifier.height(8.dp))

                Surface(
                    color = Color(0xFFF8FAFC),
                    shape = RoundedCornerShape(12.dp),
                    border = BorderStroke(1.dp, Color(0xFFE2E8F0)),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Column(modifier = Modifier.padding(10.dp)) {
                        InspectionCheckboxItem(
                            title = "Deck Rollers & Casket Clamp Locks",
                            subtitle = "Smooth glide, secure locking pins, brass stops engaged",
                            checked = checkDeckRollers,
                            onCheckedChange = { checkDeckRollers = it }
                        )
                        InspectionCheckboxItem(
                            title = "Hydraulic Lift & Lowering Mechanism",
                            subtitle = "Hydraulic deck raises/lowers without fluid leakage",
                            checked = checkHydraulicLift,
                            onCheckedChange = { checkHydraulicLift = it }
                        )
                        InspectionCheckboxItem(
                            title = "Ceremonial Flags & Bonnet Ribbons",
                            subtitle = "Purple/gold cortege flags mounted & clean",
                            checked = checkCeremonialFlags,
                            onCheckedChange = { checkCeremonialFlags = it }
                        )
                        InspectionCheckboxItem(
                            title = "Engine Oil, Coolant & Brake Fluids",
                            subtitle = "Fluids at maximum level; radiator cold-start checked",
                            checked = checkEngineFluids,
                            onCheckedChange = { checkEngineFluids = it }
                        )
                        InspectionCheckboxItem(
                            title = "Tire Pressure & Spare Wheel Tread",
                            subtitle = "36 PSI verified; spare tire & jack loaded in bay",
                            checked = checkTires,
                            onCheckedChange = { checkTires = it }
                        )
                        InspectionCheckboxItem(
                            title = "Interior Sanitization & Velvet Cleanliness",
                            subtitle = "Disinfected after previous cortege; glass gleaming",
                            checked = checkInteriorSanitized,
                            onCheckedChange = { checkInteriorSanitized = it }
                        )
                        InspectionCheckboxItem(
                            title = "Driver Ceremonial Uniform & White Gloves",
                            subtitle = "Black suit, pressed white shirt, cap & gloves ready",
                            checked = checkDriverUniform,
                            onCheckedChange = { checkDriverUniform = it }
                        )
                    }
                }

                Spacer(modifier = Modifier.height(12.dp))

                // Notes
                Text(
                    text = "Inspection Notes",
                    fontSize = 12.sp,
                    fontWeight = FontWeight.Bold,
                    color = Color(0xFF334155)
                )
                Spacer(modifier = Modifier.height(4.dp))
                OutlinedTextField(
                    value = notesText,
                    onValueChange = { notesText = it },
                    modifier = Modifier.fillMaxWidth(),
                    shape = RoundedCornerShape(10.dp)
                )

                Spacer(modifier = Modifier.height(16.dp))

                // Actions
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    OutlinedButton(
                        onClick = onDismiss,
                        modifier = Modifier.weight(1f),
                        shape = RoundedCornerShape(10.dp)
                    ) {
                        Text("Cancel")
                    }

                    Button(
                        onClick = {
                            val record = FleetInspectionRecord(
                                id = "INSP-" + UUID.randomUUID().toString().take(6).uppercase(),
                                vehicleReg = selectedVehicle,
                                inspectorDriverName = inspectorName.ifBlank { "Peter Odhiambo" },
                                date = SimpleDateFormat("dd MMM yyyy", Locale.getDefault()).format(Date()),
                                time = SimpleDateFormat("HH:mm", Locale.getDefault()).format(Date()) + " EAT",
                                odometerKm = odometerText.toIntOrNull() ?: 142850,
                                deckRollersAndClampLocks = checkDeckRollers,
                                hydraulicLiftOperating = checkHydraulicLift,
                                ceremonialFlagsAndRibbons = checkCeremonialFlags,
                                engineOilAndCoolantOk = checkEngineFluids,
                                tirePressureAndTreadOk = checkTires,
                                interiorSanitizedAndVelvetClean = checkInteriorSanitized,
                                ceremonialUniformAndGlovesReady = checkDriverUniform,
                                overallStatus = if (passedCount == 7) "Passed - Certified Ready for Cortege" else "Conditional ($passedCount/7)",
                                notes = notesText
                            )
                            onSubmit(record)
                        },
                        colors = ButtonDefaults.buttonColors(containerColor = EmeraldSuccess),
                        shape = RoundedCornerShape(10.dp),
                        modifier = Modifier
                            .weight(1.5f)
                            .testTag("submit_fleet_inspection_button")
                    ) {
                        Icon(Icons.Default.Check, contentDescription = null, modifier = Modifier.size(16.dp))
                        Spacer(modifier = Modifier.width(6.dp))
                        Text("Certify & Submit", fontWeight = FontWeight.Bold, fontSize = 13.sp)
                    }
                }
            }
        }
    }
}

@Composable
private fun InspectionCheckboxItem(
    title: String,
    subtitle: String,
    checked: Boolean,
    onCheckedChange: (Boolean) -> Unit
) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .clickable { onCheckedChange(!checked) }
            .padding(vertical = 6.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Checkbox(
            checked = checked,
            onCheckedChange = onCheckedChange,
            colors = CheckboxDefaults.colors(
                checkedColor = EmeraldSuccess,
                uncheckedColor = Color(0xFF94A3B8)
            ),
            modifier = Modifier.size(24.dp)
        )
        Spacer(modifier = Modifier.width(10.dp))
        Column(modifier = Modifier.weight(1f)) {
            Text(
                text = title,
                fontSize = 12.sp,
                fontWeight = FontWeight.SemiBold,
                color = Color(0xFF0F172A)
            )
            Text(
                text = subtitle,
                fontSize = 10.sp,
                color = Color(0xFF64748B)
            )
        }
    }
    HorizontalDivider(color = Color(0xFFF1F5F9), thickness = 0.5.dp)
}
