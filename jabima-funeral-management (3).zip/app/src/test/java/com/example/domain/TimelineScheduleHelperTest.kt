package com.example.domain

import com.example.model.ActivityCategory
import com.example.model.ActivityStatus
import com.example.model.Department
import com.example.model.FuneralArrangementStage
import com.example.model.StaffActivity
import com.example.model.TaskPriority
import com.google.common.truth.Truth.assertThat
import org.junit.Test

class TimelineScheduleHelperTest {

    private fun sampleTask(
        id: String,
        time: String,
        durationMinutes: Int = 60,
        date: String = "23 Sep 2026",
        status: ActivityStatus = ActivityStatus.SCHEDULED,
        priority: TaskPriority = TaskPriority.NORMAL,
        department: Department = Department.DRIVERS,
        stage: FuneralArrangementStage = FuneralArrangementStage.FLEET_CORTEGE,
        title: String = "Task $id"
    ) = StaffActivity(
        id = id,
        staffId = "DRV-001",
        staffName = "Victor Owino",
        department = department,
        category = ActivityCategory.FLEET_TRANSPORT,
        title = title,
        caseReference = "JFD-2026-$id",
        clientFamily = "Test Family",
        location = "Bondo",
        date = date,
        time = time,
        durationMinutes = durationMinutes,
        status = status,
        priority = priority,
        arrangementStage = stage
    )

    @Test
    fun parseTimeToMinutes_handles12HourAnd24HourFormats() {
        assertThat(TimelineScheduleHelper.parseTimeToMinutes("12:00 AM")).isEqualTo(0)
        assertThat(TimelineScheduleHelper.parseTimeToMinutes("08:30 AM")).isEqualTo(510)
        assertThat(TimelineScheduleHelper.parseTimeToMinutes("12:00 PM")).isEqualTo(720)
        assertThat(TimelineScheduleHelper.parseTimeToMinutes("02:15 PM")).isEqualTo(855)
        assertThat(TimelineScheduleHelper.parseTimeToMinutes("16:45")).isEqualTo(1005)
        assertThat(TimelineScheduleHelper.parseTimeToMinutes("")).isEqualTo(1440)
    }

    @Test
    fun formatEndTimeAndWindow_calculatesAccurateEndTime() {
        assertThat(TimelineScheduleHelper.formatEndTime("08:30 AM", 120)).isEqualTo("10:30 AM")
        assertThat(TimelineScheduleHelper.formatTimeWindow("11:30 AM", 90)).isEqualTo("11:30 AM – 01:00 PM")
    }

    @Test
    fun sortActivitiesChronologically_ordersTasksEarliestToLatest() {
        val tLate = sampleTask("T1", "02:30 PM", priority = TaskPriority.URGENT)
        val tMorning = sampleTask("T2", "07:00 AM")
        val tMidSameLow = sampleTask("T3", "09:45 AM", priority = TaskPriority.NORMAL)
        val tMidSameUrgent = sampleTask("T4", "09:45 AM", priority = TaskPriority.URGENT)

        val sorted = TimelineScheduleHelper.sortActivitiesChronologically(
            listOf(tLate, tMidSameLow, tMorning, tMidSameUrgent)
        )

        assertThat(sorted.map { it.id }).containsExactly("T2", "T4", "T3", "T1").inOrder()
    }

    @Test
    fun detectOverlappingActivityIds_identifiesConcurrentSlotsOnSameDateOnly() {
        val a = sampleTask("A", "08:00 AM", durationMinutes = 90, date = "23 Sep 2026")
        val b = sampleTask("B", "09:00 AM", durationMinutes = 60, date = "23 Sep 2026")
        val c = sampleTask("C", "11:00 AM", durationMinutes = 60, date = "23 Sep 2026")
        val otherDay = sampleTask("D", "08:15 AM", durationMinutes = 60, date = "24 Sep 2026")

        val overlaps = TimelineScheduleHelper.detectOverlappingActivityIds(listOf(a, b, c, otherDay))

        assertThat(overlaps).containsExactly("A", "B")
    }

    @Test
    fun filterActivities_filtersByStatusPriorityDepartmentDateAndQuery() {
        val urgentInProgress = sampleTask(
            id = "1",
            time = "08:30 AM",
            status = ActivityStatus.IN_PROGRESS,
            priority = TaskPriority.URGENT,
            department = Department.DRIVERS,
            title = "Lead Cortege"
        )
        val normalWorkshop = sampleTask(
            id = "2",
            time = "10:00 AM",
            status = ActivityStatus.SCHEDULED,
            priority = TaskPriority.NORMAL,
            department = Department.WORKSHOP,
            title = "Casket Polish"
        )

        val filtered = TimelineScheduleHelper.filterActivities(
            activities = listOf(urgentInProgress, normalWorkshop),
            dateFilter = "23 Sep 2026",
            statusFilter = ActivityStatus.IN_PROGRESS,
            categoryFilter = null,
            stageFilter = null,
            priorityFilter = TaskPriority.URGENT,
            departmentFilter = Department.DRIVERS,
            searchQuery = "Cortege"
        )

        assertThat(filtered).containsExactly(urgentInProgress)
    }
}
