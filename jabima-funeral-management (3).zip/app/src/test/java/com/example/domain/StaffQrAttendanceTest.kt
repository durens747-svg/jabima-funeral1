package com.example.domain

import com.example.data.StaffPortalRepository
import com.example.model.ShiftAttendanceAction
import com.example.model.ShiftPeriod
import com.example.model.StaffRole
import com.google.common.truth.Truth.assertThat
import com.google.zxing.BarcodeFormat
import com.google.zxing.qrcode.QRCodeWriter
import org.junit.Test

class StaffQrAttendanceTest {

    @Test
    fun encodeAndParseStaffQrPayload_matchesStaffAndRawIds() {
        val repository = StaffPortalRepository()
        val accounts = repository.accounts.value
        val driver = accounts.first { it.id == "DRV-001" }

        val encoded = StaffQrIdentityCodec.encodeStaffQrPayload(driver)
        assertThat(encoded).startsWith("JFD-STF|DRV-001|")

        val matrix = QRCodeWriter().encode(encoded, BarcodeFormat.QR_CODE, 240, 240)
        assertThat(matrix.width).isEqualTo(240)
        assertThat(matrix.height).isEqualTo(240)

        val matchedEncoded = StaffQrIdentityCodec.parseScannedStaffCode(encoded, accounts)
        assertThat(matchedEncoded).isInstanceOf(StaffQrParseResult.Matched::class.java)
        assertThat((matchedEncoded as StaffQrParseResult.Matched).staff.id).isEqualTo("DRV-001")

        val matchedRawId = StaffQrIdentityCodec.parseScannedStaffCode("drv-001", accounts)
        assertThat(matchedRawId).isInstanceOf(StaffQrParseResult.Matched::class.java)
        assertThat((matchedRawId as StaffQrParseResult.Matched).staff.fullName).isEqualTo(driver.fullName)

        val notFound = StaffQrIdentityCodec.parseScannedStaffCode("UNKNOWN-999", accounts)
        assertThat(notFound).isInstanceOf(StaffQrParseResult.NotFound::class.java)
    }

    @Test
    fun resolve24HourShiftWindow_coversDayAndNightVigils() {
        assertThat(StaffQrIdentityCodec.resolve24HourShiftWindow(6)).contains("Day Shift")
        assertThat(StaffQrIdentityCodec.resolve24HourShiftWindow(14)).contains("Day Shift")
        assertThat(StaffQrIdentityCodec.resolve24HourShiftWindow(18)).contains("Night Vigil")
        assertThat(StaffQrIdentityCodec.resolve24HourShiftWindow(2)).contains("Night Vigil")
    }

    @Test
    fun canVerifyShiftAttendance_restrictsToManagersAndSupervisors() {
        assertThat(StaffQrIdentityCodec.canVerifyShiftAttendance(StaffRole.MANAGING_DIRECTOR_CEO)).isTrue()
        assertThat(StaffQrIdentityCodec.canVerifyShiftAttendance(StaffRole.OPERATIONS_ADMIN)).isTrue()
        assertThat(StaffQrIdentityCodec.canVerifyShiftAttendance(StaffRole.INVENTORY_MANAGER)).isTrue()
        assertThat(StaffQrIdentityCodec.canVerifyShiftAttendance(StaffRole.FUNERAL_DIRECTOR)).isTrue()
        assertThat(StaffQrIdentityCodec.canVerifyShiftAttendance(StaffRole.CHAPEL_COORDINATOR)).isTrue()

        assertThat(StaffQrIdentityCodec.canVerifyShiftAttendance(StaffRole.DRIVER)).isFalse()
        assertThat(StaffQrIdentityCodec.canVerifyShiftAttendance(StaffRole.WORKSHOP_WORKER)).isFalse()
        assertThat(StaffQrIdentityCodec.canVerifyShiftAttendance(StaffRole.OPERATOR)).isFalse()
    }

    @Test
    fun verifyStaffShiftAttendance_logsRecordAndUpdatesMatchingRosterShift() {
        val repository = StaffPortalRepository()
        val accounts = repository.accounts.value
        val targetShift = repository.staffShiftSchedules.value.first()
        val staff = accounts.first { it.id == targetShift.staffId }
        val initialLogs = repository.shiftAttendanceLogs.value.size
        val payload = StaffQrIdentityCodec.encodeStaffQrPayload(staff)

        val checkIn = repository.verifyStaffShiftAttendance(
            staff = staff,
            scannedQrPayload = payload,
            action = ShiftAttendanceAction.CHECK_IN,
            checkpointLocation = "Bama Branch Dispatch Bay",
            shiftId = targetShift.id,
            shiftWindowLabel = "Night Vigil & 24/7 Shift (18:00 - 06:00)",
            verifiedByStaffId = "CEO-001",
            verifiedByName = "Fredrick Hayoyo"
        )

        assertThat(repository.shiftAttendanceLogs.value.size).isEqualTo(initialLogs + 1)
        assertThat(repository.shiftAttendanceLogs.value.first().id).isEqualTo(checkIn.id)

        val updatedShiftCheckIn = repository.staffShiftSchedules.value.first { it.id == targetShift.id }
        assertThat(updatedShiftCheckIn.shiftPeriod).isEqualTo(ShiftPeriod.ACTIVE)
        assertThat(updatedShiftCheckIn.checkInStatus).contains("QR Verified In")

        repository.verifyStaffShiftAttendance(
            staff = staff,
            scannedQrPayload = payload,
            action = ShiftAttendanceAction.CHECK_OUT,
            checkpointLocation = "Bama Branch Dispatch Bay",
            shiftId = targetShift.id,
            shiftWindowLabel = "Night Vigil & 24/7 Shift (18:00 - 06:00)",
            verifiedByStaffId = "CEO-001",
            verifiedByName = "Fredrick Hayoyo"
        )

        val updatedShiftCheckOut = repository.staffShiftSchedules.value.first { it.id == targetShift.id }
        assertThat(updatedShiftCheckOut.shiftPeriod).isEqualTo(ShiftPeriod.PAST)
        assertThat(updatedShiftCheckOut.checkInStatus).contains("QR Verified Out")
    }
}
