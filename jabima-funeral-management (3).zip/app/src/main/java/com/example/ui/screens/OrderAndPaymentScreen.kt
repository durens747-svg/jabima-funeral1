package com.example.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.filled.Edit
import androidx.compose.material.icons.filled.Tune
import androidx.compose.material3.MenuAnchorType
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.material.icons.filled.AccountBalance
import androidx.compose.material.icons.filled.Analytics
import androidx.compose.material.icons.filled.Check
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.ContentCopy
import androidx.compose.material.icons.filled.CreditCard
import androidx.compose.material.icons.filled.Download
import androidx.compose.material.icons.filled.LocalAtm
import androidx.compose.material.icons.filled.PhoneAndroid
import androidx.compose.material.icons.filled.PointOfSale
import androidx.compose.material.icons.filled.Print
import androidx.compose.material.icons.filled.Receipt
import androidx.compose.material.icons.automirrored.filled.Send
import androidx.compose.material.icons.filled.Share
import androidx.compose.material.icons.filled.Verified
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Checkbox
import androidx.compose.material3.CheckboxDefaults
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.ExposedDropdownMenuBox
import androidx.compose.material3.ExposedDropdownMenuDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.RadioButton
import androidx.compose.material3.RadioButtonDefaults
import androidx.compose.material3.ScrollableTabRow
import androidx.compose.material3.Surface
import androidx.compose.material3.Tab
import androidx.compose.material3.TabRowDefaults
import androidx.compose.material3.TabRowDefaults.tabIndicatorOffset
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateListOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalClipboardManager
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.foundation.BorderStroke
import androidx.compose.material.icons.filled.PictureAsPdf
import androidx.compose.material.icons.filled.Warning
import androidx.compose.runtime.LaunchedEffect
import com.example.domain.CasketCostingEngine
import com.example.domain.PayrollRulesEngine
import com.example.model.MainAppTab
import com.example.model.MarginStatus
import com.example.ui.theme.AmberLight
import com.example.ui.theme.AmberWarning
import com.example.utils.PdfDocumentGenerator
import androidx.compose.ui.text.AnnotatedString
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.window.Dialog
import com.example.model.BANK_ACCOUNT_NAME
import com.example.model.BANK_ACCOUNT_NUMBER
import com.example.model.BANK_NAME
import com.example.model.BANK_SWIFT_CODE
import com.example.model.CasketItem
import com.example.model.CustomerOrderRecord
import com.example.model.Department
import com.example.model.JABIMA_BRANCHES
import com.example.model.MPESA_PAYBILL_NUMBER
import com.example.model.MPESA_STK_NUMBER
import com.example.model.OrderAddonItem
import com.example.model.OrderPackageItem
import com.example.model.PAYMENT_TERMS
import com.example.ui.StaffPortalViewModel
import com.example.ui.theme.EmeraldLight
import com.example.ui.theme.EmeraldSuccess
import com.example.ui.theme.Navy800
import com.example.ui.theme.Navy900
import com.example.ui.theme.ObsidianBlack
import com.example.ui.theme.PureWhite
import com.example.ui.theme.RoyalCobaltBlue
import com.example.ui.theme.RoyalCobaltIce
import com.example.ui.theme.RoyalCobaltLight
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun OrderAndPaymentScreen(
    viewModel: StaffPortalViewModel,
    preSelectedCasketName: String? = null
) {
    val clipboardManager = LocalClipboardManager.current
    val context = LocalContext.current
    val currentAccount by viewModel.currentAccount.collectAsState()
    val allStaff by viewModel.allAccounts.collectAsState()
    val customerOrders by viewModel.customerOrders.collectAsState()
    val caskets by viewModel.caskets.collectAsState()
    val packages by viewModel.orderPackages.collectAsState()
    val availableAddons by viewModel.orderAddons.collectAsState()
    val gatewayStatus by viewModel.externalGatewayStatus.collectAsState()
    val isAdmin = viewModel.isAuthorizedForAdminChanges()

    var activeSubTab by remember { mutableStateOf(0) } // 0: Order Checkout, 1: Other Design, 2: Invoices & Receipts

    // FORM STATE
    var currencyMode by remember { mutableStateOf("KES") } // "KES" or "USD"
    var selectedPackageId by remember { mutableStateOf(packages.firstOrNull()?.id ?: "PKG-01") }
    var includePackageFee by remember { mutableStateOf(false) }
    var selectedCasketId by remember {
        mutableStateOf(
            caskets.firstOrNull { it.name == preSelectedCasketName }?.id
                ?: caskets.getOrNull(1)?.id
                ?: caskets.firstOrNull()?.id
                ?: "CSK-01"
        )
    }
    LaunchedEffect(preSelectedCasketName, caskets) {
        if (!preSelectedCasketName.isNullOrBlank()) {
            val matched = caskets.firstOrNull {
                it.name.equals(preSelectedCasketName, ignoreCase = true) ||
                    it.name.contains(preSelectedCasketName, ignoreCase = true)
            }
            if (matched != null) {
                selectedCasketId = matched.id
            }
        }
    }
    val selectedPackage = packages.firstOrNull { it.id == selectedPackageId } ?: packages.first()
    val selectedCasket = caskets.firstOrNull { it.id == selectedCasketId } ?: caskets.first()

    var clientName by remember { mutableStateOf("") }
    var clientPhone by remember { mutableStateOf("") }
    var deceasedName by remember { mutableStateOf("") }
    var selectedBranch by remember { mutableStateOf(currentAccount?.branch ?: JABIMA_BRANCHES.first()) }
    var paymentTerms by remember { mutableStateOf(PAYMENT_TERMS[0]) } // "Full payment" or "Lipa pole pole Option (2 installments)"
    var paymentMethod by remember { mutableStateOf("M-PESA") } // "M-PESA" or "BANK_TRANSFER"

    // ADD-ONS (tracked by ID so Admin price edits update totals dynamically)
    val selectedAddonIds = remember { mutableStateListOf<String>() }

    // OTHER DESIGN TAB STATE (custom coffin design & editable price)
    var customDesignName by remember { mutableStateOf("") }
    var customWoodType by remember { mutableStateOf("African Mahogany & Cedar") }
    var customTier by remember { mutableStateOf("Bespoke Custom") }
    var customFinish by remember { mutableStateOf("Hand-Rubbed Satin Gloss") }
    var customLining by remember { mutableStateOf("Quilted Ivory Satin Velvet") }
    var customPriceText by remember { mutableStateOf("145000") }
    var customStockText by remember { mutableStateOf("1") }

    // Inline Admin Edit Dialogs
    var inlineEditCasket by remember { mutableStateOf<CasketItem?>(null) }
    var inlineEditPackage by remember { mutableStateOf<OrderPackageItem?>(null) }
    var inlineEditAddon by remember { mutableStateOf<OrderAddonItem?>(null) }

    // SALES AGENT ASSIGNMENT (Only sales staff earn 5% commission on caskets!)
    val salesStaff = remember(allStaff) {
        allStaff.filter { it.department == Department.SALES_MARKETING || it.id.startsWith("SLS") }
    }
    var selectedSalesAgent by remember {
        mutableStateOf(salesStaff.firstOrNull { it.id == currentAccount?.id } ?: salesStaff.firstOrNull() ?: allStaff.first())
    }

    // CALCULATIONS
    val basePriceKes = selectedCasket.priceKes + if (includePackageFee) selectedPackage.priceKes else 0.0
    val selectedAddonsList = availableAddons.filter { selectedAddonIds.contains(it.id) }
    val addonsTotalKes = selectedAddonsList.sumOf { it.priceKes }
    val totalAmountKes = basePriceKes + addonsTotalKes
    val totalAmountUsd = totalAmountKes / 130.0

    // 5% Casket Commission for Sales Staff
    val casketCommissionKes = selectedCasket.priceKes * 0.05

    // DIALOGS
    var showStkPushDialog by remember { mutableStateOf(false) }
    var showBankTransferDialog by remember { mutableStateOf(false) }
    var showCashPaymentDialog by remember { mutableStateOf(false) }
    var showSuccessReceiptDialog by remember { mutableStateOf(false) }
    var lastSubmittedOrder by remember { mutableStateOf<CustomerOrderRecord?>(null) }
    var generatedRefCode by remember { mutableStateOf("") }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(PureWhite)
            .padding(16.dp)
            .testTag("orders_and_payments_screen")
    ) {
        // TOP BAR WITH CURRENCY TOGGLE
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Column {
                Text(
                    text = "Orders & Payments System",
                    fontSize = 20.sp,
                    fontWeight = FontWeight.Bold,
                    color = ObsidianBlack
                )
                Text(
                    text = "Package bookings, workshop casket selection, M-PESA & Bank transfer",
                    fontSize = 12.sp,
                    color = Color(0xFF64748B)
                )
            }

            // KES / USD TOGGLE
            Surface(
                shape = RoundedCornerShape(20.dp),
                color = RoyalCobaltIce,
                border = androidx.compose.foundation.BorderStroke(1.dp, Color(0xFFBFDBFE))
            ) {
                Row(modifier = Modifier.padding(4.dp)) {
                    Surface(
                        shape = RoundedCornerShape(16.dp),
                        color = if (currencyMode == "KES") RoyalCobaltBlue else Color.Transparent,
                        modifier = Modifier
                            .clickable { currencyMode = "KES" }
                            .padding(horizontal = 8.dp, vertical = 4.dp)
                    ) {
                        Text(
                            text = "KES",
                            fontSize = 11.sp,
                            fontWeight = FontWeight.Bold,
                            color = if (currencyMode == "KES") Color.White else RoyalCobaltBlue
                        )
                    }
                    Surface(
                        shape = RoundedCornerShape(16.dp),
                        color = if (currencyMode == "USD") RoyalCobaltBlue else Color.Transparent,
                        modifier = Modifier
                            .clickable { currencyMode = "USD" }
                            .padding(horizontal = 8.dp, vertical = 4.dp)
                    ) {
                        Text(
                            text = "USD ($)",
                            fontSize = 11.sp,
                            fontWeight = FontWeight.Bold,
                            color = if (currencyMode == "USD") Color.White else RoyalCobaltBlue
                        )
                    }
                }
            }
        }

        Spacer(modifier = Modifier.height(8.dp))

        // DARAJA M-PESA GATEWAY STATUS STRIP
        Surface(
            color = if (gatewayStatus.mpesaLiveConfigured) EmeraldLight else Color(0xFFFEF3C7),
            shape = RoundedCornerShape(8.dp),
            border = androidx.compose.foundation.BorderStroke(
                1.dp,
                if (gatewayStatus.mpesaLiveConfigured) Color(0xFFA7F3D0) else Color(0xFFFDE68A)
            ),
            modifier = Modifier
                .fillMaxWidth()
                .testTag("order_mpesa_gateway_status_banner")
        ) {
            Row(
                modifier = Modifier.padding(horizontal = 10.dp, vertical = 6.dp),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(6.dp)
            ) {
                Icon(
                    imageVector = Icons.Default.PhoneAndroid,
                    contentDescription = null,
                    tint = if (gatewayStatus.mpesaLiveConfigured) EmeraldSuccess else Color(0xFFD97706),
                    modifier = Modifier.size(14.dp)
                )
                Text(
                    text = gatewayStatus.mpesaStatusLabel,
                    fontSize = 11.sp,
                    fontWeight = FontWeight.SemiBold,
                    color = if (gatewayStatus.mpesaLiveConfigured) Color(0xFF065F46) else Color(0xFF92400E),
                    maxLines = 1,
                    overflow = TextOverflow.Ellipsis
                )
            }
        }

        Spacer(modifier = Modifier.height(8.dp))

        // SUB TABS: ORDER CHECKOUT | OTHER DESIGN | INVOICES & RECEIPTS
        ScrollableTabRow(
            selectedTabIndex = activeSubTab,
            containerColor = MaterialTheme.colorScheme.surface,
            contentColor = RoyalCobaltBlue,
            edgePadding = 0.dp,
            indicator = { tabPositions ->
                if (activeSubTab < tabPositions.size) {
                    TabRowDefaults.SecondaryIndicator(
                        modifier = Modifier.tabIndicatorOffset(tabPositions[activeSubTab]),
                        color = RoyalCobaltBlue,
                        height = 3.dp
                    )
                }
            },
            modifier = Modifier
                .fillMaxWidth()
                .clip(RoundedCornerShape(8.dp))
                .border(1.dp, MaterialTheme.colorScheme.outline.copy(alpha = 0.25f), RoundedCornerShape(8.dp))
        ) {
            Tab(
                selected = activeSubTab == 0,
                onClick = { activeSubTab = 0 },
                text = {
                    Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(5.dp)) {
                        Icon(Icons.Default.CreditCard, contentDescription = null, modifier = Modifier.size(15.dp))
                        Text(
                            text = "Order Checkout",
                            fontSize = 12.sp,
                            fontWeight = if (activeSubTab == 0) FontWeight.Bold else FontWeight.Medium,
                            maxLines = 1,
                            softWrap = false,
                            overflow = TextOverflow.Ellipsis
                        )
                    }
                },
                modifier = Modifier.testTag("tab_order_checkout")
            )

            Tab(
                selected = activeSubTab == 1,
                onClick = { activeSubTab = 1 },
                text = {
                    Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(5.dp)) {
                        Icon(Icons.Default.Analytics, contentDescription = null, modifier = Modifier.size(15.dp))
                        Text(
                            text = "Order Dashboard",
                            fontSize = 12.sp,
                            fontWeight = if (activeSubTab == 1) FontWeight.Bold else FontWeight.Medium,
                            maxLines = 1,
                            softWrap = false,
                            overflow = TextOverflow.Ellipsis
                        )
                    }
                },
                modifier = Modifier.testTag("tab_order_dashboard")
            )

            Tab(
                selected = activeSubTab == 2,
                onClick = { activeSubTab = 2 },
                text = {
                    Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(5.dp)) {
                        Icon(Icons.Default.Tune, contentDescription = null, modifier = Modifier.size(15.dp))
                        Text(
                            text = "Other Design",
                            fontSize = 12.sp,
                            fontWeight = if (activeSubTab == 2) FontWeight.Bold else FontWeight.Medium,
                            maxLines = 1,
                            softWrap = false,
                            overflow = TextOverflow.Ellipsis
                        )
                    }
                },
                modifier = Modifier.testTag("tab_order_other_design")
            )

            Tab(
                selected = activeSubTab == 3,
                onClick = { activeSubTab = 3 },
                text = {
                    Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(5.dp)) {
                        Icon(Icons.Default.Receipt, contentDescription = null, modifier = Modifier.size(15.dp))
                        Text(
                            text = "Invoices & Receipts (${customerOrders.size})",
                            fontSize = 12.sp,
                            fontWeight = if (activeSubTab == 3) FontWeight.Bold else FontWeight.Medium,
                            maxLines = 1,
                            softWrap = false,
                            overflow = TextOverflow.Ellipsis
                        )
                    }
                },
                modifier = Modifier.testTag("tab_invoices_receipts")
            )
        }

        Spacer(modifier = Modifier.height(12.dp))

        // TAB 0: ORDER & CHECKOUT FLOW
        if (activeSubTab == 0) {
            LazyColumn(
                modifier = Modifier.weight(1f),
                verticalArrangement = Arrangement.spacedBy(14.dp)
            ) {
                // 0. ADMIN QUICK PRICE CONTROL & FUNERAL PACKAGE SELECTION
                item {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Column(modifier = Modifier.weight(1f)) {
                            Text(
                                text = "0. Service Package (Editable Pricing)",
                                fontSize = 14.sp,
                                fontWeight = FontWeight.Bold,
                                color = MaterialTheme.colorScheme.onSurface
                            )
                            Text(
                                text = "Select package tier or tap Other Design for bespoke caskets.",
                                fontSize = 11.sp,
                                color = MaterialTheme.colorScheme.onSurfaceVariant
                            )
                        }
                        if (isAdmin) {
                            OutlinedButton(
                                onClick = { viewModel.showPriceEditorDialog.value = true },
                                shape = RoundedCornerShape(8.dp),
                                modifier = Modifier.height(34.dp).testTag("btn_order_admin_edit_prices")
                            ) {
                                Icon(Icons.Default.Edit, contentDescription = "Admin Edit Prices", modifier = Modifier.size(13.dp))
                                Spacer(modifier = Modifier.width(4.dp))
                                Text("Admin Prices", fontSize = 11.sp, fontWeight = FontWeight.Bold, maxLines = 1, softWrap = false)
                            }
                        }
                    }

                    Spacer(modifier = Modifier.height(6.dp))

                    Card(
                        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                        border = androidx.compose.foundation.BorderStroke(1.dp, MaterialTheme.colorScheme.outline.copy(alpha = 0.25f)),
                        shape = RoundedCornerShape(8.dp)
                    ) {
                        Column(modifier = Modifier.padding(10.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                            packages.forEach { pkg ->
                                val isSelected = selectedPackage.id == pkg.id
                                Surface(
                                    shape = RoundedCornerShape(8.dp),
                                    color = if (isSelected) RoyalCobaltIce else MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.35f),
                                    border = androidx.compose.foundation.BorderStroke(
                                        if (isSelected) 1.5.dp else 1.dp,
                                        if (isSelected) RoyalCobaltBlue else MaterialTheme.colorScheme.outline.copy(alpha = 0.2f)
                                    ),
                                    modifier = Modifier
                                        .fillMaxWidth()
                                        .clickable { selectedPackageId = pkg.id }
                                        .testTag("order_package_${pkg.id}")
                                ) {
                                    Row(
                                        modifier = Modifier.padding(10.dp),
                                        horizontalArrangement = Arrangement.SpaceBetween,
                                        verticalAlignment = Alignment.CenterVertically
                                    ) {
                                        Column(modifier = Modifier.weight(1f)) {
                                            Text(pkg.name, fontWeight = FontWeight.Bold, fontSize = 12.sp, color = ObsidianBlack)
                                            Text(pkg.inclusions.joinToString(" • "), fontSize = 10.sp, color = Color(0xFF475569), maxLines = 2)
                                        }
                                        Column(horizontalAlignment = Alignment.End) {
                                            Text(
                                                text = "KES ${String.format(Locale.getDefault(), "%,.0f", pkg.priceKes)}",
                                                fontWeight = FontWeight.Bold,
                                                fontSize = 12.sp,
                                                color = RoyalCobaltBlue
                                            )
                                            if (isAdmin) {
                                                Text(
                                                    text = "Edit Price",
                                                    fontSize = 10.sp,
                                                    fontWeight = FontWeight.Bold,
                                                    color = EmeraldSuccess,
                                                    modifier = Modifier
                                                        .clickable { inlineEditPackage = pkg }
                                                        .padding(top = 2.dp)
                                                        .testTag("inline_edit_pkg_${pkg.id}")
                                                )
                                            }
                                        }
                                    }
                                }
                            }
                            Row(
                                verticalAlignment = Alignment.CenterVertically,
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .clickable { includePackageFee = !includePackageFee }
                            ) {
                                Checkbox(
                                    checked = includePackageFee,
                                    onCheckedChange = { includePackageFee = it },
                                    colors = CheckboxDefaults.colors(checkedColor = RoyalCobaltBlue)
                                )
                                Text(
                                    text = "Add Selected Package Service Fee (+KES ${String.format(Locale.getDefault(), "%,.0f", selectedPackage.priceKes)})",
                                    fontSize = 11.sp,
                                    fontWeight = FontWeight.SemiBold,
                                    color = MaterialTheme.colorScheme.onSurface
                                )
                            }
                        }
                    }
                }

                // 1. WORKSHOP CASKET SELECTION (EDITABLE BY ADMIN)
                item {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Column(modifier = Modifier.weight(1f)) {
                            Text(
                                text = "1. Workshop Casket Selection & Customization",
                                fontSize = 14.sp,
                                fontWeight = FontWeight.Bold,
                                color = MaterialTheme.colorScheme.onSurface
                            )
                            Text(
                                text = "Select or customize casket. Sales agent earns 5% commission.",
                                fontSize = 11.sp,
                                color = MaterialTheme.colorScheme.onSurfaceVariant
                            )
                        }
                        Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                            if (isAdmin) {
                                OutlinedButton(
                                    onClick = { inlineEditCasket = selectedCasket },
                                    shape = RoundedCornerShape(8.dp),
                                    modifier = Modifier.height(34.dp).testTag("btn_inline_edit_selected_casket")
                                ) {
                                    Icon(Icons.Default.Edit, contentDescription = "Edit Casket", modifier = Modifier.size(13.dp))
                                    Spacer(modifier = Modifier.width(3.dp))
                                    Text("Edit Casket", fontSize = 10.sp, fontWeight = FontWeight.Bold, maxLines = 1, softWrap = false)
                                }
                            }
                            OutlinedButton(
                                onClick = { activeSubTab = 1 },
                                shape = RoundedCornerShape(8.dp),
                                modifier = Modifier.height(34.dp).testTag("btn_quick_other_design")
                            ) {
                                Text("Other Design", fontSize = 10.sp, fontWeight = FontWeight.Bold, color = RoyalCobaltBlue, maxLines = 1, softWrap = false)
                            }
                        }
                    }
                    Spacer(modifier = Modifier.height(6.dp))

                    var casketExpanded by remember { mutableStateOf(false) }
                    ExposedDropdownMenuBox(
                        expanded = casketExpanded,
                        onExpandedChange = { casketExpanded = it },
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        OutlinedTextField(
                            value = "${selectedCasket.name} (${selectedCasket.woodType}) - KES ${String.format(Locale.getDefault(), "%,.0f", selectedCasket.priceKes)}",
                            onValueChange = {},
                            readOnly = true,
                            label = { Text("Selected Casket", fontSize = 12.sp) },
                            trailingIcon = { ExposedDropdownMenuDefaults.TrailingIcon(expanded = casketExpanded) },
                            modifier = Modifier
                                .fillMaxWidth()
                                .menuAnchor(MenuAnchorType.PrimaryNotEditable),
                            colors = OutlinedTextFieldDefaults.colors(
                                focusedBorderColor = RoyalCobaltBlue,
                                unfocusedBorderColor = Color(0xFFCBD5E1)
                            )
                        )
                        ExposedDropdownMenu(
                            expanded = casketExpanded,
                            onDismissRequest = { casketExpanded = false }
                        ) {
                            caskets.forEach { c ->
                                DropdownMenuItem(
                                    text = {
                                        Column {
                                            Text("${c.name} • ${c.tier}", fontWeight = FontWeight.SemiBold, fontSize = 12.sp)
                                            Text("KES ${String.format(Locale.getDefault(), "%,.0f", c.priceKes)} | $ ${String.format(Locale.getDefault(), "%,.0f", c.priceUsd)} (5% comm: KES ${String.format(Locale.getDefault(), "%,.0f", c.priceKes * 0.05)})", fontSize = 10.sp, color = RoyalCobaltBlue)
                                        }
                                    },
                                    onClick = {
                                        selectedCasketId = c.id
                                        casketExpanded = false
                                    }
                                )
                            }
                        }
                    }

                    val guideSpec = CasketCostingEngine.findModelForCasketName(selectedCasket.name)
                    if (guideSpec != null) {
                        val marginEval = PayrollRulesEngine.evaluateBomMargin(
                            sellingPriceKes = selectedCasket.priceKes,
                            materialCostKes = guideSpec.baseBodyMaterialCostKes + guideSpec.paintAndAbrasivesCostKes,
                            laborCostKes = guideSpec.crewLaborCostKes,
                            finishingCostKes = guideSpec.finishingMaterialCostKes
                        )
                        Spacer(modifier = Modifier.height(6.dp))
                        Surface(
                            color = RoyalCobaltIce,
                            shape = RoundedCornerShape(8.dp),
                            border = BorderStroke(1.dp, RoyalCobaltBlue.copy(alpha = 0.25f)),
                            modifier = Modifier
                                .fillMaxWidth()
                                .testTag("order_pdf_cost_guide_banner")
                        ) {
                            Row(
                                modifier = Modifier.padding(horizontal = 10.dp, vertical = 8.dp),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Column(modifier = Modifier.weight(1f)) {
                                    Text(
                                        text = "Order Price Guide • ${guideSpec.modelName}",
                                        fontSize = 11.sp,
                                        fontWeight = FontWeight.Bold,
                                        color = Navy900
                                    )
                                    Text(
                                        text = "Prod Cost: KES ${String.format(Locale.getDefault(), "%,.0f", guideSpec.totalProductionCostKes)} (Mat ${String.format(Locale.getDefault(), "%,.0f", guideSpec.directMaterialCostKes)}) • Margin ${marginEval.marginPercent}%",
                                        fontSize = 10.sp,
                                        color = if (marginEval.status == MarginStatus.HEALTHY) EmeraldSuccess else AmberWarning,
                                        fontWeight = FontWeight.SemiBold
                                    )
                                }
                                OutlinedButton(
                                    onClick = { viewModel.setMainAppTab(MainAppTab.COSTINGS_AND_PRICING) },
                                    shape = RoundedCornerShape(6.dp),
                                    contentPadding = androidx.compose.foundation.layout.PaddingValues(horizontal = 8.dp, vertical = 2.dp),
                                    modifier = Modifier.height(30.dp)
                                ) {
                                    Text("BOM Guide", fontSize = 10.sp, fontWeight = FontWeight.Bold, maxLines = 1, softWrap = false)
                                }
                            }
                        }
                    }
                }

                // 2. CUSTOMIZABLE ADD-ONS
                item {
                    Text(
                        text = "2. Customizable Add-Ons & Services",
                        fontSize = 14.sp,
                        fontWeight = FontWeight.Bold,
                        color = MaterialTheme.colorScheme.onSurface
                    )
                    Spacer(modifier = Modifier.height(4.dp))

                    Card(
                        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                        border = androidx.compose.foundation.BorderStroke(1.dp, MaterialTheme.colorScheme.outline.copy(alpha = 0.25f)),
                        shape = RoundedCornerShape(8.dp)
                    ) {
                        Column(modifier = Modifier.padding(10.dp)) {
                            availableAddons.forEach { addon ->
                                val isChecked = selectedAddonIds.contains(addon.id)
                                Row(
                                    modifier = Modifier
                                        .fillMaxWidth()
                                        .clickable {
                                            if (isChecked) selectedAddonIds.remove(addon.id)
                                            else selectedAddonIds.add(addon.id)
                                        }
                                        .padding(vertical = 4.dp),
                                    verticalAlignment = Alignment.CenterVertically,
                                    horizontalArrangement = Arrangement.SpaceBetween
                                ) {
                                    Row(
                                        verticalAlignment = Alignment.CenterVertically,
                                        modifier = Modifier.weight(1f)
                                    ) {
                                        Checkbox(
                                            checked = isChecked,
                                            onCheckedChange = { checked ->
                                                if (checked) selectedAddonIds.add(addon.id)
                                                else selectedAddonIds.remove(addon.id)
                                            },
                                            colors = CheckboxDefaults.colors(checkedColor = RoyalCobaltBlue)
                                        )
                                        Spacer(modifier = Modifier.width(6.dp))
                                        Text(
                                            text = "${addon.name} (+KES ${String.format(Locale.getDefault(), "%,.0f", addon.priceKes)})",
                                            fontSize = 12.sp,
                                            color = MaterialTheme.colorScheme.onSurface,
                                            fontWeight = if (isChecked) FontWeight.SemiBold else FontWeight.Normal
                                        )
                                    }
                                    if (isAdmin) {
                                        IconButton(
                                            onClick = { inlineEditAddon = addon },
                                            modifier = Modifier.size(32.dp).testTag("inline_edit_addon_${addon.id}")
                                        ) {
                                            Icon(Icons.Default.Edit, contentDescription = "Edit Add-on Price", tint = RoyalCobaltBlue, modifier = Modifier.size(15.dp))
                                        }
                                    }
                                }
                            }
                        }
                    }
                }

                // 3. CLIENT & DECEASED DETAILS
                item {
                    Text(
                        text = "3. Client & Deceased Records",
                        fontSize = 14.sp,
                        fontWeight = FontWeight.Bold,
                        color = ObsidianBlack
                    )
                    Spacer(modifier = Modifier.height(6.dp))

                    Card(
                        colors = CardDefaults.cardColors(containerColor = PureWhite),
                        border = androidx.compose.foundation.BorderStroke(1.dp, Color(0xFFE2E8F0)),
                        shape = RoundedCornerShape(8.dp)
                    ) {
                        Column(modifier = Modifier.padding(12.dp)) {
                            OutlinedTextField(
                                value = clientName,
                                onValueChange = { clientName = it },
                                label = { Text("Family Contact / Client Name", fontSize = 12.sp) },
                                placeholder = { Text("e.g. Ezekiel Ochieng", fontSize = 12.sp) },
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .testTag("input_client_name"),
                                singleLine = true
                            )

                            Spacer(modifier = Modifier.height(8.dp))

                            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                                OutlinedTextField(
                                    value = clientPhone,
                                    onValueChange = { clientPhone = it },
                                    label = { Text("Client Phone (for M-PESA STK)", fontSize = 12.sp) },
                                    placeholder = { Text("+254 7XX XXX XXX", fontSize = 12.sp) },
                                    modifier = Modifier
                                        .weight(1f)
                                        .testTag("input_client_phone"),
                                    singleLine = true
                                )

                                OutlinedTextField(
                                    value = deceasedName,
                                    onValueChange = { deceasedName = it },
                                    label = { Text("Name of the Deceased", fontSize = 12.sp) },
                                    placeholder = { Text("The Late...", fontSize = 12.sp) },
                                    modifier = Modifier
                                        .weight(1f)
                                        .testTag("input_deceased_name"),
                                    singleLine = true
                                )
                            }

                            Spacer(modifier = Modifier.height(8.dp))

                            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                                // Branch Selector
                                var branchExpanded by remember { mutableStateOf(false) }
                                ExposedDropdownMenuBox(
                                    expanded = branchExpanded,
                                    onExpandedChange = { branchExpanded = it },
                                    modifier = Modifier.weight(1f)
                                ) {
                                    OutlinedTextField(
                                        value = selectedBranch,
                                        onValueChange = {},
                                        readOnly = true,
                                        label = { Text("Service Branch", fontSize = 12.sp) },
                                        trailingIcon = { ExposedDropdownMenuDefaults.TrailingIcon(expanded = branchExpanded) },
                                        modifier = Modifier.menuAnchor()
                                    )
                                    ExposedDropdownMenu(
                                        expanded = branchExpanded,
                                        onDismissRequest = { branchExpanded = false }
                                    ) {
                                        JABIMA_BRANCHES.forEach { b ->
                                            DropdownMenuItem(
                                                text = { Text(b, fontSize = 12.sp) },
                                                onClick = {
                                                    selectedBranch = b
                                                    branchExpanded = false
                                                }
                                            )
                                        }
                                    }
                                }

                                // Sales Counselor Selector
                                var salesExpanded by remember { mutableStateOf(false) }
                                ExposedDropdownMenuBox(
                                    expanded = salesExpanded,
                                    onExpandedChange = { salesExpanded = it },
                                    modifier = Modifier.weight(1f)
                                ) {
                                    OutlinedTextField(
                                        value = selectedSalesAgent.fullName,
                                        onValueChange = {},
                                        readOnly = true,
                                        label = { Text("Sales Counselor (5% Comm)", fontSize = 12.sp) },
                                        trailingIcon = { ExposedDropdownMenuDefaults.TrailingIcon(expanded = salesExpanded) },
                                        modifier = Modifier.menuAnchor()
                                    )
                                    ExposedDropdownMenu(
                                        expanded = salesExpanded,
                                        onDismissRequest = { salesExpanded = false }
                                    ) {
                                        salesStaff.forEach { s ->
                                            DropdownMenuItem(
                                                text = { Text("${s.fullName} (${s.branch})", fontSize = 12.sp) },
                                                onClick = {
                                                    selectedSalesAgent = s
                                                    salesExpanded = false
                                                }
                                            )
                                        }
                                    }
                                }
                            }
                        }
                    }
                }

                // 4. PAYMENT TERMS & METHOD
                item {
                    Text(
                        text = "4. Payment Terms & Method",
                        fontSize = 14.sp,
                        fontWeight = FontWeight.Bold,
                        color = ObsidianBlack
                    )
                    Spacer(modifier = Modifier.height(6.dp))

                    Card(
                        colors = CardDefaults.cardColors(containerColor = PureWhite),
                        border = androidx.compose.foundation.BorderStroke(1.dp, Color(0xFFE2E8F0)),
                        shape = RoundedCornerShape(8.dp)
                    ) {
                        Column(modifier = Modifier.padding(12.dp)) {
                            Text(text = "Payment Terms:", fontSize = 12.sp, fontWeight = FontWeight.SemiBold, color = ObsidianBlack)
                            Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                                PAYMENT_TERMS.forEach { term ->
                                    Row(
                                        verticalAlignment = Alignment.CenterVertically,
                                        modifier = Modifier
                                            .clickable { paymentTerms = term }
                                            .padding(vertical = 4.dp)
                                    ) {
                                        RadioButton(
                                            selected = paymentTerms == term,
                                            onClick = { paymentTerms = term },
                                            colors = RadioButtonDefaults.colors(selectedColor = RoyalCobaltBlue)
                                        )
                                        Text(text = term, fontSize = 11.sp, color = ObsidianBlack)
                                    }
                                }
                            }

                            Spacer(modifier = Modifier.height(8.dp))

                            Text(text = "Select Payment Channel:", fontSize = 12.sp, fontWeight = FontWeight.SemiBold, color = ObsidianBlack)
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.spacedBy(8.dp)
                            ) {
                                // M-PESA
                                Surface(
                                    shape = RoundedCornerShape(8.dp),
                                    color = if (paymentMethod == "M-PESA") Color(0xFFECFDF5) else PureWhite,
                                    border = androidx.compose.foundation.BorderStroke(
                                        if (paymentMethod == "M-PESA") 2.dp else 1.dp,
                                        if (paymentMethod == "M-PESA") Color(0xFF059669) else Color(0xFFCBD5E1)
                                    ),
                                    modifier = Modifier
                                        .weight(1f)
                                        .clickable { paymentMethod = "M-PESA" }
                                        .testTag("select_mpesa_payment")
                                ) {
                                    Column(modifier = Modifier.padding(8.dp)) {
                                        Row(verticalAlignment = Alignment.CenterVertically) {
                                            Icon(Icons.Default.PhoneAndroid, contentDescription = null, tint = Color(0xFF059669), modifier = Modifier.size(15.dp))
                                            Spacer(modifier = Modifier.width(3.dp))
                                            Text(text = "M-PESA STK", fontSize = 11.sp, fontWeight = FontWeight.Bold, color = Color(0xFF065F46))
                                        }
                                        Text(text = "Paybill: $MPESA_PAYBILL_NUMBER", fontSize = 9.sp, color = Color(0xFF047857))
                                        Text(text = "Instant Mobile", fontSize = 8.sp, color = Color(0xFF64748B))
                                    }
                                }

                                // BANK TRANSFER
                                Surface(
                                    shape = RoundedCornerShape(8.dp),
                                    color = if (paymentMethod == "BANK_TRANSFER") RoyalCobaltIce else PureWhite,
                                    border = androidx.compose.foundation.BorderStroke(
                                        if (paymentMethod == "BANK_TRANSFER") 2.dp else 1.dp,
                                        if (paymentMethod == "BANK_TRANSFER") RoyalCobaltBlue else Color(0xFFCBD5E1)
                                    ),
                                    modifier = Modifier
                                        .weight(1f)
                                        .clickable { paymentMethod = "BANK_TRANSFER" }
                                        .testTag("select_bank_payment")
                                ) {
                                    Column(modifier = Modifier.padding(8.dp)) {
                                        Row(verticalAlignment = Alignment.CenterVertically) {
                                            Icon(Icons.Default.AccountBalance, contentDescription = null, tint = RoyalCobaltBlue, modifier = Modifier.size(15.dp))
                                            Spacer(modifier = Modifier.width(3.dp))
                                            Text(text = "Bank Transfer", fontSize = 11.sp, fontWeight = FontWeight.Bold, color = RoyalCobaltBlue)
                                        }
                                        Text(text = "Swift: $BANK_SWIFT_CODE", fontSize = 9.sp, color = Color(0xFF1E3A8A))
                                        Text(text = "Standard Chartered", fontSize = 8.sp, color = Color(0xFF64748B))
                                    }
                                }

                                // CASH PAYMENT
                                Surface(
                                    shape = RoundedCornerShape(8.dp),
                                    color = if (paymentMethod == "CASH") Color(0xFFFEF3C7) else PureWhite,
                                    border = androidx.compose.foundation.BorderStroke(
                                        if (paymentMethod == "CASH") 2.dp else 1.dp,
                                        if (paymentMethod == "CASH") Color(0xFFD97706) else Color(0xFFCBD5E1)
                                    ),
                                    modifier = Modifier
                                        .weight(1f)
                                        .clickable { paymentMethod = "CASH" }
                                        .testTag("select_cash_payment")
                                ) {
                                    Column(modifier = Modifier.padding(8.dp)) {
                                        Row(verticalAlignment = Alignment.CenterVertically) {
                                            Icon(Icons.Default.LocalAtm, contentDescription = null, tint = Color(0xFFD97706), modifier = Modifier.size(15.dp))
                                            Spacer(modifier = Modifier.width(3.dp))
                                            Text(text = "Cash", fontSize = 11.sp, fontWeight = FontWeight.Bold, color = Color(0xFF92400E))
                                        }
                                        Text(text = "Branch Cashier Till", fontSize = 9.sp, color = Color(0xFFB45309))
                                        Text(text = "Instant ETR Receipt", fontSize = 8.sp, color = Color(0xFF64748B))
                                    }
                                }
                            }
                        }
                    }
                }

                // 5. ORDER TOTAL & PROCEED BUTTONS
                item {
                    Card(
                        colors = CardDefaults.cardColors(containerColor = ObsidianBlack),
                        shape = RoundedCornerShape(10.dp),
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Column(modifier = Modifier.padding(14.dp)) {
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Column {
                                    Text(text = "TOTAL ORDER AMOUNT", fontSize = 10.sp, fontWeight = FontWeight.Bold, color = Color(0xFF94A3B8))
                                    val formattedPrice = if (currencyMode == "KES") "KES ${String.format(Locale.getDefault(), "%,.0f", totalAmountKes)}"
                                    else "$ ${String.format(Locale.getDefault(), "%,.0f", totalAmountUsd)}"
                                    Text(text = formattedPrice, fontSize = 20.sp, fontWeight = FontWeight.Bold, color = PureWhite)
                                }

                                Column(horizontalAlignment = Alignment.End) {
                                    Text(
                                        text = "Sales 5% Comm: KES ${String.format(Locale.getDefault(), "%,.0f", casketCommissionKes)}",
                                        fontSize = 11.sp,
                                        fontWeight = FontWeight.SemiBold,
                                        color = Color(0xFF60A5FA)
                                    )
                                    Text(
                                        text = "Agent: ${selectedSalesAgent.fullName.substringBefore(" ")}",
                                        fontSize = 10.sp,
                                        color = Color(0xFF94A3B8)
                                    )
                                }
                            }

                            Spacer(modifier = Modifier.height(12.dp))

                            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                                when (paymentMethod) {
                                    "M-PESA" -> {
                                        Button(
                                            onClick = { showStkPushDialog = true },
                                            colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF059669)),
                                            shape = RoundedCornerShape(6.dp),
                                            modifier = Modifier
                                                .weight(1f)
                                                .height(44.dp)
                                                .testTag("btn_trigger_mpesa_stk")
                                        ) {
                                            Icon(Icons.Default.PhoneAndroid, contentDescription = null, modifier = Modifier.size(16.dp))
                                            Spacer(modifier = Modifier.width(6.dp))
                                            Text("Send M-PESA STK Push", fontWeight = FontWeight.Bold, fontSize = 12.sp)
                                        }
                                    }
                                    "BANK_TRANSFER" -> {
                                        Button(
                                            onClick = { showBankTransferDialog = true },
                                            colors = ButtonDefaults.buttonColors(containerColor = RoyalCobaltBlue),
                                            shape = RoundedCornerShape(6.dp),
                                            modifier = Modifier
                                                .weight(1f)
                                                .height(44.dp)
                                                .testTag("btn_log_bank_transfer")
                                        ) {
                                            Icon(Icons.Default.AccountBalance, contentDescription = null, modifier = Modifier.size(16.dp))
                                            Spacer(modifier = Modifier.width(6.dp))
                                            Text("Log Bank Transfer (EFT/RTGS)", fontWeight = FontWeight.Bold, fontSize = 12.sp)
                                        }
                                    }
                                    else -> { // CASH
                                        Button(
                                            onClick = { showCashPaymentDialog = true },
                                            colors = ButtonDefaults.buttonColors(containerColor = Color(0xFFD97706)),
                                            shape = RoundedCornerShape(6.dp),
                                            modifier = Modifier
                                                .weight(1f)
                                                .height(44.dp)
                                                .testTag("btn_accept_cash")
                                        ) {
                                            Icon(Icons.Default.LocalAtm, contentDescription = null, modifier = Modifier.size(16.dp))
                                            Spacer(modifier = Modifier.width(6.dp))
                                            Text("Accept Cash & Issue Receipt", fontWeight = FontWeight.Bold, fontSize = 12.sp)
                                        }
                                    }
                                }
                            }
                        }
                    }
                }
            }
        } else if (activeSubTab == 1) {
            Box(modifier = Modifier.weight(1f)) {
                OrderDashboardScreen(
                    viewModel = viewModel,
                    onCreateNewOrderClick = { activeSubTab = 0 },
                    onOpenCostAnalyticsClick = { viewModel.setMainAppTab(MainAppTab.COST_ANALYTICS) }
                )
            }
        } else if (activeSubTab == 2) {
            // TAB 1: OTHER DESIGN (BESPOKE CASKET & EDITABLE PRICE TAG + MARGIN GUARD)
            val parsedCustomPrice = customPriceText.toDoubleOrNull()?.coerceAtLeast(0.0) ?: 0.0
            var customBomCostText by remember { mutableStateOf("45000") }
            val parsedBomCost = customBomCostText.toDoubleOrNull()?.coerceAtLeast(0.0) ?: 0.0
            val matEst = parsedBomCost * 0.65
            val laborEst = parsedBomCost * 0.23
            val finishEst = parsedBomCost * 0.12
            val marginEval = PayrollRulesEngine.evaluateBomMargin(
                sellingPriceKes = parsedCustomPrice,
                materialCostKes = matEst,
                laborCostKes = laborEst,
                finishingCostKes = finishEst
            )
            val customUsd = parsedCustomPrice / 130.0
            val customComm = parsedCustomPrice * 0.05

            Column(
                modifier = Modifier
                    .weight(1f)
                    .verticalScroll(rememberScrollState()),
                verticalArrangement = Arrangement.spacedBy(12.dp)
            ) {
                Card(
                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                    border = BorderStroke(1.dp, MaterialTheme.colorScheme.outline.copy(alpha = 0.25f)),
                    shape = RoundedCornerShape(12.dp),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Column(modifier = Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                        Text(
                            text = "Custom \"Other Design\" Coffin Builder",
                            fontSize = 15.sp,
                            fontWeight = FontWeight.Bold,
                            color = MaterialTheme.colorScheme.onSurface
                        )
                        Text(
                            text = "Specify bespoke dimensions, timber, interior finish & set the selling price tag with real-time Margin Guard verification.",
                            fontSize = 11.sp,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )

                        OutlinedTextField(
                            value = customDesignName,
                            onValueChange = { customDesignName = it },
                            label = { Text("Custom Casket / Design Name") },
                            placeholder = { Text("e.g. Royal Dome Carved Teak") },
                            singleLine = true,
                            modifier = Modifier.fillMaxWidth().testTag("order_other_design_name")
                        )

                        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                            OutlinedTextField(
                                value = customWoodType,
                                onValueChange = { customWoodType = it },
                                label = { Text("Timber / Material") },
                                singleLine = true,
                                modifier = Modifier.weight(1f)
                            )
                            OutlinedTextField(
                                value = customTier,
                                onValueChange = { customTier = it },
                                label = { Text("Tier Category") },
                                singleLine = true,
                                modifier = Modifier.weight(1f)
                            )
                        }

                        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                            OutlinedTextField(
                                value = customFinish,
                                onValueChange = { customFinish = it },
                                label = { Text("Exterior Finish") },
                                singleLine = true,
                                modifier = Modifier.weight(1f)
                            )
                            OutlinedTextField(
                                value = customLining,
                                onValueChange = { customLining = it },
                                label = { Text("Interior Lining") },
                                singleLine = true,
                                modifier = Modifier.weight(1f)
                            )
                        }

                        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                            OutlinedTextField(
                                value = customPriceText,
                                onValueChange = { customPriceText = it },
                                label = { Text("Selling Price (KES)") },
                                keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                                singleLine = true,
                                modifier = Modifier.weight(1.1f).testTag("order_other_design_price")
                            )
                            OutlinedTextField(
                                value = customBomCostText,
                                onValueChange = { customBomCostText = it },
                                label = { Text("Est. BOM Cost (KES)") },
                                keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                                singleLine = true,
                                modifier = Modifier.weight(1.1f).testTag("order_other_design_bom_cost")
                            )
                            OutlinedTextField(
                                value = customStockText,
                                onValueChange = { customStockText = it },
                                label = { Text("Units") },
                                keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                                singleLine = true,
                                modifier = Modifier.weight(0.65f)
                            )
                        }

                        Surface(
                            color = RoyalCobaltIce,
                            shape = RoundedCornerShape(8.dp),
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            Column(modifier = Modifier.padding(10.dp), verticalArrangement = Arrangement.spacedBy(4.dp)) {
                                Row(
                                    modifier = Modifier.fillMaxWidth(),
                                    horizontalArrangement = Arrangement.SpaceBetween
                                ) {
                                    Text(
                                        text = "USD Equiv: $${String.format(Locale.getDefault(), "%,.0f", customUsd)}",
                                        fontSize = 11.sp,
                                        fontWeight = FontWeight.Bold,
                                        color = RoyalCobaltBlue
                                    )
                                    Text(
                                        text = "5% Sales Comm: KES ${String.format(Locale.getDefault(), "%,.0f", customComm)}",
                                        fontSize = 11.sp,
                                        fontWeight = FontWeight.Bold,
                                        color = EmeraldSuccess
                                    )
                                }
                                Row(
                                    modifier = Modifier.fillMaxWidth(),
                                    horizontalArrangement = Arrangement.SpaceBetween
                                ) {
                                    Text(
                                        text = "BOM Gross Profit: KES ${String.format(Locale.getDefault(), "%,.0f", marginEval.profitKes)}",
                                        fontSize = 11.sp,
                                        fontWeight = FontWeight.SemiBold,
                                        color = Navy900
                                    )
                                    Text(
                                        text = "Margin: ${marginEval.marginPercent}%",
                                        fontSize = 11.sp,
                                        fontWeight = FontWeight.ExtraBold,
                                        color = when (marginEval.status) {
                                            MarginStatus.HEALTHY -> EmeraldSuccess
                                            MarginStatus.LOW_MARGIN -> Color(0xFFB45309)
                                            MarginStatus.BELOW_COST -> Color(0xFFDC2626)
                                        }
                                    )
                                }
                            }
                        }

                        if (marginEval.status != MarginStatus.HEALTHY && marginEval.warningMessage != null) {
                            Surface(
                                color = if (marginEval.status == MarginStatus.BELOW_COST) Color(0xFFFEE2E2) else AmberLight,
                                shape = RoundedCornerShape(8.dp),
                                border = BorderStroke(
                                    1.dp,
                                    if (marginEval.status == MarginStatus.BELOW_COST) Color(0xFFDC2626) else AmberWarning
                                ),
                                modifier = Modifier.fillMaxWidth().testTag("order_other_design_margin_warning")
                            ) {
                                Row(
                                    modifier = Modifier.padding(10.dp),
                                    verticalAlignment = Alignment.CenterVertically
                                ) {
                                    Icon(
                                        imageVector = Icons.Default.Warning,
                                        contentDescription = "Margin Guard Alert",
                                        tint = if (marginEval.status == MarginStatus.BELOW_COST) Color(0xFFDC2626) else Color(0xFFB45309),
                                        modifier = Modifier.size(18.dp)
                                    )
                                    Spacer(modifier = Modifier.width(8.dp))
                                    Text(
                                        text = marginEval.warningMessage,
                                        fontSize = 11.sp,
                                        fontWeight = FontWeight.SemiBold,
                                        color = if (marginEval.status == MarginStatus.BELOW_COST) Color(0xFF991B1B) else Color(0xFF92400E)
                                    )
                                }
                            }
                        }

                        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                            OutlinedButton(
                                onClick = {
                                    val newId = "CSK-CUST-${(100..999).random()}"
                                    val itemName = customDesignName.trim().ifBlank { "Custom Bespoke Design #$newId" }
                                    val item = CasketItem(
                                        id = newId,
                                        name = itemName,
                                        woodType = customWoodType.trim().ifBlank { "Seasoned Timber" },
                                        tier = customTier.trim().ifBlank { "Bespoke Custom" },
                                        priceKes = parsedCustomPrice,
                                        priceUsd = customUsd,
                                        finish = customFinish.trim().ifBlank { "Satin Gloss" },
                                        interiorLining = customLining.trim().ifBlank { "Velvet Crepe" },
                                        features = listOf("Custom Design", customWoodType, customLining),
                                        inStock = true,
                                        stockCount = customStockText.toIntOrNull() ?: 1
                                    )
                                    viewModel.addOrReplaceCasketItem(item)
                                    viewModel.raiseCustomMarginAlertIfNeeded(
                                        casketName = itemName,
                                        sellingPriceKes = parsedCustomPrice,
                                        materialCostKes = matEst,
                                        laborCostKes = laborEst,
                                        finishingCostKes = finishEst
                                    )
                                    selectedCasketId = item.id
                                },
                                shape = RoundedCornerShape(8.dp),
                                modifier = Modifier.weight(1f).height(44.dp).testTag("btn_save_other_design_catalog")
                            ) {
                                Text("Save to Catalog", fontSize = 11.sp, fontWeight = FontWeight.Bold, maxLines = 1, softWrap = false)
                            }

                            Button(
                                onClick = {
                                    val newId = "CSK-CUST-${(100..999).random()}"
                                    val itemName = customDesignName.trim().ifBlank { "Custom Bespoke Design #$newId" }
                                    val item = CasketItem(
                                        id = newId,
                                        name = itemName,
                                        woodType = customWoodType.trim().ifBlank { "Seasoned Timber" },
                                        tier = customTier.trim().ifBlank { "Bespoke Custom" },
                                        priceKes = parsedCustomPrice,
                                        priceUsd = customUsd,
                                        finish = customFinish.trim().ifBlank { "Satin Gloss" },
                                        interiorLining = customLining.trim().ifBlank { "Velvet Crepe" },
                                        features = listOf("Custom Design", customWoodType, customLining),
                                        inStock = true,
                                        stockCount = customStockText.toIntOrNull() ?: 1
                                    )
                                    viewModel.addOrReplaceCasketItem(item)
                                    viewModel.raiseCustomMarginAlertIfNeeded(
                                        casketName = itemName,
                                        sellingPriceKes = parsedCustomPrice,
                                        materialCostKes = matEst,
                                        laborCostKes = laborEst,
                                        finishingCostKes = finishEst
                                    )
                                    selectedCasketId = item.id
                                    activeSubTab = 0
                                },
                                colors = ButtonDefaults.buttonColors(containerColor = RoyalCobaltBlue),
                                shape = RoundedCornerShape(8.dp),
                                modifier = Modifier.weight(1.2f).height(44.dp).testTag("btn_use_other_design_checkout")
                            ) {
                                Text("Use in Checkout", fontSize = 11.sp, fontWeight = FontWeight.Bold, maxLines = 1, softWrap = false)
                            }
                        }
                    }
                }
            }
        } else {
            // TAB 2: INVOICES & TAX RECEIPTS VIEWER
            LazyColumn(
                modifier = Modifier.weight(1f),
                verticalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                items(customerOrders) { order ->
                    Card(
                        colors = CardDefaults.cardColors(containerColor = PureWhite),
                        shape = RoundedCornerShape(8.dp),
                        border = androidx.compose.foundation.BorderStroke(1.dp, Color(0xFFE2E8F0)),
                        modifier = Modifier
                            .fillMaxWidth()
                            .testTag("order_receipt_card_${order.orderId}")
                    ) {
                        Column(modifier = Modifier.padding(14.dp)) {
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Row(verticalAlignment = Alignment.CenterVertically) {
                                    Icon(Icons.Default.Receipt, contentDescription = null, tint = RoyalCobaltBlue, modifier = Modifier.size(16.dp))
                                    Spacer(modifier = Modifier.width(6.dp))
                                    Text(text = "TAX INVOICE: ${order.orderId}", fontSize = 12.sp, fontWeight = FontWeight.Bold, color = ObsidianBlack)
                                }

                                Surface(
                                    color = EmeraldLight,
                                    shape = RoundedCornerShape(12.dp)
                                ) {
                                    Text(
                                        text = order.paymentStatus,
                                        fontSize = 10.sp,
                                        fontWeight = FontWeight.SemiBold,
                                        color = EmeraldSuccess,
                                        modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp)
                                    )
                                }
                            }

                            Spacer(modifier = Modifier.height(8.dp))

                            Text(text = "Client: ${order.clientName} (${order.clientPhone})", fontSize = 12.sp, fontWeight = FontWeight.SemiBold, color = ObsidianBlack)
                            Text(text = "Deceased: ${order.deceasedName}", fontSize = 11.sp, color = Color(0xFF475569))
                            Text(text = "Package: ${order.selectedPackage} • Casket: ${order.selectedCasket}", fontSize = 11.sp, color = RoyalCobaltBlue, fontWeight = FontWeight.Medium)
                            Text(text = "Addons: ${if (order.selectedAddons.isEmpty()) "Standard package inclusions" else order.selectedAddons.joinToString(", ")}", fontSize = 10.sp, color = Color(0xFF64748B))

                            Spacer(modifier = Modifier.height(8.dp))

                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Column {
                                    Text(text = "Total Paid / Invoiced:", fontSize = 10.sp, color = Color(0xFF64748B))
                                    Text(
                                        text = "KES ${String.format(Locale.getDefault(), "%,.0f", order.totalAmountKes)} ($ ${String.format(Locale.getDefault(), "%,.0f", order.totalAmountUsd)})",
                                        fontSize = 14.sp,
                                        fontWeight = FontWeight.Bold,
                                        color = ObsidianBlack
                                    )
                                    Text(text = "Ref: ${order.referenceCode} • ${order.paymentMethod}", fontSize = 10.sp, color = Color(0xFF059669), fontWeight = FontWeight.SemiBold)
                                }

                                Column(horizontalAlignment = Alignment.End) {
                                    Text(text = "Branch: ${order.branch}", fontSize = 10.sp, color = Color(0xFF64748B))
                                    Text(text = "Sales: ${order.salesAgentName}", fontSize = 10.sp, color = Color(0xFF64748B))
                                    Text(
                                        text = "5% Casket Comm: KES ${String.format(Locale.getDefault(), "%,.0f", order.commissionEarnedKes)}",
                                        fontSize = 10.sp,
                                        fontWeight = FontWeight.Bold,
                                        color = RoyalCobaltBlue
                                    )
                                }
                            }

                            Spacer(modifier = Modifier.height(10.dp))

                            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                                OutlinedButton(
                                    onClick = {
                                        clipboardManager.setText(AnnotatedString("JABIMA TAX INVOICE\nOrder: ${order.orderId}\nClient: ${order.clientName}\nDeceased: ${order.deceasedName}\nTotal: KES ${order.totalAmountKes}\nRef: ${order.referenceCode}"))
                                        viewModel.actionFeedbackMessage.value = "Receipt text copied to clipboard!"
                                    },
                                    modifier = Modifier.weight(1f).height(36.dp),
                                    shape = RoundedCornerShape(6.dp)
                                ) {
                                    Icon(Icons.Default.ContentCopy, contentDescription = null, modifier = Modifier.size(14.dp))
                                    Spacer(modifier = Modifier.width(4.dp))
                                    Text("Copy Details", fontSize = 10.sp)
                                }

                                Button(
                                    onClick = {
                                        lastSubmittedOrder = order
                                        showSuccessReceiptDialog = true
                                    },
                                    colors = ButtonDefaults.buttonColors(containerColor = RoyalCobaltBlue),
                                    modifier = Modifier.weight(1f).height(36.dp),
                                    shape = RoundedCornerShape(6.dp)
                                ) {
                                    Icon(Icons.Default.Print, contentDescription = null, modifier = Modifier.size(14.dp))
                                    Spacer(modifier = Modifier.width(4.dp))
                                    Text("View & Print", fontSize = 10.sp)
                                }
                            }
                        }
                    }
                }
            }
        }
    }

    // ==========================================
    // DIALOG: M-PESA STK PUSH PROMPT
    // ==========================================
    if (showStkPushDialog) {
        var inputMpesaPhone by remember { mutableStateOf(if (clientPhone.isNotBlank()) clientPhone else MPESA_STK_NUMBER) }
        var isSimulatingPush by remember { mutableStateOf(false) }

        Dialog(onDismissRequest = { showStkPushDialog = false }) {
            Surface(
                shape = RoundedCornerShape(12.dp),
                color = PureWhite,
                modifier = Modifier.fillMaxWidth().padding(8.dp).testTag("dialog_mpesa_stk_push")
            ) {
                Column(modifier = Modifier.padding(16.dp)) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Icon(Icons.Default.PhoneAndroid, contentDescription = null, tint = Color(0xFF059669))
                            Spacer(modifier = Modifier.width(6.dp))
                            Text("Safaricom M-PESA STK Push", fontSize = 15.sp, fontWeight = FontWeight.Bold, color = Color(0xFF065F46))
                        }
                        IconButton(onClick = { showStkPushDialog = false }) {
                            Icon(Icons.Default.Close, contentDescription = "Close", tint = Color(0xFF64748B))
                        }
                    }

                    Spacer(modifier = Modifier.height(8.dp))

                    Surface(
                        color = Color(0xFFECFDF5),
                        shape = RoundedCornerShape(8.dp),
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Column(modifier = Modifier.padding(10.dp)) {
                            Text(text = "Paybill Number: $MPESA_PAYBILL_NUMBER", fontWeight = FontWeight.Bold, fontSize = 12.sp, color = Color(0xFF065F46))
                            Text(text = "STK Line: $MPESA_STK_NUMBER", fontSize = 11.sp, color = Color(0xFF047857))
                            Text(
                                text = "Amount Due: KES ${String.format(Locale.getDefault(), "%,.0f", totalAmountKes)}",
                                fontWeight = FontWeight.Bold,
                                fontSize = 13.sp,
                                color = Color(0xFF065F46)
                            )
                        }
                    }

                    Spacer(modifier = Modifier.height(10.dp))

                    OutlinedTextField(
                        value = inputMpesaPhone,
                        onValueChange = { inputMpesaPhone = it },
                        label = { Text("Client M-PESA Phone Number", fontSize = 12.sp) },
                        modifier = Modifier.fillMaxWidth().testTag("input_mpesa_stk_phone"),
                        singleLine = true
                    )

                    Spacer(modifier = Modifier.height(12.dp))

                    Button(
                        onClick = {
                            isSimulatingPush = true
                            val ref = "MPESA-${(100000..999999).random()}"
                            generatedRefCode = ref
                            val newOrder = CustomerOrderRecord(
                                orderId = "JFD-ORD-${(100..999).random()}",
                                clientName = clientName.ifBlank { "Family of Case #${(10..99).random()}" },
                                clientPhone = inputMpesaPhone,
                                deceasedName = deceasedName.ifBlank { "The Late" },
                                selectedPackage = selectedPackage.name,
                                selectedCasket = "${selectedCasket.name} (KES ${String.format(Locale.getDefault(), "%,.0f", selectedCasket.priceKes)})",
                                selectedAddons = selectedAddonsList.map { "${it.name} (+KES ${String.format(Locale.getDefault(), "%,.0f", it.priceKes)})" },
                                totalAmountKes = totalAmountKes,
                                totalAmountUsd = totalAmountUsd,
                                paymentMethod = "M-PESA",
                                paymentTerms = paymentTerms,
                                paymentStatus = "Confirmed (M-PESA STK Verified)",
                                referenceCode = ref,
                                orderDate = SimpleDateFormat("dd MMM yyyy, HH:mm", Locale.getDefault()).format(Date()),
                                branch = selectedBranch,
                                salesAgentName = selectedSalesAgent.fullName,
                                commissionEarnedKes = casketCommissionKes
                            )
                            viewModel.submitCustomerOrder(newOrder)
                            lastSubmittedOrder = newOrder
                            showStkPushDialog = false
                            showSuccessReceiptDialog = true
                        },
                        colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF059669)),
                        shape = RoundedCornerShape(6.dp),
                        modifier = Modifier.fillMaxWidth().height(44.dp).testTag("btn_confirm_mpesa_push")
                    ) {
                        Icon(Icons.AutoMirrored.Filled.Send, contentDescription = null, modifier = Modifier.size(16.dp))
                        Spacer(modifier = Modifier.width(6.dp))
                        Text("Send STK Push & Generate Receipt", fontWeight = FontWeight.Bold)
                    }
                }
            }
        }
    }

    // ==========================================
    // DIALOG: BANK TRANSFER DETAILS (WIRE / EFT / RTGS)
    // ==========================================
    if (showBankTransferDialog) {
        var bankRefInput by remember { mutableStateOf("SCB-RTGS-${(100000..999999).random()}") }

        Dialog(onDismissRequest = { showBankTransferDialog = false }) {
            Surface(
                shape = RoundedCornerShape(12.dp),
                color = PureWhite,
                modifier = Modifier.fillMaxWidth().padding(8.dp).testTag("dialog_bank_transfer")
            ) {
                Column(modifier = Modifier.padding(16.dp)) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Icon(Icons.Default.AccountBalance, contentDescription = null, tint = RoyalCobaltBlue)
                            Spacer(modifier = Modifier.width(6.dp))
                            Text("Standard Chartered Bank Transfer", fontSize = 15.sp, fontWeight = FontWeight.Bold, color = ObsidianBlack)
                        }
                        IconButton(onClick = { showBankTransferDialog = false }) {
                            Icon(Icons.Default.Close, contentDescription = "Close", tint = Color(0xFF64748B))
                        }
                    }

                    Spacer(modifier = Modifier.height(8.dp))

                    Surface(
                        color = RoyalCobaltIce,
                        shape = RoundedCornerShape(8.dp),
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Column(modifier = Modifier.padding(10.dp)) {
                            Text(text = "Bank: $BANK_NAME", fontWeight = FontWeight.Bold, fontSize = 12.sp, color = RoyalCobaltBlue)
                            Text(text = "Account Name: $BANK_ACCOUNT_NAME", fontSize = 11.sp, color = Color(0xFF1E3A8A))
                            Text(text = "Account Number: $BANK_ACCOUNT_NUMBER", fontWeight = FontWeight.Bold, fontSize = 12.sp, color = ObsidianBlack)
                            Text(text = "Swift Code: $BANK_SWIFT_CODE", fontWeight = FontWeight.Bold, fontSize = 12.sp, color = RoyalCobaltBlue)
                            Text(text = "Amount: KES ${String.format(Locale.getDefault(), "%,.0f", totalAmountKes)} ($ ${String.format(Locale.getDefault(), "%,.0f", totalAmountUsd)})", fontWeight = FontWeight.Bold, fontSize = 12.sp, color = ObsidianBlack)
                        }
                    }

                    Spacer(modifier = Modifier.height(10.dp))

                    OutlinedTextField(
                        value = bankRefInput,
                        onValueChange = { bankRefInput = it },
                        label = { Text("Bank Transfer Reference / Transaction ID", fontSize = 12.sp) },
                        modifier = Modifier.fillMaxWidth().testTag("input_bank_ref"),
                        singleLine = true
                    )

                    Spacer(modifier = Modifier.height(12.dp))

                    Button(
                        onClick = {
                            val ref = bankRefInput.ifBlank { "SCB-REF-${(100000..999999).random()}" }
                            generatedRefCode = ref
                            val newOrder = CustomerOrderRecord(
                                orderId = "JFD-ORD-${(100..999).random()}",
                                clientName = clientName.ifBlank { "Family of Case #${(10..99).random()}" },
                                clientPhone = clientPhone.ifBlank { "+254700000000" },
                                deceasedName = deceasedName.ifBlank { "The Late" },
                                selectedPackage = selectedPackage.name,
                                selectedCasket = "${selectedCasket.name} (KES ${String.format(Locale.getDefault(), "%,.0f", selectedCasket.priceKes)})",
                                selectedAddons = selectedAddonsList.map { "${it.name} (+KES ${String.format(Locale.getDefault(), "%,.0f", it.priceKes)})" },
                                totalAmountKes = totalAmountKes,
                                totalAmountUsd = totalAmountUsd,
                                paymentMethod = "BANK_TRANSFER",
                                paymentTerms = paymentTerms,
                                paymentStatus = "Verified & Cleared ($BANK_SWIFT_CODE)",
                                referenceCode = ref,
                                orderDate = SimpleDateFormat("dd MMM yyyy, HH:mm", Locale.getDefault()).format(Date()),
                                branch = selectedBranch,
                                salesAgentName = selectedSalesAgent.fullName,
                                commissionEarnedKes = casketCommissionKes
                            )
                            viewModel.submitCustomerOrder(newOrder)
                            lastSubmittedOrder = newOrder
                            showBankTransferDialog = false
                            showSuccessReceiptDialog = true
                        },
                        colors = ButtonDefaults.buttonColors(containerColor = RoyalCobaltBlue),
                        shape = RoundedCornerShape(6.dp),
                        modifier = Modifier.fillMaxWidth().height(44.dp).testTag("btn_confirm_bank_transfer")
                    ) {
                        Icon(Icons.Default.Check, contentDescription = null, modifier = Modifier.size(16.dp))
                        Spacer(modifier = Modifier.width(6.dp))
                        Text("Log & Verify Bank Transfer", fontWeight = FontWeight.Bold)
                    }
                }
            }
        }
    }

    // ==========================================
    // DIALOG: OFFICIAL TAX INVOICE & DIGITAL RECEIPT VIEWER
    // ==========================================
    if (showSuccessReceiptDialog && lastSubmittedOrder != null) {
        val order = lastSubmittedOrder!!
        Dialog(onDismissRequest = { showSuccessReceiptDialog = false }) {
            Surface(
                shape = RoundedCornerShape(12.dp),
                color = PureWhite,
                modifier = Modifier.fillMaxWidth().padding(6.dp).testTag("dialog_tax_receipt_viewer")
            ) {
                Column(
                    modifier = Modifier.padding(14.dp)
                ) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text("OFFICIAL TAX INVOICE & RECEIPT", fontWeight = FontWeight.Bold, fontSize = 13.sp, color = ObsidianBlack)
                        IconButton(onClick = { showSuccessReceiptDialog = false }) {
                            Icon(Icons.Default.Close, contentDescription = "Close", tint = Color(0xFF64748B))
                        }
                    }

                    // Thermal / ETR Styled Paper Look
                    Surface(
                        color = Color(0xFFFAFAFA),
                        shape = RoundedCornerShape(6.dp),
                        border = androidx.compose.foundation.BorderStroke(1.dp, Color(0xFFE2E8F0)),
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Column(modifier = Modifier.padding(10.dp)) {
                            Text(text = "JABIMA FUNERAL DIRECTORS LTD", fontWeight = FontWeight.Bold, fontSize = 13.sp, textAlign = TextAlign.Center, modifier = Modifier.fillMaxWidth(), color = ObsidianBlack)
                            Text(text = "P.O. Box 482 - Siaya, Kenya | Pin: P051928192X", fontSize = 10.sp, textAlign = TextAlign.Center, modifier = Modifier.fillMaxWidth(), color = Color(0xFF64748B))
                            Text(text = "Branch: ${order.branch} | 24/7 Hotline: +254793553434", fontSize = 9.sp, textAlign = TextAlign.Center, modifier = Modifier.fillMaxWidth(), color = RoyalCobaltBlue)
                            Text(text = "--------------------------------------------------", fontSize = 9.sp, textAlign = TextAlign.Center, modifier = Modifier.fillMaxWidth(), color = Color(0xFFCBD5E1))

                            Text(text = "Invoice / Receipt #: ${order.orderId}", fontSize = 10.sp, fontWeight = FontWeight.Bold, color = ObsidianBlack)
                            Text(text = "Date: ${order.orderDate}", fontSize = 9.sp, color = Color(0xFF64748B))
                            Text(text = "Client: ${order.clientName} (${order.clientPhone})", fontSize = 10.sp, color = ObsidianBlack)
                            Text(text = "Deceased: ${order.deceasedName}", fontSize = 10.sp, fontWeight = FontWeight.SemiBold, color = ObsidianBlack)
                            Text(text = "--------------------------------------------------", fontSize = 9.sp, textAlign = TextAlign.Center, modifier = Modifier.fillMaxWidth(), color = Color(0xFFCBD5E1))

                            Text(text = "Itemized Breakdown:", fontSize = 10.sp, fontWeight = FontWeight.Bold, color = ObsidianBlack)
                            Text(text = "• Package: ${order.selectedPackage}", fontSize = 10.sp, color = Color(0xFF334155))
                            Text(text = "• Casket: ${order.selectedCasket}", fontSize = 10.sp, color = Color(0xFF334155))
                            if (order.selectedAddons.isNotEmpty()) {
                                order.selectedAddons.forEach { addon ->
                                    Text(text = "• Add-on: $addon", fontSize = 10.sp, color = Color(0xFF334155))
                                }
                            }

                            Text(text = "--------------------------------------------------", fontSize = 9.sp, textAlign = TextAlign.Center, modifier = Modifier.fillMaxWidth(), color = Color(0xFFCBD5E1))
                            Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                                Text(text = "TOTAL AMOUNT:", fontWeight = FontWeight.Bold, fontSize = 12.sp, color = ObsidianBlack)
                                Text(text = "KES ${String.format(Locale.getDefault(), "%,.0f", order.totalAmountKes)} ($ ${String.format(Locale.getDefault(), "%,.0f", order.totalAmountUsd)})", fontWeight = FontWeight.Bold, fontSize = 12.sp, color = RoyalCobaltBlue)
                            }

                            Text(text = "Payment Method: ${order.paymentMethod} (Ref: ${order.referenceCode})", fontSize = 10.sp, color = Color(0xFF059669), fontWeight = FontWeight.SemiBold)
                            Text(text = "Payment Terms: ${order.paymentTerms}", fontSize = 9.sp, color = Color(0xFF64748B))
                            Text(text = "Sales Counselor: ${order.salesAgentName} (5% Casket Comm: KES ${String.format(Locale.getDefault(), "%,.0f", order.commissionEarnedKes)})", fontSize = 9.sp, color = Color(0xFF1E3A8A))
                        }
                    }

                    Spacer(modifier = Modifier.height(10.dp))

                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        Button(
                            onClick = {
                                viewModel.actionFeedbackMessage.value = "Receipt sent to thermal printer on ${order.branch} queue."
                                showSuccessReceiptDialog = false
                            },
                            colors = ButtonDefaults.buttonColors(containerColor = RoyalCobaltBlue),
                            shape = RoundedCornerShape(6.dp),
                            modifier = Modifier.weight(1f).height(40.dp)
                        ) {
                            Icon(Icons.Default.Print, contentDescription = null, modifier = Modifier.size(14.dp))
                            Spacer(modifier = Modifier.width(4.dp))
                            Text("Print Thermal Slip", fontSize = 11.sp, fontWeight = FontWeight.Bold)
                        }

                        OutlinedButton(
                            onClick = {
                                viewModel.sendBulkSms(
                                    recipientType = "Client Family",
                                    recipients = order.clientPhone,
                                    body = "Jabima Funeral Directors Ltd: Receipt confirmed for ${order.clientName} (Order #${order.orderId}). Casket & Service scheduled at ${order.branch}. Ref: ${order.referenceCode}. Hotline: +254793553434."
                                )
                                showSuccessReceiptDialog = false
                            },
                            shape = RoundedCornerShape(6.dp),
                            modifier = Modifier.weight(1f).height(40.dp)
                        ) {
                            Icon(Icons.AutoMirrored.Filled.Send, contentDescription = null, modifier = Modifier.size(14.dp))
                            Spacer(modifier = Modifier.width(4.dp))
                            Text("SMS Receipt", fontSize = 11.sp)
                        }
                    }

                    Spacer(modifier = Modifier.height(8.dp))

                    OutlinedButton(
                        onClick = {
                            runCatching {
                                val pdfFile = PdfDocumentGenerator.generateOrderTaxReceiptPdf(context, order)
                                PdfDocumentGenerator.sharePdfFile(
                                    context = context,
                                    pdfFile = pdfFile,
                                    title = "Jabima Tax Invoice #${order.orderId}"
                                )
                            }
                            viewModel.actionFeedbackMessage.value = "Generated printable A4 PDF Tax Invoice for Order #${order.orderId}."
                        },
                        shape = RoundedCornerShape(6.dp),
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(40.dp)
                            .testTag("btn_share_pdf_receipt")
                    ) {
                        Icon(Icons.Default.PictureAsPdf, contentDescription = null, modifier = Modifier.size(15.dp), tint = RoyalCobaltBlue)
                        Spacer(modifier = Modifier.width(6.dp))
                        Text("Share Printable PDF Invoice", fontSize = 11.sp, fontWeight = FontWeight.Bold, color = RoyalCobaltBlue)
                    }
                }
            }
        }
    }

    // ==========================================
    // DIALOG: CASH PAYMENT CONFIRMATION
    // ==========================================
    if (showCashPaymentDialog) {
        var inputTendered by remember { mutableStateOf("${totalAmountKes.toInt()}") }
        val tenderedVal = inputTendered.toDoubleOrNull() ?: 0.0
        val changeVal = (tenderedVal - totalAmountKes).coerceAtLeast(0.0)

        Dialog(onDismissRequest = { showCashPaymentDialog = false }) {
            Surface(
                shape = RoundedCornerShape(12.dp),
                color = PureWhite,
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(8.dp)
                    .testTag("dialog_cash_payment")
            ) {
                Column(modifier = Modifier.padding(16.dp)) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Icon(Icons.Default.LocalAtm, contentDescription = null, tint = Color(0xFFD97706))
                            Spacer(modifier = Modifier.width(6.dp))
                            Text("Cash Payment & ETR Receipt", fontSize = 15.sp, fontWeight = FontWeight.Bold, color = Color(0xFF92400E))
                        }
                        IconButton(onClick = { showCashPaymentDialog = false }) {
                            Icon(Icons.Default.Close, contentDescription = "Close", tint = Color(0xFF64748B))
                        }
                    }

                    Spacer(modifier = Modifier.height(10.dp))

                    Surface(
                        color = Color(0xFFFEF3C7),
                        shape = RoundedCornerShape(8.dp),
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Column(modifier = Modifier.padding(10.dp)) {
                            Text(text = "Branch Cashier Till: $selectedBranch", fontWeight = FontWeight.Bold, fontSize = 12.sp, color = Color(0xFF92400E))
                            Text(
                                text = "Total Bill Amount: KES ${String.format(Locale.getDefault(), "%,.0f", totalAmountKes)}",
                                fontWeight = FontWeight.ExtraBold,
                                fontSize = 14.sp,
                                color = Color(0xFF92400E)
                            )
                        }
                    }

                    Spacer(modifier = Modifier.height(12.dp))

                    OutlinedTextField(
                        value = inputTendered,
                        onValueChange = { inputTendered = it },
                        label = { Text("Cash Received from Client (KES)", fontSize = 12.sp) },
                        modifier = Modifier
                            .fillMaxWidth()
                            .testTag("input_cash_tendered"),
                        singleLine = true
                    )

                    Spacer(modifier = Modifier.height(8.dp))

                    Surface(
                        color = Color(0xFFF1F5F9),
                        shape = RoundedCornerShape(6.dp),
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Row(
                            modifier = Modifier
                                .padding(8.dp)
                                .fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween
                        ) {
                            Text("Change to Return:", fontSize = 12.sp, color = Color(0xFF475569))
                            Text(
                                text = "KES ${String.format(Locale.getDefault(), "%,.0f", changeVal)}",
                                fontSize = 12.sp,
                                fontWeight = FontWeight.Bold,
                                color = Color(0xFF15803D)
                            )
                        }
                    }

                    Spacer(modifier = Modifier.height(14.dp))

                    Button(
                        onClick = {
                            val ref = "CASH-RCP-${(100000..999999).random()}"
                            generatedRefCode = ref
                            val newOrder = CustomerOrderRecord(
                                orderId = "JFD-ORD-${(100..999).random()}",
                                clientName = clientName.ifBlank { "Walk-in Cash Client" },
                                clientPhone = clientPhone.ifBlank { "+254 700 000 000" },
                                deceasedName = deceasedName.ifBlank { "The Late" },
                                selectedPackage = selectedPackage.name,
                                selectedCasket = "${selectedCasket.name} (KES ${String.format(Locale.getDefault(), "%,.0f", selectedCasket.priceKes)})",
                                selectedAddons = selectedAddonsList.map { "${it.name} (+KES ${String.format(Locale.getDefault(), "%,.0f", it.priceKes)})" },
                                totalAmountKes = totalAmountKes,
                                totalAmountUsd = totalAmountUsd,
                                paymentMethod = "CASH",
                                paymentTerms = paymentTerms,
                                paymentStatus = "Confirmed & Paid (Cash Counter)",
                                referenceCode = ref,
                                orderDate = SimpleDateFormat("dd MMM yyyy, HH:mm", Locale.getDefault()).format(Date()),
                                branch = selectedBranch,
                                salesAgentName = selectedSalesAgent.fullName,
                                commissionEarnedKes = casketCommissionKes
                            )
                            viewModel.submitCustomerOrder(newOrder)
                            lastSubmittedOrder = newOrder
                            showCashPaymentDialog = false
                            showSuccessReceiptDialog = true
                        },
                        colors = ButtonDefaults.buttonColors(containerColor = Color(0xFFD97706)),
                        shape = RoundedCornerShape(8.dp),
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(44.dp)
                            .testTag("btn_confirm_cash_payment")
                    ) {
                        Icon(Icons.Default.CheckCircle, contentDescription = null, modifier = Modifier.size(16.dp))
                        Spacer(modifier = Modifier.width(6.dp))
                        Text("Confirm Cash Received & Issue Receipt", fontWeight = FontWeight.Bold, fontSize = 12.sp)
                    }
                }
            }
        }
    }

    // ADMIN INLINE EDIT DIALOGS
    inlineEditCasket?.let { csk ->
        var editName by remember { mutableStateOf(csk.name) }
        var editWood by remember { mutableStateOf(csk.woodType) }
        var editTier by remember { mutableStateOf(csk.tier) }
        var editPrice by remember { mutableStateOf(csk.priceKes.toLong().toString()) }
        Dialog(onDismissRequest = { inlineEditCasket = null }) {
            Surface(shape = RoundedCornerShape(14.dp), color = MaterialTheme.colorScheme.surface) {
                Column(modifier = Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    Text("Admin: Edit Casket Type & Price", fontWeight = FontWeight.Bold, fontSize = 15.sp)
                    OutlinedTextField(value = editName, onValueChange = { editName = it }, label = { Text("Casket Name") }, singleLine = true, modifier = Modifier.fillMaxWidth())
                    OutlinedTextField(value = editWood, onValueChange = { editWood = it }, label = { Text("Wood / Material") }, singleLine = true, modifier = Modifier.fillMaxWidth())
                    OutlinedTextField(value = editTier, onValueChange = { editTier = it }, label = { Text("Tier") }, singleLine = true, modifier = Modifier.fillMaxWidth())
                    OutlinedTextField(
                        value = editPrice,
                        onValueChange = { editPrice = it },
                        label = { Text("Price (KES)") },
                        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                        singleLine = true,
                        modifier = Modifier.fillMaxWidth()
                    )
                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp), modifier = Modifier.fillMaxWidth()) {
                        OutlinedButton(onClick = { inlineEditCasket = null }, modifier = Modifier.weight(1f)) { Text("Cancel") }
                        Button(
                            onClick = {
                                val price = editPrice.toDoubleOrNull() ?: csk.priceKes
                                viewModel.addOrReplaceCasketItem(
                                    csk.copy(
                                        name = editName.trim().ifBlank { csk.name },
                                        woodType = editWood.trim().ifBlank { csk.woodType },
                                        tier = editTier.trim().ifBlank { csk.tier },
                                        priceKes = price,
                                        priceUsd = price / 130.0
                                    )
                                )
                                viewModel.updateCasketPrice(csk.id, price, csk.priceUsd, csk.stockCount, csk.inStock, "Inline Order & Pay adjustment")
                                inlineEditCasket = null
                            },
                            colors = ButtonDefaults.buttonColors(containerColor = RoyalCobaltBlue),
                            modifier = Modifier.weight(1f)
                        ) { Text("Save") }
                    }
                }
            }
        }
    }

    inlineEditPackage?.let { pkg ->
        var editPrice by remember { mutableStateOf(pkg.priceKes.toLong().toString()) }
        Dialog(onDismissRequest = { inlineEditPackage = null }) {
            Surface(shape = RoundedCornerShape(14.dp), color = MaterialTheme.colorScheme.surface) {
                Column(modifier = Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    Text("Admin: Adjust Package Price", fontWeight = FontWeight.Bold, fontSize = 15.sp)
                    Text(pkg.name, fontSize = 12.sp, color = RoyalCobaltBlue)
                    OutlinedTextField(
                        value = editPrice,
                        onValueChange = { editPrice = it },
                        label = { Text("Package Price (KES)") },
                        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                        singleLine = true,
                        modifier = Modifier.fillMaxWidth()
                    )
                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp), modifier = Modifier.fillMaxWidth()) {
                        OutlinedButton(onClick = { inlineEditPackage = null }, modifier = Modifier.weight(1f)) { Text("Cancel") }
                        Button(
                            onClick = {
                                viewModel.updateOrderPackagePrice(pkg.id, editPrice.toDoubleOrNull() ?: pkg.priceKes)
                                inlineEditPackage = null
                            },
                            colors = ButtonDefaults.buttonColors(containerColor = EmeraldSuccess),
                            modifier = Modifier.weight(1f)
                        ) { Text("Update") }
                    }
                }
            }
        }
    }

    inlineEditAddon?.let { addon ->
        var editPrice by remember { mutableStateOf(addon.priceKes.toLong().toString()) }
        Dialog(onDismissRequest = { inlineEditAddon = null }) {
            Surface(shape = RoundedCornerShape(14.dp), color = MaterialTheme.colorScheme.surface) {
                Column(modifier = Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    Text("Admin: Adjust Add-On Price", fontWeight = FontWeight.Bold, fontSize = 15.sp)
                    Text(addon.name, fontSize = 12.sp, color = RoyalCobaltBlue)
                    OutlinedTextField(
                        value = editPrice,
                        onValueChange = { editPrice = it },
                        label = { Text("Add-On Fee (KES)") },
                        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                        singleLine = true,
                        modifier = Modifier.fillMaxWidth()
                    )
                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp), modifier = Modifier.fillMaxWidth()) {
                        OutlinedButton(onClick = { inlineEditAddon = null }, modifier = Modifier.weight(1f)) { Text("Cancel") }
                        Button(
                            onClick = {
                                viewModel.updateOrderAddonPrice(addon.id, editPrice.toDoubleOrNull() ?: addon.priceKes)
                                inlineEditAddon = null
                            },
                            colors = ButtonDefaults.buttonColors(containerColor = EmeraldSuccess),
                            modifier = Modifier.weight(1f)
                        ) { Text("Update") }
                    }
                }
            }
        }
    }
}
