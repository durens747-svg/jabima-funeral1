package com.example.data.firebase

import com.google.firebase.firestore.FirebaseFirestoreException
import kotlinx.coroutines.CancellationException

sealed class FirestoreOperationError(val userMessage: String, val isRetryable: Boolean) {
    data object Unauthenticated : FirestoreOperationError("Please sign in with Google to sync cloud records.", false)
    data object PermissionDenied : FirestoreOperationError("Access denied by cloud security rules. Admin privileges may be required.", false)
    data object NetworkUnavailable : FirestoreOperationError("Offline or cloud service unreachable. Changes remain cached locally.", true)
    data object NotFound : FirestoreOperationError("Requested cloud document no longer exists.", false)
    data class ValidationOrUnknown(val message: String) : FirestoreOperationError(message, false)
}

object FirestoreErrorHandler {

    fun mapException(throwable: Throwable): FirestoreOperationError {
        val fsEx = unwrapFirestoreException(throwable)
        if (fsEx != null) {
            return when (fsEx.code) {
                FirebaseFirestoreException.Code.PERMISSION_DENIED -> FirestoreOperationError.PermissionDenied
                FirebaseFirestoreException.Code.UNAUTHENTICATED -> FirestoreOperationError.Unauthenticated
                FirebaseFirestoreException.Code.UNAVAILABLE,
                FirebaseFirestoreException.Code.DEADLINE_EXCEEDED -> FirestoreOperationError.NetworkUnavailable
                FirebaseFirestoreException.Code.NOT_FOUND -> FirestoreOperationError.NotFound
                else -> FirestoreOperationError.ValidationOrUnknown(
                    fsEx.localizedMessage ?: "Cloud sync error (${fsEx.code.name})"
                )
            }
        }
        return FirestoreOperationError.ValidationOrUnknown(
            throwable.localizedMessage ?: "Unexpected cloud synchronization error."
        )
    }

    tailrec fun unwrapFirestoreException(t: Throwable?): FirebaseFirestoreException? = when (t) {
        null -> null
        is FirebaseFirestoreException -> t
        else -> unwrapFirestoreException(t.cause)
    }

    fun isCancellationWithoutFirestoreError(t: Throwable): Boolean {
        return t is CancellationException && unwrapFirestoreException(t) == null
    }
}
