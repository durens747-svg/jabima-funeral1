package com.example.ui.screens

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.AccountBalanceWallet
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.AdminPanelSettings
import androidx.compose.material.icons.filled.AttachMoney
import androidx.compose.material.icons.filled.Build
import androidx.compose.material.icons.filled.Check
import androidx.compose.material.icons.filled.Clear
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.CloudSync
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material.icons.filled.DirectionsCar
import androidx.compose.material.icons.filled.Edit
import androidx.compose.material.icons.filled.Inventory
import androidx.compose.material.icons.filled.Key
import androidx.compose.material.icons.filled.LocalShipping
import androidx.compose.material.icons.filled.Lock
import androidx.compose.material.icons.filled.Login
import androidx.compose.material.icons.filled.NotificationsActive
import androidx.compose.material.icons.filled.Payments
import androidx.compose.material.icons.filled.People
import androidx.compose.material.icons.filled.Person
import androidx.compose.material.icons.filled.PrecisionManufacturing
import androidx.compose.material.icons.filled.QrCodeScanner
import androidx.compose.material.icons.filled.ReceiptLong
import androidx.compose.material.icons.filled.Search
import androidx.compose.material.icons.filled.Security
import androidx.compose.material.icons.filled.Shield
import androidx.compose.material.icons.filled.TableChart
import androidx.compose.material.icons.filled.Tune
import androidx.compose.material.icons.filled.CloudDone
import androidx.compose.material.icons.filled.ContentCopy
import androidx.compose.material.icons.filled.Visibility
import androidx.compose.material.icons.filled.Warning
import androidx.compose.ui.platform.LocalClipboardManager
import androidx.compose.ui.text.AnnotatedString
import com.example.data.firebase.FirestoreAdminEntry
import com.example.ui.components.ManagerialOversightDashboardCard
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Checkbox
import androidx.compose.material3.CheckboxDefaults
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.ExposedDropdownMenuBox
import androidx.compose.material3.ExposedDropdownMenuDefaults
import androidx.compose.material3.FilterChip
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.MenuAnchorType
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.ScrollableTabRow
import androidx.compose.material3.Surface
import androidx.compose.material3.Tab
import androidx.compose.material3.TabRowDefaults
import androidx.compose.material3.TabRowDefaults.tabIndicatorOffset
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.model.ActivityCategory
import com.example.model.ActivityStatus
import com.example.model.BranchStatusBoard
import com.example.model.CasketItem
import com.example.model.CustomerOrderRecord
import com.example.model.Department
import com.example.model.ExcelDatasetType
import com.example.model.FleetGpsVehicle
import com.example.model.InventoryMaterialItem
import com.example.model.OperatorWageAllocation
import com.example.model.OrderAddonItem
import com.example.model.OrderPackageItem
import com.example.model.PaymentStatus
import com.example.model.ShiftAttendanceAction
import com.example.model.ShiftAttendanceRecord
import com.example.model.StaffAccount
import com.example.model.StaffActivity
import com.example.model.StaffAlertNotification
import com.example.model.StaffBreakageRecord
import com.example.model.StaffRole
import com.example.model.StaffWalletSummary
import com.example.model.TaskPriority
import com.example.model.WalletTransaction
import com.example.model.WorkshopProductionItem
import com.example.ui.components.AdminAddEditCasketDialog
import com.example.ui.components.AdminAddEditMaterialDialog
import com.example.ui.components.AdminAddEditStaffDialog
import com.example.ui.components.AdminConfirmDeleteDialog
import com.example.ui.theme.AmberLight
import com.example.ui.theme.AmberWarning
import com.example.ui.theme.BorderLight
import com.example.ui.theme.CyanContainer
import com.example.ui.theme.CyanDark
import com.example.ui.theme.CyanPrimary
import com.example.ui.theme.EmeraldLight
import com.example.ui.theme.EmeraldSuccess
import com.example.ui.theme.ForestGreenPrimary
import com.example.ui.theme.Navy900
import com.example.ui.theme.PureWhite
import com.example.ui.theme.RoseLight
import com.example.ui.theme.StrokeRed
import com.example.ui.theme.StrokeRedLight
import kotlin.math.abs

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun AdminConsoleScreen(
    adminAccount: StaffAccount,
    staffAccounts: List<StaffAccount>,
    activities: List<StaffActivity>,
    transactions: List<WalletTransaction>,
    caskets: List<CasketItem> = emptyList(),
    inventoryMaterials: List<InventoryMaterialItem> = emptyList(),
    workshopItems: List<WorkshopProductionItem> = emptyList(),
    fleetVehicles: List<FleetGpsVehicle> = emptyList(),
    customerOrders: List<CustomerOrderRecord> = emptyList(),
    branchBoards: List<BranchStatusBoard> = emptyList(),
    onAccessStaffAccount: (StaffAccount) -> Unit,
    onInspectStaff: (StaffAccount) -> Unit,
    onApprovePayout: (transactionId: String) -> Unit,
    onRejectPayout: (transactionId: String, reason: String) -> Unit,
    onCreditStaffWallet: (StaffAccount) -> Unit,
    onOpenPriceEditor: () -> Unit = {},
    onOpenStockUpload: () -> Unit = {},
    onOpenUniversalExcelImport: (ExcelDatasetType) -> Unit = {},
    onOpenCrmIntegrations: () -> Unit = {},
    onEditStaffValues: (StaffAccount) -> Unit = {},
    onAddOrReplaceStaff: (StaffAccount) -> Unit = {},
    onDeleteStaff: (String) -> Unit = {},
    onAddOrReplaceCasket: (CasketItem) -> Unit = {},
    onDeleteCasket: (String) -> Unit = {},
    onAddOrReplaceMaterial: (InventoryMaterialItem) -> Unit = {},
    onDeleteMaterial: (String) -> Unit = {},
    onAddOrReplaceWorkshopItem: (WorkshopProductionItem) -> Unit = {},
    onDeleteWorkshopItem: (String) -> Unit = {},
    onAddOrReplaceActivity: (StaffActivity) -> Unit = {},
    onDeleteActivity: (String) -> Unit = {},
    onAddOrReplaceFleetVehicle: (FleetGpsVehicle) -> Unit = {},
    onDeleteFleetVehicle: (String) -> Unit = {},
    onAddOrReplaceCustomerOrder: (CustomerOrderRecord) -> Unit = {},
    onDeleteCustomerOrder: (String) -> Unit = {},
    onAddOrReplaceBranch: (BranchStatusBoard) -> Unit = {},
    onDeleteBranch: (String) -> Unit = {},
    orderPackages: List<OrderPackageItem> = emptyList(),
    orderAddons: List<OrderAddonItem> = emptyList(),
    staffAlerts: List<StaffAlertNotification> = emptyList(),
    breakageRecords: List<StaffBreakageRecord> = emptyList(),
    operatorWageAllocations: List<OperatorWageAllocation> = emptyList(),
    onAutoAssignTask: (ActivityCategory, String, String, String, String, TaskPriority, Double, String) -> Unit = { _, _, _, _, _, _, _, _ -> },
    onAdminAssessAndPriceActivity: (String, Double, Boolean, String) -> Unit = { _, _, _, _ -> },
    onRecordBreakage: (String, String, String, Double, Boolean) -> Unit = { _, _, _, _, _ -> },
    onExecutePendingBreakage: (String) -> Unit = {},
    onAllocateOperatorWage: (String, Double, Double, String, Boolean) -> Unit = { _, _, _, _, _ -> },
    onDisburseOperatorWage: (String) -> Unit = {},
    walletSummaries: Map<String, StaffWalletSummary> = emptyMap(),
    onAccessStaffWallet: (StaffAccount) -> Unit = { onAccessStaffAccount(it) },
    onUpdateActivityStatus: (activityId: String, status: ActivityStatus) -> Unit = { _, _ -> },
    onDispatchTaskAlert: (StaffActivity) -> Unit = {},
    onOpenDailyTimeline: () -> Unit = {},
    attendanceLogs: List<ShiftAttendanceRecord> = emptyList(),
    onOpenShiftQrScanner: () -> Unit = {},
    cloudUserEmail: String? = null,
    cloudUserUid: String? = null,
    cloudAdmins: List<FirestoreAdminEntry> = emptyList(),
    onAuthorizeCloudBranchAdmin: (uid: String, email: String, branch: String) -> Unit = { _, _, _ -> },
    onRevokeCloudBranchAdmin: (uid: String) -> Unit = {},
    onOpenCloudAuth: () -> Unit = {}
) {
    val clipboardManager = LocalClipboardManager.current
    var uidCopiedFeedback by remember { mutableStateOf(false) }
    var branchAdminUidInput by remember { mutableStateOf("") }
    var branchAdminEmailInput by remember { mutableStateOf("") }
    var branchAdminBranchInput by remember { mutableStateOf("Nairobi Central Branch") }

    val pendingPayouts = transactions.filter { it.status == PaymentStatus.PENDING_APPROVAL }
    val operatorsList = staffAccounts.filter {
        it.role == StaffRole.OPERATOR || it.department == Department.OPERATORS
    }

    var adminMasterTab by remember { mutableIntStateOf(0) }
    var staffDirectorySearch by remember { mutableStateOf("") }
    var staffDirectoryDeptFilter by remember { mutableStateOf<Department?>(null) }
    val adminTabs = listOf(
        "Staff Portals (${staffAccounts.size})",
        "Caskets & Stock (${caskets.size})",
        "Materials & Inventory (${inventoryMaterials.size})",
        "Workshop Jobs (${workshopItems.size})",
        "Fleet Vehicles (${fleetVehicles.size})",
        "Customer Orders (${customerOrders.size})",
        "Breakages (${breakageRecords.size})",
        "Operators Wages (${operatorWageAllocations.size})",
        "Tasks & Pricing (${activities.size})"
    )

    // Dialog state holders
    var showAddStaffDialog by remember { mutableStateOf(false) }
    var staffToEdit by remember { mutableStateOf<StaffAccount?>(null) }
    var showAddCasketDialog by remember { mutableStateOf(false) }
    var casketToEdit by remember { mutableStateOf<CasketItem?>(null) }
    var showAddMaterialDialog by remember { mutableStateOf(false) }
    var materialToEdit by remember { mutableStateOf<InventoryMaterialItem?>(null) }

    var showRecordBreakageDialog by remember { mutableStateOf(false) }
    var showAllocateOperatorWageDialog by remember { mutableStateOf(false) }
    var preselectedOperatorForWage by remember { mutableStateOf<StaffAccount?>(null) }
    var showAutoAssignTaskDialog by remember { mutableStateOf(false) }
    var activityToAssessPrice by remember { mutableStateOf<StaffActivity?>(null) }

    // Delete confirmation state
    var deleteConfirmTarget by remember { mutableStateOf<Triple<String, String, () -> Unit>?>(null) }

    LazyColumn(
        modifier = Modifier
            .fillMaxSize()
            .padding(horizontal = 16.dp),
        verticalArrangement = Arrangement.spacedBy(14.dp)
    ) {
        item {
            Spacer(modifier = Modifier.height(4.dp))

            // Admin Header Banner
            Surface(
                color = Navy900,
                shape = RoundedCornerShape(16.dp),
                modifier = Modifier.fillMaxWidth()
            ) {
                Row(
                    modifier = Modifier.padding(16.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Box(
                        modifier = Modifier
                            .size(46.dp)
                            .clip(CircleShape)
                            .background(CyanPrimary),
                        contentAlignment = Alignment.Center
                    ) {
                        Icon(
                            imageVector = Icons.Default.Shield,
                            contentDescription = null,
                            tint = Color.White,
                            modifier = Modifier.size(24.dp)
                        )
                    }

                    Spacer(modifier = Modifier.width(12.dp))

                    Column {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Text(
                                text = "ADMIN MASTER CONTROL CONSOLE",
                                color = Color.White,
                                fontWeight = FontWeight.Bold,
                                fontSize = 14.sp,
                                letterSpacing = 0.5.sp
                            )
                            Spacer(modifier = Modifier.width(6.dp))
                            Box(
                                modifier = Modifier
                                    .background(StrokeRed, RoundedCornerShape(4.dp))
                                    .padding(horizontal = 6.dp, vertical = 2.dp)
                            ) {
                                Text(
                                    text = "FULL CRUD ACCESS",
                                    color = Color.White,
                                    fontSize = 8.sp,
                                    fontWeight = FontWeight.ExtraBold
                                )
                            }
                        }
                        Text(
                            text = "Active Admin: ${adminAccount.fullName} (${adminAccount.role.title}) • Authorized to Add, Edit, Replace & Delete All Data",
                            color = Color(0xFFBBF7D0),
                            fontSize = 11.sp,
                            fontWeight = FontWeight.SemiBold
                        )
                    }
                }
            }
        }

        // Summary Counters Row
        item {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                AdminStatCard(
                    title = "Staff Roster",
                    value = "${staffAccounts.size}",
                    sub = "Full Roster",
                    color = CyanPrimary,
                    bgColor = CyanContainer,
                    modifier = Modifier.weight(1f)
                )

                AdminStatCard(
                    title = "Payout Requests",
                    value = "${pendingPayouts.size}",
                    sub = "Needs approval",
                    color = if (pendingPayouts.isNotEmpty()) AmberWarning else EmeraldSuccess,
                    bgColor = if (pendingPayouts.isNotEmpty()) AmberLight else EmeraldLight,
                    modifier = Modifier.weight(1f)
                )

                AdminStatCard(
                    title = "Caskets In Catalog",
                    value = "${caskets.size}",
                    sub = "16 standard types",
                    color = Color(0xFF8B5CF6),
                    bgColor = Color(0xFFEDE9FE),
                    modifier = Modifier.weight(1f)
                )
            }
        }

        // EXECUTIVE QUICK CONTROLS: PRICES, STOCK INTAKE & CLOUD CRM
        item {
            Surface(
                color = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.5f),
                shape = RoundedCornerShape(14.dp),
                border = BorderStroke(1.dp, MaterialTheme.colorScheme.outline.copy(alpha = 0.2f)),
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(modifier = Modifier.padding(14.dp)) {
                    Text(
                        text = "EXECUTIVE SHORTCUTS & BULK ERP",
                        fontSize = 11.sp,
                        fontWeight = FontWeight.Bold,
                        color = CyanPrimary,
                        letterSpacing = 0.5.sp
                    )
                    Spacer(modifier = Modifier.height(10.dp))

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        Button(
                            onClick = onOpenPriceEditor,
                            colors = ButtonDefaults.buttonColors(containerColor = EmeraldSuccess),
                            shape = RoundedCornerShape(8.dp),
                            contentPadding = androidx.compose.foundation.layout.PaddingValues(horizontal = 8.dp, vertical = 4.dp),
                            modifier = Modifier
                                .weight(1f)
                                .height(38.dp)
                                .testTag("admin_open_price_editor_button")
                        ) {
                            Icon(Icons.Default.AttachMoney, contentDescription = null, modifier = Modifier.size(15.dp))
                            Spacer(modifier = Modifier.width(4.dp))
                            Text("Prices", fontSize = 11.sp, fontWeight = FontWeight.Bold)
                        }

                        Button(
                            onClick = onOpenStockUpload,
                            colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF107C41)),
                            shape = RoundedCornerShape(8.dp),
                            contentPadding = androidx.compose.foundation.layout.PaddingValues(horizontal = 8.dp, vertical = 4.dp),
                            modifier = Modifier
                                .weight(1.3f)
                                .height(38.dp)
                                .testTag("admin_open_stock_upload_button")
                        ) {
                            Icon(Icons.Default.TableChart, contentDescription = null, modifier = Modifier.size(15.dp))
                            Spacer(modifier = Modifier.width(4.dp))
                            Text("Upload Stock (Excel)", fontSize = 11.sp, fontWeight = FontWeight.Bold)
                        }

                        Button(
                            onClick = onOpenCrmIntegrations,
                            colors = ButtonDefaults.buttonColors(containerColor = Navy900),
                            shape = RoundedCornerShape(8.dp),
                            contentPadding = androidx.compose.foundation.layout.PaddingValues(horizontal = 8.dp, vertical = 4.dp),
                            modifier = Modifier
                                .weight(1.2f)
                                .height(38.dp)
                                .testTag("admin_open_crm_integrations_button")
                        ) {
                            Icon(Icons.Default.CloudSync, contentDescription = null, modifier = Modifier.size(15.dp))
                            Spacer(modifier = Modifier.width(4.dp))
                            Text("Cloud CRM", fontSize = 11.sp, fontWeight = FontWeight.Bold)
                        }
                    }

                    Spacer(modifier = Modifier.height(8.dp))

                    Surface(
                        onClick = {
                            val dataset = when (adminMasterTab) {
                                0 -> ExcelDatasetType.STAFF_ACCOUNTS
                                1 -> ExcelDatasetType.INVENTORY_STOCK
                                2 -> ExcelDatasetType.INVENTORY_STOCK
                                3 -> ExcelDatasetType.WORKSHOP_JOBS
                                4 -> ExcelDatasetType.FLEET_VEHICLES
                                5 -> ExcelDatasetType.CUSTOMER_ORDERS
                                else -> ExcelDatasetType.INVENTORY_STOCK
                            }
                            onOpenUniversalExcelImport(dataset)
                        },
                        shape = RoundedCornerShape(8.dp),
                        color = Color(0xFF107C41).copy(alpha = 0.12f),
                        border = BorderStroke(1.dp, Color(0xFF107C41).copy(alpha = 0.45f)),
                        modifier = Modifier
                            .fillMaxWidth()
                            .testTag("admin_open_universal_excel_import_hub")
                    ) {
                        Row(
                            modifier = Modifier.padding(horizontal = 10.dp, vertical = 8.dp),
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.SpaceBetween
                        ) {
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Icon(
                                    imageVector = Icons.Default.TableChart,
                                    contentDescription = null,
                                    tint = Color(0xFF107C41),
                                    modifier = Modifier.size(16.dp)
                                )
                                Spacer(modifier = Modifier.width(8.dp))
                                Column {
                                    Text(
                                        text = "Import Various Data from Microsoft Excel (All Datasets)",
                                        fontSize = 11.sp,
                                        fontWeight = FontWeight.Bold,
                                        color = Color(0xFF107C41)
                                    )
                                    Text(
                                        text = "Import Stocks, Burial Schedules, Orders, Staff, Fleet, & Workshop Jobs",
                                        fontSize = 9.sp,
                                        color = Color(0xFF64748B)
                                    )
                                }
                            }
                            Text(
                                text = "Open Hub →",
                                fontSize = 10.sp,
                                fontWeight = FontWeight.Bold,
                                color = Color(0xFF107C41)
                            )
                        }
                    }

                    Spacer(modifier = Modifier.height(8.dp))

                    Button(
                        onClick = onOpenShiftQrScanner,
                        colors = ButtonDefaults.buttonColors(
                            containerColor = ForestGreenPrimary,
                            contentColor = Color.White
                        ),
                        shape = RoundedCornerShape(8.dp),
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(40.dp)
                            .testTag("admin_open_shift_qr_scanner_button")
                    ) {
                        Icon(Icons.Default.QrCodeScanner, contentDescription = null, modifier = Modifier.size(16.dp))
                        Spacer(modifier = Modifier.width(6.dp))
                        Text(
                            text = "Scan & Verify 24/7 Staff Shift QR (${attendanceLogs.size} logs)",
                            fontSize = 11.5.sp,
                            fontWeight = FontWeight.Bold
                        )
                    }
                }
            }
        }

        // EXECUTIVE MANAGERIAL OVERSIGHT BAR CHART & PENDING SERVICE TASKS
        item {
            ManagerialOversightDashboardCard(
                staffAccounts = staffAccounts,
                activities = activities,
                onUpdateActivityStatus = onUpdateActivityStatus,
                onDispatchTaskAlert = onDispatchTaskAlert,
                onOpenTasksTimeline = onOpenDailyTimeline
            )
        }

        // MULTI-DEVICE CLOUD SYNC & BRANCH ADMINS MANAGEMENT
        item {
            Card(
                shape = RoundedCornerShape(14.dp),
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                border = BorderStroke(1.dp, MaterialTheme.colorScheme.outline.copy(alpha = 0.35f)),
                modifier = Modifier
                    .fillMaxWidth()
                    .testTag("admin_cloud_branch_admins_card")
            ) {
                Column(modifier = Modifier.padding(14.dp)) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Row(verticalAlignment = Alignment.CenterVertically, modifier = Modifier.weight(1f)) {
                            Icon(
                                imageVector = if (cloudUserEmail != null) Icons.Default.CloudDone else Icons.Default.CloudSync,
                                contentDescription = "Multi-Device Cloud Sync",
                                tint = if (cloudUserEmail != null) EmeraldSuccess else CyanPrimary,
                                modifier = Modifier.size(20.dp)
                            )
                            Spacer(modifier = Modifier.width(8.dp))
                            Column {
                                Text(
                                    text = "Multi-Device Cloud Sync & Branch Admins",
                                    fontSize = 13.sp,
                                    fontWeight = FontWeight.Bold,
                                    color = MaterialTheme.colorScheme.onSurface
                                )
                                Text(
                                    text = if (cloudUserEmail != null) {
                                        "Signed in: $cloudUserEmail"
                                    } else {
                                        "Connect Google Cloud to authorize branch supervisor devices"
                                    },
                                    fontSize = 11.sp,
                                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                                    maxLines = 1,
                                    overflow = TextOverflow.Ellipsis
                                )
                            }
                        }
                        if (cloudUserEmail == null) {
                            TextButton(
                                onClick = onOpenCloudAuth,
                                modifier = Modifier.testTag("admin_open_cloud_auth_button")
                            ) {
                                Text("Connect", fontSize = 11.sp, fontWeight = FontWeight.Bold)
                            }
                        }
                    }

                    if (!cloudUserUid.isNullOrBlank()) {
                        Spacer(modifier = Modifier.height(10.dp))
                        Surface(
                            color = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.7f),
                            shape = RoundedCornerShape(10.dp),
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            Row(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .padding(horizontal = 10.dp, vertical = 8.dp),
                                verticalAlignment = Alignment.CenterVertically,
                                horizontalArrangement = Arrangement.SpaceBetween
                            ) {
                                Column(modifier = Modifier.weight(1f)) {
                                    Text(
                                        text = "YOUR FIREBASE AUTH UID",
                                        fontSize = 9.sp,
                                        fontWeight = FontWeight.Bold,
                                        color = MaterialTheme.colorScheme.onSurfaceVariant
                                    )
                                    Text(
                                        text = cloudUserUid,
                                        fontSize = 11.sp,
                                        fontFamily = FontFamily.Monospace,
                                        fontWeight = FontWeight.SemiBold,
                                        color = MaterialTheme.colorScheme.onSurface,
                                        maxLines = 1,
                                        overflow = TextOverflow.Ellipsis
                                    )
                                }
                                IconButton(
                                    onClick = {
                                        clipboardManager.setText(AnnotatedString(cloudUserUid))
                                        uidCopiedFeedback = true
                                    },
                                    modifier = Modifier
                                        .size(48.dp)
                                        .testTag("admin_copy_uid_button")
                                ) {
                                    Icon(
                                        imageVector = if (uidCopiedFeedback) Icons.Default.Check else Icons.Default.ContentCopy,
                                        contentDescription = "Copy Firebase UID to clipboard",
                                        tint = if (uidCopiedFeedback) EmeraldSuccess else CyanPrimary,
                                        modifier = Modifier.size(18.dp)
                                    )
                                }
                            }
                        }
                    }

                    if (cloudAdmins.isNotEmpty()) {
                        Spacer(modifier = Modifier.height(10.dp))
                        Text(
                            text = "Authorized Cloud Admins (${cloudAdmins.size})",
                            fontSize = 11.sp,
                            fontWeight = FontWeight.Bold,
                            color = MaterialTheme.colorScheme.primary
                        )
                        Spacer(modifier = Modifier.height(6.dp))
                        Column(verticalArrangement = Arrangement.spacedBy(6.dp)) {
                            cloudAdmins.forEach { adminEntry ->
                                val isSelf = adminEntry.id == cloudUserUid
                                Surface(
                                    color = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.45f),
                                    shape = RoundedCornerShape(8.dp),
                                    modifier = Modifier.fillMaxWidth()
                                ) {
                                    Row(
                                        modifier = Modifier
                                            .fillMaxWidth()
                                            .padding(horizontal = 10.dp, vertical = 8.dp),
                                        verticalAlignment = Alignment.CenterVertically,
                                        horizontalArrangement = Arrangement.SpaceBetween
                                    ) {
                                        Column(modifier = Modifier.weight(1f)) {
                                            Text(
                                                text = adminEntry.email.ifBlank { adminEntry.id },
                                                fontSize = 11.5.sp,
                                                fontWeight = FontWeight.Bold,
                                                color = MaterialTheme.colorScheme.onSurface,
                                                maxLines = 1,
                                                overflow = TextOverflow.Ellipsis
                                            )
                                            Text(
                                                text = "${adminEntry.role} • ${adminEntry.branch} • UID: ${adminEntry.id}",
                                                fontSize = 10.sp,
                                                color = MaterialTheme.colorScheme.onSurfaceVariant,
                                                maxLines = 1,
                                                overflow = TextOverflow.Ellipsis
                                            )
                                        }
                                        if (!isSelf) {
                                            IconButton(
                                                onClick = { onRevokeCloudBranchAdmin(adminEntry.id) },
                                                modifier = Modifier
                                                    .size(48.dp)
                                                    .testTag("admin_revoke_branch_admin_${adminEntry.id}")
                                            ) {
                                                Icon(
                                                    imageVector = Icons.Default.Delete,
                                                    contentDescription = "Revoke cloud admin ${adminEntry.email}",
                                                    tint = StrokeRed,
                                                    modifier = Modifier.size(18.dp)
                                                )
                                            }
                                        }
                                    }
                                }
                            }
                        }
                    }

                    if (cloudUserEmail != null) {
                        Spacer(modifier = Modifier.height(12.dp))
                        HorizontalDivider()
                        Spacer(modifier = Modifier.height(10.dp))
                        Text(
                            text = "Authorize Supervisor Device for Cross-Branch Admin Sync",
                            fontSize = 11.sp,
                            fontWeight = FontWeight.Bold,
                            color = MaterialTheme.colorScheme.onSurface
                        )
                        Spacer(modifier = Modifier.height(8.dp))
                        OutlinedTextField(
                            value = branchAdminUidInput,
                            onValueChange = { branchAdminUidInput = it },
                            label = { Text("Supervisor Firebase UID") },
                            placeholder = { Text("Paste UID from supervisor's device") },
                            singleLine = true,
                            modifier = Modifier
                                .fillMaxWidth()
                                .testTag("admin_cloud_uid_input")
                        )
                        Spacer(modifier = Modifier.height(8.dp))
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.spacedBy(8.dp)
                        ) {
                            OutlinedTextField(
                                value = branchAdminEmailInput,
                                onValueChange = { branchAdminEmailInput = it },
                                label = { Text("Google Email") },
                                singleLine = true,
                                modifier = Modifier
                                    .weight(1f)
                                    .testTag("admin_cloud_email_input")
                            )
                            OutlinedTextField(
                                value = branchAdminBranchInput,
                                onValueChange = { branchAdminBranchInput = it },
                                label = { Text("Branch") },
                                singleLine = true,
                                modifier = Modifier
                                    .weight(1f)
                                    .testTag("admin_cloud_branch_input")
                            )
                        }
                        Spacer(modifier = Modifier.height(8.dp))
                        Button(
                            onClick = {
                                onAuthorizeCloudBranchAdmin(
                                    branchAdminUidInput,
                                    branchAdminEmailInput,
                                    branchAdminBranchInput
                                )
                                branchAdminUidInput = ""
                                branchAdminEmailInput = ""
                            },
                            colors = ButtonDefaults.buttonColors(containerColor = Navy900),
                            shape = RoundedCornerShape(10.dp),
                            modifier = Modifier
                                .fillMaxWidth()
                                .height(48.dp)
                                .testTag("admin_authorize_branch_admin_button")
                        ) {
                            Icon(Icons.Default.AdminPanelSettings, contentDescription = null, modifier = Modifier.size(16.dp))
                            Spacer(modifier = Modifier.width(6.dp))
                            Text("Authorize Cloud Branch Admin", fontSize = 12.sp, fontWeight = FontWeight.Bold)
                        }
                    }
                }
            }
        }

        // PENDING PAYOUTS SECTION
        if (pendingPayouts.isNotEmpty()) {
            item {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Icon(
                        imageVector = Icons.Default.NotificationsActive,
                        contentDescription = null,
                        tint = AmberWarning,
                        modifier = Modifier.size(18.dp)
                    )
                    Spacer(modifier = Modifier.width(6.dp))
                    Text(
                        text = "Pending Payout Requests (${pendingPayouts.size})",
                        style = MaterialTheme.typography.titleMedium,
                        fontWeight = FontWeight.Bold,
                        color = MaterialTheme.colorScheme.onSurface
                    )
                }
            }

            items(pendingPayouts, key = { it.id }) { payout ->
                val requestingStaff = staffAccounts.firstOrNull { it.id == payout.staffId }

                Card(
                    shape = RoundedCornerShape(14.dp),
                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                    border = BorderStroke(1.5.dp, AmberWarning),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Column(modifier = Modifier.padding(16.dp)) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Column {
                                Text(
                                    text = requestingStaff?.fullName ?: "Staff ID: ${payout.staffId}",
                                    fontWeight = FontWeight.Bold,
                                    fontSize = 14.sp
                                )
                                Text(
                                    text = "${requestingStaff?.role?.title ?: ""} • ${payout.date}",
                                    fontSize = 11.sp,
                                    color = MaterialTheme.colorScheme.onSurfaceVariant
                                )
                            }

                            Text(
                                text = "KES ${String.format("%,.0f", abs(payout.amount))}",
                                fontWeight = FontWeight.ExtraBold,
                                fontSize = 16.sp,
                                color = Navy900
                            )
                        }

                        Spacer(modifier = Modifier.height(8.dp))

                        Surface(
                            color = MaterialTheme.colorScheme.surfaceVariant,
                            shape = RoundedCornerShape(6.dp),
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            Column(modifier = Modifier.padding(8.dp)) {
                                Text(
                                    text = "Channel: ${payout.payoutMethod ?: "M-PESA"} -> ${payout.payoutDestination ?: "Default phone"}",
                                    fontSize = 11.sp,
                                    fontWeight = FontWeight.SemiBold,
                                    color = CyanDark
                                )
                                if (payout.notes.isNotBlank()) {
                                    Text(
                                        text = "Remarks: ${payout.notes}",
                                        fontSize = 10.sp,
                                        color = MaterialTheme.colorScheme.onSurfaceVariant
                                    )
                                }
                            }
                        }

                        Spacer(modifier = Modifier.height(12.dp))

                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.End,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            OutlinedButton(
                                onClick = { onRejectPayout(payout.id, "Requires operational verification") },
                                colors = ButtonDefaults.outlinedButtonColors(contentColor = com.example.ui.theme.StrokeRed),
                                shape = RoundedCornerShape(8.dp),
                                modifier = Modifier.height(36.dp)
                            ) {
                                Icon(Icons.Default.Close, contentDescription = null, modifier = Modifier.size(14.dp))
                                Spacer(modifier = Modifier.width(4.dp))
                                Text("Reject", fontSize = 11.sp)
                            }

                            Spacer(modifier = Modifier.width(8.dp))

                            Button(
                                onClick = { onApprovePayout(payout.id) },
                                colors = ButtonDefaults.buttonColors(containerColor = EmeraldSuccess),
                                shape = RoundedCornerShape(8.dp),
                                modifier = Modifier
                                    .height(36.dp)
                                    .testTag("admin_approve_payout_button")
                            ) {
                                Icon(Icons.Default.Check, contentDescription = null, modifier = Modifier.size(14.dp))
                                Spacer(modifier = Modifier.width(4.dp))
                                Text("Approve & Disburse", fontSize = 11.sp, fontWeight = FontWeight.Bold)
                            }
                        }
                    }
                }
            }
        }

        // ==========================================
        // MASTER DATA CRUD MANAGER SECTION (EDIT, ADD, REPLACE, DELETE)
        // ==========================================
        item {
            Card(
                shape = RoundedCornerShape(14.dp),
                colors = CardDefaults.cardColors(containerColor = PureWhite),
                border = BorderStroke(1.dp, BorderLight),
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(modifier = Modifier.padding(14.dp)) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Column {
                            Text(
                                text = "MASTER DATA CRUD HUB",
                                fontWeight = FontWeight.ExtraBold,
                                fontSize = 13.sp,
                                color = Navy900,
                                letterSpacing = 0.5.sp
                            )
                            Text(
                                text = "Admin can Add, Edit, Replace or Delete any record",
                                fontSize = 10.sp,
                                color = Color(0xFF64748B)
                            )
                        }

                        // Add action based on selected tab
                        Button(
                            onClick = {
                                when (adminMasterTab) {
                                    0 -> showAddStaffDialog = true
                                    1 -> showAddCasketDialog = true
                                    2 -> showAddMaterialDialog = true
                                    6 -> showRecordBreakageDialog = true
                                    7 -> {
                                        preselectedOperatorForWage = operatorsList.firstOrNull()
                                        showAllocateOperatorWageDialog = true
                                    }
                                    8 -> showAutoAssignTaskDialog = true
                                    else -> onOpenStockUpload()
                                }
                            },
                            colors = ButtonDefaults.buttonColors(containerColor = EmeraldSuccess),
                            shape = RoundedCornerShape(8.dp),
                            contentPadding = PaddingValues(horizontal = 10.dp, vertical = 6.dp),
                            modifier = Modifier.testTag("btn_admin_add_master_record")
                        ) {
                            Icon(Icons.Default.Add, contentDescription = null, modifier = Modifier.size(15.dp))
                            Spacer(modifier = Modifier.width(4.dp))
                            Text(
                                text = when (adminMasterTab) {
                                    0 -> "Add Staff"
                                    1 -> "Add Casket"
                                    2 -> "Add Material"
                                    3 -> "New Job"
                                    4 -> "Add Vehicle"
                                    5 -> "Add Order"
                                    6 -> "Log Breakage"
                                    7 -> "Allocate Wage"
                                    else -> "Auto-Assign"
                                },
                                fontSize = 11.sp,
                                fontWeight = FontWeight.Bold,
                                maxLines = 1,
                                softWrap = false
                            )
                        }
                    }

                    Spacer(modifier = Modifier.height(10.dp))

                    ScrollableTabRow(
                        selectedTabIndex = adminMasterTab,
                        containerColor = Color(0xFFF8FAFC),
                        contentColor = Navy900,
                        edgePadding = 0.dp,
                        indicator = { tabPositions ->
                            if (adminMasterTab < tabPositions.size) {
                                TabRowDefaults.SecondaryIndicator(
                                    modifier = Modifier.tabIndicatorOffset(tabPositions[adminMasterTab]),
                                    color = Navy900,
                                    height = 3.dp
                                )
                            }
                        },
                        divider = { HorizontalDivider(color = BorderLight, thickness = 0.5.dp) },
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        adminTabs.forEachIndexed { idx, label ->
                            val isSel = adminMasterTab == idx
                            Tab(
                                selected = isSel,
                                onClick = { adminMasterTab = idx },
                                text = {
                                    Text(
                                        text = label,
                                        fontSize = 11.sp,
                                        fontWeight = if (isSel) FontWeight.Bold else FontWeight.Medium,
                                        color = if (isSel) Navy900 else Color(0xFF64748B),
                                        maxLines = 1,
                                        softWrap = false,
                                        overflow = TextOverflow.Ellipsis
                                    )
                                },
                                modifier = Modifier.testTag("admin_crud_tab_$idx")
                            )
                        }
                    }
                }
            }
        }

        // TAB 0: INDEPENDENT STAFF PORTALS DIRECTORY (WITH SEARCH, WALLET SUMMARY, PORTAL ACCESS, EDIT, DELETE)
        if (adminMasterTab == 0) {
            val filteredStaffDirectory = staffAccounts.filter { staff ->
                val matchesDept = staffDirectoryDeptFilter == null || staff.department == staffDirectoryDeptFilter
                val matchesSearch = if (staffDirectorySearch.isBlank()) true
                else {
                    val q = staffDirectorySearch.trim().lowercase()
                    staff.fullName.lowercase().contains(q) ||
                        staff.id.lowercase().contains(q) ||
                        staff.role.title.lowercase().contains(q) ||
                        staff.branch.lowercase().contains(q) ||
                        staff.department.displayName.lowercase().contains(q)
                }
                matchesDept && matchesSearch
            }

            item {
                Surface(
                    color = MaterialTheme.colorScheme.surface,
                    shape = RoundedCornerShape(12.dp),
                    border = BorderStroke(1.dp, MaterialTheme.colorScheme.outline.copy(alpha = 0.35f)),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Column(modifier = Modifier.padding(12.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                        Text(
                            text = "INDEPENDENT STAFF PORTALS & WALLETS (${filteredStaffDirectory.size}/${staffAccounts.size})",
                            fontSize = 11.sp,
                            fontWeight = FontWeight.ExtraBold,
                            color = MaterialTheme.colorScheme.primary
                        )
                        OutlinedTextField(
                            value = staffDirectorySearch,
                            onValueChange = { staffDirectorySearch = it },
                            placeholder = { Text("Search staff by name, ID, role, branch...", fontSize = 12.sp) },
                            leadingIcon = { Icon(Icons.Default.Search, contentDescription = null, modifier = Modifier.size(18.dp)) },
                            trailingIcon = {
                                if (staffDirectorySearch.isNotBlank()) {
                                    IconButton(onClick = { staffDirectorySearch = "" }) {
                                        Icon(Icons.Default.Clear, contentDescription = "Clear", modifier = Modifier.size(16.dp))
                                    }
                                }
                            },
                            singleLine = true,
                            shape = RoundedCornerShape(10.dp),
                            modifier = Modifier
                                .fillMaxWidth()
                                .testTag("admin_staff_portal_search")
                        )
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .horizontalScroll(rememberScrollState()),
                            horizontalArrangement = Arrangement.spacedBy(6.dp)
                        ) {
                            FilterChip(
                                selected = staffDirectoryDeptFilter == null,
                                onClick = { staffDirectoryDeptFilter = null },
                                label = { Text("All (${staffAccounts.size})", fontSize = 11.sp, maxLines = 1, softWrap = false) }
                            )
                            Department.entries.forEach { dept ->
                                val count = staffAccounts.count { it.department == dept }
                                if (count > 0) {
                                    FilterChip(
                                        selected = staffDirectoryDeptFilter == dept,
                                        onClick = {
                                            staffDirectoryDeptFilter = if (staffDirectoryDeptFilter == dept) null else dept
                                        },
                                        label = {
                                            Text("${dept.displayName} ($count)", fontSize = 11.sp, maxLines = 1, softWrap = false)
                                        }
                                    )
                                }
                            }
                        }
                    }
                }
            }

            items(filteredStaffDirectory, key = { it.id }) { staff ->
                val isCeo = staff.id == "CEO-001"
                val staffWallet = walletSummaries[staff.id]
                Card(
                    shape = RoundedCornerShape(12.dp),
                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                    border = BorderStroke(1.dp, MaterialTheme.colorScheme.outline.copy(alpha = 0.35f)),
                    modifier = Modifier
                        .fillMaxWidth()
                        .testTag("admin_staff_portal_card_${staff.id}")
                ) {
                    Column(modifier = Modifier.padding(14.dp)) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.SpaceBetween
                        ) {
                            Row(
                                verticalAlignment = Alignment.CenterVertically,
                                modifier = Modifier.weight(1f)
                            ) {
                                Box(
                                    modifier = Modifier
                                        .size(38.dp)
                                        .clip(CircleShape)
                                        .background(Color(staff.avatarColor)),
                                    contentAlignment = Alignment.Center
                                ) {
                                    Text(
                                        text = staff.fullName.split(" ").mapNotNull { it.firstOrNull()?.toString() }.take(2).joinToString(""),
                                        color = Color.White,
                                        fontWeight = FontWeight.Bold,
                                        fontSize = 13.sp
                                    )
                                }
                                Spacer(modifier = Modifier.width(10.dp))
                                Column {
                                    Text(staff.fullName, fontWeight = FontWeight.Bold, fontSize = 13.sp, color = MaterialTheme.colorScheme.onSurface)
                                    Text("${staff.id} • ${staff.role.title}", fontSize = 10.sp, color = MaterialTheme.colorScheme.secondary, fontWeight = FontWeight.SemiBold)
                                    Text("${staff.department.displayName} • ${staff.branch} • ${staff.phone}", fontSize = 9.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
                                }
                            }

                            // Password & latest 24/7 QR scan badge
                            val latestQrScan = attendanceLogs.firstOrNull {
                                it.staffId.equals(staff.id, ignoreCase = true)
                            }
                            Column(horizontalAlignment = Alignment.End, verticalArrangement = Arrangement.spacedBy(3.dp)) {
                                Surface(
                                    color = if (staff.mustRotatePassword) AmberLight else EmeraldLight,
                                    shape = RoundedCornerShape(4.dp)
                                ) {
                                    Text(
                                        text = if (staff.mustRotatePassword) "Default (Rotate)" else "Hashed ✓",
                                        fontSize = 9.sp,
                                        fontWeight = FontWeight.ExtraBold,
                                        color = if (staff.mustRotatePassword) Navy900 else EmeraldSuccess,
                                        modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp)
                                    )
                                }
                                if (latestQrScan != null) {
                                    val isIn = latestQrScan.action == ShiftAttendanceAction.CHECK_IN
                                    Surface(
                                        color = if (isIn) EmeraldLight else StrokeRedLight,
                                        shape = RoundedCornerShape(4.dp)
                                    ) {
                                        Text(
                                            text = if (isIn) "QR In ✓" else "QR Out",
                                            fontSize = 8.5.sp,
                                            fontWeight = FontWeight.ExtraBold,
                                            color = if (isIn) EmeraldSuccess else StrokeRed,
                                            modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp)
                                        )
                                    }
                                }
                            }
                        }

                        if (staffWallet != null) {
                            Spacer(modifier = Modifier.height(8.dp))
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.spacedBy(6.dp)
                            ) {
                                Surface(
                                    color = MaterialTheme.colorScheme.surfaceVariant,
                                    shape = RoundedCornerShape(6.dp),
                                    modifier = Modifier.weight(1f)
                                ) {
                                    Column(modifier = Modifier.padding(horizontal = 8.dp, vertical = 5.dp)) {
                                        Text("Wallet Bal", fontSize = 9.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
                                        Text(
                                            text = "KES ${String.format("%,.0f", staffWallet.availableBalance)}",
                                            fontSize = 11.sp,
                                            fontWeight = FontWeight.ExtraBold,
                                            color = MaterialTheme.colorScheme.onSurface,
                                            maxLines = 1
                                        )
                                    }
                                }
                                Surface(
                                    color = AmberLight.copy(alpha = 0.55f),
                                    shape = RoundedCornerShape(6.dp),
                                    modifier = Modifier.weight(1f)
                                ) {
                                    Column(modifier = Modifier.padding(horizontal = 8.dp, vertical = 5.dp)) {
                                        Text("Commissions", fontSize = 9.sp, color = Color(0xFF92400E))
                                        Text(
                                            text = "KES ${String.format("%,.0f", staffWallet.casketCommissionTotal)}",
                                            fontSize = 11.sp,
                                            fontWeight = FontWeight.ExtraBold,
                                            color = Color(0xFF92400E),
                                            maxLines = 1
                                        )
                                    }
                                }
                                Surface(
                                    color = EmeraldLight.copy(alpha = 0.7f),
                                    shape = RoundedCornerShape(6.dp),
                                    modifier = Modifier.weight(1f)
                                ) {
                                    Column(modifier = Modifier.padding(horizontal = 8.dp, vertical = 5.dp)) {
                                        Text("Service Pay", fontSize = 9.sp, color = EmeraldSuccess)
                                        Text(
                                            text = "KES ${String.format("%,.0f", staffWallet.servicePayoutsTotal)}",
                                            fontSize = 11.sp,
                                            fontWeight = FontWeight.ExtraBold,
                                            color = EmeraldSuccess,
                                            maxLines = 1
                                        )
                                    }
                                }
                            }
                        }

                        Spacer(modifier = Modifier.height(10.dp))

                        // Action buttons: Open Portal, Open Wallet, Role/Branch, Inspect, Delete
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.spacedBy(6.dp)
                        ) {
                            Button(
                                onClick = { onAccessStaffAccount(staff) },
                                colors = ButtonDefaults.buttonColors(containerColor = MaterialTheme.colorScheme.secondary),
                                shape = RoundedCornerShape(6.dp),
                                contentPadding = PaddingValues(horizontal = 6.dp, vertical = 2.dp),
                                modifier = Modifier.weight(1f).height(34.dp).testTag("btn_open_portal_${staff.id}")
                            ) {
                                Icon(Icons.Default.Login, contentDescription = null, modifier = Modifier.size(13.dp))
                                Spacer(modifier = Modifier.width(3.dp))
                                Text("Portal", fontSize = 10.sp, fontWeight = FontWeight.Bold, maxLines = 1, softWrap = false)
                            }

                            Button(
                                onClick = { onAccessStaffWallet(staff) },
                                colors = ButtonDefaults.buttonColors(containerColor = EmeraldSuccess),
                                shape = RoundedCornerShape(6.dp),
                                contentPadding = PaddingValues(horizontal = 6.dp, vertical = 2.dp),
                                modifier = Modifier.weight(1f).height(34.dp).testTag("btn_open_wallet_${staff.id}")
                            ) {
                                Icon(Icons.Default.AccountBalanceWallet, contentDescription = null, modifier = Modifier.size(13.dp))
                                Spacer(modifier = Modifier.width(3.dp))
                                Text("Wallet", fontSize = 10.sp, fontWeight = FontWeight.Bold, maxLines = 1, softWrap = false)
                            }

                            Button(
                                onClick = { onEditStaffValues(staff) },
                                colors = ButtonDefaults.buttonColors(containerColor = Navy900),
                                shape = RoundedCornerShape(6.dp),
                                contentPadding = PaddingValues(horizontal = 6.dp, vertical = 2.dp),
                                modifier = Modifier.weight(1f).height(34.dp).testTag("btn_reassign_role_${staff.id}")
                            ) {
                                Icon(Icons.Default.Tune, contentDescription = null, modifier = Modifier.size(13.dp))
                                Spacer(modifier = Modifier.width(3.dp))
                                Text("Role", fontSize = 10.sp, fontWeight = FontWeight.Bold, maxLines = 1, softWrap = false)
                            }

                            OutlinedButton(
                                onClick = { onInspectStaff(staff) },
                                shape = RoundedCornerShape(6.dp),
                                contentPadding = PaddingValues(horizontal = 6.dp, vertical = 2.dp),
                                modifier = Modifier.height(34.dp).testTag("btn_inspect_staff_${staff.id}")
                            ) {
                                Icon(Icons.Default.Visibility, contentDescription = "Inspect", modifier = Modifier.size(13.dp))
                            }

                            if (!isCeo) {
                                OutlinedButton(
                                    onClick = {
                                        deleteConfirmTarget = Triple(staff.fullName, "Staff Account") {
                                            onDeleteStaff(staff.id)
                                        }
                                    },
                                    colors = ButtonDefaults.outlinedButtonColors(contentColor = StrokeRed),
                                    shape = RoundedCornerShape(6.dp),
                                    contentPadding = PaddingValues(horizontal = 6.dp, vertical = 2.dp),
                                    modifier = Modifier.height(34.dp).testTag("btn_delete_staff_${staff.id}")
                                ) {
                                    Icon(Icons.Default.Delete, contentDescription = "Delete", modifier = Modifier.size(13.dp))
                                }
                            }
                        }
                    }
                }
            }
        }

        // TAB 1: CASKETS & CATALOG (WITH ADD, EDIT/REPLACE, DELETE)
        if (adminMasterTab == 1) {
            items(caskets, key = { it.id }) { casket ->
                Card(
                    shape = RoundedCornerShape(12.dp),
                    colors = CardDefaults.cardColors(containerColor = PureWhite),
                    border = BorderStroke(1.dp, BorderLight),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Column(modifier = Modifier.padding(14.dp)) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Column(modifier = Modifier.weight(1f)) {
                                Text(casket.name, fontWeight = FontWeight.Bold, fontSize = 13.sp, color = Navy900)
                                Text("${casket.id} • ${casket.woodType} • ${casket.tier}", fontSize = 10.sp, color = Color(0xFF64748B))
                            }
                            Column(horizontalAlignment = Alignment.End) {
                                Text(
                                    text = "KES ${String.format("%,.0f", casket.priceKes)}",
                                    fontWeight = FontWeight.ExtraBold,
                                    fontSize = 13.sp,
                                    color = EmeraldSuccess
                                )
                                Text("Stock: ${casket.stockCount} units", fontSize = 10.sp, color = Color(0xFF475569))
                            }
                        }

                        Spacer(modifier = Modifier.height(10.dp))

                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.End
                        ) {
                            Button(
                                onClick = { casketToEdit = casket },
                                colors = ButtonDefaults.buttonColors(containerColor = Navy900),
                                shape = RoundedCornerShape(6.dp),
                                modifier = Modifier.height(32.dp).testTag("btn_edit_casket_${casket.id}")
                            ) {
                                Icon(Icons.Default.Edit, contentDescription = null, modifier = Modifier.size(13.dp))
                                Spacer(modifier = Modifier.width(3.dp))
                                Text("Edit & Replace", fontSize = 10.sp)
                            }

                            Spacer(modifier = Modifier.width(6.dp))

                            OutlinedButton(
                                onClick = {
                                    deleteConfirmTarget = Triple(casket.name, "Casket Model") {
                                        onDeleteCasket(casket.id)
                                    }
                                },
                                colors = ButtonDefaults.outlinedButtonColors(contentColor = StrokeRed),
                                shape = RoundedCornerShape(6.dp),
                                modifier = Modifier.height(32.dp).testTag("btn_delete_casket_${casket.id}")
                            ) {
                                Icon(Icons.Default.Delete, contentDescription = null, modifier = Modifier.size(13.dp))
                                Spacer(modifier = Modifier.width(3.dp))
                                Text("Delete", fontSize = 10.sp)
                            }
                        }
                    }
                }
            }
        }

        // TAB 2: RAW MATERIALS & INVENTORY (WITH ADD, EDIT/REPLACE, DELETE)
        if (adminMasterTab == 2) {
            items(inventoryMaterials, key = { it.id }) { material ->
                Card(
                    shape = RoundedCornerShape(12.dp),
                    colors = CardDefaults.cardColors(containerColor = PureWhite),
                    border = BorderStroke(1.dp, BorderLight),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Column(modifier = Modifier.padding(14.dp)) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Column(modifier = Modifier.weight(1f)) {
                                Text(material.name, fontWeight = FontWeight.Bold, fontSize = 13.sp, color = Navy900)
                                Text("${material.id} • ${material.categoryName} • ${material.branchWarehouse}", fontSize = 10.sp, color = Color(0xFF64748B))
                            }
                            Column(horizontalAlignment = Alignment.End) {
                                Text("${material.quantity} ${material.unit}", fontWeight = FontWeight.ExtraBold, fontSize = 13.sp, color = ForestGreenPrimary)
                                Text("@ KES ${String.format("%,.0f", material.unitCostKes)}", fontSize = 10.sp, color = Color(0xFF64748B))
                            }
                        }

                        Spacer(modifier = Modifier.height(10.dp))

                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.End
                        ) {
                            Button(
                                onClick = { materialToEdit = material },
                                colors = ButtonDefaults.buttonColors(containerColor = Navy900),
                                shape = RoundedCornerShape(6.dp),
                                modifier = Modifier.height(32.dp).testTag("btn_edit_material_${material.id}")
                            ) {
                                Icon(Icons.Default.Edit, contentDescription = null, modifier = Modifier.size(13.dp))
                                Spacer(modifier = Modifier.width(3.dp))
                                Text("Edit & Replace", fontSize = 10.sp)
                            }

                            Spacer(modifier = Modifier.width(6.dp))

                            OutlinedButton(
                                onClick = {
                                    deleteConfirmTarget = Triple(material.name, "Raw Material") {
                                        onDeleteMaterial(material.id)
                                    }
                                },
                                colors = ButtonDefaults.outlinedButtonColors(contentColor = StrokeRed),
                                shape = RoundedCornerShape(6.dp),
                                modifier = Modifier.height(32.dp).testTag("btn_delete_material_${material.id}")
                            ) {
                                Icon(Icons.Default.Delete, contentDescription = null, modifier = Modifier.size(13.dp))
                                Spacer(modifier = Modifier.width(3.dp))
                                Text("Delete", fontSize = 10.sp)
                            }
                        }
                    }
                }
            }
        }

        // TAB 3: WORKSHOP JOBS (WITH EDIT/REPLACE, DELETE)
        if (adminMasterTab == 3) {
            items(workshopItems, key = { it.id }) { job ->
                Card(
                    shape = RoundedCornerShape(12.dp),
                    colors = CardDefaults.cardColors(containerColor = PureWhite),
                    border = BorderStroke(1.dp, BorderLight),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Column(modifier = Modifier.padding(14.dp)) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Column(modifier = Modifier.weight(1f)) {
                                Text(job.casketType, fontWeight = FontWeight.Bold, fontSize = 13.sp, color = Navy900)
                                Text("Craftsman: ${job.assignedCraftsmanName} • ${job.woodType}", fontSize = 10.sp, color = Color(0xFF64748B))
                                Text("Stage: ${job.currentStage.title} (${job.percentageDone}%)", fontSize = 10.sp, fontWeight = FontWeight.SemiBold, color = CyanDark)
                            }
                            OutlinedButton(
                                onClick = {
                                    deleteConfirmTarget = Triple(job.casketType, "Workshop Production Job") {
                                        onDeleteWorkshopItem(job.id)
                                    }
                                },
                                colors = ButtonDefaults.outlinedButtonColors(contentColor = StrokeRed),
                                shape = RoundedCornerShape(6.dp),
                                modifier = Modifier.height(32.dp).testTag("btn_delete_job_${job.id}")
                            ) {
                                Icon(Icons.Default.Delete, contentDescription = null, modifier = Modifier.size(13.dp))
                                Spacer(modifier = Modifier.width(2.dp))
                                Text("Delete", fontSize = 10.sp)
                            }
                        }
                    }
                }
            }
        }

        // TAB 4: FLEET VEHICLES (WITH EDIT/REPLACE, DELETE)
        if (adminMasterTab == 4) {
            items(fleetVehicles, key = { it.registration }) { vehicle ->
                Card(
                    shape = RoundedCornerShape(12.dp),
                    colors = CardDefaults.cardColors(containerColor = PureWhite),
                    border = BorderStroke(1.dp, BorderLight),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Column(modifier = Modifier.padding(14.dp)) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Column(modifier = Modifier.weight(1f)) {
                                Text(vehicle.registration, fontWeight = FontWeight.ExtraBold, fontSize = 13.sp, color = Navy900, fontFamily = FontFamily.Monospace)
                                Text("${vehicle.model} • ${vehicle.statusLabel}", fontSize = 10.sp, color = Color(0xFF64748B))
                                Text("Driver: ${vehicle.driverName} • Fuel: ${vehicle.fuelPercent}%", fontSize = 9.sp, color = ForestGreenPrimary)
                            }
                            OutlinedButton(
                                onClick = {
                                    deleteConfirmTarget = Triple(vehicle.registration, "Fleet Vehicle") {
                                        onDeleteFleetVehicle(vehicle.registration)
                                    }
                                },
                                colors = ButtonDefaults.outlinedButtonColors(contentColor = StrokeRed),
                                shape = RoundedCornerShape(6.dp),
                                modifier = Modifier.height(32.dp).testTag("btn_delete_vehicle_${vehicle.registration}")
                            ) {
                                Icon(Icons.Default.Delete, contentDescription = null, modifier = Modifier.size(13.dp))
                                Spacer(modifier = Modifier.width(2.dp))
                                Text("Delete", fontSize = 10.sp)
                            }
                        }
                    }
                }
            }
        }

        // TAB 5: CUSTOMER ORDERS (WITH EDIT/REPLACE, DELETE)
        if (adminMasterTab == 5) {
            items(customerOrders, key = { it.orderId }) { order ->
                Card(
                    shape = RoundedCornerShape(12.dp),
                    colors = CardDefaults.cardColors(containerColor = PureWhite),
                    border = BorderStroke(1.dp, BorderLight),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Column(modifier = Modifier.padding(14.dp)) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Column(modifier = Modifier.weight(1f)) {
                                Text("${order.clientName} (${order.orderId})", fontWeight = FontWeight.Bold, fontSize = 13.sp, color = Navy900)
                                Text("Casket: ${order.selectedCasket} • ${order.branch}", fontSize = 10.sp, color = Color(0xFF64748B))
                                Text("Status: ${order.paymentStatus} • Date: ${order.orderDate}", fontSize = 9.sp, color = CyanDark)
                            }
                            Column(horizontalAlignment = Alignment.End) {
                                Text("KES ${String.format("%,.0f", order.totalAmountKes)}", fontWeight = FontWeight.ExtraBold, fontSize = 13.sp, color = EmeraldSuccess)
                                Spacer(modifier = Modifier.height(4.dp))
                                OutlinedButton(
                                    onClick = {
                                        deleteConfirmTarget = Triple("Order ${order.orderId}", "Customer Order") {
                                            onDeleteCustomerOrder(order.orderId)
                                        }
                                    },
                                    colors = ButtonDefaults.outlinedButtonColors(contentColor = StrokeRed),
                                    shape = RoundedCornerShape(6.dp),
                                    modifier = Modifier.height(30.dp).testTag("btn_delete_order_${order.orderId}")
                                ) {
                                    Icon(Icons.Default.Delete, contentDescription = null, modifier = Modifier.size(12.dp))
                                    Spacer(modifier = Modifier.width(2.dp))
                                    Text("Delete", fontSize = 9.sp)
                                }
                            }
                        }
                    }
                }
            }
        }

        // TAB 6: STAFF BREAKAGES & WALLET DEDUCTIONS
        if (adminMasterTab == 6) {
            item {
                val totalBreakageKes = breakageRecords.sumOf { it.breakageCostKes }
                val pendingCount = breakageRecords.count { !it.isDeducted }
                Surface(
                    color = RoseLight,
                    shape = RoundedCornerShape(12.dp),
                    border = BorderStroke(1.dp, StrokeRed.copy(alpha = 0.35f)),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Row(
                        modifier = Modifier.padding(14.dp),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Column(modifier = Modifier.weight(1f)) {
                            Text("Breakages & Cost Recovery Ledger", fontWeight = FontWeight.ExtraBold, fontSize = 13.sp, color = StrokeRed)
                            Text(
                                "Total Logged: KES ${String.format("%,.0f", totalBreakageKes)} • Pending Deductions: $pendingCount",
                                fontSize = 11.sp,
                                color = Navy900
                            )
                        }
                        Button(
                            onClick = { showRecordBreakageDialog = true },
                            colors = ButtonDefaults.buttonColors(containerColor = StrokeRed),
                            shape = RoundedCornerShape(8.dp),
                            contentPadding = PaddingValues(horizontal = 10.dp, vertical = 6.dp),
                            modifier = Modifier.testTag("btn_open_log_breakage")
                        ) {
                            Icon(Icons.Default.Warning, contentDescription = null, modifier = Modifier.size(14.dp))
                            Spacer(modifier = Modifier.width(4.dp))
                            Text("Log Breakage", fontSize = 11.sp, fontWeight = FontWeight.Bold, maxLines = 1, softWrap = false)
                        }
                    }
                }
            }

            items(breakageRecords, key = { it.id }) { rec ->
                Card(
                    shape = RoundedCornerShape(12.dp),
                    colors = CardDefaults.cardColors(containerColor = PureWhite),
                    border = BorderStroke(1.dp, if (rec.isDeducted) EmeraldSuccess.copy(alpha = 0.4f) else StrokeRed.copy(alpha = 0.4f)),
                    modifier = Modifier.fillMaxWidth().testTag("breakage_card_${rec.id}")
                ) {
                    Column(modifier = Modifier.padding(14.dp)) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Column(modifier = Modifier.weight(1f)) {
                                Text(rec.itemBroken, fontWeight = FontWeight.Bold, fontSize = 13.sp, color = Navy900)
                                Text("${rec.staffName} (${rec.department.displayName})", fontSize = 11.sp, color = CyanDark, fontWeight = FontWeight.SemiBold)
                                Text(rec.description, fontSize = 10.sp, color = Color(0xFF475569))
                                Text("Logged ${rec.date} by ${rec.loggedBy}", fontSize = 9.sp, color = Color(0xFF64748B))
                            }
                            Column(horizontalAlignment = Alignment.End) {
                                Text(
                                    "- KES ${String.format("%,.0f", rec.breakageCostKes)}",
                                    fontWeight = FontWeight.ExtraBold,
                                    fontSize = 14.sp,
                                    color = StrokeRed
                                )
                                Surface(
                                    color = if (rec.isDeducted) EmeraldLight else AmberLight,
                                    shape = RoundedCornerShape(6.dp)
                                ) {
                                    Text(
                                        text = if (rec.isDeducted) "DEDUCTED" else "PENDING",
                                        fontSize = 9.sp,
                                        fontWeight = FontWeight.ExtraBold,
                                        color = if (rec.isDeducted) EmeraldSuccess else AmberWarning,
                                        modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp)
                                    )
                                }
                            }
                        }

                        if (!rec.isDeducted) {
                            Spacer(modifier = Modifier.height(10.dp))
                            Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.End) {
                                Button(
                                    onClick = { onExecutePendingBreakage(rec.id) },
                                    colors = ButtonDefaults.buttonColors(containerColor = StrokeRed),
                                    shape = RoundedCornerShape(8.dp),
                                    contentPadding = PaddingValues(horizontal = 12.dp, vertical = 6.dp),
                                    modifier = Modifier.height(34.dp).testTag("btn_execute_breakage_${rec.id}")
                                ) {
                                    Icon(Icons.Default.Payments, contentDescription = null, modifier = Modifier.size(14.dp))
                                    Spacer(modifier = Modifier.width(4.dp))
                                    Text("Deduct Now", fontSize = 11.sp, fontWeight = FontWeight.Bold, maxLines = 1, softWrap = false)
                                }
                            }
                        }
                    }
                }
            }
        }

        // TAB 7: OPERATORS TRANSPORT FEE & DAILY WAGES
        if (adminMasterTab == 7) {
            item {
                Surface(
                    color = CyanContainer,
                    shape = RoundedCornerShape(12.dp),
                    border = BorderStroke(1.dp, CyanPrimary.copy(alpha = 0.4f)),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Row(
                        modifier = Modifier.padding(14.dp),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Column(modifier = Modifier.weight(1f)) {
                            Text("Operators Transport & Daily Wages", fontWeight = FontWeight.ExtraBold, fontSize = 13.sp, color = Navy900)
                            Text(
                                "Active Operators: ${operatorsList.size} • Total Allocations: ${operatorWageAllocations.size}",
                                fontSize = 11.sp,
                                color = CyanDark
                            )
                        }
                        Button(
                            onClick = {
                                preselectedOperatorForWage = operatorsList.firstOrNull()
                                showAllocateOperatorWageDialog = true
                            },
                            colors = ButtonDefaults.buttonColors(containerColor = CyanPrimary),
                            shape = RoundedCornerShape(8.dp),
                            contentPadding = PaddingValues(horizontal = 10.dp, vertical = 6.dp),
                            modifier = Modifier.testTag("btn_open_allocate_operator_wage")
                        ) {
                            Icon(Icons.Default.LocalShipping, contentDescription = null, modifier = Modifier.size(14.dp))
                            Spacer(modifier = Modifier.width(4.dp))
                            Text("Allocate Wage", fontSize = 11.sp, fontWeight = FontWeight.Bold, maxLines = 1, softWrap = false)
                        }
                    }
                }
            }

            items(operatorsList, key = { "op_${it.id}" }) { op ->
                Card(
                    shape = RoundedCornerShape(12.dp),
                    colors = CardDefaults.cardColors(containerColor = PureWhite),
                    border = BorderStroke(1.dp, BorderLight),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Row(
                        modifier = Modifier.padding(14.dp),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Column(modifier = Modifier.weight(1f)) {
                            Text(op.fullName, fontWeight = FontWeight.Bold, fontSize = 13.sp, color = Navy900)
                            Text("${op.id} • ${op.branch} • ${op.phone}", fontSize = 10.sp, color = Color(0xFF64748B))
                            Text(
                                "Assigned Transport: KES ${String.format("%,.0f", op.transportFeeKes)} • Daily Wage: KES ${String.format("%,.0f", op.dailyWageKes)}",
                                fontSize = 10.sp,
                                fontWeight = FontWeight.SemiBold,
                                color = ForestGreenPrimary
                            )
                        }
                        Button(
                            onClick = {
                                preselectedOperatorForWage = op
                                showAllocateOperatorWageDialog = true
                            },
                            colors = ButtonDefaults.buttonColors(containerColor = Navy900),
                            shape = RoundedCornerShape(6.dp),
                            contentPadding = PaddingValues(horizontal = 10.dp, vertical = 4.dp),
                            modifier = Modifier.height(34.dp).testTag("btn_quick_allocate_${op.id}")
                        ) {
                            Text("Allocate", fontSize = 10.sp, fontWeight = FontWeight.Bold, maxLines = 1, softWrap = false)
                        }
                    }
                }
            }

            items(operatorWageAllocations, key = { it.id }) { alloc ->
                Card(
                    shape = RoundedCornerShape(12.dp),
                    colors = CardDefaults.cardColors(containerColor = PureWhite),
                    border = BorderStroke(1.dp, if (alloc.isDisbursed) EmeraldSuccess.copy(alpha = 0.4f) else AmberWarning),
                    modifier = Modifier.fillMaxWidth().testTag("operator_wage_card_${alloc.id}")
                ) {
                    Column(modifier = Modifier.padding(14.dp)) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Column(modifier = Modifier.weight(1f)) {
                                Text(alloc.staffName, fontWeight = FontWeight.Bold, fontSize = 13.sp, color = Navy900)
                                Text("${alloc.dutyAssignment} • ${alloc.branch}", fontSize = 11.sp, color = CyanDark, fontWeight = FontWeight.SemiBold)
                                Text(
                                    "Transport: KES ${String.format("%,.0f", alloc.transportFeeKes)} + Daily Wage: KES ${String.format("%,.0f", alloc.dailyWageKes)}",
                                    fontSize = 10.sp,
                                    color = Color(0xFF334155)
                                )
                                Text("${alloc.date} • By ${alloc.allocatedBy}", fontSize = 9.sp, color = Color(0xFF64748B))
                            }
                            Column(horizontalAlignment = Alignment.End) {
                                Text(
                                    "KES ${String.format("%,.0f", alloc.totalPaidKes)}",
                                    fontWeight = FontWeight.ExtraBold,
                                    fontSize = 14.sp,
                                    color = EmeraldSuccess
                                )
                                Surface(
                                    color = if (alloc.isDisbursed) EmeraldLight else AmberLight,
                                    shape = RoundedCornerShape(6.dp)
                                ) {
                                    Text(
                                        text = if (alloc.isDisbursed) "DISBURSED" else "ALLOCATED",
                                        fontSize = 9.sp,
                                        fontWeight = FontWeight.ExtraBold,
                                        color = if (alloc.isDisbursed) EmeraldSuccess else AmberWarning,
                                        modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp)
                                    )
                                }
                            }
                        }

                        if (!alloc.isDisbursed) {
                            Spacer(modifier = Modifier.height(10.dp))
                            Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.End) {
                                Button(
                                    onClick = { onDisburseOperatorWage(alloc.id) },
                                    colors = ButtonDefaults.buttonColors(containerColor = EmeraldSuccess),
                                    shape = RoundedCornerShape(8.dp),
                                    contentPadding = PaddingValues(horizontal = 12.dp, vertical = 6.dp),
                                    modifier = Modifier.height(34.dp).testTag("btn_disburse_wage_${alloc.id}")
                                ) {
                                    Icon(Icons.Default.Check, contentDescription = null, modifier = Modifier.size(14.dp))
                                    Spacer(modifier = Modifier.width(4.dp))
                                    Text("Disburse to Wallet", fontSize = 11.sp, fontWeight = FontWeight.Bold, maxLines = 1, softWrap = false)
                                }
                            }
                        }
                    }
                }
            }
        }

        // TAB 8: AUTO-ASSIGN TASKS, ALERTS & PAYMENT PRICING
        if (adminMasterTab == 8) {
            item {
                Surface(
                    color = AmberLight,
                    shape = RoundedCornerShape(12.dp),
                    border = BorderStroke(1.dp, AmberWarning),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Row(
                        modifier = Modifier.padding(14.dp),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Column(modifier = Modifier.weight(1f)) {
                            Text("Role Auto-Assignment & Task Pricing", fontWeight = FontWeight.ExtraBold, fontSize = 13.sp, color = Navy900)
                            Text(
                                "Auto-route tasks by role, alert staff & set verified payout rates (${staffAlerts.size} alerts)",
                                fontSize = 11.sp,
                                color = Color(0xFF78350F)
                            )
                        }
                        Button(
                            onClick = { showAutoAssignTaskDialog = true },
                            colors = ButtonDefaults.buttonColors(containerColor = Navy900),
                            shape = RoundedCornerShape(8.dp),
                            contentPadding = PaddingValues(horizontal = 10.dp, vertical = 6.dp),
                            modifier = Modifier.testTag("btn_open_admin_auto_assign")
                        ) {
                            Icon(Icons.Default.NotificationsActive, contentDescription = null, modifier = Modifier.size(14.dp))
                            Spacer(modifier = Modifier.width(4.dp))
                            Text("Auto-Assign", fontSize = 11.sp, fontWeight = FontWeight.Bold, maxLines = 1, softWrap = false)
                        }
                    }
                }
            }

            items(activities, key = { it.id }) { act ->
                Card(
                    shape = RoundedCornerShape(12.dp),
                    colors = CardDefaults.cardColors(containerColor = PureWhite),
                    border = BorderStroke(1.dp, BorderLight),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Column(modifier = Modifier.padding(14.dp)) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Column(modifier = Modifier.weight(1f)) {
                                Text(act.title, fontWeight = FontWeight.Bold, fontSize = 13.sp, color = Navy900)
                                Text("${act.staffName} (${act.department.displayName}) • ${act.caseReference}", fontSize = 10.sp, color = CyanDark, fontWeight = FontWeight.SemiBold)
                                Text("Status: ${act.status.label} • Priority: ${act.priority.label}", fontSize = 10.sp, color = Color(0xFF64748B))
                            }
                            Column(horizontalAlignment = Alignment.End) {
                                Text("KES ${String.format("%,.0f", act.allowanceEarned)}", fontWeight = FontWeight.ExtraBold, fontSize = 13.sp, color = EmeraldSuccess)
                                Spacer(modifier = Modifier.height(6.dp))
                                Button(
                                    onClick = { activityToAssessPrice = act },
                                    colors = ButtonDefaults.buttonColors(containerColor = EmeraldSuccess),
                                    shape = RoundedCornerShape(6.dp),
                                    contentPadding = PaddingValues(horizontal = 10.dp, vertical = 4.dp),
                                    modifier = Modifier.height(32.dp).testTag("btn_admin_assess_${act.id}")
                                ) {
                                    Text("Assess & Price", fontSize = 10.sp, fontWeight = FontWeight.Bold, maxLines = 1, softWrap = false)
                                }
                            }
                        }
                    }
                }
            }

            if (staffAlerts.isNotEmpty()) {
                item {
                    Text(
                        text = "Dispatched Staff Alerts (${staffAlerts.size})",
                        fontWeight = FontWeight.Bold,
                        fontSize = 13.sp,
                        color = MaterialTheme.colorScheme.onSurface,
                        modifier = Modifier.padding(top = 6.dp)
                    )
                }
                items(staffAlerts.take(10), key = { it.id }) { alert ->
                    Surface(
                        color = PureWhite,
                        shape = RoundedCornerShape(10.dp),
                        border = BorderStroke(1.dp, if (alert.isRead) BorderLight else AmberWarning),
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Column(modifier = Modifier.padding(12.dp)) {
                            Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                                Text(alert.title, fontWeight = FontWeight.Bold, fontSize = 12.sp, color = Navy900)
                                Text(alert.category, fontSize = 9.sp, fontWeight = FontWeight.Bold, color = CyanDark)
                            }
                            Text("To: ${alert.recipientName} • ${alert.timestamp}", fontSize = 10.sp, color = Color(0xFF64748B))
                            Text(alert.message, fontSize = 11.sp, color = Color(0xFF334155))
                        }
                    }
                }
            }
        }

        item {
            Spacer(modifier = Modifier.height(80.dp)) // padding for bottom bar
        }
    }

    // DIALOGS: ADD / EDIT / DELETE CONFIRMATION
    if (showAddStaffDialog) {
        AdminAddEditStaffDialog(
            existingStaff = null,
            onDismiss = { showAddStaffDialog = false },
            onSave = { newStaff ->
                onAddOrReplaceStaff(newStaff)
                showAddStaffDialog = false
            }
        )
    }

    staffToEdit?.let { staff ->
        AdminAddEditStaffDialog(
            existingStaff = staff,
            onDismiss = { staffToEdit = null },
            onSave = { updatedStaff ->
                onAddOrReplaceStaff(updatedStaff)
                staffToEdit = null
            }
        )
    }

    if (showAddCasketDialog) {
        AdminAddEditCasketDialog(
            existingCasket = null,
            onDismiss = { showAddCasketDialog = false },
            onSave = { newCasket ->
                onAddOrReplaceCasket(newCasket)
                showAddCasketDialog = false
            }
        )
    }

    casketToEdit?.let { casket ->
        AdminAddEditCasketDialog(
            existingCasket = casket,
            onDismiss = { casketToEdit = null },
            onSave = { updatedCasket ->
                onAddOrReplaceCasket(updatedCasket)
                casketToEdit = null
            }
        )
    }

    if (showAddMaterialDialog) {
        AdminAddEditMaterialDialog(
            existingMaterial = null,
            onDismiss = { showAddMaterialDialog = false },
            onSave = { newMat ->
                onAddOrReplaceMaterial(newMat)
                showAddMaterialDialog = false
            }
        )
    }

    materialToEdit?.let { mat ->
        AdminAddEditMaterialDialog(
            existingMaterial = mat,
            onDismiss = { materialToEdit = null },
            onSave = { updatedMat ->
                onAddOrReplaceMaterial(updatedMat)
                materialToEdit = null
            }
        )
    }

    // LOG BREAKAGE & DEDUCTION DIALOG
    if (showRecordBreakageDialog) {
        var selectedStaff by remember { mutableStateOf(staffAccounts.firstOrNull()) }
        var staffExpanded by remember { mutableStateOf(false) }
        var itemBroken by remember { mutableStateOf("") }
        var description by remember { mutableStateOf("") }
        var costText by remember { mutableStateOf("2500") }
        var deductImmediately by remember { mutableStateOf(true) }

        AlertDialog(
            onDismissRequest = { showRecordBreakageDialog = false },
            title = {
                Text("Log Staff Breakage & Cost Deduction", fontWeight = FontWeight.Bold, fontSize = 15.sp, color = Navy900)
            },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(8.dp), modifier = Modifier.verticalScroll(rememberScrollState())) {
                    ExposedDropdownMenuBox(expanded = staffExpanded, onExpandedChange = { staffExpanded = !staffExpanded }) {
                        OutlinedTextField(
                            value = selectedStaff?.let { "${it.fullName} (${it.role.title})" } ?: "Select Staff",
                            onValueChange = {},
                            readOnly = true,
                            label = { Text("Responsible Staff Member", fontSize = 11.sp) },
                            trailingIcon = { ExposedDropdownMenuDefaults.TrailingIcon(expanded = staffExpanded) },
                            modifier = Modifier.fillMaxWidth().menuAnchor(MenuAnchorType.PrimaryNotEditable)
                        )
                        ExposedDropdownMenu(expanded = staffExpanded, onDismissRequest = { staffExpanded = false }) {
                            staffAccounts.forEach { st ->
                                DropdownMenuItem(
                                    text = { Text("${st.fullName} • ${st.department.displayName}", fontSize = 12.sp) },
                                    onClick = {
                                        selectedStaff = st
                                        staffExpanded = false
                                    }
                                )
                            }
                        }
                    }

                    OutlinedTextField(
                        value = itemBroken,
                        onValueChange = { itemBroken = it },
                        label = { Text("Damaged / Broken Item*", fontSize = 11.sp) },
                        placeholder = { Text("e.g. Brass Viewing Glass Frame", fontSize = 11.sp) },
                        singleLine = true,
                        modifier = Modifier.fillMaxWidth().testTag("breakage_item_input")
                    )

                    OutlinedTextField(
                        value = costText,
                        onValueChange = { costText = it.filter { ch -> ch.isDigit() || ch == '.' } },
                        label = { Text("Breakage Cost (KES)*", fontSize = 11.sp) },
                        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                        singleLine = true,
                        modifier = Modifier.fillMaxWidth().testTag("breakage_cost_input")
                    )

                    OutlinedTextField(
                        value = description,
                        onValueChange = { description = it },
                        label = { Text("Incident Details", fontSize = 11.sp) },
                        maxLines = 2,
                        modifier = Modifier.fillMaxWidth()
                    )

                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        modifier = Modifier.fillMaxWidth().clickable { deductImmediately = !deductImmediately }
                    ) {
                        Checkbox(checked = deductImmediately, onCheckedChange = { deductImmediately = it })
                        Spacer(modifier = Modifier.width(6.dp))
                        Text("Execute Wallet Deduction Immediately", fontSize = 12.sp, fontWeight = FontWeight.SemiBold, color = Navy900)
                    }
                }
            },
            confirmButton = {
                Button(
                    onClick = {
                        val st = selectedStaff ?: return@Button
                        val cost = costText.toDoubleOrNull() ?: 0.0
                        if (cost > 0.0) {
                            onRecordBreakage(
                                st.id,
                                itemBroken.ifBlank { "Workshop / Field Equipment" },
                                description.ifBlank { "Logged by ${adminAccount.fullName}" },
                                cost,
                                deductImmediately
                            )
                            showRecordBreakageDialog = false
                        }
                    },
                    colors = ButtonDefaults.buttonColors(containerColor = StrokeRed),
                    modifier = Modifier.testTag("btn_confirm_record_breakage")
                ) {
                    Text(if (deductImmediately) "Record & Deduct" else "Log Pending", maxLines = 1, softWrap = false)
                }
            },
            dismissButton = {
                TextButton(onClick = { showRecordBreakageDialog = false }) { Text("Cancel") }
            },
            containerColor = PureWhite
        )
    }

    // ALLOCATE OPERATOR TRANSPORT FEE & DAILY WAGE DIALOG
    if (showAllocateOperatorWageDialog) {
        var selectedOp by remember(preselectedOperatorForWage) {
            mutableStateOf(preselectedOperatorForWage ?: operatorsList.firstOrNull() ?: staffAccounts.firstOrNull())
        }
        var opExpanded by remember { mutableStateOf(false) }
        var transportText by remember { mutableStateOf((selectedOp?.transportFeeKes?.takeIf { it > 0 } ?: 800.0).toLong().toString()) }
        var dailyWageText by remember { mutableStateOf((selectedOp?.dailyWageKes?.takeIf { it > 0 } ?: 1500.0).toLong().toString()) }
        var dutyAssignment by remember { mutableStateOf("Gravesite Lowering Gear & Grounds Setup") }
        var disburseNow by remember { mutableStateOf(true) }

        AlertDialog(
            onDismissRequest = { showAllocateOperatorWageDialog = false },
            title = {
                Text("Allocate Operator Transport & Daily Wage", fontWeight = FontWeight.Bold, fontSize = 15.sp, color = Navy900)
            },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(8.dp), modifier = Modifier.verticalScroll(rememberScrollState())) {
                    ExposedDropdownMenuBox(expanded = opExpanded, onExpandedChange = { opExpanded = !opExpanded }) {
                        OutlinedTextField(
                            value = selectedOp?.let { "${it.fullName} (${it.branch})" } ?: "Select Operator",
                            onValueChange = {},
                            readOnly = true,
                            label = { Text("Operator / Grounds Staff", fontSize = 11.sp) },
                            trailingIcon = { ExposedDropdownMenuDefaults.TrailingIcon(expanded = opExpanded) },
                            modifier = Modifier.fillMaxWidth().menuAnchor(MenuAnchorType.PrimaryNotEditable)
                        )
                        ExposedDropdownMenu(expanded = opExpanded, onDismissRequest = { opExpanded = false }) {
                            (operatorsList.ifEmpty { staffAccounts }).forEach { st ->
                                DropdownMenuItem(
                                    text = { Text("${st.fullName} • ${st.role.title}", fontSize = 12.sp) },
                                    onClick = {
                                        selectedOp = st
                                        opExpanded = false
                                    }
                                )
                            }
                        }
                    }

                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        OutlinedTextField(
                            value = transportText,
                            onValueChange = { transportText = it.filter { ch -> ch.isDigit() || ch == '.' } },
                            label = { Text("Transport Fee (KES)", fontSize = 11.sp) },
                            keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                            singleLine = true,
                            modifier = Modifier.weight(1f).testTag("operator_transport_fee_input")
                        )
                        OutlinedTextField(
                            value = dailyWageText,
                            onValueChange = { dailyWageText = it.filter { ch -> ch.isDigit() || ch == '.' } },
                            label = { Text("Daily Wage (KES)", fontSize = 11.sp) },
                            keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                            singleLine = true,
                            modifier = Modifier.weight(1f).testTag("operator_daily_wage_input")
                        )
                    }

                    OutlinedTextField(
                        value = dutyAssignment,
                        onValueChange = { dutyAssignment = it },
                        label = { Text("Duty Assignment", fontSize = 11.sp) },
                        singleLine = true,
                        modifier = Modifier.fillMaxWidth()
                    )

                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        modifier = Modifier.fillMaxWidth().clickable { disburseNow = !disburseNow }
                    ) {
                        Checkbox(checked = disburseNow, onCheckedChange = { disburseNow = it })
                        Spacer(modifier = Modifier.width(6.dp))
                        Text("Disburse to Operator Wallet Immediately", fontSize = 12.sp, fontWeight = FontWeight.SemiBold, color = Navy900)
                    }
                }
            },
            confirmButton = {
                Button(
                    onClick = {
                        val op = selectedOp ?: return@Button
                        val tFee = transportText.toDoubleOrNull() ?: 0.0
                        val dWage = dailyWageText.toDoubleOrNull() ?: 0.0
                        onAllocateOperatorWage(
                            op.id,
                            tFee,
                            dWage,
                            dutyAssignment.ifBlank { "Operator Daily Field Shift" },
                            disburseNow
                        )
                        showAllocateOperatorWageDialog = false
                    },
                    colors = ButtonDefaults.buttonColors(containerColor = CyanPrimary),
                    modifier = Modifier.testTag("btn_confirm_allocate_operator_wage")
                ) {
                    Text(if (disburseNow) "Allocate & Pay" else "Save Allocation", maxLines = 1, softWrap = false)
                }
            },
            dismissButton = {
                TextButton(onClick = { showAllocateOperatorWageDialog = false }) { Text("Cancel") }
            },
            containerColor = PureWhite
        )
    }

    // ADMIN AUTO-ASSIGN TASK DIALOG
    if (showAutoAssignTaskDialog) {
        var selectedCategory by remember { mutableStateOf(ActivityCategory.OPERATOR_SETUP) }
        var catExpanded by remember { mutableStateOf(false) }
        var titleInput by remember { mutableStateOf("") }
        var caseRefInput by remember { mutableStateOf("CASE-2026-" + (100..999).random()) }
        var familyInput by remember { mutableStateOf("") }
        var locationInput by remember { mutableStateOf("Bama Branch") }
        var selectedPriority by remember { mutableStateOf(TaskPriority.HIGH) }
        var payPriceText by remember { mutableStateOf("2000") }
        var notesInput by remember { mutableStateOf("") }

        AlertDialog(
            onDismissRequest = { showAutoAssignTaskDialog = false },
            title = { Text("Auto-Assign Task & Alert Staff", fontWeight = FontWeight.Bold, fontSize = 15.sp, color = Navy900) },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(8.dp), modifier = Modifier.verticalScroll(rememberScrollState())) {
                    ExposedDropdownMenuBox(expanded = catExpanded, onExpandedChange = { catExpanded = !catExpanded }) {
                        OutlinedTextField(
                            value = selectedCategory.label,
                            onValueChange = {},
                            readOnly = true,
                            label = { Text("Role / Task Category", fontSize = 11.sp) },
                            trailingIcon = { ExposedDropdownMenuDefaults.TrailingIcon(expanded = catExpanded) },
                            modifier = Modifier.fillMaxWidth().menuAnchor(MenuAnchorType.PrimaryNotEditable)
                        )
                        ExposedDropdownMenu(expanded = catExpanded, onDismissRequest = { catExpanded = false }) {
                            ActivityCategory.values().forEach { cat ->
                                DropdownMenuItem(
                                    text = { Text(cat.label, fontSize = 12.sp) },
                                    onClick = {
                                        selectedCategory = cat
                                        catExpanded = false
                                    }
                                )
                            }
                        }
                    }

                    OutlinedTextField(
                        value = titleInput,
                        onValueChange = { titleInput = it },
                        label = { Text("Task Title*", fontSize = 11.sp) },
                        singleLine = true,
                        modifier = Modifier.fillMaxWidth()
                    )

                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        OutlinedTextField(
                            value = caseRefInput,
                            onValueChange = { caseRefInput = it },
                            label = { Text("Case Ref", fontSize = 11.sp) },
                            singleLine = true,
                            modifier = Modifier.weight(1f)
                        )
                        OutlinedTextField(
                            value = payPriceText,
                            onValueChange = { payPriceText = it.filter { ch -> ch.isDigit() || ch == '.' } },
                            label = { Text("Pay Price (KES)", fontSize = 11.sp) },
                            keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                            singleLine = true,
                            modifier = Modifier.weight(1f)
                        )
                    }

                    OutlinedTextField(
                        value = familyInput,
                        onValueChange = { familyInput = it },
                        label = { Text("Client / Family", fontSize = 11.sp) },
                        singleLine = true,
                        modifier = Modifier.fillMaxWidth()
                    )

                    OutlinedTextField(
                        value = locationInput,
                        onValueChange = { locationInput = it },
                        label = { Text("Location", fontSize = 11.sp) },
                        singleLine = true,
                        modifier = Modifier.fillMaxWidth()
                    )

                    Row(horizontalArrangement = Arrangement.spacedBy(6.dp), modifier = Modifier.horizontalScroll(rememberScrollState())) {
                        TaskPriority.values().forEach { prio ->
                            FilterChip(
                                selected = selectedPriority == prio,
                                onClick = { selectedPriority = prio },
                                label = { Text(prio.label, fontSize = 10.sp, maxLines = 1, softWrap = false) }
                            )
                        }
                    }

                    OutlinedTextField(
                        value = notesInput,
                        onValueChange = { notesInput = it },
                        label = { Text("Notes", fontSize = 11.sp) },
                        maxLines = 2,
                        modifier = Modifier.fillMaxWidth()
                    )
                }
            },
            confirmButton = {
                Button(
                    onClick = {
                        onAutoAssignTask(
                            selectedCategory,
                            titleInput.ifBlank { "${selectedCategory.label} Task" },
                            caseRefInput,
                            familyInput.ifBlank { "Jabima Family Case" },
                            locationInput,
                            selectedPriority,
                            payPriceText.toDoubleOrNull() ?: 1500.0,
                            notesInput
                        )
                        showAutoAssignTaskDialog = false
                    },
                    colors = ButtonDefaults.buttonColors(containerColor = Navy900)
                ) {
                    Text("Assign & Alert", maxLines = 1, softWrap = false)
                }
            },
            dismissButton = {
                TextButton(onClick = { showAutoAssignTaskDialog = false }) { Text("Cancel") }
            },
            containerColor = PureWhite
        )
    }

    // ADMIN ASSESS & PRICE ACTIVITY DIALOG
    activityToAssessPrice?.let { act ->
        var priceText by remember(act.id) { mutableStateOf(act.allowanceEarned.toLong().toString()) }
        var approveAndCredit by remember(act.id) { mutableStateOf(true) }
        var notes by remember(act.id) { mutableStateOf("Admin assessed & approved task payment.") }

        AlertDialog(
            onDismissRequest = { activityToAssessPrice = null },
            title = { Text("Assess & Price Task Pay", fontWeight = FontWeight.Bold, fontSize = 15.sp, color = Navy900) },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    Text("${act.title} — ${act.staffName}", fontSize = 12.sp, fontWeight = FontWeight.SemiBold, color = CyanDark)
                    OutlinedTextField(
                        value = priceText,
                        onValueChange = { priceText = it.filter { ch -> ch.isDigit() || ch == '.' } },
                        label = { Text("Payment Price (KES)", fontSize = 11.sp) },
                        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                        singleLine = true,
                        modifier = Modifier.fillMaxWidth()
                    )
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        modifier = Modifier.fillMaxWidth().clickable { approveAndCredit = !approveAndCredit }
                    ) {
                        Checkbox(checked = approveAndCredit, onCheckedChange = { approveAndCredit = it })
                        Spacer(modifier = Modifier.width(6.dp))
                        Text("Approve & Credit Staff Wallet Now", fontSize = 12.sp, fontWeight = FontWeight.SemiBold, color = Navy900)
                    }
                    OutlinedTextField(
                        value = notes,
                        onValueChange = { notes = it },
                        label = { Text("Assessment Notes", fontSize = 11.sp) },
                        maxLines = 2,
                        modifier = Modifier.fillMaxWidth()
                    )
                }
            },
            confirmButton = {
                Button(
                    onClick = {
                        onAdminAssessAndPriceActivity(
                            act.id,
                            priceText.toDoubleOrNull() ?: act.allowanceEarned,
                            approveAndCredit,
                            notes
                        )
                        activityToAssessPrice = null
                    },
                    colors = ButtonDefaults.buttonColors(containerColor = EmeraldSuccess)
                ) {
                    Text("Save Payment", maxLines = 1, softWrap = false)
                }
            },
            dismissButton = {
                TextButton(onClick = { activityToAssessPrice = null }) { Text("Cancel") }
            },
            containerColor = PureWhite
        )
    }

    deleteConfirmTarget?.let { (name, type, onConfirm) ->
        AdminConfirmDeleteDialog(
            itemName = name,
            itemCategory = type,
            onDismiss = { deleteConfirmTarget = null },
            onConfirmDelete = {
                onConfirm()
                deleteConfirmTarget = null
            }
        )
    }
}

@Composable
private fun AdminStatCard(
    title: String,
    value: String,
    sub: String,
    color: Color,
    bgColor: Color,
    modifier: Modifier = Modifier
) {
    Surface(
        color = bgColor,
        shape = RoundedCornerShape(12.dp),
        modifier = modifier
    ) {
        Column(modifier = Modifier.padding(12.dp)) {
            Text(text = title, fontSize = 10.sp, color = color, fontWeight = FontWeight.SemiBold)
            Text(text = value, fontSize = 18.sp, fontWeight = FontWeight.ExtraBold, color = color)
            Text(text = sub, fontSize = 9.sp, color = color.copy(alpha = 0.8f))
        }
    }
}
