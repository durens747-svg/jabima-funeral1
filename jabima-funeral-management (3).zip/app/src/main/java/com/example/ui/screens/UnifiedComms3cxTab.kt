package com.example.ui.screens

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Backspace
import androidx.compose.material.icons.filled.Call
import androidx.compose.material.icons.filled.CallEnd
import androidx.compose.material.icons.filled.CallReceived
import androidx.compose.material.icons.filled.CallMade
import androidx.compose.material.icons.filled.CallMissed
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.Dialpad
import androidx.compose.material.icons.filled.HeadsetMic
import androidx.compose.material.icons.filled.Mic
import androidx.compose.material.icons.filled.MicOff
import androidx.compose.material.icons.filled.Pause
import androidx.compose.material.icons.filled.PhoneForwarded
import androidx.compose.material.icons.filled.PhoneInTalk
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material.icons.filled.RecordVoiceOver
import androidx.compose.material.icons.filled.Search
import androidx.compose.material.icons.filled.VolumeUp
import androidx.compose.material.icons.filled.VolumeOff
import androidx.compose.material.icons.filled.FiberManualRecord
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.FilterChip
import androidx.compose.material3.FilterChipDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.ScrollableTabRow
import androidx.compose.material3.Surface
import androidx.compose.material3.Tab
import androidx.compose.material3.TabRowDefaults
import androidx.compose.material3.TabRowDefaults.tabIndicatorOffset
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.model.MPESA_STK_NUMBER
import com.example.model.VoipCallLog
import com.example.model.VoipExtension
import com.example.ui.StaffPortalViewModel
import com.example.ui.theme.AmberLight
import com.example.ui.theme.AmberWarning
import com.example.ui.theme.BorderLight
import com.example.ui.theme.EmeraldLight
import com.example.ui.theme.EmeraldSuccess
import com.example.ui.theme.Navy800
import com.example.ui.theme.Navy900
import com.example.ui.theme.ObsidianBlack
import com.example.ui.theme.PureWhite
import com.example.ui.theme.RoyalCobaltBlue
import com.example.ui.theme.RoyalCobaltIce
import com.example.ui.theme.TextPrimary
import com.example.ui.theme.TextSecondary
import kotlinx.coroutines.delay

enum class Comms3cxView(val label: String) {
    DIALER("SIP Dialer"),
    EXTENSIONS("Extension Directory"),
    CALL_LOGS("Call History & CDR")
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun UnifiedComms3cxTab(
    viewModel: StaffPortalViewModel
) {
    val extensions by viewModel.voipExtensions.collectAsState()
    val callLogs by viewModel.voipCallLogs.collectAsState()
    val currentAccount by viewModel.currentAccount.collectAsState()

    var activeSubView by remember { mutableStateOf(Comms3cxView.DIALER) }
    var dialedNumber by remember { mutableStateOf("") }
    var activeCallTarget by remember { mutableStateOf<String?>(null) }
    var activeCallNumber by remember { mutableStateOf<String?>(null) }
    var isCallActive by remember { mutableStateOf(false) }
    var callSeconds by remember { mutableIntStateOf(0) }

    var isMuted by remember { mutableStateOf(false) }
    var isSpeakerOn by remember { mutableStateOf(true) }
    var isRecording by remember { mutableStateOf(true) }
    var isHold by remember { mutableStateOf(false) }

    var staffPresence by remember { mutableStateOf("Available") }
    var extensionSearchQuery by remember { mutableStateOf("") }
    var selectedExtensionFilter by remember { mutableStateOf("All") }

    // Active call timer
    LaunchedEffect(isCallActive) {
        if (isCallActive) {
            callSeconds = 0
            while (isCallActive) {
                delay(1000)
                callSeconds++
            }
        }
    }

    val formatTimer = { secs: Int ->
        val m = secs / 60
        val s = secs % 60
        String.format("%02d:%02d", m, s)
    }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(PureWhite)
            .padding(16.dp)
            .testTag("3cx_unified_comms_tab")
    ) {
        // TOP SYSTEM HEADER
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Column {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Box(
                        modifier = Modifier
                            .size(34.dp)
                            .clip(CircleShape)
                            .background(RoyalCobaltIce),
                        contentAlignment = Alignment.Center
                    ) {
                        Icon(
                            imageVector = Icons.Default.PhoneInTalk,
                            contentDescription = null,
                            tint = RoyalCobaltBlue,
                            modifier = Modifier.size(18.dp)
                        )
                    }
                    Spacer(modifier = Modifier.width(10.dp))
                    Column {
                        Text(
                            text = "3CX Communication Portal",
                            fontSize = 18.sp,
                            fontWeight = FontWeight.Bold,
                            color = ObsidianBlack,
                            modifier = Modifier.testTag("3cx_portal_header_title")
                        )
                        Text(
                            text = "SIP VOIP Phone • 24/7 Central Dispatch • Branch Intercom",
                            fontSize = 11.sp,
                            color = TextSecondary
                        )
                    }
                }
            }

            // PBX ONLINE STATUS BADGE
            Surface(
                color = EmeraldLight,
                shape = RoundedCornerShape(16.dp),
                border = BorderStroke(1.dp, Color(0xFFA7F3D0))
            ) {
                Row(
                    modifier = Modifier.padding(horizontal = 10.dp, vertical = 5.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Box(
                        modifier = Modifier
                            .size(8.dp)
                            .clip(CircleShape)
                            .background(EmeraldSuccess)
                    )
                    Spacer(modifier = Modifier.width(6.dp))
                    Text(
                        text = "3CX PBX Online (18ms)",
                        fontSize = 11.sp,
                        fontWeight = FontWeight.Bold,
                        color = Color(0xFF065F46),
                        modifier = Modifier.testTag("3cx_pbx_online_badge")
                    )
                }
            }
        }

        Spacer(modifier = Modifier.height(10.dp))

        // STAFF EXTENSION INFO & PRESENCE STRIP
        Surface(
            color = Color(0xFFF8FAFC),
            shape = RoundedCornerShape(10.dp),
            border = BorderStroke(1.dp, BorderLight),
            modifier = Modifier.fillMaxWidth()
        ) {
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 12.dp, vertical = 8.dp),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Text(
                        text = "SIP Trunk:",
                        fontSize = 11.sp,
                        fontWeight = FontWeight.Bold,
                        color = TextSecondary
                    )
                    Spacer(modifier = Modifier.width(4.dp))
                    Text(
                        text = "sip.jabimafuneral.co.ke:5060",
                        fontSize = 11.sp,
                        fontWeight = FontWeight.SemiBold,
                        color = RoyalCobaltBlue
                    )
                    Spacer(modifier = Modifier.width(8.dp))
                    Text(
                        text = "• Codec: Opus HD 48kHz",
                        fontSize = 11.sp,
                        color = TextSecondary
                    )
                }

                Row(verticalAlignment = Alignment.CenterVertically) {
                    Text(
                        text = "Presence: ",
                        fontSize = 11.sp,
                        fontWeight = FontWeight.Bold,
                        color = TextSecondary
                    )
                    listOf("Available", "On Call", "DND").forEach { status ->
                        val isSel = staffPresence == status
                        Surface(
                            color = if (isSel) RoyalCobaltBlue else Color.Transparent,
                            shape = RoundedCornerShape(6.dp),
                            border = if (!isSel) BorderStroke(1.dp, BorderLight) else null,
                            modifier = Modifier
                                .padding(horizontal = 3.dp)
                                .clickable { staffPresence = status }
                        ) {
                            Text(
                                text = status,
                                fontSize = 10.sp,
                                fontWeight = if (isSel) FontWeight.Bold else FontWeight.Normal,
                                color = if (isSel) PureWhite else TextSecondary,
                                modifier = Modifier.padding(horizontal = 8.dp, vertical = 3.dp)
                            )
                        }
                    }
                }
            }
        }

        Spacer(modifier = Modifier.height(10.dp))

        // SUB-NAVIGATION TABS (Dialer, Extension Directory, Call History)
        ScrollableTabRow(
            selectedTabIndex = activeSubView.ordinal,
            containerColor = PureWhite,
            contentColor = TextPrimary,
            edgePadding = 0.dp,
            indicator = { tabPositions ->
                if (activeSubView.ordinal < tabPositions.size) {
                    TabRowDefaults.SecondaryIndicator(
                        modifier = Modifier.tabIndicatorOffset(tabPositions[activeSubView.ordinal]),
                        color = RoyalCobaltBlue,
                        height = 3.dp
                    )
                }
            },
            modifier = Modifier
                .fillMaxWidth()
                .border(1.dp, BorderLight, RoundedCornerShape(8.dp))
                .clip(RoundedCornerShape(8.dp))
        ) {
            Comms3cxView.values().forEach { view ->
                val isSelected = activeSubView == view
                Tab(
                    selected = isSelected,
                    onClick = { activeSubView = view },
                    text = {
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.spacedBy(6.dp)
                        ) {
                            Icon(
                                imageVector = when (view) {
                                    Comms3cxView.DIALER -> Icons.Default.Dialpad
                                    Comms3cxView.EXTENSIONS -> Icons.Default.HeadsetMic
                                    Comms3cxView.CALL_LOGS -> Icons.Default.CallMade
                                },
                                contentDescription = null,
                                modifier = Modifier.size(15.dp),
                                tint = if (isSelected) RoyalCobaltBlue else TextSecondary
                            )
                            Text(
                                text = view.label,
                                fontSize = 12.sp,
                                fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Normal,
                                color = if (isSelected) RoyalCobaltBlue else TextSecondary,
                                maxLines = 1,
                                softWrap = false,
                                overflow = TextOverflow.Ellipsis
                            )
                        }
                    },
                    modifier = Modifier.testTag("3cx_subtab_${view.name.lowercase()}")
                )
            }
        }

        Spacer(modifier = Modifier.height(10.dp))

        // ACTIVE CALL BANNER / CONTROLS (WHEN A CALL IS IN PROGRESS)
        if (isCallActive) {
            Card(
                colors = CardDefaults.cardColors(containerColor = Navy900),
                shape = RoundedCornerShape(12.dp),
                border = BorderStroke(1.dp, Color(0xFF1E40AF)),
                modifier = Modifier
                    .fillMaxWidth()
                    .testTag("3cx_active_call_banner")
            ) {
                Column(modifier = Modifier.padding(14.dp)) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Box(
                                modifier = Modifier
                                    .size(40.dp)
                                    .clip(CircleShape)
                                    .background(Color(0xFF047857)),
                                contentAlignment = Alignment.Center
                            ) {
                                Icon(
                                    Icons.Default.PhoneInTalk,
                                    contentDescription = null,
                                    tint = PureWhite,
                                    modifier = Modifier.size(20.dp)
                                )
                            }
                            Spacer(modifier = Modifier.width(10.dp))
                            Column {
                                Text(
                                    text = activeCallTarget ?: "Connected Call",
                                    fontSize = 14.sp,
                                    fontWeight = FontWeight.Bold,
                                    color = PureWhite
                                )
                                Text(
                                    text = "${activeCallNumber ?: ""} • Connected via 3CX Trunk",
                                    fontSize = 11.sp,
                                    color = Color(0xFF93C5FD)
                                )
                            }
                        }

                        // CALL DURATION TIMER
                        Surface(
                            color = Color(0xFF1E293B),
                            shape = RoundedCornerShape(8.dp),
                            border = BorderStroke(1.dp, Color(0xFF334155))
                        ) {
                            Row(
                                modifier = Modifier.padding(horizontal = 10.dp, vertical = 4.dp),
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Icon(
                                    Icons.Default.FiberManualRecord,
                                    contentDescription = null,
                                    tint = if (isHold) AmberWarning else EmeraldSuccess,
                                    modifier = Modifier.size(10.dp)
                                )
                                Spacer(modifier = Modifier.width(6.dp))
                                Text(
                                    text = if (isHold) "ON HOLD" else formatTimer(callSeconds),
                                    fontSize = 13.sp,
                                    fontWeight = FontWeight.Bold,
                                    color = if (isHold) AmberWarning else PureWhite
                                )
                            }
                        }
                    }

                    Spacer(modifier = Modifier.height(12.dp))

                    // IN-CALL CONTROL BUTTONS (Mute, Speaker, Hold, Rec, Transfer, End)
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceEvenly,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        // MUTE
                        IconButton(
                            onClick = { isMuted = !isMuted },
                            modifier = Modifier.testTag("dialpad_mute_button")
                        ) {
                            Column(horizontalAlignment = Alignment.CenterHorizontally) {
                                Box(
                                    modifier = Modifier
                                        .size(36.dp)
                                        .clip(CircleShape)
                                        .background(if (isMuted) com.example.ui.theme.StrokeRed else Color(0xFF334155)),
                                    contentAlignment = Alignment.Center
                                ) {
                                    Icon(
                                        if (isMuted) Icons.Default.MicOff else Icons.Default.Mic,
                                        contentDescription = "Mute",
                                        tint = PureWhite,
                                        modifier = Modifier.size(18.dp)
                                    )
                                }
                                Text(if (isMuted) "Unmute" else "Mute", fontSize = 9.sp, color = PureWhite)
                            }
                        }

                        // SPEAKER
                        IconButton(
                            onClick = { isSpeakerOn = !isSpeakerOn },
                            modifier = Modifier.testTag("dialpad_speaker_button")
                        ) {
                            Column(horizontalAlignment = Alignment.CenterHorizontally) {
                                Box(
                                    modifier = Modifier
                                        .size(36.dp)
                                        .clip(CircleShape)
                                        .background(if (isSpeakerOn) RoyalCobaltBlue else Color(0xFF334155)),
                                    contentAlignment = Alignment.Center
                                ) {
                                    Icon(
                                        if (isSpeakerOn) Icons.Default.VolumeUp else Icons.Default.VolumeOff,
                                        contentDescription = "Speaker",
                                        tint = PureWhite,
                                        modifier = Modifier.size(18.dp)
                                    )
                                }
                                Text("Speaker", fontSize = 9.sp, color = PureWhite)
                            }
                        }

                        // HOLD
                        IconButton(
                            onClick = { isHold = !isHold }
                        ) {
                            Column(horizontalAlignment = Alignment.CenterHorizontally) {
                                Box(
                                    modifier = Modifier
                                        .size(36.dp)
                                        .clip(CircleShape)
                                        .background(if (isHold) AmberWarning else Color(0xFF334155)),
                                    contentAlignment = Alignment.Center
                                ) {
                                    Icon(Icons.Default.Pause, contentDescription = "Hold", tint = PureWhite, modifier = Modifier.size(18.dp))
                                }
                                Text(if (isHold) "Resume" else "Hold", fontSize = 9.sp, color = PureWhite)
                            }
                        }

                        // RECORDING
                        IconButton(
                            onClick = { isRecording = !isRecording },
                            modifier = Modifier.testTag("dialpad_record_button")
                        ) {
                            Column(horizontalAlignment = Alignment.CenterHorizontally) {
                                Box(
                                    modifier = Modifier
                                        .size(36.dp)
                                        .clip(CircleShape)
                                        .background(if (isRecording) com.example.ui.theme.StrokeRed else Color(0xFF334155)),
                                    contentAlignment = Alignment.Center
                                ) {
                                    Icon(Icons.Default.FiberManualRecord, contentDescription = "Record", tint = PureWhite, modifier = Modifier.size(16.dp))
                                }
                                Text(if (isRecording) "REC ON" else "Rec Off", fontSize = 9.sp, color = PureWhite)
                            }
                        }

                        // TRANSFER
                        IconButton(
                            onClick = {
                                viewModel.actionFeedbackMessage.value = "Call transferred to Central Dispatch Ext 101."
                                isCallActive = false
                            }
                        ) {
                            Column(horizontalAlignment = Alignment.CenterHorizontally) {
                                Box(
                                    modifier = Modifier
                                        .size(36.dp)
                                        .clip(CircleShape)
                                        .background(Color(0xFF334155)),
                                    contentAlignment = Alignment.Center
                                ) {
                                    Icon(Icons.Default.PhoneForwarded, contentDescription = "Transfer", tint = PureWhite, modifier = Modifier.size(18.dp))
                                }
                                Text("Transfer", fontSize = 9.sp, color = PureWhite)
                            }
                        }

                        // END CALL
                        Button(
                            onClick = {
                                viewModel.recordVoipCall(
                                    callType = "Outbound",
                                    contactName = activeCallTarget ?: "Unknown",
                                    numberOrExt = activeCallNumber ?: "",
                                    durationText = formatTimer(callSeconds) + " min"
                                )
                                isCallActive = false
                                activeCallTarget = null
                                activeCallNumber = null
                            },
                            colors = ButtonDefaults.buttonColors(containerColor = com.example.ui.theme.StrokeRed),
                            shape = RoundedCornerShape(8.dp),
                            modifier = Modifier
                                .height(38.dp)
                                .testTag("dialpad_end_call_button")
                        ) {
                            Icon(Icons.Default.CallEnd, contentDescription = "End Call", modifier = Modifier.size(16.dp))
                            Spacer(modifier = Modifier.width(4.dp))
                            Text("End", fontSize = 11.sp, fontWeight = FontWeight.Bold)
                        }
                    }
                }
            }
            Spacer(modifier = Modifier.height(10.dp))
        }

        // VIEW SELECTION CONTENT
        when (activeSubView) {
            Comms3cxView.DIALER -> {
                // DIALER VIEW
                Column(
                    modifier = Modifier
                        .fillMaxSize()
                        .testTag("3cx_dialer_view")
                ) {
                    // 24/7 EMERGENCY HOTLINE QUICK CALL
                    Card(
                        colors = CardDefaults.cardColors(containerColor = Navy900),
                        shape = RoundedCornerShape(10.dp),
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Row(
                            modifier = Modifier.padding(12.dp),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Box(
                                    modifier = Modifier
                                        .size(36.dp)
                                        .clip(CircleShape)
                                        .background(Color(0xFF047857)),
                                    contentAlignment = Alignment.Center
                                ) {
                                    Icon(Icons.Default.PhoneInTalk, contentDescription = null, tint = PureWhite, modifier = Modifier.size(18.dp))
                                }
                                Spacer(modifier = Modifier.width(10.dp))
                                Column {
                                    Text(
                                        text = "24/7 EMERGENCY DISPATCH HOTLINE",
                                        fontSize = 10.sp,
                                        fontWeight = FontWeight.Bold,
                                        color = Color(0xFF93C5FD)
                                    )
                                    Text(
                                        text = MPESA_STK_NUMBER,
                                        fontSize = 15.sp,
                                        fontWeight = FontWeight.ExtraBold,
                                        color = PureWhite
                                    )
                                    Text(
                                        text = "Direct SIP line to Central Dispatch & Fleet Base",
                                        fontSize = 10.sp,
                                        color = Color(0xFFCBD5E1)
                                    )
                                }
                            }

                            Button(
                                onClick = {
                                    activeCallTarget = "24/7 Emergency Dispatch"
                                    activeCallNumber = MPESA_STK_NUMBER
                                    isCallActive = true
                                },
                                colors = ButtonDefaults.buttonColors(containerColor = EmeraldSuccess),
                                shape = RoundedCornerShape(8.dp),
                                modifier = Modifier.testTag("3cx_hotline_dial_button")
                            ) {
                                Icon(Icons.Default.Call, contentDescription = null, modifier = Modifier.size(14.dp))
                                Spacer(modifier = Modifier.width(4.dp))
                                Text("Call 24/7", fontSize = 11.sp, fontWeight = FontWeight.Bold)
                            }
                        }
                    }

                    Spacer(modifier = Modifier.height(10.dp))

                    // NUMERIC DIALPAD CARD
                    Card(
                        colors = CardDefaults.cardColors(containerColor = PureWhite),
                        shape = RoundedCornerShape(12.dp),
                        border = BorderStroke(1.dp, BorderLight),
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Column(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(16.dp),
                            horizontalAlignment = Alignment.CenterHorizontally
                        ) {
                            // DIALED NUMBER DISPLAY
                            OutlinedTextField(
                                value = dialedNumber,
                                onValueChange = { dialedNumber = it },
                                placeholder = {
                                    Text(
                                        "Enter phone number or extension...",
                                        fontSize = 13.sp,
                                        color = Color(0xFF94A3B8)
                                    )
                                },
                                trailingIcon = {
                                    if (dialedNumber.isNotEmpty()) {
                                        IconButton(onClick = {
                                            dialedNumber = dialedNumber.dropLast(1)
                                        }) {
                                            Icon(
                                                Icons.Default.Backspace,
                                                contentDescription = "Backspace",
                                                tint = Color(0xFF64748B),
                                                modifier = Modifier.size(20.dp)
                                            )
                                        }
                                    }
                                },
                                colors = OutlinedTextFieldDefaults.colors(
                                    focusedBorderColor = RoyalCobaltBlue,
                                    unfocusedBorderColor = BorderLight,
                                    focusedContainerColor = Color(0xFFF8FAFC),
                                    unfocusedContainerColor = Color(0xFFF8FAFC)
                                ),
                                textStyle = androidx.compose.ui.text.TextStyle(
                                    fontSize = 20.sp,
                                    fontWeight = FontWeight.Bold,
                                    textAlign = TextAlign.Center,
                                    color = ObsidianBlack
                                ),
                                singleLine = true,
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .testTag("3cx_dialpad_input")
                            )

                            Spacer(modifier = Modifier.height(12.dp))

                            // 12-KEY SIP DIALPAD
                            val keys = listOf(
                                listOf("1" to "", "2" to "ABC", "3" to "DEF"),
                                listOf("4" to "GHI", "5" to "JKL", "6" to "MNO"),
                                listOf("7" to "PQRS", "8" to "TUV", "9" to "WXYZ"),
                                listOf("*" to "", "0" to "+", "#" to "")
                            )

                            Column(
                                modifier = Modifier.testTag("3cx_dialpad"),
                                verticalArrangement = Arrangement.spacedBy(8.dp)
                            ) {
                                keys.forEach { row ->
                                    Row(
                                        modifier = Modifier.fillMaxWidth(),
                                        horizontalArrangement = Arrangement.SpaceEvenly
                                    ) {
                                        row.forEach { (digit, sub) ->
                                            val testTagKey = when (digit) {
                                                "*" -> "dialpad_digit_star"
                                                "#" -> "dialpad_digit_hash"
                                                else -> "dialpad_digit_$digit"
                                            }
                                            Surface(
                                                color = Color(0xFFF8FAFC),
                                                shape = RoundedCornerShape(10.dp),
                                                border = BorderStroke(1.dp, BorderLight),
                                                modifier = Modifier
                                                    .size(width = 90.dp, height = 52.dp)
                                                    .clip(RoundedCornerShape(10.dp))
                                                    .clickable { dialedNumber += digit }
                                                    .testTag(testTagKey)
                                            ) {
                                                Column(
                                                    modifier = Modifier.fillMaxSize(),
                                                    verticalArrangement = Arrangement.Center,
                                                    horizontalAlignment = Alignment.CenterHorizontally
                                                ) {
                                                    Text(
                                                        text = digit,
                                                        fontSize = 18.sp,
                                                        fontWeight = FontWeight.ExtraBold,
                                                        color = ObsidianBlack
                                                    )
                                                    if (sub.isNotEmpty()) {
                                                        Text(
                                                            text = sub,
                                                            fontSize = 8.sp,
                                                            color = Color(0xFF94A3B8),
                                                            fontWeight = FontWeight.SemiBold
                                                        )
                                                    }
                                                }
                                            }
                                        }
                                    }
                                }
                            }

                            Spacer(modifier = Modifier.height(14.dp))

                            // CALL ACTION BUTTON
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.spacedBy(10.dp)
                            ) {
                                Button(
                                    onClick = {
                                        val numberToCall = dialedNumber.ifBlank { MPESA_STK_NUMBER }
                                        activeCallTarget = if (dialedNumber.isBlank()) "Hotline Dispatch" else "Ext/Number: $numberToCall"
                                        activeCallNumber = numberToCall
                                        isCallActive = true
                                    },
                                    colors = ButtonDefaults.buttonColors(containerColor = RoyalCobaltBlue),
                                    shape = RoundedCornerShape(10.dp),
                                    modifier = Modifier
                                        .weight(1f)
                                        .height(46.dp)
                                        .testTag("dialpad_call_button")
                                ) {
                                    Icon(Icons.Default.Call, contentDescription = null, modifier = Modifier.size(18.dp))
                                    Spacer(modifier = Modifier.width(8.dp))
                                    Text(
                                        text = if (dialedNumber.isBlank()) "Dial 24/7 Hotline ($MPESA_STK_NUMBER)" else "Call $dialedNumber via 3CX",
                                        fontSize = 12.sp,
                                        fontWeight = FontWeight.Bold
                                    )
                                }

                                if (dialedNumber.isNotEmpty()) {
                                    Button(
                                        onClick = { dialedNumber = "" },
                                        colors = ButtonDefaults.buttonColors(containerColor = Color(0xFFF1F5F9)),
                                        shape = RoundedCornerShape(10.dp),
                                        modifier = Modifier.height(46.dp)
                                    ) {
                                        Text("Clear", color = TextSecondary, fontSize = 12.sp)
                                    }
                                }
                            }
                        }
                    }
                }
            }

            Comms3cxView.EXTENSIONS -> {
                // EXTENSION DIRECTORY VIEW
                Column(
                    modifier = Modifier
                        .fillMaxSize()
                        .testTag("3cx_extension_directory_view")
                ) {
                    // SEARCH AND FILTER
                    OutlinedTextField(
                        value = extensionSearchQuery,
                        onValueChange = { extensionSearchQuery = it },
                        placeholder = { Text("Search branch, person, or extension number...", fontSize = 12.sp) },
                        leadingIcon = {
                            Icon(Icons.Default.Search, contentDescription = null, tint = TextSecondary, modifier = Modifier.size(16.dp))
                        },
                        colors = OutlinedTextFieldDefaults.colors(
                            focusedBorderColor = RoyalCobaltBlue,
                            unfocusedBorderColor = BorderLight,
                            focusedContainerColor = PureWhite,
                            unfocusedContainerColor = PureWhite
                        ),
                        singleLine = true,
                        modifier = Modifier
                            .fillMaxWidth()
                            .testTag("3cx_extension_search")
                    )

                    Spacer(modifier = Modifier.height(8.dp))

                    val filteredExtensions = extensions.filter { ext ->
                        val queryMatches = extensionSearchQuery.isBlank() ||
                                ext.extension.contains(extensionSearchQuery, ignoreCase = true) ||
                                ext.departmentOrBranch.contains(extensionSearchQuery, ignoreCase = true) ||
                                ext.contactPerson.contains(extensionSearchQuery, ignoreCase = true)
                        queryMatches
                    }

                    LazyColumn(
                        modifier = Modifier.weight(1f),
                        verticalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        items(filteredExtensions) { ext ->
                            Card(
                                colors = CardDefaults.cardColors(containerColor = PureWhite),
                                border = BorderStroke(1.dp, BorderLight),
                                shape = RoundedCornerShape(10.dp),
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .testTag("extension_card_${ext.extension}")
                            ) {
                                Row(
                                    modifier = Modifier.padding(12.dp),
                                    horizontalArrangement = Arrangement.SpaceBetween,
                                    verticalAlignment = Alignment.CenterVertically
                                ) {
                                    Row(verticalAlignment = Alignment.CenterVertically) {
                                        Surface(
                                            color = RoyalCobaltIce,
                                            shape = RoundedCornerShape(8.dp),
                                            modifier = Modifier.size(42.dp)
                                        ) {
                                            Box(contentAlignment = Alignment.Center) {
                                                Text(
                                                    text = ext.extension,
                                                    fontSize = 13.sp,
                                                    fontWeight = FontWeight.ExtraBold,
                                                    color = RoyalCobaltBlue
                                                )
                                            }
                                        }

                                        Spacer(modifier = Modifier.width(12.dp))

                                        Column {
                                            Row(verticalAlignment = Alignment.CenterVertically) {
                                                Text(
                                                    text = ext.departmentOrBranch,
                                                    fontSize = 13.sp,
                                                    fontWeight = FontWeight.Bold,
                                                    color = ObsidianBlack
                                                )
                                                Spacer(modifier = Modifier.width(6.dp))
                                                Box(
                                                    modifier = Modifier
                                                        .size(6.dp)
                                                        .clip(CircleShape)
                                                        .background(EmeraldSuccess)
                                                )
                                            }
                                            Text(
                                                text = "${ext.contactPerson} • ${ext.directDial}",
                                                fontSize = 11.sp,
                                                color = TextSecondary
                                            )
                                        }
                                    }

                                    Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                                        Button(
                                            onClick = {
                                                activeCallTarget = "${ext.departmentOrBranch} (${ext.contactPerson})"
                                                activeCallNumber = "Ext ${ext.extension}"
                                                isCallActive = true
                                            },
                                            colors = ButtonDefaults.buttonColors(containerColor = RoyalCobaltBlue),
                                            shape = RoundedCornerShape(6.dp),
                                            modifier = Modifier.height(34.dp)
                                        ) {
                                            Icon(Icons.Default.Call, contentDescription = null, modifier = Modifier.size(12.dp))
                                            Spacer(modifier = Modifier.width(4.dp))
                                            Text("Call", fontSize = 11.sp)
                                        }

                                        Button(
                                            onClick = {
                                                viewModel.actionFeedbackMessage.value = "Direct intercom paging opened to Ext ${ext.extension}."
                                            },
                                            colors = ButtonDefaults.buttonColors(containerColor = Color(0xFFF1F5F9)),
                                            shape = RoundedCornerShape(6.dp),
                                            modifier = Modifier.height(34.dp)
                                        ) {
                                            Text("Intercom", fontSize = 10.sp, color = TextPrimary)
                                        }
                                    }
                                }
                            }
                        }
                    }
                }
            }

            Comms3cxView.CALL_LOGS -> {
                // CALL LOGS & CDR VIEW
                Column(
                    modifier = Modifier
                        .fillMaxSize()
                        .testTag("3cx_call_logs_tab")
                ) {
                    Text(
                        text = "Recent SIP Call Detail Records (CDR)",
                        fontSize = 13.sp,
                        fontWeight = FontWeight.Bold,
                        color = ObsidianBlack
                    )
                    Spacer(modifier = Modifier.height(8.dp))

                    LazyColumn(
                        modifier = Modifier.weight(1f),
                        verticalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        items(callLogs) { log ->
                            Card(
                                colors = CardDefaults.cardColors(containerColor = PureWhite),
                                border = BorderStroke(1.dp, BorderLight),
                                shape = RoundedCornerShape(10.dp),
                                modifier = Modifier.fillMaxWidth()
                            ) {
                                Row(
                                    modifier = Modifier.padding(12.dp),
                                    horizontalArrangement = Arrangement.SpaceBetween,
                                    verticalAlignment = Alignment.CenterVertically
                                ) {
                                    Row(verticalAlignment = Alignment.CenterVertically) {
                                        val icon = when (log.callType) {
                                            "Inbound" -> Icons.Default.CallReceived
                                            "Outbound" -> Icons.Default.CallMade
                                            "Missed" -> Icons.Default.CallMissed
                                            else -> Icons.Default.PhoneInTalk
                                        }
                                        val iconColor = when (log.callType) {
                                            "Inbound" -> EmeraldSuccess
                                            "Outbound" -> RoyalCobaltBlue
                                            "Missed" -> com.example.ui.theme.StrokeRed
                                            else -> AmberWarning
                                        }
                                        Box(
                                            modifier = Modifier
                                                .size(36.dp)
                                                .clip(CircleShape)
                                                .background(iconColor.copy(alpha = 0.1f)),
                                            contentAlignment = Alignment.Center
                                        ) {
                                            Icon(icon, contentDescription = null, tint = iconColor, modifier = Modifier.size(18.dp))
                                        }

                                        Spacer(modifier = Modifier.width(10.dp))

                                        Column {
                                            Text(
                                                text = log.contactName,
                                                fontSize = 13.sp,
                                                fontWeight = FontWeight.Bold,
                                                color = ObsidianBlack
                                            )
                                            Text(
                                                text = "${log.callType} • ${log.numberOrExt} • ${log.durationText}",
                                                fontSize = 11.sp,
                                                color = TextSecondary
                                            )
                                        }
                                    }

                                    Column(horizontalAlignment = Alignment.End) {
                                        Text(
                                            text = log.timestamp,
                                            fontSize = 10.sp,
                                            color = TextSecondary
                                        )
                                        Spacer(modifier = Modifier.height(4.dp))
                                        if (log.recordingAvailable) {
                                            Surface(
                                                color = RoyalCobaltIce,
                                                shape = RoundedCornerShape(4.dp),
                                                modifier = Modifier.clickable {
                                                    viewModel.actionFeedbackMessage.value = "Playing 3CX encrypted call recording for ${log.contactName} (${log.durationText})."
                                                }
                                            ) {
                                                Row(
                                                    modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp),
                                                    verticalAlignment = Alignment.CenterVertically
                                                ) {
                                                    Icon(Icons.Default.PlayArrow, contentDescription = null, tint = RoyalCobaltBlue, modifier = Modifier.size(10.dp))
                                                    Spacer(modifier = Modifier.width(2.dp))
                                                    Text("Audio Rec", fontSize = 9.sp, fontWeight = FontWeight.Bold, color = RoyalCobaltBlue)
                                                }
                                            }
                                        }
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }
    }
}
