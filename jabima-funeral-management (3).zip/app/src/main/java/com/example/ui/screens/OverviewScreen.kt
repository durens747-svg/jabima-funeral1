package com.example.ui.screens

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import com.example.ui.theme.PureWhite
import com.example.ui.theme.TextSecondary
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.AccountBalanceWallet
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.ArrowForward
import androidx.compose.material.icons.filled.Assignment
import androidx.compose.material.icons.filled.CalendarMonth
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.LocationOn
import androidx.compose.material.icons.filled.Payment
import androidx.compose.material.icons.filled.PhoneInTalk
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material.icons.filled.ReceiptLong
import androidx.compose.material.icons.filled.Schedule
import androidx.compose.material.icons.automirrored.filled.ArrowForward
import androidx.compose.material.icons.automirrored.filled.FactCheck
import androidx.compose.material.icons.automirrored.filled.Send
import androidx.compose.material.icons.filled.Build
import androidx.compose.material.icons.filled.Handyman
import androidx.compose.material.icons.filled.FormatPaint
import androidx.compose.material.icons.filled.Lens
import androidx.compose.material.icons.filled.LinearScale
import androidx.compose.material.icons.filled.Check
import androidx.compose.material.icons.filled.Visibility
import androidx.compose.material.icons.filled.Person
import androidx.compose.material.icons.filled.Layers
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.ScrollableTabRow
import androidx.compose.material3.Tab
import androidx.compose.material3.TabRowDefaults
import androidx.compose.material3.TabRowDefaults.tabIndicatorOffset
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import com.example.model.WorkshopProductionItem
import com.example.model.WorkshopProductionStage
import com.example.model.InventoryMaterialItem
import com.example.ui.theme.ForestGreenPrimary
import com.example.ui.theme.ForestGreenDark
import com.example.ui.theme.ForestGreenBorder
import com.example.ui.theme.ForestGreenLight
import com.example.ui.theme.StrokeRed
import com.example.ui.theme.StrokeRedLight
import com.example.ui.theme.StrokeRedDark
import androidx.compose.material.icons.filled.TrendingUp
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.font.FontWeight
import com.example.BuildConfig
import com.example.R
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.rememberScrollState
import androidx.compose.material.icons.filled.AttachMoney
import androidx.compose.material.icons.filled.EventNote
import androidx.compose.material.icons.filled.Inventory
import androidx.compose.material.icons.filled.Paid
import androidx.compose.material.icons.filled.PrecisionManufacturing
import androidx.compose.material.icons.filled.ShoppingBag
import androidx.compose.material.icons.filled.Warning
import com.example.model.ActivityStatus
import com.example.model.CasketStockByBranchRow
import com.example.model.DashboardDailyKpis
import com.example.model.JABIMA_BRANCHES
import com.example.model.JABIMA_CASKET_TYPES
import com.example.model.NavTab
import com.example.model.ExcelDatasetType
import com.example.model.BurialScheduleEvent
import com.example.model.FleetGpsVehicle
import com.example.model.StaffAccount
import com.example.model.StaffActivity
import com.example.model.StaffWalletSummary
import com.example.model.WalletTransaction
import com.example.ui.theme.AmberLight
import com.example.ui.theme.AmberWarning
import com.example.ui.theme.BorderLight
import com.example.ui.theme.CyanContainer
import com.example.ui.theme.CyanDark
import com.example.ui.theme.CyanLight
import com.example.ui.theme.CyanPrimary
import com.example.ui.theme.EmeraldLight
import com.example.ui.theme.EmeraldSuccess
import com.example.ui.theme.Navy800
import com.example.ui.theme.Navy900
import com.example.ui.components.ManagerialOversightDashboardCard
import com.example.ui.theme.RoyalCobaltBlue
import com.example.ui.theme.RoyalCobaltIce
import kotlin.math.abs

@Composable
fun OverviewScreen(
    currentAccount: StaffAccount,
    walletSummary: StaffWalletSummary,
    activities: List<StaffActivity>,
    recentTransactions: List<WalletTransaction>,
    dailyKpis: DashboardDailyKpis = DashboardDailyKpis(),
    casketStockByBranch: List<CasketStockByBranchRow> = emptyList(),
    workshopItems: List<WorkshopProductionItem> = emptyList(),
    craftsmenList: List<StaffAccount> = emptyList(),
    inventoryMaterials: List<InventoryMaterialItem> = emptyList(),
    onRequestPayout: () -> Unit,
    onLogActivity: () -> Unit,
    onNavigateTab: (NavTab) -> Unit,
    onOpenLiveWorkshop: () -> Unit = {},
    onOpenInventory: () -> Unit = {},
    onOpenBurialScheduler: () -> Unit = {},
    onOpenDailyReport: () -> Unit = {},
    onUpdateActivityStatus: (activityId: String, status: ActivityStatus) -> Unit,
    onSelectTransaction: (WalletTransaction) -> Unit,
    onToggleChecklistItem: (activityId: String, item: String) -> Unit = { _, _ -> },
    onOpenRealtimeLogger: () -> Unit = {},
    onOpenPriceEditor: () -> Unit = {},
    onOpenStockUpload: () -> Unit = {},
    onOpenUniversalExcelImport: (ExcelDatasetType) -> Unit = {},
    onOpenExportManifest: () -> Unit = {},
    burialSchedules: List<BurialScheduleEvent> = emptyList(),
    fleetVehicles: List<FleetGpsVehicle> = emptyList(),
    allActivities: List<StaffActivity> = activities,
    allStaffAccounts: List<StaffAccount> = emptyList(),
    onDispatchTaskAlert: (StaffActivity) -> Unit = {},
    onOpenOrderDashboard: () -> Unit = {},
    onOpenCostAnalytics: () -> Unit = {}
) {
    var selectedOverviewTab by remember { mutableIntStateOf(0) }
    val overviewTabs = listOf(
        "Operations & Logs" to Icons.AutoMirrored.Filled.FactCheck,
        "The Workshop" to Icons.Default.PrecisionManufacturing,
        "Financials & KPIs" to Icons.Default.TrendingUp,
        "Staff Wallet & Duties" to Icons.Default.AccountBalanceWallet,
        "All Combined" to Icons.Default.Layers
    )

    val completedCount = activities.count { it.status == ActivityStatus.COMPLETED || it.status == ActivityStatus.VERIFIED_BY_ADMIN }
    val inProgressCount = activities.count { it.status == ActivityStatus.IN_PROGRESS }
    val scheduledCount = activities.count { it.status == ActivityStatus.SCHEDULED }

    val activeActivity = activities.firstOrNull { it.status == ActivityStatus.IN_PROGRESS }
        ?: activities.firstOrNull { it.status == ActivityStatus.SCHEDULED }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(MaterialTheme.colorScheme.background)
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 14.dp, vertical = 4.dp)
        ) {
            // Welcome & Staff Identity Header
            Surface(
                color = MaterialTheme.colorScheme.surface,
                shape = RoundedCornerShape(14.dp),
                border = androidx.compose.foundation.BorderStroke(1.dp, MaterialTheme.colorScheme.outline.copy(alpha = 0.5f)),
                modifier = Modifier.fillMaxWidth()
            ) {
                Row(
                    modifier = Modifier.padding(12.dp),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Box(
                            modifier = Modifier
                                .size(44.dp)
                                .clip(CircleShape)
                                .background(Color(currentAccount.avatarColor)),
                            contentAlignment = Alignment.Center
                        ) {
                            Text(
                                text = currentAccount.fullName.split(" ").mapNotNull { it.firstOrNull()?.toString() }.take(2).joinToString(""),
                                color = Color.White,
                                fontWeight = FontWeight.Bold,
                                fontSize = 16.sp
                            )
                        }

                        Spacer(modifier = Modifier.width(10.dp))

                        Column {
                            Text(
                                text = "Welcome, ${currentAccount.fullName}",
                                style = MaterialTheme.typography.titleMedium,
                                fontWeight = FontWeight.Bold,
                                color = MaterialTheme.colorScheme.onSurface
                            )
                            Text(
                                text = "${currentAccount.role.title} • ${currentAccount.id}",
                                fontSize = 11.sp,
                                color = MaterialTheme.colorScheme.secondary,
                                fontWeight = FontWeight.SemiBold
                            )
                            Text(
                                text = currentAccount.branch,
                                fontSize = 10.sp,
                                color = MaterialTheme.colorScheme.onSurfaceVariant
                            )
                        }
                    }
                }
            }

            Spacer(modifier = Modifier.height(6.dp))

            // OVERVIEW SUB-TABS (Operations & Logs is Tab 0, Workshop is Tab 1)
            Surface(
                color = MaterialTheme.colorScheme.surface,
                shape = RoundedCornerShape(12.dp),
                border = BorderStroke(1.dp, MaterialTheme.colorScheme.outline.copy(alpha = 0.3f)),
                modifier = Modifier
                    .fillMaxWidth()
                    .testTag("overview_section_tab_bar")
            ) {
                ScrollableTabRow(
                    selectedTabIndex = selectedOverviewTab,
                    containerColor = MaterialTheme.colorScheme.surface,
                    contentColor = MaterialTheme.colorScheme.primary,
                    edgePadding = 6.dp,
                    indicator = { tabPositions ->
                        if (selectedOverviewTab < tabPositions.size) {
                            TabRowDefaults.SecondaryIndicator(
                                modifier = Modifier.tabIndicatorOffset(tabPositions[selectedOverviewTab]),
                                color = MaterialTheme.colorScheme.primary,
                                height = 3.dp
                            )
                        }
                    },
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(40.dp)
                ) {
                    overviewTabs.forEachIndexed { index, (tabTitle, icon) ->
                        val isSelected = selectedOverviewTab == index
                        Tab(
                            selected = isSelected,
                            onClick = { selectedOverviewTab = index },
                            text = {
                                Row(
                                    verticalAlignment = Alignment.CenterVertically,
                                    horizontalArrangement = Arrangement.spacedBy(4.dp)
                                ) {
                                    Icon(
                                        imageVector = icon,
                                        contentDescription = null,
                                        modifier = Modifier.size(13.dp),
                                        tint = if (isSelected) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.onSurfaceVariant
                                    )
                                    Text(
                                        text = tabTitle,
                                        fontSize = 11.sp,
                                        fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Normal,
                                        color = if (isSelected) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.onSurfaceVariant,
                                        maxLines = 1,
                                        softWrap = false,
                                        overflow = TextOverflow.Ellipsis
                                    )
                                }
                            },
                            modifier = Modifier.testTag("overview_subtab_$index")
                        )
                    }
                }
            }
        }

        if (selectedOverviewTab == 0) {
            StaffOperationsDashboardScreen(
                currentAccount = currentAccount,
                activities = activities,
                onUpdateActivityStatus = onUpdateActivityStatus,
                onToggleChecklistItem = onToggleChecklistItem,
                onOpenRealtimeLogger = onOpenRealtimeLogger,
                onLogActivity = onLogActivity,
                onNavigateTab = onNavigateTab,
                onOpenPriceEditor = onOpenPriceEditor,
                onOpenStockUpload = onOpenStockUpload,
                onOpenUniversalExcelImport = onOpenUniversalExcelImport,
                onOpenExportManifest = onOpenExportManifest,
                burialSchedules = burialSchedules,
                workshopItems = workshopItems,
                fleetVehicles = fleetVehicles,
                allActivities = allActivities,
                allStaffAccounts = allStaffAccounts,
                onDispatchTaskAlert = onDispatchTaskAlert,
                modifier = Modifier.weight(1f)
            )
        } else {
            LazyColumn(
                modifier = Modifier
                    .weight(1f)
                    .padding(horizontal = 16.dp),
                verticalArrangement = Arrangement.spacedBy(16.dp)
            ) {
                // THE WORKSHOP TAB CONTENT: WORKSHOP OPERATIONS & STOCK
                if (selectedOverviewTab == 1 || selectedOverviewTab == 4) {
                    item {
                        TheWorkshopOverviewSection(
                            workshopItems = workshopItems,
                            craftsmenList = craftsmenList,
                            inventoryMaterials = inventoryMaterials,
                            casketStockByBranch = casketStockByBranch,
                            onOpenLiveWorkshop = onOpenLiveWorkshop,
                            onOpenInventory = onOpenInventory,
                            onNavigateTab = onNavigateTab
                        )
                    }
                }

                // WALLET HERO CARD
                if (selectedOverviewTab == 3 || selectedOverviewTab == 4) {
            item {
                Card(
                shape = RoundedCornerShape(18.dp),
                colors = CardDefaults.cardColors(containerColor = Color.Transparent),
                modifier = Modifier
                    .fillMaxWidth()
                    .testTag("overview_wallet_card")
            ) {
                Box(
                    modifier = Modifier
                        .fillMaxWidth()
                        .background(
                            brush = Brush.linearGradient(
                                colors = listOf(Navy900, Color(0xFF14426B), ForestGreenDark)
                            )
                        )
                        .padding(20.dp)
                ) {
                    Column {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Icon(
                                    imageVector = Icons.Default.AccountBalanceWallet,
                                    contentDescription = null,
                                    tint = CyanLight,
                                    modifier = Modifier.size(20.dp)
                                )
                                Spacer(modifier = Modifier.width(8.dp))
                                Text(
                                    text = "STAFF WALLET BALANCE",
                                    color = Color(0xFF93C5FD),
                                    fontSize = 11.sp,
                                    fontWeight = FontWeight.Bold,
                                    letterSpacing = 1.sp
                                )
                            }

                            Text(
                                text = "KES Currency",
                                color = Color(0xFFBFDBFE),
                                fontSize = 10.sp
                            )
                        }

                        Spacer(modifier = Modifier.height(10.dp))

                        Text(
                            text = "KES ${String.format("%,.2f", walletSummary.availableBalance)}",
                            fontSize = 30.sp,
                            fontWeight = FontWeight.ExtraBold,
                            color = Color.White
                        )

                        Spacer(modifier = Modifier.height(14.dp))

                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween
                        ) {
                            Column {
                                Text(text = "Total Earned", color = Color(0xFF93C5FD), fontSize = 10.sp)
                                Text(
                                    text = "KES ${String.format("%,.0f", walletSummary.totalEarned)}",
                                    color = EmeraldLight,
                                    fontWeight = FontWeight.Bold,
                                    fontSize = 13.sp
                                )
                            }

                            Column {
                                Text(text = "Pending Payout", color = Color(0xFF93C5FD), fontSize = 10.sp)
                                Text(
                                    text = "KES ${String.format("%,.0f", walletSummary.pendingPayouts)}",
                                    color = AmberLight,
                                    fontWeight = FontWeight.Bold,
                                    fontSize = 13.sp
                                )
                            }

                            Column {
                                Text(text = "Withdrawn", color = Color(0xFF93C5FD), fontSize = 10.sp)
                                Text(
                                    text = "KES ${String.format("%,.0f", walletSummary.totalWithdrawn)}",
                                    color = Color.White,
                                    fontWeight = FontWeight.Bold,
                                    fontSize = 13.sp
                                )
                            }
                        }

                        Spacer(modifier = Modifier.height(16.dp))

                        // Wallet Quick Action Buttons
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.spacedBy(10.dp)
                        ) {
                            Button(
                                onClick = onRequestPayout,
                                colors = ButtonDefaults.buttonColors(
                                    containerColor = EmeraldSuccess,
                                    contentColor = Color.White
                                ),
                                shape = RoundedCornerShape(10.dp),
                                modifier = Modifier
                                    .weight(1f)
                                    .height(40.dp)
                                    .testTag("wallet_request_payout_button")
                            ) {
                                Icon(imageVector = Icons.AutoMirrored.Filled.Send, contentDescription = null, modifier = Modifier.size(16.dp))
                                Spacer(modifier = Modifier.width(6.dp))
                                Text("Request Payout", fontSize = 13.sp, fontWeight = FontWeight.Bold)
                            }

                            Button(
                                onClick = { onNavigateTab(NavTab.WALLET) },
                                colors = ButtonDefaults.buttonColors(
                                    containerColor = Color.White.copy(alpha = 0.2f),
                                    contentColor = Color.White
                                ),
                                shape = RoundedCornerShape(10.dp),
                                modifier = Modifier
                                    .weight(1f)
                                    .height(40.dp)
                                    .testTag("overview_view_wallet_button")
                                    .testTag("overview_staff_payment_wallet_button")
                            ) {
                                Icon(imageVector = Icons.Default.ReceiptLong, contentDescription = null, modifier = Modifier.size(16.dp))
                                Spacer(modifier = Modifier.width(6.dp))
                                Text("Payment Wallet", fontSize = 13.sp, fontWeight = FontWeight.Bold)
                            }
                        }
                    }
                }
            }
        }
        }

        // =========================================================================
        // DASHBOARD DAILY METRICS & STOCK BY BRANCH (TAB: FINANCIALS & KPIS)
        // =========================================================================
        if (selectedOverviewTab == 2 || selectedOverviewTab == 4) {
            item {
                Card(
                shape = RoundedCornerShape(16.dp),
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                border = BorderStroke(1.dp, MaterialTheme.colorScheme.outline.copy(alpha = 0.4f)),
                modifier = Modifier
                    .fillMaxWidth()
                    .testTag("dashboard_daily_metrics_card")
            ) {
                Column(modifier = Modifier.padding(16.dp)) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Box(
                                modifier = Modifier
                                    .size(34.dp)
                                    .clip(CircleShape)
                                    .background(MaterialTheme.colorScheme.secondaryContainer),
                                contentAlignment = Alignment.Center
                            ) {
                                Icon(Icons.Default.TrendingUp, contentDescription = null, tint = MaterialTheme.colorScheme.secondary, modifier = Modifier.size(18.dp))
                            }
                            Spacer(modifier = Modifier.width(8.dp))
                            Column {
                                Text(
                                    text = "Daily Operations & Financial Overview",
                                    fontWeight = FontWeight.Bold,
                                    fontSize = 14.sp,
                                    color = MaterialTheme.colorScheme.onSurface
                                )
                                Text(
                                    text = "Live daily counters across production, sales & payments",
                                    fontSize = 10.sp,
                                    color = MaterialTheme.colorScheme.onSurfaceVariant
                                )
                            }
                        }

                        Surface(
                            shape = RoundedCornerShape(12.dp),
                            color = MaterialTheme.colorScheme.primaryContainer
                        ) {
                            Text(
                                text = "Today's Ledger",
                                fontSize = 10.sp,
                                fontWeight = FontWeight.Bold,
                                color = MaterialTheme.colorScheme.onPrimaryContainer,
                                modifier = Modifier.padding(horizontal = 8.dp, vertical = 3.dp)
                            )
                        }
                    }

                    Spacer(modifier = Modifier.height(14.dp))

                    // Row 1: Materials, Finished, In-Production
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        KpiCounterTile(
                            title = "Material Costs",
                            value = "KES ${String.format("%,.0f", dailyKpis.totalMaterialCostsToday)}",
                            sub = "Costs for the day",
                            color = com.example.ui.theme.StrokeRed,
                            bgColor = com.example.ui.theme.StrokeRedLight,
                            modifier = Modifier.weight(1f)
                        )
                        KpiCounterTile(
                            title = "Finished Products",
                            value = "${dailyKpis.finishedProductsToday} Caskets",
                            sub = "Done for the day",
                            color = EmeraldSuccess,
                            bgColor = EmeraldLight,
                            modifier = Modifier.weight(1f)
                        )
                        KpiCounterTile(
                            title = "In Production",
                            value = "${dailyKpis.productsInProduction} Items",
                            sub = "Active in workshop",
                            color = Color(0xFF2563EB),
                            bgColor = Color(0xFFEFF6FF),
                            modifier = Modifier.weight(1f)
                        )
                    }

                    Spacer(modifier = Modifier.height(8.dp))

                    // Row 2: Sales, Staff Earnings, Payments
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        KpiCounterTile(
                            title = "Total Sales",
                            value = "KES ${String.format("%,.0f", dailyKpis.totalSalesToday)}",
                            sub = "Sales for the day",
                            color = RoyalCobaltBlue,
                            bgColor = RoyalCobaltIce,
                            modifier = Modifier.weight(1f)
                        )
                        KpiCounterTile(
                            title = "Staff Earnings",
                            value = "KES ${String.format("%,.0f", dailyKpis.totalStaffEarnings)}",
                            sub = "Total staff earnings",
                            color = Color(0xFFD97706),
                            bgColor = Color(0xFFFEF3C7),
                            modifier = Modifier.weight(1f)
                        )
                        KpiCounterTile(
                            title = "Total Payments",
                            value = "KES ${String.format("%,.0f", dailyKpis.totalPaymentsToday)}",
                            sub = "Payments for the day",
                            color = Color(0xFF0D9488),
                            bgColor = Color(0xFFCCFBF1),
                            modifier = Modifier.weight(1f)
                        )
                    }
                }
            }
        }

        if (selectedOverviewTab == 2) {
            item {
                ManagerialOversightDashboardCard(
                    staffAccounts = allStaffAccounts.ifEmpty { listOf(currentAccount) },
                    activities = allActivities,
                    onUpdateActivityStatus = onUpdateActivityStatus,
                    onDispatchTaskAlert = onDispatchTaskAlert,
                    onOpenTasksTimeline = { onNavigateTab(NavTab.ACTIVITIES) }
                )
            }
        }

        // =========================================================================
        // LIVE OPERATIONS QUICK LAUNCH BAR
        // =========================================================================
        item {
            Card(
                shape = RoundedCornerShape(14.dp),
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                border = BorderStroke(1.dp, MaterialTheme.colorScheme.outline.copy(alpha = 0.4f)),
                modifier = Modifier
                    .fillMaxWidth()
                    .testTag("live_operations_quick_launch_card")
            ) {
                Column(modifier = Modifier.padding(14.dp)) {
                    Text(
                        text = "Operations Portals",
                        fontWeight = FontWeight.Bold,
                        fontSize = 13.sp,
                        color = Navy900
                    )
                    Spacer(modifier = Modifier.height(8.dp))
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        Button(
                            onClick = {
                                onOpenLiveWorkshop()
                                onNavigateTab(NavTab.WORKSHOP_PRODUCTION)
                            },
                            colors = ButtonDefaults.buttonColors(containerColor = RoyalCobaltBlue),
                            shape = RoundedCornerShape(8.dp),
                            contentPadding = PaddingValues(horizontal = 6.dp, vertical = 4.dp),
                            modifier = Modifier.weight(1f).height(36.dp).testTag("overview_btn_workshop")
                        ) {
                            Icon(Icons.Default.PrecisionManufacturing, contentDescription = null, modifier = Modifier.size(13.dp))
                            Spacer(modifier = Modifier.width(3.dp))
                            Text("Workshop", fontSize = 10.sp, fontWeight = FontWeight.Bold)
                        }

                        Button(
                            onClick = {
                                onOpenInventory()
                                onNavigateTab(NavTab.INVENTORY_MANAGEMENT)
                            },
                            colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF0D9488)),
                            shape = RoundedCornerShape(8.dp),
                            contentPadding = PaddingValues(horizontal = 6.dp, vertical = 4.dp),
                            modifier = Modifier.weight(1f).height(36.dp).testTag("overview_btn_inventory")
                        ) {
                            Icon(Icons.Default.Inventory, contentDescription = null, modifier = Modifier.size(13.dp))
                            Spacer(modifier = Modifier.width(3.dp))
                            Text("Inventory", fontSize = 10.sp, fontWeight = FontWeight.Bold)
                        }

                        Button(
                            onClick = {
                                onOpenBurialScheduler()
                                onNavigateTab(NavTab.BURIAL_SCHEDULING)
                            },
                            colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF7C3AED)),
                            shape = RoundedCornerShape(8.dp),
                            contentPadding = PaddingValues(horizontal = 6.dp, vertical = 4.dp),
                            modifier = Modifier.weight(1f).height(36.dp).testTag("overview_btn_burial_scheduler")
                        ) {
                            Icon(Icons.Default.CalendarMonth, contentDescription = null, modifier = Modifier.size(13.dp))
                            Spacer(modifier = Modifier.width(3.dp))
                            Text("Scheduler", fontSize = 10.sp, fontWeight = FontWeight.Bold)
                        }

                        Button(
                            onClick = {
                                onOpenDailyReport()
                                onNavigateTab(NavTab.DAILY_REPORT)
                            },
                            colors = ButtonDefaults.buttonColors(containerColor = EmeraldSuccess),
                            shape = RoundedCornerShape(8.dp),
                            contentPadding = PaddingValues(horizontal = 6.dp, vertical = 4.dp),
                            modifier = Modifier.weight(1f).height(36.dp).testTag("overview_btn_daily_report")
                        ) {
                            Icon(Icons.Default.EventNote, contentDescription = null, modifier = Modifier.size(13.dp))
                            Spacer(modifier = Modifier.width(3.dp))
                            Text("Daily Log", fontSize = 10.sp, fontWeight = FontWeight.Bold, maxLines = 1, softWrap = false)
                        }
                    }

                    Spacer(modifier = Modifier.height(6.dp))

                    OutlinedButton(
                        onClick = { onNavigateTab(NavTab.COSTINGS_PRICING) },
                        shape = RoundedCornerShape(8.dp),
                        contentPadding = PaddingValues(horizontal = 10.dp, vertical = 4.dp),
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(34.dp)
                            .testTag("overview_btn_costings_bom")
                    ) {
                        Icon(Icons.Default.PrecisionManufacturing, contentDescription = "Costings & BOM", tint = RoyalCobaltBlue, modifier = Modifier.size(14.dp))
                        Spacer(modifier = Modifier.width(6.dp))
                        Text(
                            text = "Open Production Costings, Material BOM & Order Price Guide",
                            fontSize = 11.sp,
                            fontWeight = FontWeight.Bold,
                            color = RoyalCobaltBlue,
                            maxLines = 1,
                            softWrap = false,
                            overflow = TextOverflow.Ellipsis
                        )
                    }

                    Spacer(modifier = Modifier.height(6.dp))

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(6.dp)
                    ) {
                        OutlinedButton(
                            onClick = onOpenOrderDashboard,
                            shape = RoundedCornerShape(8.dp),
                            contentPadding = PaddingValues(horizontal = 8.dp, vertical = 4.dp),
                            modifier = Modifier
                                .weight(1f)
                                .height(34.dp)
                                .testTag("overview_btn_order_dashboard")
                        ) {
                            Icon(Icons.Default.ReceiptLong, contentDescription = null, tint = EmeraldSuccess, modifier = Modifier.size(14.dp))
                            Spacer(modifier = Modifier.width(4.dp))
                            Text(
                                text = "Order Dashboard",
                                fontSize = 10.sp,
                                fontWeight = FontWeight.Bold,
                                color = Navy900,
                                maxLines = 1,
                                softWrap = false,
                                overflow = TextOverflow.Ellipsis
                            )
                        }
                        OutlinedButton(
                            onClick = onOpenCostAnalytics,
                            shape = RoundedCornerShape(8.dp),
                            contentPadding = PaddingValues(horizontal = 8.dp, vertical = 4.dp),
                            modifier = Modifier
                                .weight(1f)
                                .height(34.dp)
                                .testTag("overview_btn_cost_analytics")
                        ) {
                            Icon(Icons.Default.TrendingUp, contentDescription = null, tint = RoyalCobaltBlue, modifier = Modifier.size(14.dp))
                            Spacer(modifier = Modifier.width(4.dp))
                            Text(
                                text = "Cost Analytics",
                                fontSize = 10.sp,
                                fontWeight = FontWeight.Bold,
                                color = Navy900,
                                maxLines = 1,
                                softWrap = false,
                                overflow = TextOverflow.Ellipsis
                            )
                        }
                    }
                }
            }
        }

        // =========================================================================
        // STOCK BY BRANCH SECTION (TABULATED: 16 PRODUCTS VERTICAL, BRANCHES HORIZONTAL)
        // Products: Dragon, Dumu Mayai, English Coffin, Executive, Giraffe Flat,
        // Half Glass, Half Glass Dome, Kids, Kupa, Mini Executive, Modern High Roof,
        // Reagan, Saitoti, Simple, Tonny, VIP
        // =========================================================================
        item {
            Card(
                shape = RoundedCornerShape(16.dp),
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                border = BorderStroke(1.dp, MaterialTheme.colorScheme.outline.copy(alpha = 0.4f)),
                modifier = Modifier
                    .fillMaxWidth()
                    .testTag("stock_by_branch_card")
            ) {
                Column(modifier = Modifier.padding(16.dp)) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Column {
                            Text(
                                text = "Stock By Branch (16 Casket Types)",
                                fontWeight = FontWeight.Bold,
                                fontSize = 15.sp,
                                color = Navy900
                            )
                            Text(
                                text = "Products vertically aligned • Branches tabulated horizontally",
                                fontSize = 11.sp,
                                color = TextSecondary
                            )
                        }

                        Surface(
                            shape = RoundedCornerShape(10.dp),
                            color = RoyalCobaltIce
                        ) {
                            Text(
                                text = "Tabulated Live Matrix",
                                fontSize = 10.sp,
                                fontWeight = FontWeight.Bold,
                                color = RoyalCobaltBlue,
                                modifier = Modifier.padding(horizontal = 8.dp, vertical = 3.dp)
                            )
                        }
                    }

                    Spacer(modifier = Modifier.height(12.dp))

                    // Horizontal Scrollable Data Table
                    val horizontalScroll = rememberScrollState()
                    val branches = JABIMA_BRANCHES

                    Box(
                        modifier = Modifier
                            .fillMaxWidth()
                            .clip(RoundedCornerShape(8.dp))
                            .border(1.dp, Color(0xFFCBD5E1), RoundedCornerShape(8.dp))
                    ) {
                        Column(
                            modifier = Modifier
                                .horizontalScroll(horizontalScroll)
                                .background(MaterialTheme.colorScheme.surface)
                        ) {
                            // TABLE HEADER
                            Row(
                                modifier = Modifier
                                    .background(Color(0xFF0F172A))
                                    .padding(vertical = 10.dp),
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Text(
                                    text = "CASKET TYPE",
                                    color = Color.White,
                                    fontSize = 11.sp,
                                    fontWeight = FontWeight.Bold,
                                    modifier = Modifier
                                        .width(140.dp)
                                        .padding(start = 12.dp)
                                )

                                branches.forEach { branch ->
                                    val shortBranch = when (branch) {
                                        "Siaya opposite Shell Petrol" -> "Siaya Shell"
                                        "Siaya Referral (Opposite Morgue)" -> "Siaya Referral"
                                        else -> branch
                                    }
                                    Text(
                                        text = shortBranch.uppercase(),
                                        color = Color(0xFF93C5FD),
                                        fontSize = 10.sp,
                                        fontWeight = FontWeight.Bold,
                                        modifier = Modifier
                                            .width(90.dp)
                                            .padding(horizontal = 6.dp)
                                    )
                                }

                                Text(
                                    text = "TOTAL STOCK",
                                    color = EmeraldLight,
                                    fontSize = 10.sp,
                                    fontWeight = FontWeight.ExtraBold,
                                    modifier = Modifier
                                        .width(95.dp)
                                        .padding(horizontal = 8.dp)
                                )
                            }

                            // 16 CASKET TYPES (VERTICAL ROWS)
                            val tableRows = if (casketStockByBranch.isNotEmpty()) casketStockByBranch else {
                                listOf(
                                    CasketStockByBranchRow("Dragon", mapOf("Bama Branch" to 8, "Bondo" to 3, "Matibabu" to 2, "Siaya opposite Shell Petrol" to 4, "Ukwala" to 1, "Uradi" to 2, "Siaya Referral (Opposite Morgue)" to 5, "Rangala" to 1), 65000.0),
                                    CasketStockByBranchRow("Dumu Mayai", mapOf("Bama Branch" to 6, "Bondo" to 2, "Matibabu" to 1, "Siaya opposite Shell Petrol" to 3, "Ukwala" to 1, "Uradi" to 1, "Siaya Referral (Opposite Morgue)" to 4, "Rangala" to 2), 55000.0),
                                    CasketStockByBranchRow("English Coffin", mapOf("Bama Branch" to 10, "Bondo" to 4, "Matibabu" to 3, "Siaya opposite Shell Petrol" to 5, "Ukwala" to 2, "Uradi" to 3, "Siaya Referral (Opposite Morgue)" to 6, "Rangala" to 2), 48000.0),
                                    CasketStockByBranchRow("Executive", mapOf("Bama Branch" to 12, "Bondo" to 5, "Matibabu" to 4, "Siaya opposite Shell Petrol" to 6, "Ukwala" to 3, "Uradi" to 2, "Siaya Referral (Opposite Morgue)" to 7, "Rangala" to 3), 110000.0),
                                    CasketStockByBranchRow("Giraffe Flat", mapOf("Bama Branch" to 5, "Bondo" to 2, "Matibabu" to 1, "Siaya opposite Shell Petrol" to 2, "Ukwala" to 1, "Uradi" to 1, "Siaya Referral (Opposite Morgue)" to 3, "Rangala" to 1), 58000.0),
                                    CasketStockByBranchRow("Half Glass", mapOf("Bama Branch" to 9, "Bondo" to 4, "Matibabu" to 2, "Siaya opposite Shell Petrol" to 5, "Ukwala" to 2, "Uradi" to 2, "Siaya Referral (Opposite Morgue)" to 6, "Rangala" to 2), 75000.0),
                                    CasketStockByBranchRow("Half Glass Dome", mapOf("Bama Branch" to 8, "Bondo" to 3, "Matibabu" to 3, "Siaya opposite Shell Petrol" to 4, "Ukwala" to 2, "Uradi" to 1, "Siaya Referral (Opposite Morgue)" to 5, "Rangala" to 2), 85000.0),
                                    CasketStockByBranchRow("Kids", mapOf("Bama Branch" to 7, "Bondo" to 2, "Matibabu" to 2, "Siaya opposite Shell Petrol" to 3, "Ukwala" to 1, "Uradi" to 1, "Siaya Referral (Opposite Morgue)" to 4, "Rangala" to 1), 30000.0),
                                    CasketStockByBranchRow("Kupa", mapOf("Bama Branch" to 6, "Bondo" to 2, "Matibabu" to 1, "Siaya opposite Shell Petrol" to 3, "Ukwala" to 1, "Uradi" to 2, "Siaya Referral (Opposite Morgue)" to 3, "Rangala" to 1), 52000.0),
                                    CasketStockByBranchRow("Mini Executive", mapOf("Bama Branch" to 8, "Bondo" to 3, "Matibabu" to 2, "Siaya opposite Shell Petrol" to 4, "Ukwala" to 2, "Uradi" to 1, "Siaya Referral (Opposite Morgue)" to 5, "Rangala" to 2), 88000.0),
                                    CasketStockByBranchRow("Modern High Roof", mapOf("Bama Branch" to 11, "Bondo" to 4, "Matibabu" to 3, "Siaya opposite Shell Petrol" to 6, "Ukwala" to 2, "Uradi" to 3, "Siaya Referral (Opposite Morgue)" to 7, "Rangala" to 3), 125000.0),
                                    CasketStockByBranchRow("Reagan", mapOf("Bama Branch" to 7, "Bondo" to 3, "Matibabu" to 2, "Siaya opposite Shell Petrol" to 4, "Ukwala" to 1, "Uradi" to 2, "Siaya Referral (Opposite Morgue)" to 4, "Rangala" to 2), 95000.0),
                                    CasketStockByBranchRow("Saitoti", mapOf("Bama Branch" to 9, "Bondo" to 3, "Matibabu" to 2, "Siaya opposite Shell Petrol" to 4, "Ukwala" to 2, "Uradi" to 2, "Siaya Referral (Opposite Morgue)" to 5, "Rangala" to 2), 105000.0),
                                    CasketStockByBranchRow("Simple", mapOf("Bama Branch" to 14, "Bondo" to 6, "Matibabu" to 5, "Siaya opposite Shell Petrol" to 8, "Ukwala" to 4, "Uradi" to 4, "Siaya Referral (Opposite Morgue)" to 9, "Rangala" to 5), 25000.0),
                                    CasketStockByBranchRow("Tonny", mapOf("Bama Branch" to 6, "Bondo" to 2, "Matibabu" to 1, "Siaya opposite Shell Petrol" to 3, "Ukwala" to 1, "Uradi" to 1, "Siaya Referral (Opposite Morgue)" to 4, "Rangala" to 1), 60000.0),
                                    CasketStockByBranchRow("VIP", mapOf("Bama Branch" to 10, "Bondo" to 4, "Matibabu" to 3, "Siaya opposite Shell Petrol" to 5, "Ukwala" to 2, "Uradi" to 2, "Siaya Referral (Opposite Morgue)" to 6, "Rangala" to 3), 140000.0)
                                )
                            }

                            tableRows.forEachIndexed { index, row ->
                                val rowBg = if (index % 2 == 0) MaterialTheme.colorScheme.surface else MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.35f)
                                Row(
                                    modifier = Modifier
                                        .background(rowBg)
                                        .padding(vertical = 8.dp),
                                    verticalAlignment = Alignment.CenterVertically
                                ) {
                                    Text(
                                        text = row.casketType,
                                        fontWeight = FontWeight.Bold,
                                        fontSize = 12.sp,
                                        color = Navy900,
                                        modifier = Modifier
                                            .width(140.dp)
                                            .padding(start = 12.dp)
                                    )

                                    branches.forEach { branch ->
                                        val qty = row.branchStockMap[branch] ?: 0
                                        Text(
                                            text = "$qty",
                                            fontWeight = if (qty > 3) FontWeight.SemiBold else FontWeight.Normal,
                                            fontSize = 12.sp,
                                            color = if (qty <= 1) AmberWarning else Navy900,
                                            modifier = Modifier
                                                .width(90.dp)
                                                .padding(horizontal = 6.dp)
                                        )
                                    }

                                    Surface(
                                        shape = RoundedCornerShape(6.dp),
                                        color = if (row.totalStock >= 10) EmeraldLight else AmberLight,
                                        modifier = Modifier
                                            .width(85.dp)
                                            .padding(horizontal = 4.dp)
                                    ) {
                                        Text(
                                            text = "${row.totalStock} units",
                                            fontSize = 11.sp,
                                            fontWeight = FontWeight.ExtraBold,
                                            color = if (row.totalStock >= 10) EmeraldSuccess else AmberWarning,
                                            modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp)
                                        )
                                    }
                                }
                            }

                            // SUMMARY FOOTER ROW
                            Row(
                                modifier = Modifier
                                    .background(Color(0xFFE2E8F0))
                                    .padding(vertical = 10.dp),
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Text(
                                    text = "BRANCH TOTALS",
                                    color = Navy900,
                                    fontSize = 11.sp,
                                    fontWeight = FontWeight.ExtraBold,
                                    modifier = Modifier
                                        .width(140.dp)
                                        .padding(start = 12.dp)
                                )

                                val grandTotal = tableRows.sumOf { it.totalStock }
                                branches.forEach { branch ->
                                    val branchTotal = tableRows.sumOf { it.branchStockMap[branch] ?: 0 }
                                    Text(
                                        text = "$branchTotal",
                                        color = RoyalCobaltBlue,
                                        fontSize = 11.sp,
                                        fontWeight = FontWeight.ExtraBold,
                                        modifier = Modifier
                                            .width(90.dp)
                                            .padding(horizontal = 6.dp)
                                    )
                                }

                                Text(
                                    text = "$grandTotal",
                                    color = EmeraldSuccess,
                                    fontSize = 12.sp,
                                    fontWeight = FontWeight.ExtraBold,
                                    modifier = Modifier
                                        .width(95.dp)
                                        .padding(horizontal = 8.dp)
                                )
                            }
                        }
                    }
                }
            }
        }
        }

        // =========================================================================
        // STAFF DUTIES & WALLET DETAILS (TAB: STAFF WALLET & DUTIES)
        // =========================================================================
        if (selectedOverviewTab == 3 || selectedOverviewTab == 4) {
            // QUICK STATS COUNTERS (Duties in progress, scheduled, completed)
            item {
                Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                StatCard(
                    title = "In Progress",
                    count = "$inProgressCount",
                    sub = "Active duties",
                    color = AmberWarning,
                    bgColor = AmberLight,
                    modifier = Modifier.weight(1f)
                )

                StatCard(
                    title = "Scheduled",
                    count = "$scheduledCount",
                    sub = "Upcoming",
                    color = CyanPrimary,
                    bgColor = CyanContainer,
                    modifier = Modifier.weight(1f)
                )

                StatCard(
                    title = "Completed",
                    count = "$completedCount",
                    sub = "Logged tasks",
                    color = EmeraldSuccess,
                    bgColor = EmeraldLight,
                    modifier = Modifier.weight(1f)
                )
            }
        }

        // QUICK ROSTER VIEW SHORTCUT
        item {
            Surface(
                color = Color(0xFFF8FAFC),
                shape = RoundedCornerShape(12.dp),
                border = androidx.compose.foundation.BorderStroke(1.dp, Color(0xFFE2E8F0)),
                modifier = Modifier.fillMaxWidth()
            ) {
                Row(
                    modifier = Modifier.padding(12.dp),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    Row(verticalAlignment = Alignment.CenterVertically, modifier = Modifier.weight(1f)) {
                        Box(
                            modifier = Modifier
                                .size(36.dp)
                                .clip(CircleShape)
                                .background(CyanPrimary),
                            contentAlignment = Alignment.Center
                        ) {
                            Icon(
                                imageVector = Icons.Default.CalendarMonth,
                                contentDescription = null,
                                tint = Color.White,
                                modifier = Modifier.size(20.dp)
                            )
                        }
                        Spacer(modifier = Modifier.width(10.dp))
                        Column {
                            Text(
                                text = "Weekly Staff Duty Roster",
                                fontWeight = FontWeight.Bold,
                                fontSize = 13.sp,
                                color = Navy900
                            )
                            Text(
                                text = "View shift calendar, cortege times & hearse allocation",
                                fontSize = 10.sp,
                                color = Color(0xFF64748B)
                            )
                        }
                    }
                    Button(
                        onClick = { onNavigateTab(NavTab.ROSTER) },
                        colors = ButtonDefaults.buttonColors(containerColor = CyanPrimary),
                        shape = RoundedCornerShape(8.dp),
                        contentPadding = PaddingValues(horizontal = 10.dp, vertical = 4.dp),
                        modifier = Modifier
                            .height(34.dp)
                            .testTag("overview_open_roster_button")
                    ) {
                        Text("View Roster", fontSize = 11.sp, fontWeight = FontWeight.Bold)
                    }
                }
            }
        }

        // ACTIVE / NEXT ASSIGNMENT CARD
        item {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(
                    text = "Current Assignment",
                    style = MaterialTheme.typography.titleMedium,
                    fontWeight = FontWeight.Bold
                )

                Text(
                    text = "View All",
                    fontSize = 12.sp,
                    color = CyanPrimary,
                    fontWeight = FontWeight.Bold,
                    modifier = Modifier.clickable { onNavigateTab(NavTab.ACTIVITIES) }
                )
            }

            Spacer(modifier = Modifier.height(6.dp))

            if (activeActivity != null) {
                Card(
                    shape = RoundedCornerShape(14.dp),
                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                    border = androidx.compose.foundation.BorderStroke(1.dp, MaterialTheme.colorScheme.outline.copy(alpha = 0.5f)),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Column(modifier = Modifier.padding(16.dp)) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Surface(
                                color = if (activeActivity.status == ActivityStatus.IN_PROGRESS) AmberLight else CyanContainer,
                                shape = RoundedCornerShape(6.dp)
                            ) {
                                Text(
                                    text = activeActivity.status.label,
                                    color = if (activeActivity.status == ActivityStatus.IN_PROGRESS) AmberWarning else CyanDark,
                                    fontSize = 11.sp,
                                    fontWeight = FontWeight.Bold,
                                    modifier = Modifier.padding(horizontal = 8.dp, vertical = 2.dp)
                                )
                            }

                            Text(
                                text = "+ KES ${String.format("%,.0f", activeActivity.allowanceEarned)}",
                                fontWeight = FontWeight.ExtraBold,
                                fontSize = 13.sp,
                                color = EmeraldSuccess
                            )
                        }

                        Spacer(modifier = Modifier.height(8.dp))

                        Text(
                            text = activeActivity.title,
                            style = MaterialTheme.typography.titleMedium,
                            fontWeight = FontWeight.Bold
                        )

                        Text(
                            text = "${activeActivity.caseReference} • ${activeActivity.clientFamily}",
                            fontSize = 12.sp,
                            color = CyanPrimary,
                            fontWeight = FontWeight.SemiBold
                        )

                        Spacer(modifier = Modifier.height(8.dp))

                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Icon(Icons.Default.LocationOn, contentDescription = null, tint = MaterialTheme.colorScheme.onSurfaceVariant, modifier = Modifier.size(14.dp))
                            Spacer(modifier = Modifier.width(4.dp))
                            Text(text = activeActivity.location, fontSize = 12.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
                        }

                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Icon(Icons.Default.Schedule, contentDescription = null, tint = MaterialTheme.colorScheme.onSurfaceVariant, modifier = Modifier.size(14.dp))
                            Spacer(modifier = Modifier.width(4.dp))
                            Text(text = "${activeActivity.date}, ${activeActivity.time} (${activeActivity.durationMinutes} min)", fontSize = 12.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
                        }

                        if (activeActivity.notes.isNotBlank()) {
                            Spacer(modifier = Modifier.height(8.dp))
                            Text(
                                text = "Notes: ${activeActivity.notes}",
                                fontSize = 11.sp,
                                color = MaterialTheme.colorScheme.onSurfaceVariant,
                                maxLines = 2
                            )
                        }

                        Spacer(modifier = Modifier.height(14.dp))

                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.End
                        ) {
                            if (activeActivity.status == ActivityStatus.SCHEDULED) {
                                Button(
                                    onClick = { onUpdateActivityStatus(activeActivity.id, ActivityStatus.IN_PROGRESS) },
                                    colors = ButtonDefaults.buttonColors(containerColor = CyanPrimary),
                                    shape = RoundedCornerShape(8.dp),
                                    modifier = Modifier.height(36.dp)
                                ) {
                                    Icon(Icons.Default.PlayArrow, contentDescription = null, modifier = Modifier.size(16.dp))
                                    Spacer(modifier = Modifier.width(4.dp))
                                    Text("Start Task", fontSize = 12.sp)
                                }
                            } else if (activeActivity.status == ActivityStatus.IN_PROGRESS) {
                                Button(
                                    onClick = { onUpdateActivityStatus(activeActivity.id, ActivityStatus.COMPLETED) },
                                    colors = ButtonDefaults.buttonColors(containerColor = EmeraldSuccess),
                                    shape = RoundedCornerShape(8.dp),
                                    modifier = Modifier.height(36.dp)
                                ) {
                                    Icon(Icons.Default.CheckCircle, contentDescription = null, modifier = Modifier.size(16.dp))
                                    Spacer(modifier = Modifier.width(4.dp))
                                    Text("Mark Complete (+KES ${String.format("%,.0f", activeActivity.allowanceEarned)})", fontSize = 12.sp)
                                }
                            }
                        }
                    }
                }
            } else {
                Surface(
                    color = MaterialTheme.colorScheme.surfaceVariant,
                    shape = RoundedCornerShape(12.dp),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Column(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(20.dp),
                        horizontalAlignment = Alignment.CenterHorizontally
                    ) {
                        Text("No active tasks right now", fontWeight = FontWeight.Bold, fontSize = 13.sp)
                        Text("All assignments for today have been completed", fontSize = 11.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
                        Spacer(modifier = Modifier.height(10.dp))
                        Button(
                            onClick = onLogActivity,
                            colors = ButtonDefaults.buttonColors(containerColor = CyanPrimary),
                            shape = RoundedCornerShape(8.dp)
                        ) {
                            Icon(Icons.Default.Add, contentDescription = null)
                            Spacer(modifier = Modifier.width(4.dp))
                            Text("Log New Activity")
                        }
                    }
                }
            }
        }

        // 3CX & BULK SMS COMMUNICATIONS HUB
        item {
            Card(
                shape = RoundedCornerShape(14.dp),
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                border = androidx.compose.foundation.BorderStroke(1.dp, MaterialTheme.colorScheme.outline.copy(alpha = 0.5f)),
                modifier = Modifier
                    .fillMaxWidth()
                    .testTag("overview_comms_hub_card")
            ) {
                Column(modifier = Modifier.padding(14.dp)) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Icon(
                                Icons.Default.PhoneInTalk,
                                contentDescription = null,
                                tint = CyanPrimary,
                                modifier = Modifier.size(18.dp)
                            )
                            Spacer(modifier = Modifier.width(8.dp))
                            Text(
                                text = "Communications & Broadcast Hub",
                                fontWeight = FontWeight.Bold,
                                fontSize = 13.sp
                            )
                        }
                        Surface(
                            color = EmeraldLight,
                            shape = RoundedCornerShape(12.dp)
                        ) {
                            Text(
                                text = "3CX & SMS Online",
                                fontSize = 9.sp,
                                fontWeight = FontWeight.Bold,
                                color = EmeraldSuccess,
                                modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp)
                            )
                        }
                    }

                    Spacer(modifier = Modifier.height(10.dp))

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(10.dp)
                    ) {
                        Button(
                            onClick = { onNavigateTab(NavTab.COMMUNICATION_3CX) },
                            colors = ButtonDefaults.buttonColors(containerColor = CyanPrimary),
                            shape = RoundedCornerShape(8.dp),
                            modifier = Modifier
                                .weight(1f)
                                .height(38.dp)
                                .testTag("overview_open_3cx_button")
                        ) {
                            Icon(Icons.Default.PhoneInTalk, contentDescription = null, modifier = Modifier.size(14.dp))
                            Spacer(modifier = Modifier.width(6.dp))
                            Text("3CX Phone Portal", fontSize = 11.sp, fontWeight = FontWeight.Bold)
                        }

                        Button(
                            onClick = { onNavigateTab(NavTab.BULK_SMS) },
                            colors = ButtonDefaults.buttonColors(containerColor = EmeraldSuccess),
                            shape = RoundedCornerShape(8.dp),
                            modifier = Modifier
                                .weight(1f)
                                .height(38.dp)
                                .testTag("overview_open_bulk_sms_button")
                        ) {
                            Icon(Icons.AutoMirrored.Filled.Send, contentDescription = null, modifier = Modifier.size(14.dp))
                            Spacer(modifier = Modifier.width(6.dp))
                            Text("Bulk SMS Broadcast", fontSize = 11.sp, fontWeight = FontWeight.Bold)
                        }
                    }
                }
            }
        }

        // RECENT WALLET TRANSACTIONS PREVIEW
        item {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(
                    text = "Recent Payments & Withdrawals",
                    style = MaterialTheme.typography.titleMedium,
                    fontWeight = FontWeight.Bold
                )

                Text(
                    text = "View Ledger",
                    fontSize = 12.sp,
                    color = CyanPrimary,
                    fontWeight = FontWeight.Bold,
                    modifier = Modifier.clickable { onNavigateTab(NavTab.WALLET) }
                )
            }
        }

        if (recentTransactions.isEmpty()) {
            item {
                Surface(
                    color = MaterialTheme.colorScheme.surfaceVariant,
                    shape = RoundedCornerShape(12.dp),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Text(
                        text = "No recent transactions found.",
                        fontSize = 12.sp,
                        color = MaterialTheme.colorScheme.onSurfaceVariant,
                        modifier = Modifier.padding(16.dp)
                    )
                }
            }
        } else {
            items(recentTransactions.take(4)) { txn ->
                val isCredit = txn.amount > 0
                Surface(
                    color = MaterialTheme.colorScheme.surface,
                    shape = RoundedCornerShape(12.dp),
                    border = androidx.compose.foundation.BorderStroke(1.dp, MaterialTheme.colorScheme.outline.copy(alpha = 0.5f)),
                    modifier = Modifier
                        .fillMaxWidth()
                        .clickable { onSelectTransaction(txn) }
                ) {
                    Row(
                        modifier = Modifier.padding(14.dp),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Box(
                                modifier = Modifier
                                    .size(38.dp)
                                    .clip(CircleShape)
                                    .background(if (isCredit) EmeraldLight else AmberLight),
                                contentAlignment = Alignment.Center
                            ) {
                                Icon(
                                    imageVector = if (isCredit) Icons.Default.TrendingUp else Icons.Default.Payment,
                                    contentDescription = null,
                                    tint = if (isCredit) EmeraldSuccess else AmberWarning,
                                    modifier = Modifier.size(18.dp)
                                )
                            }

                            Spacer(modifier = Modifier.width(12.dp))

                            Column {
                                Text(
                                    text = txn.title,
                                    fontWeight = FontWeight.Bold,
                                    fontSize = 13.sp,
                                    color = MaterialTheme.colorScheme.onSurface
                                )
                                Text(
                                    text = "${txn.date} • ${txn.status.label}",
                                    fontSize = 11.sp,
                                    color = MaterialTheme.colorScheme.onSurfaceVariant
                                )
                            }
                        }

                        Column(horizontalAlignment = Alignment.End) {
                            Text(
                                text = if (isCredit) "+ KES ${String.format("%,.0f", txn.amount)}" else "- KES ${String.format("%,.0f", abs(txn.amount))}",
                                fontWeight = FontWeight.ExtraBold,
                                fontSize = 13.sp,
                                color = if (isCredit) EmeraldSuccess else com.example.ui.theme.StrokeRed
                            )
                            Text(
                                text = "View Voucher",
                                fontSize = 10.sp,
                                color = CyanPrimary,
                                fontWeight = FontWeight.SemiBold
                            )
                        }
                    }
                }
            }
        }
        }

        item {
            Surface(
                color = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.45f),
                shape = RoundedCornerShape(12.dp),
                border = BorderStroke(1.dp, MaterialTheme.colorScheme.outline.copy(alpha = 0.25f)),
                modifier = Modifier
                    .fillMaxWidth()
                    .testTag("overview_developer_clause")
            ) {
                Column(
                    modifier = Modifier.padding(horizontal = 14.dp, vertical = 12.dp),
                    horizontalAlignment = Alignment.CenterHorizontally
                ) {
                    Text(
                        text = "Jabima Funeral Staff Portal • v${BuildConfig.VERSION_NAME} (Build ${BuildConfig.VERSION_CODE})",
                        fontSize = 11.sp,
                        fontWeight = FontWeight.Bold,
                        color = MaterialTheme.colorScheme.onSurface,
                        textAlign = TextAlign.Center
                    )
                    Spacer(modifier = Modifier.height(2.dp))
                    Text(
                        text = stringResource(R.string.developer_attribution_clause),
                        fontSize = 10.5.sp,
                        color = MaterialTheme.colorScheme.onSurfaceVariant,
                        textAlign = TextAlign.Center
                    )
                }
            }
        }

        item {
            Spacer(modifier = Modifier.height(80.dp)) // Padding for bottom bar
        }
    }
    }
}
}

@Composable
private fun StatCard(
    title: String,
    count: String,
    sub: String,
    color: Color,
    bgColor: Color,
    modifier: Modifier = Modifier
) {
    Surface(
        color = bgColor,
        shape = RoundedCornerShape(12.dp),
        modifier = modifier
    ) {
        Column(modifier = Modifier.padding(12.dp)) {
            Text(text = title, fontSize = 11.sp, fontWeight = FontWeight.Medium, color = color)
            Text(text = count, fontSize = 20.sp, fontWeight = FontWeight.ExtraBold, color = color)
            Text(text = sub, fontSize = 10.sp, color = color.copy(alpha = 0.8f))
        }
    }
}

@Composable
private fun KpiCounterTile(
    title: String,
    value: String,
    sub: String,
    color: Color,
    bgColor: Color,
    modifier: Modifier = Modifier
) {
    Surface(
        color = bgColor,
        shape = RoundedCornerShape(10.dp),
        border = BorderStroke(1.dp, color.copy(alpha = 0.25f)),
        modifier = modifier
    ) {
        Column(modifier = Modifier.padding(10.dp)) {
            Text(text = title, fontSize = 10.sp, fontWeight = FontWeight.SemiBold, color = color)
            Spacer(modifier = Modifier.height(2.dp))
            Text(text = value, fontSize = 13.sp, fontWeight = FontWeight.ExtraBold, color = color)
            Spacer(modifier = Modifier.height(2.dp))
            Text(text = sub, fontSize = 9.sp, color = Navy900.copy(alpha = 0.7f))
        }
    }
}

