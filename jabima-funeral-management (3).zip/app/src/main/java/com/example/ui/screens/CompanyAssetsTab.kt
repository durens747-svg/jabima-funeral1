package com.example.ui.screens

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Build
import androidx.compose.material.icons.filled.DirectionsCar
import androidx.compose.material.icons.filled.QrCode2
import androidx.compose.material.icons.filled.QrCodeScanner
import androidx.compose.material.icons.filled.Warning
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Checkbox
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.model.CompanyAsset
import com.example.model.CustodyStatus
import com.example.ui.StaffPortalViewModel
import com.example.ui.components.BarcodeScannerDialog
import com.example.ui.components.QrCodeBadge
import com.example.ui.theme.AmberLight
import com.example.ui.theme.AmberWarning
import com.example.ui.theme.EmeraldLight
import com.example.ui.theme.EmeraldSuccess
import com.example.ui.theme.ObsidianBlack
import com.example.ui.theme.PureWhite
import com.example.ui.theme.RoseLight
import com.example.ui.theme.RoyalCobaltBlue

@Composable
fun CompanyAssetsTab(
    viewModel: StaffPortalViewModel
) {
    val assets by viewModel.companyAssets.collectAsState()
    val custodyLogs by viewModel.assetCustodyLogs.collectAsState()
    var filterCategory by remember { mutableStateOf("ALL") }
    var showQrScanner by remember { mutableStateOf(false) }
    var scannedTagForDialog by remember { mutableStateOf<String?>(null) }
    var assetForQrPreview by remember { mutableStateOf<CompanyAsset?>(null) }

    val categories = listOf("ALL", "Fleet", "Lowering Gear", "Church Trolley", "Stunchions", "Red Carpet", "Cold Room", "Workshop Machinery")

    val filteredAssets = if (filterCategory == "ALL") assets else assets.filter { it.category == filterCategory }

    if (showQrScanner) {
        val quickDemo = assets.filter {
            it.category == "Lowering Gear" || it.category == "Church Trolley" || it.category == "Stunchions" || it.category == "Red Carpet"
        }.take(4).map { it.qrTagCode to it.registrationOrTag }
        BarcodeScannerDialog(
            title = "Scan Grounds Gear / Asset QR",
            subtitle = "Scan QR label to check equipment OUT for a burial or IN back to depot.",
            quickDemoTags = quickDemo,
            onCodeScanned = { code ->
                showQrScanner = false
                scannedTagForDialog = code
            },
            onDismiss = { showQrScanner = false }
        )
    }

    scannedTagForDialog?.let { scannedCode ->
        val matched = assets.firstOrNull {
            it.qrTagCode.equals(scannedCode, ignoreCase = true) ||
                it.registrationOrTag.equals(scannedCode, ignoreCase = true) ||
                it.id.equals(scannedCode, ignoreCase = true)
        }
        var isCheckOut by remember { mutableStateOf(matched?.custodyStatus != CustodyStatus.CHECKED_OUT) }
        var caseRef by remember { mutableStateOf(matched?.checkedOutCaseRef ?: "REF-2026-99") }
        var isDamagedOrMissing by remember { mutableStateOf(false) }
        var notes by remember { mutableStateOf("") }
        var breakageCostStr by remember { mutableStateOf("2500") }

        AlertDialog(
            onDismissRequest = { scannedTagForDialog = null },
            title = {
                Text(
                    text = matched?.name ?: "Tag: $scannedCode",
                    fontWeight = FontWeight.Bold,
                    fontSize = 15.sp
                )
            },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    Text(
                        text = "QR Tag: ${matched?.qrTagCode ?: scannedCode} • Current: ${matched?.custodyStatus?.label ?: "Unregistered Tag"}",
                        fontSize = 11.sp,
                        color = RoyalCobaltBlue,
                        fontWeight = FontWeight.SemiBold
                    )
                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        OutlinedButton(
                            onClick = { isCheckOut = true },
                            colors = ButtonDefaults.outlinedButtonColors(
                                containerColor = if (isCheckOut) Color(0xFFDBEAFE) else Color.Transparent
                            ),
                            modifier = Modifier.weight(1f).testTag("btn_custody_checkout_mode")
                        ) {
                            Text("Check OUT", fontSize = 11.sp, fontWeight = FontWeight.Bold)
                        }
                        OutlinedButton(
                            onClick = { isCheckOut = false },
                            colors = ButtonDefaults.outlinedButtonColors(
                                containerColor = if (!isCheckOut) EmeraldLight else Color.Transparent
                            ),
                            modifier = Modifier.weight(1f).testTag("btn_custody_checkin_mode")
                        ) {
                            Text("Check IN", fontSize = 11.sp, fontWeight = FontWeight.Bold)
                        }
                    }

                    OutlinedTextField(
                        value = caseRef,
                        onValueChange = { caseRef = it },
                        label = { Text("Burial Case Reference") },
                        singleLine = true,
                        modifier = Modifier.fillMaxWidth()
                    )

                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Checkbox(
                            checked = isDamagedOrMissing,
                            onCheckedChange = { isDamagedOrMissing = it },
                            modifier = Modifier.testTag("checkbox_custody_damaged")
                        )
                        Text(
                            text = "Flag Missing / Damaged (Auto-log Breakage Deduction)",
                            fontSize = 11.sp,
                            fontWeight = FontWeight.SemiBold,
                            color = if (isDamagedOrMissing) Color(0xFFDC2626) else ObsidianBlack
                        )
                    }

                    if (isDamagedOrMissing) {
                        OutlinedTextField(
                            value = breakageCostStr,
                            onValueChange = { breakageCostStr = it },
                            label = { Text("Breakage / Replacement Cost (KES)") },
                            keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                            singleLine = true,
                            modifier = Modifier.fillMaxWidth()
                        )
                    }

                    OutlinedTextField(
                        value = notes,
                        onValueChange = { notes = it },
                        label = { Text("Inspection / Condition Notes") },
                        placeholder = { Text("e.g. Hydraulic belt intact / Missing stanchion rope") },
                        modifier = Modifier.fillMaxWidth()
                    )
                }
            },
            confirmButton = {
                Button(
                    onClick = {
                        viewModel.scanAssetCustody(
                            qrOrTag = scannedCode,
                            actionCheckOut = isCheckOut,
                            caseReference = caseRef,
                            isDamagedOrMissing = isDamagedOrMissing,
                            conditionNotes = notes,
                            breakageCostKes = breakageCostStr.toDoubleOrNull() ?: 2500.0
                        )
                        scannedTagForDialog = null
                    },
                    colors = ButtonDefaults.buttonColors(
                        containerColor = if (isDamagedOrMissing) Color(0xFFDC2626) else EmeraldSuccess
                    ),
                    modifier = Modifier.testTag("btn_confirm_qr_custody")
                ) {
                    Text(if (isDamagedOrMissing) "Log Breakage & Save" else if (isCheckOut) "Confirm Check-Out" else "Confirm Check-In")
                }
            },
            dismissButton = {
                TextButton(onClick = { scannedTagForDialog = null }) {
                    Text("Cancel")
                }
            }
        )
    }

    assetForQrPreview?.let { asset ->
        AlertDialog(
            onDismissRequest = { assetForQrPreview = null },
            title = { Text("Asset QR Tag Label", fontWeight = FontWeight.Bold, fontSize = 15.sp) },
            text = {
                Column(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalAlignment = Alignment.CenterHorizontally,
                    verticalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    Text(asset.name, fontWeight = FontWeight.Bold, fontSize = 13.sp)
                    Text("${asset.registrationOrTag} • ${asset.branchAssigned}", fontSize = 11.sp, color = Color(0xFF64748B))
                    QrCodeBadge(qrData = asset.qrTagCode, label = asset.name, sizeDp = 150.dp)
                    Text(
                        text = "Print or affix this QR label onto the equipment case for check-out/in custody scans.",
                        fontSize = 10.sp,
                        color = Color(0xFF64748B)
                    )
                }
            },
            confirmButton = {
                Button(
                    onClick = {
                        val code = asset.qrTagCode
                        assetForQrPreview = null
                        scannedTagForDialog = code
                    },
                    colors = ButtonDefaults.buttonColors(containerColor = RoyalCobaltBlue)
                ) {
                    Text("Scan Check-Out/In")
                }
            },
            dismissButton = {
                TextButton(onClick = { assetForQrPreview = null }) { Text("Close") }
            }
        )
    }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(PureWhite)
            .padding(16.dp)
            .testTag("company_assets_tab")
    ) {
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Column(modifier = Modifier.weight(1f)) {
                Text(
                    text = "Company Assets & QR Custody",
                    fontSize = 18.sp,
                    fontWeight = FontWeight.Bold,
                    color = ObsidianBlack
                )
                Text(
                    text = "Scan QR tags on lowering gear, trolleys & carpets at check-out/in",
                    fontSize = 11.sp,
                    color = Color(0xFF64748B)
                )
            }
            Button(
                onClick = { showQrScanner = true },
                colors = ButtonDefaults.buttonColors(containerColor = RoyalCobaltBlue),
                shape = RoundedCornerShape(10.dp),
                contentPadding = PaddingValues(horizontal = 10.dp, vertical = 6.dp),
                modifier = Modifier.testTag("btn_open_qr_custody_scanner")
            ) {
                Icon(Icons.Default.QrCodeScanner, contentDescription = "Scan Asset QR", modifier = Modifier.size(16.dp))
                Spacer(modifier = Modifier.width(6.dp))
                Text("Scan QR", fontSize = 11.sp, fontWeight = FontWeight.Bold)
            }
        }

        Spacer(modifier = Modifier.height(10.dp))

        // CATEGORY PILLS
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.spacedBy(6.dp)
        ) {
            categories.take(4).forEach { cat ->
                val isSelected = filterCategory == cat
                Surface(
                    shape = RoundedCornerShape(16.dp),
                    color = if (isSelected) RoyalCobaltBlue else PureWhite,
                    border = BorderStroke(1.dp, if (isSelected) RoyalCobaltBlue else Color(0xFFCBD5E1)),
                    modifier = Modifier.weight(1f)
                ) {
                    Box(
                        modifier = Modifier
                            .clickable { filterCategory = cat }
                            .padding(vertical = 6.dp),
                        contentAlignment = Alignment.Center
                    ) {
                        Text(
                            text = cat,
                            fontSize = 10.sp,
                            fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Medium,
                            color = if (isSelected) Color.White else ObsidianBlack
                        )
                    }
                }
            }
        }

        Spacer(modifier = Modifier.height(10.dp))

        LazyColumn(
            modifier = Modifier.weight(1f),
            verticalArrangement = Arrangement.spacedBy(10.dp)
        ) {
            items(filteredAssets) { asset ->
                val (custodyBg, custodyFg) = when (asset.custodyStatus) {
                    CustodyStatus.IN_DEPOT -> EmeraldLight to EmeraldSuccess
                    CustodyStatus.CHECKED_OUT -> Color(0xFFDBEAFE) to RoyalCobaltBlue
                    CustodyStatus.DAMAGED, CustodyStatus.MISSING_FLAGGED -> RoseLight to Color(0xFFDC2626)
                }

                Card(
                    colors = CardDefaults.cardColors(containerColor = PureWhite),
                    border = BorderStroke(1.dp, Color(0xFFE2E8F0)),
                    shape = RoundedCornerShape(8.dp),
                    modifier = Modifier
                        .fillMaxWidth()
                        .testTag("asset_card_${asset.id}")
                ) {
                    Column(modifier = Modifier.padding(12.dp)) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Row(verticalAlignment = Alignment.CenterVertically, modifier = Modifier.weight(1f)) {
                                Icon(
                                    imageVector = if (asset.category == "Fleet") Icons.Default.DirectionsCar else Icons.Default.Build,
                                    contentDescription = null,
                                    tint = RoyalCobaltBlue,
                                    modifier = Modifier.size(16.dp)
                                )
                                Spacer(modifier = Modifier.width(6.dp))
                                Text(text = asset.name, fontSize = 13.sp, fontWeight = FontWeight.Bold, color = ObsidianBlack)
                            }

                            Surface(
                                color = custodyBg,
                                shape = RoundedCornerShape(12.dp)
                            ) {
                                Text(
                                    text = asset.custodyStatus.label,
                                    fontSize = 10.sp,
                                    fontWeight = FontWeight.SemiBold,
                                    color = custodyFg,
                                    modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp)
                                )
                            }
                        }

                        Spacer(modifier = Modifier.height(6.dp))

                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween
                        ) {
                            Text(text = "QR: ${asset.qrTagCode} (${asset.registrationOrTag})", fontSize = 11.sp, fontWeight = FontWeight.SemiBold, color = RoyalCobaltBlue)
                            Text(text = "Stationed: ${asset.branchAssigned}", fontSize = 11.sp, color = Color(0xFF475569))
                        }

                        Text(
                            text = "Custodian: ${asset.custodianStaffName} • Condition: ${asset.condition}" +
                                (asset.checkedOutCaseRef?.let { " • Case #$it" } ?: ""),
                            fontSize = 10.sp,
                            color = Color(0xFF64748B)
                        )

                        Spacer(modifier = Modifier.height(8.dp))

                        Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                            OutlinedButton(
                                onClick = { assetForQrPreview = asset },
                                modifier = Modifier.weight(0.9f).height(32.dp),
                                contentPadding = PaddingValues(horizontal = 4.dp),
                                shape = RoundedCornerShape(4.dp)
                            ) {
                                Icon(Icons.Default.QrCode2, contentDescription = null, modifier = Modifier.size(12.dp))
                                Spacer(modifier = Modifier.width(3.dp))
                                Text("QR Tag", fontSize = 10.sp)
                            }

                            OutlinedButton(
                                onClick = { scannedTagForDialog = asset.qrTagCode },
                                modifier = Modifier.weight(1.1f).height(32.dp).testTag("btn_asset_custody_${asset.id}"),
                                contentPadding = PaddingValues(horizontal = 4.dp),
                                shape = RoundedCornerShape(4.dp)
                            ) {
                                Text(
                                    if (asset.custodyStatus == CustodyStatus.CHECKED_OUT) "Check IN" else "Check OUT",
                                    fontSize = 10.sp,
                                    fontWeight = FontWeight.Bold
                                )
                            }

                            Button(
                                onClick = { viewModel.updateAssetStatus(asset.id, "Operational") },
                                colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF0F172A)),
                                modifier = Modifier.weight(0.9f).height(32.dp),
                                contentPadding = PaddingValues(horizontal = 4.dp),
                                shape = RoundedCornerShape(4.dp)
                            ) {
                                Text("Mark OK", fontSize = 10.sp)
                            }
                        }
                    }
                }
            }

            if (custodyLogs.isNotEmpty()) {
                item {
                    Spacer(modifier = Modifier.height(6.dp))
                    Text(
                        text = "Recent QR Custody Audit Trail (${custodyLogs.size})",
                        fontSize = 13.sp,
                        fontWeight = FontWeight.Bold,
                        color = ObsidianBlack
                    )
                }
                items(custodyLogs.take(5), key = { it.id }) { log ->
                    Surface(
                        color = if (log.breakageRecordId != null) AmberLight else PureWhite,
                        border = BorderStroke(1.dp, if (log.breakageRecordId != null) AmberWarning else Color(0xFFE2E8F0)),
                        shape = RoundedCornerShape(8.dp),
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Row(
                            modifier = Modifier.padding(10.dp),
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.SpaceBetween
                        ) {
                            Column(modifier = Modifier.weight(1f)) {
                                Text(
                                    text = "${log.assetName} (${log.qrTagCode})",
                                    fontSize = 12.sp,
                                    fontWeight = FontWeight.Bold,
                                    color = ObsidianBlack
                                )
                                Text(
                                    text = "${log.custodyStatus.label} • ${log.staffName} • Case #${log.caseReference}",
                                    fontSize = 10.sp,
                                    color = Color(0xFF475569)
                                )
                                if (log.breakageRecordId != null) {
                                    Row(verticalAlignment = Alignment.CenterVertically) {
                                        Icon(Icons.Default.Warning, contentDescription = null, tint = Color(0xFFB45309), modifier = Modifier.size(12.dp))
                                        Spacer(modifier = Modifier.width(4.dp))
                                        Text(
                                            text = "Auto-Breakage Deducted: #${log.breakageRecordId}",
                                            fontSize = 10.sp,
                                            fontWeight = FontWeight.Bold,
                                            color = Color(0xFFB45309)
                                        )
                                    }
                                }
                            }
                            Text(log.timestamp, fontSize = 9.sp, color = Color(0xFF64748B))
                        }
                    }
                }
            }
        }
    }
}

