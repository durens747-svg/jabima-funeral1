package com.example.ui.screens

import androidx.compose.animation.core.Spring
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.spring
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyListScope
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.Clear
import androidx.compose.material.icons.filled.Handyman
import androidx.compose.material.icons.filled.Inventory
import androidx.compose.material.icons.filled.Remove
import androidx.compose.material.icons.filled.Search
import androidx.compose.material.icons.filled.ShoppingCart
import androidx.compose.material.icons.filled.Warning
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.FilterChip
import androidx.compose.material3.FilterChipDefaults
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.CornerRadius
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.domain.InventoryHealthStatus
import com.example.domain.InventoryTrackerSummary
import com.example.model.InventoryMaterialItem
import com.example.model.JABIMA_BRANCHES
import com.example.ui.theme.AmberLight
import com.example.ui.theme.AmberWarning
import com.example.ui.theme.BorderLight
import com.example.ui.theme.EmeraldLight
import com.example.ui.theme.EmeraldSuccess
import com.example.ui.theme.ForestGreenDark
import com.example.ui.theme.ForestGreenLight
import com.example.ui.theme.ForestGreenPrimary
import com.example.ui.theme.Navy900
import com.example.ui.theme.PureWhite
import com.example.ui.theme.RoyalCobaltBlue
import com.example.ui.theme.RoyalCobaltIce
import com.example.ui.theme.StrokeRed
import com.example.ui.theme.StrokeRedLight
import com.example.ui.theme.TextMuted
import com.example.ui.theme.TextSecondary
import java.util.Locale

fun LazyListScope.inventoryTrackerItems(
    summary: InventoryTrackerSummary,
    selectedBranch: String,
    selectedHealth: InventoryHealthStatus,
    searchQuery: String,
    hasActiveWorkshopJobs: Boolean,
    onBranchChange: (String) -> Unit,
    onHealthChange: (InventoryHealthStatus) -> Unit,
    onSearchChange: (String) -> Unit,
    onAdjustQuantity: (InventoryMaterialItem, Int) -> Unit,
    onIssueToWorkshop: (InventoryMaterialItem) -> Unit,
    onOpenPurchaseDialog: () -> Unit
) {
    // 1. Live Stock Health Banner & KPI Grid
    item(key = "tracker_hero_kpis") {
        Card(
            shape = RoundedCornerShape(16.dp),
            border = BorderStroke(1.5.dp, StrokeRed.copy(alpha = 0.5f)),
            colors = CardDefaults.cardColors(containerColor = PureWhite),
            modifier = Modifier
                .fillMaxWidth()
                .testTag("inventory_tracker_overview_card")
        ) {
            Column {
                Box(
                    modifier = Modifier
                        .fillMaxWidth()
                        .background(Brush.linearGradient(listOf(ForestGreenDark, ForestGreenPrimary, ForestGreenLight)))
                        .padding(14.dp)
                ) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Column(modifier = Modifier.weight(1f)) {
                            Text(
                                text = "LIVE INVENTORY TRACKER",
                                fontSize = 10.sp,
                                fontWeight = FontWeight.ExtraBold,
                                color = Color(0xFF86EFAC),
                                letterSpacing = 0.8.sp
                            )
                            Text(
                                text = "Stock Par Levels, Reorder Queue & Branch Units",
                                fontSize = 15.sp,
                                fontWeight = FontWeight.Bold,
                                color = Color.White,
                                maxLines = 1,
                                overflow = TextOverflow.Ellipsis
                            )
                            Text(
                                text = "${summary.totalMaterialSkus} Material SKUs • ${summary.casketBranchUnitsTotal} Caskets across 8+ branches",
                                fontSize = 11.sp,
                                color = Color(0xFFDBEAFE)
                            )
                        }
                        Button(
                            onClick = onOpenPurchaseDialog,
                            colors = ButtonDefaults.buttonColors(containerColor = EmeraldSuccess),
                            shape = RoundedCornerShape(8.dp),
                            contentPadding = PaddingValues(horizontal = 10.dp, vertical = 6.dp),
                            modifier = Modifier.height(36.dp).testTag("tracker_btn_restock_po")
                        ) {
                            Icon(Icons.Default.ShoppingCart, contentDescription = null, modifier = Modifier.size(14.dp))
                            Spacer(modifier = Modifier.width(4.dp))
                            Text("Restock PO", fontSize = 11.sp, fontWeight = FontWeight.Bold, maxLines = 1, softWrap = false)
                        }
                    }
                }

                Column(
                    modifier = Modifier.padding(12.dp),
                    verticalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        TrackerKpiTile(
                            label = "Tracked Valuation",
                            value = "KES ${String.format(Locale.US, "%,.0f", summary.totalMaterialValuationKes)}",
                            sub = "${summary.totalMaterialUnits} units in store",
                            accent = RoyalCobaltBlue,
                            bg = RoyalCobaltIce,
                            modifier = Modifier.weight(1f)
                        )
                        TrackerKpiTile(
                            label = "Critical / Reorder",
                            value = "${summary.outOfStockCount + summary.lowStockCount} SKUs",
                            sub = "Est. PO: KES ${String.format(Locale.US, "%,.0f", summary.estimatedReorderCostKes)}",
                            accent = if (summary.outOfStockCount > 0) StrokeRed else AmberWarning,
                            bg = if (summary.outOfStockCount > 0) StrokeRedLight else AmberLight,
                            modifier = Modifier.weight(1f)
                        )
                    }
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        TrackerKpiTile(
                            label = "Healthy Stock SKUs",
                            value = "${summary.healthyStockCount} / ${summary.totalMaterialSkus}",
                            sub = "Above min threshold",
                            accent = EmeraldSuccess,
                            bg = EmeraldLight,
                            modifier = Modifier.weight(1f)
                        )
                        TrackerKpiTile(
                            label = "Finished & Casket Pool",
                            value = "${summary.casketBranchUnitsTotal + summary.finishedProductsCount} Units",
                            sub = "${summary.branchCasketMetrics.size} tracked branches",
                            accent = Color(0xFF7C3AED),
                            bg = Color(0xFFEDE9FE),
                            modifier = Modifier.weight(1f)
                        )
                    }
                }
            }
        }
    }

    // 2. Category Valuation & Branch Readiness Bars
    if (summary.categoryMetrics.isNotEmpty()) {
        item(key = "tracker_category_bars") {
            val maxCatVal = summary.categoryMetrics.maxOfOrNull { it.valuationKes }?.coerceAtLeast(1.0) ?: 1.0
            Card(
                shape = RoundedCornerShape(14.dp),
                colors = CardDefaults.cardColors(containerColor = PureWhite),
                border = BorderStroke(1.dp, BorderLight),
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(modifier = Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    Text(
                        text = "Material Capital Tied by Category",
                        fontSize = 13.sp,
                        fontWeight = FontWeight.ExtraBold,
                        color = Navy900
                    )
                    summary.categoryMetrics.take(5).forEach { cat ->
                        val ratio by animateFloatAsState(
                            targetValue = (cat.valuationKes / maxCatVal).toFloat().coerceIn(0.05f, 1f),
                            animationSpec = spring(stiffness = Spring.StiffnessMediumLow),
                            label = "catBar_${cat.categoryName}"
                        )
                        Column {
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.SpaceBetween
                            ) {
                                Text(
                                    text = "${cat.categoryName} (${cat.skuCount} SKUs)",
                                    fontSize = 11.sp,
                                    fontWeight = FontWeight.SemiBold,
                                    color = Navy900,
                                    maxLines = 1,
                                    overflow = TextOverflow.Ellipsis,
                                    modifier = Modifier.weight(1f)
                                )
                                Text(
                                    text = "KES ${String.format(Locale.US, "%,.0f", cat.valuationKes)}",
                                    fontSize = 11.sp,
                                    fontWeight = FontWeight.Bold,
                                    color = if (cat.lowOrOutCount > 0) AmberWarning else RoyalCobaltBlue
                                )
                            }
                            Spacer(modifier = Modifier.height(3.dp))
                            Canvas(modifier = Modifier.fillMaxWidth().height(8.dp)) {
                                drawRoundRect(
                                    color = Color(0xFFE2E8F0),
                                    cornerRadius = CornerRadius(4.dp.toPx())
                                )
                                drawRoundRect(
                                    color = if (cat.lowOrOutCount > 0) AmberWarning else RoyalCobaltBlue,
                                    size = Size(size.width * ratio, size.height),
                                    cornerRadius = CornerRadius(4.dp.toPx())
                                )
                            }
                        }
                    }
                }
            }
        }
    }

    // 3. Search, Branch & Health Filters
    item(key = "tracker_filters") {
        Card(
            shape = RoundedCornerShape(14.dp),
            colors = CardDefaults.cardColors(containerColor = PureWhite),
            border = BorderStroke(1.dp, BorderLight),
            modifier = Modifier.fillMaxWidth()
        ) {
            Column(modifier = Modifier.padding(12.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                OutlinedTextField(
                    value = searchQuery,
                    onValueChange = onSearchChange,
                    placeholder = { Text("Track material, wood, hardware or branch...", fontSize = 12.sp) },
                    leadingIcon = { Icon(Icons.Default.Search, contentDescription = null, tint = RoyalCobaltBlue) },
                    trailingIcon = {
                        if (searchQuery.isNotEmpty()) {
                            IconButton(onClick = { onSearchChange("") }) {
                                Icon(Icons.Default.Clear, contentDescription = "Clear search")
                            }
                        }
                    },
                    singleLine = true,
                    shape = RoundedCornerShape(10.dp),
                    modifier = Modifier.fillMaxWidth().testTag("tracker_search_input")
                )

                Row(
                    modifier = Modifier.fillMaxWidth().horizontalScroll(rememberScrollState()),
                    horizontalArrangement = Arrangement.spacedBy(6.dp)
                ) {
                    InventoryHealthStatus.entries.forEach { health ->
                        val selected = selectedHealth == health
                        FilterChip(
                            selected = selected,
                            onClick = { onHealthChange(health) },
                            label = { Text(health.label, fontSize = 11.sp, maxLines = 1, softWrap = false) },
                            colors = FilterChipDefaults.filterChipColors(
                                selectedContainerColor = Navy900,
                                selectedLabelColor = Color.White
                            ),
                            modifier = Modifier.testTag("tracker_health_${health.name.lowercase()}")
                        )
                    }
                }

                Row(
                    modifier = Modifier.fillMaxWidth().horizontalScroll(rememberScrollState()),
                    horizontalArrangement = Arrangement.spacedBy(6.dp)
                ) {
                    val branchOptions = listOf("All Branches") + JABIMA_BRANCHES
                    branchOptions.forEach { branch ->
                        val selected = selectedBranch == branch
                        FilterChip(
                            selected = selected,
                            onClick = { onBranchChange(branch) },
                            label = { Text(branch, fontSize = 11.sp, maxLines = 1, softWrap = false) },
                            colors = FilterChipDefaults.filterChipColors(
                                selectedContainerColor = RoyalCobaltBlue,
                                selectedLabelColor = Color.White
                            ),
                            modifier = Modifier.testTag("tracker_branch_${branch.lowercase().replace(" ", "_")}")
                        )
                    }
                }
            }
        }
    }

    // 4. Individual Stock Item Trackers with Instant Cycle Count / Adjust Controls
    if (summary.prioritizedMaterials.isEmpty()) {
        item(key = "tracker_empty_state") {
            Surface(
                color = MaterialTheme.colorScheme.surfaceVariant,
                shape = RoundedCornerShape(12.dp),
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(
                    modifier = Modifier.padding(20.dp),
                    horizontalAlignment = Alignment.CenterHorizontally
                ) {
                    Icon(Icons.Default.Inventory, contentDescription = null, tint = TextMuted, modifier = Modifier.size(28.dp))
                    Spacer(modifier = Modifier.height(6.dp))
                    Text("No stock items match your selected filter.", fontSize = 13.sp, fontWeight = FontWeight.Bold, color = Navy900)
                    Text("Try switching branch or health status filter.", fontSize = 11.sp, color = TextMuted)
                }
            }
        }
    } else {
        items(summary.prioritizedMaterials, key = { "trk_${it.id}" }) { item ->
            TrackedMaterialCard(
                item = item,
                hasActiveWorkshopJobs = hasActiveWorkshopJobs,
                onAdjustQuantity = { delta -> onAdjustQuantity(item, delta) },
                onIssueToWorkshop = { onIssueToWorkshop(item) }
            )
        }
    }

    // 5. Branch Casket Stock Tracker Strip
    if (summary.branchCasketMetrics.isNotEmpty()) {
        item(key = "tracker_branch_casket_summary") {
            Card(
                shape = RoundedCornerShape(14.dp),
                colors = CardDefaults.cardColors(containerColor = PureWhite),
                border = BorderStroke(1.dp, BorderLight),
                modifier = Modifier.fillMaxWidth().testTag("tracker_branch_caskets_card")
            ) {
                Column(modifier = Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    Text(
                        text = "Finished Caskets On Hand by Branch",
                        fontSize = 13.sp,
                        fontWeight = FontWeight.ExtraBold,
                        color = Navy900
                    )
                    summary.branchCasketMetrics.forEach { bMetric ->
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Column(modifier = Modifier.weight(1f)) {
                                Text(bMetric.branchName, fontSize = 12.sp, fontWeight = FontWeight.Bold, color = Navy900)
                                Text(
                                    text = if (bMetric.depletedModelsCount > 0) "${bMetric.depletedModelsCount} models at zero stock" else "All models stocked",
                                    fontSize = 10.sp,
                                    color = if (bMetric.depletedModelsCount > 0) AmberWarning else EmeraldSuccess
                                )
                            }
                            Column(horizontalAlignment = Alignment.End) {
                                Text("${bMetric.casketUnitsTotal} Caskets", fontSize = 12.sp, fontWeight = FontWeight.ExtraBold, color = RoyalCobaltBlue)
                                Text("KES ${String.format(Locale.US, "%,.0f", bMetric.branchValueKes)}", fontSize = 10.sp, color = TextSecondary)
                            }
                        }
                        HorizontalDivider(color = BorderLight.copy(alpha = 0.6f))
                    }
                }
            }
        }
    }
}

@Composable
private fun TrackerKpiTile(
    label: String,
    value: String,
    sub: String,
    accent: Color,
    bg: Color,
    modifier: Modifier = Modifier
) {
    Surface(
        color = bg,
        shape = RoundedCornerShape(10.dp),
        border = BorderStroke(1.dp, accent.copy(alpha = 0.25f)),
        modifier = modifier
    ) {
        Column(modifier = Modifier.padding(10.dp)) {
            Text(label, fontSize = 10.sp, fontWeight = FontWeight.SemiBold, color = accent, maxLines = 1, overflow = TextOverflow.Ellipsis)
            Spacer(modifier = Modifier.height(2.dp))
            Text(value, fontSize = 14.sp, fontWeight = FontWeight.ExtraBold, color = Navy900, maxLines = 1, overflow = TextOverflow.Ellipsis)
            Text(sub, fontSize = 10.sp, color = TextSecondary, maxLines = 1, overflow = TextOverflow.Ellipsis)
        }
    }
}

@Composable
private fun TrackedMaterialCard(
    item: InventoryMaterialItem,
    hasActiveWorkshopJobs: Boolean,
    onAdjustQuantity: (Int) -> Unit,
    onIssueToWorkshop: () -> Unit
) {
    val parTarget = (item.minThreshold * 3).coerceAtLeast(10)
    val fillFraction by animateFloatAsState(
        targetValue = (item.quantity.toFloat() / parTarget.toFloat()).coerceIn(0.03f, 1f),
        animationSpec = spring(stiffness = Spring.StiffnessMediumLow),
        label = "matFill_${item.id}"
    )

    val (badgeLabel, badgeBg, badgeFg) = when {
        item.isOutOfStock -> Triple("OUT OF STOCK", StrokeRedLight, StrokeRed)
        item.isLowStock -> Triple("LOW STOCK", AmberLight, AmberWarning)
        else -> Triple("IN STOCK", EmeraldLight, EmeraldSuccess)
    }

    Card(
        shape = RoundedCornerShape(12.dp),
        colors = CardDefaults.cardColors(containerColor = PureWhite),
        border = BorderStroke(1.dp, if (item.isOutOfStock) StrokeRed.copy(alpha = 0.45f) else if (item.isLowStock) AmberWarning.copy(alpha = 0.45f) else BorderLight),
        modifier = Modifier.fillMaxWidth().testTag("tracked_item_card_${item.id}")
    ) {
        Column(modifier = Modifier.padding(12.dp)) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Column(modifier = Modifier.weight(1f)) {
                    Text(item.name, fontSize = 13.sp, fontWeight = FontWeight.Bold, color = Navy900)
                    Text("${item.categoryName} • ${item.branchWarehouse}", fontSize = 10.sp, color = TextMuted)
                }
                Surface(color = badgeBg, shape = RoundedCornerShape(8.dp)) {
                    Text(
                        text = badgeLabel,
                        fontSize = 9.sp,
                        fontWeight = FontWeight.ExtraBold,
                        color = badgeFg,
                        modifier = Modifier.padding(horizontal = 7.dp, vertical = 3.dp)
                    )
                }
            }

            Spacer(modifier = Modifier.height(8.dp))

            // Par Level Bar
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                Text(
                    text = "On Hand: ${item.quantity} ${item.unit} (Min ${item.minThreshold} • Par $parTarget)",
                    fontSize = 11.sp,
                    fontWeight = FontWeight.SemiBold,
                    color = Navy900
                )
                Text(
                    text = "KES ${String.format(Locale.US, "%,.0f", item.totalValueKes)}",
                    fontSize = 11.sp,
                    fontWeight = FontWeight.Bold,
                    color = RoyalCobaltBlue
                )
            }
            Spacer(modifier = Modifier.height(4.dp))
            Canvas(modifier = Modifier.fillMaxWidth().height(9.dp)) {
                drawRoundRect(
                    color = Color(0xFFE2E8F0),
                    cornerRadius = CornerRadius(5.dp.toPx())
                )
                drawRoundRect(
                    color = badgeFg,
                    size = Size(size.width * fillFraction, size.height),
                    cornerRadius = CornerRadius(5.dp.toPx())
                )
                val thresholdX = (item.minThreshold.toFloat() / parTarget.toFloat()).coerceIn(0.05f, 0.95f) * size.width
                drawLine(
                    color = Navy900.copy(alpha = 0.65f),
                    start = Offset(thresholdX, 0f),
                    end = Offset(thresholdX, size.height),
                    strokeWidth = 2.dp.toPx()
                )
            }

            Spacer(modifier = Modifier.height(10.dp))

            // Interactive Cycle Count & Workshop Actions
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(6.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                OutlinedButton(
                    enabled = item.quantity > 0,
                    onClick = { onAdjustQuantity(-1) },
                    shape = RoundedCornerShape(8.dp),
                    contentPadding = PaddingValues(horizontal = 8.dp, vertical = 2.dp),
                    modifier = Modifier.height(34.dp).testTag("btn_tracker_minus_${item.id}")
                ) {
                    Icon(Icons.Default.Remove, contentDescription = "Consume 1", modifier = Modifier.size(14.dp))
                    Text("-1", fontSize = 11.sp, fontWeight = FontWeight.Bold, maxLines = 1, softWrap = false)
                }

                OutlinedButton(
                    onClick = { onAdjustQuantity(1) },
                    shape = RoundedCornerShape(8.dp),
                    contentPadding = PaddingValues(horizontal = 8.dp, vertical = 2.dp),
                    modifier = Modifier.height(34.dp).testTag("btn_tracker_plus1_${item.id}")
                ) {
                    Icon(Icons.Default.Add, contentDescription = "Add 1", modifier = Modifier.size(14.dp))
                    Text("+1", fontSize = 11.sp, fontWeight = FontWeight.Bold, maxLines = 1, softWrap = false)
                }

                OutlinedButton(
                    onClick = { onAdjustQuantity(5) },
                    shape = RoundedCornerShape(8.dp),
                    contentPadding = PaddingValues(horizontal = 8.dp, vertical = 2.dp),
                    modifier = Modifier.height(34.dp).testTag("btn_tracker_plus5_${item.id}")
                ) {
                    Text("+5 Stock", fontSize = 11.sp, fontWeight = FontWeight.Bold, maxLines = 1, softWrap = false)
                }

                Spacer(modifier = Modifier.weight(1f))

                Button(
                    enabled = item.quantity > 0 && hasActiveWorkshopJobs,
                    onClick = onIssueToWorkshop,
                    colors = ButtonDefaults.buttonColors(containerColor = RoyalCobaltBlue),
                    shape = RoundedCornerShape(8.dp),
                    contentPadding = PaddingValues(horizontal = 10.dp, vertical = 2.dp),
                    modifier = Modifier.height(34.dp).testTag("btn_tracker_issue_${item.id}")
                ) {
                    Icon(Icons.Default.Handyman, contentDescription = null, modifier = Modifier.size(13.dp))
                    Spacer(modifier = Modifier.width(4.dp))
                    Text("Issue", fontSize = 11.sp, fontWeight = FontWeight.Bold, maxLines = 1, softWrap = false)
                }
            }
        }
    }
}
