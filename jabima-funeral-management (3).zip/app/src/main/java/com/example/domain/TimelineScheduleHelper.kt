package com.example.domain

import com.example.model.ActivityCategory
import com.example.model.ActivityStatus
import com.example.model.Department
import com.example.model.FuneralArrangementStage
import com.example.model.StaffActivity
import com.example.model.TaskPriority
import java.util.Locale

/**
 * Pure domain utilities for parsing activity/shift timestamps, formatting time windows,
 * sorting daily funeral tasks strictly chronologically, and detecting parallel/overlapping slots.
 */
object TimelineScheduleHelper {

    /**
     * Parses strings like "08:30 AM", "8:00 am", "12:15 PM", "14:30", "00:00"
     * into minutes since midnight [0..1439]. Returns 24 * 60 for unparseable values.
     */
    fun parseTimeToMinutes(timeStr: String): Int {
        val cleaned = timeStr.trim().uppercase(Locale.US)
        if (cleaned.isEmpty()) return 24 * 60

        val isAm = cleaned.endsWith("AM")
        val isPm = cleaned.endsWith("PM")
        val timePart = cleaned
            .removeSuffix("AM")
            .removeSuffix("PM")
            .trim()

        val parts = timePart.split(":")
        if (parts.size < 2) return 24 * 60

        val rawHour = parts[0].trim().toIntOrNull() ?: return 24 * 60
        val minute = parts[1].trim().takeWhile { it.isDigit() }.toIntOrNull() ?: return 24 * 60

        if (minute !in 0..59) return 24 * 60

        val hour24 = when {
            isAm -> {
                if (rawHour !in 1..12) return 24 * 60
                if (rawHour == 12) 0 else rawHour
            }
            isPm -> {
                if (rawHour !in 1..12) return 24 * 60
                if (rawHour == 12) 12 else rawHour + 12
            }
            else -> {
                if (rawHour !in 0..23) return 24 * 60
                rawHour
            }
        }
        return hour24 * 60 + minute
    }

    /**
     * Formats minutes since midnight into "hh:mm AM/PM".
     */
    fun formatMinutesTo12Hour(totalMinutes: Int): String {
        val normalized = ((totalMinutes % 1440) + 1440) % 1440
        val hour24 = normalized / 60
        val min = normalized % 60
        val amPm = if (hour24 < 12) "AM" else "PM"
        val hour12 = when {
            hour24 == 0 -> 12
            hour24 > 12 -> hour24 - 12
            else -> hour24
        }
        return String.format(Locale.US, "%02d:%02d %s", hour12, min, amPm)
    }

    /**
     * Computes end time label from startTime string and duration in minutes.
     */
    fun formatEndTime(startTime: String, durationMinutes: Int): String {
        val startMins = parseTimeToMinutes(startTime)
        if (startMins >= 24 * 60) return "--:--"
        return formatMinutesTo12Hour(startMins + durationMinutes.coerceAtLeast(0))
    }

    /**
     * Returns formatted chronological range, e.g. "08:30 AM – 10:30 AM".
     */
    fun formatTimeWindow(startTime: String, durationMinutes: Int): String {
        val startMins = parseTimeToMinutes(startTime)
        if (startMins >= 24 * 60) return startTime
        val startFormatted = formatMinutesTo12Hour(startMins)
        val endFormatted = formatMinutesTo12Hour(startMins + durationMinutes.coerceAtLeast(0))
        return "$startFormatted – $endFormatted"
    }

    /**
     * Returns hour bucket label such as "08:00 AM" for grouping timeline markers.
     */
    fun formatHourBucket(startTime: String): String {
        val mins = parseTimeToMinutes(startTime)
        if (mins >= 24 * 60) return "Unscheduled"
        val bucketMins = (mins / 60) * 60
        return formatMinutesTo12Hour(bucketMins)
    }

    /**
     * Sorts tasks strictly chronologically (earliest start time first).
     * When multiple tasks start at the same time on the same day, URGENT/HIGH tasks appear first,
     * followed by active status and deterministic ID tie-breaker.
     */
    fun sortActivitiesChronologically(activities: List<StaffActivity>): List<StaffActivity> {
        return activities.sortedWith(
            compareBy<StaffActivity>(
                { parseTimeToMinutes(it.time) },
                { -priorityWeight(it.priority) },
                { statusWeight(it.status) },
                { it.id }
            )
        )
    }

    /**
     * Detects task IDs whose scheduled windows overlap with another task on the same date,
     * enabling the visual timeline to call out parallel operations.
     */
    fun detectOverlappingActivityIds(activities: List<StaffActivity>): Set<String> {
        val overlapping = mutableSetOf<String>()
        val byDate = activities.groupBy { it.date.trim() }
        byDate.values.forEach { dayTasks ->
            if (dayTasks.size < 2) return@forEach
            val windows = dayTasks.mapNotNull { task ->
                val start = parseTimeToMinutes(task.time)
                if (start >= 24 * 60) null
                else Triple(task.id, start, start + task.durationMinutes.coerceAtLeast(15))
            }
            for (i in windows.indices) {
                for (j in i + 1 until windows.size) {
                    val (idA, startA, endA) = windows[i]
                    val (idB, startB, endB) = windows[j]
                    if (startA < endB && startB < endA) {
                        overlapping.add(idA)
                        overlapping.add(idB)
                    }
                }
            }
        }
        return overlapping
    }

    /**
     * Multi-criteria task filtering for daily timeline and list modes.
     */
    fun filterActivities(
        activities: List<StaffActivity>,
        dateFilter: String?,
        statusFilter: ActivityStatus?,
        categoryFilter: ActivityCategory?,
        stageFilter: FuneralArrangementStage?,
        priorityFilter: TaskPriority?,
        departmentFilter: Department?,
        searchQuery: String
    ): List<StaffActivity> {
        val trimmedQuery = searchQuery.trim()
        return activities.filter { act ->
            val matchesDate = dateFilter == null || act.date.contains(dateFilter, ignoreCase = true)
            val matchesStatus = statusFilter == null || act.status == statusFilter
            val matchesCategory = categoryFilter == null || act.category == categoryFilter
            val matchesStage = stageFilter == null || act.arrangementStage == stageFilter
            val matchesPriority = priorityFilter == null || act.priority == priorityFilter
            val matchesDept = departmentFilter == null || act.department == departmentFilter
            val matchesSearch = trimmedQuery.isEmpty() ||
                act.title.contains(trimmedQuery, ignoreCase = true) ||
                act.caseReference.contains(trimmedQuery, ignoreCase = true) ||
                act.clientFamily.contains(trimmedQuery, ignoreCase = true) ||
                act.location.contains(trimmedQuery, ignoreCase = true) ||
                act.staffName.contains(trimmedQuery, ignoreCase = true) ||
                act.department.displayName.contains(trimmedQuery, ignoreCase = true) ||
                (act.assignedVehicle?.contains(trimmedQuery, ignoreCase = true) == true) ||
                (act.assignedEquipment?.contains(trimmedQuery, ignoreCase = true) == true)

            matchesDate && matchesStatus && matchesCategory && matchesStage &&
                matchesPriority && matchesDept && matchesSearch
        }
    }

    private fun priorityWeight(priority: TaskPriority): Int = when (priority) {
        TaskPriority.URGENT -> 3
        TaskPriority.HIGH -> 2
        TaskPriority.NORMAL -> 1
    }

    private fun statusWeight(status: ActivityStatus): Int = when (status) {
        ActivityStatus.IN_PROGRESS -> 0
        ActivityStatus.IN_TRANSIT -> 1
        ActivityStatus.SCHEDULED -> 2
        ActivityStatus.ON_HOLD -> 3
        ActivityStatus.COMPLETED -> 4
        ActivityStatus.VERIFIED_BY_ADMIN -> 5
    }
}
