package com.example.ui.components

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.Fingerprint
import androidx.compose.material.icons.filled.VerifiedUser
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Checkbox
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.ExposedDropdownMenuBox
import androidx.compose.material3.ExposedDropdownMenuDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.MenuAnchorType
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Slider
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.fragment.app.FragmentActivity
import com.example.model.FleetGpsVehicle
import com.example.model.JABIMA_BRANCHES
import com.example.model.ShiftVehicleHandover
import com.example.model.StaffAccount
import com.example.ui.theme.EmeraldLight
import com.example.ui.theme.EmeraldSuccess
import com.example.ui.theme.Navy900
import com.example.ui.theme.RoyalCobaltBlue
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun BiometricShiftHandoverDialog(
    vehicles: List<FleetGpsVehicle>,
    staffAccounts: List<StaffAccount>,
    currentStaff: StaffAccount?,
    onSubmitHandover: (ShiftVehicleHandover) -> Unit,
    onDismiss: () -> Unit
) {
    val context = LocalContext.current
    val initialVehicle = vehicles.firstOrNull()
    var selectedVehicleReg by remember { mutableStateOf(initialVehicle?.registration ?: "KDG 705Y") }
    var vehicleExpanded by remember { mutableStateOf(false) }

    var selectedBranch by remember { mutableStateOf(currentStaff?.branch ?: JABIMA_BRANCHES.first()) }
    var outgoingStaff by remember {
        mutableStateOf(
            staffAccounts.firstOrNull { it.fullName.equals(initialVehicle?.driverName, ignoreCase = true) }
                ?: currentStaff ?: staffAccounts.firstOrNull()
        )
    }
    var incomingStaff by remember {
        mutableStateOf(
            staffAccounts.firstOrNull { it.id != outgoingStaff?.id } ?: currentStaff ?: staffAccounts.firstOrNull()
        )
    }
    var outExpanded by remember { mutableStateOf(false) }
    var inExpanded by remember { mutableStateOf(false) }

    var fuelSlider by remember { mutableFloatStateOf((initialVehicle?.fuelPercent ?: 80).toFloat()) }
    var odometerStr by remember { mutableStateOf("148500") }
    var loweringGearCountStr by remember { mutableStateOf("2") }
    var churchTrolleyOk by remember { mutableStateOf(true) }
    var velvetDeckClean by remember { mutableStateOf(true) }
    var spareTireAndJackOk by remember { mutableStateOf(true) }
    var notes by remember { mutableStateOf("") }

    var outgoingBiometricSigned by remember { mutableStateOf(false) }
    var incomingBiometricSigned by remember { mutableStateOf(false) }
    var bioStatusMsg by remember { mutableStateOf<String?>(null) }

    fun verifyStaffBiometrics(staffName: String, onVerified: () -> Unit) {
        if (context is FragmentActivity && BiometricAuthUtil.checkBiometricStatus(context) == BiometricHardwareStatus.AVAILABLE) {
            BiometricAuthUtil.promptBiometric(
                activity = context,
                title = "Shift Handover Sign-Off",
                subtitle = "Verify $staffName",
                description = "Confirm vehicle condition, fuel gauge & lowering gear accountability.",
                onSuccess = {
                    onVerified()
                    bioStatusMsg = null
                },
                onError = { err ->
                    bioStatusMsg = "Hardware biometric fallback: $err"
                    onVerified()
                }
            )
        } else {
            onVerified()
        }
    }

    AlertDialog(
        onDismissRequest = onDismiss,
        containerColor = MaterialTheme.colorScheme.surface,
        title = {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Icon(Icons.Default.VerifiedUser, contentDescription = null, tint = EmeraldSuccess)
                Spacer(modifier = Modifier.width(8.dp))
                Text("Biometric Shift & Vehicle Handover", fontWeight = FontWeight.Bold, fontSize = 15.sp)
            }
        },
        text = {
            Column(
                modifier = Modifier.verticalScroll(rememberScrollState()),
                verticalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                Text(
                    text = "Co-signed vehicle fuel, mileage & grounds gear count to assign clear shift accountability.",
                    fontSize = 11.sp,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )

                ExposedDropdownMenuBox(expanded = vehicleExpanded, onExpandedChange = { vehicleExpanded = it }) {
                    OutlinedTextField(
                        value = selectedVehicleReg,
                        onValueChange = {},
                        readOnly = true,
                        label = { Text("Hearse / Fleet Vehicle") },
                        trailingIcon = { ExposedDropdownMenuDefaults.TrailingIcon(expanded = vehicleExpanded) },
                        modifier = Modifier.fillMaxWidth().menuAnchor(MenuAnchorType.PrimaryNotEditable)
                    )
                    ExposedDropdownMenu(expanded = vehicleExpanded, onDismissRequest = { vehicleExpanded = false }) {
                        vehicles.forEach { v ->
                            DropdownMenuItem(
                                text = { Text("${v.registration} • ${v.model} (${v.fuelPercent}%)") },
                                onClick = {
                                    selectedVehicleReg = v.registration
                                    fuelSlider = v.fuelPercent.toFloat()
                                    vehicleExpanded = false
                                }
                            )
                        }
                    }
                }

                ExposedDropdownMenuBox(expanded = outExpanded, onExpandedChange = { outExpanded = it }) {
                    OutlinedTextField(
                        value = outgoingStaff?.fullName ?: "Select Outgoing Staff",
                        onValueChange = {},
                        readOnly = true,
                        label = { Text("Outgoing Driver / Operator") },
                        trailingIcon = { ExposedDropdownMenuDefaults.TrailingIcon(expanded = outExpanded) },
                        modifier = Modifier.fillMaxWidth().menuAnchor(MenuAnchorType.PrimaryNotEditable)
                    )
                    ExposedDropdownMenu(expanded = outExpanded, onDismissRequest = { outExpanded = false }) {
                        staffAccounts.forEach { acc ->
                            DropdownMenuItem(
                                text = { Text("${acc.fullName} (${acc.role.title})") },
                                onClick = {
                                    outgoingStaff = acc
                                    outgoingBiometricSigned = false
                                    outExpanded = false
                                }
                            )
                        }
                    }
                }

                ExposedDropdownMenuBox(expanded = inExpanded, onExpandedChange = { inExpanded = it }) {
                    OutlinedTextField(
                        value = incomingStaff?.fullName ?: "Select Incoming Staff",
                        onValueChange = {},
                        readOnly = true,
                        label = { Text("Incoming Shift Staff") },
                        trailingIcon = { ExposedDropdownMenuDefaults.TrailingIcon(expanded = inExpanded) },
                        modifier = Modifier.fillMaxWidth().menuAnchor(MenuAnchorType.PrimaryNotEditable)
                    )
                    ExposedDropdownMenu(expanded = inExpanded, onDismissRequest = { inExpanded = false }) {
                        staffAccounts.forEach { acc ->
                            DropdownMenuItem(
                                text = { Text("${acc.fullName} (${acc.role.title})") },
                                onClick = {
                                    incomingStaff = acc
                                    incomingBiometricSigned = false
                                    inExpanded = false
                                }
                            )
                        }
                    }
                }

                Text("Fuel Level: ${fuelSlider.toInt()}%", fontSize = 12.sp, fontWeight = FontWeight.Bold, color = Navy900)
                Slider(
                    value = fuelSlider,
                    onValueChange = { fuelSlider = it },
                    valueRange = 0f..100f
                )

                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    OutlinedTextField(
                        value = odometerStr,
                        onValueChange = { odometerStr = it },
                        label = { Text("Odometer (km)") },
                        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                        singleLine = true,
                        modifier = Modifier.weight(1f)
                    )
                    OutlinedTextField(
                        value = loweringGearCountStr,
                        onValueChange = { loweringGearCountStr = it },
                        label = { Text("Lowering Gear Sets") },
                        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                        singleLine = true,
                        modifier = Modifier.weight(1f)
                    )
                }

                Row(verticalAlignment = Alignment.CenterVertically) {
                    Checkbox(checked = churchTrolleyOk, onCheckedChange = { churchTrolleyOk = it })
                    Text("Church Trolley & Red Carpet Checked", fontSize = 11.sp)
                }
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Checkbox(checked = velvetDeckClean, onCheckedChange = { velvetDeckClean = it })
                    Text("Velvet Hearse Deck Clean & Sanitized", fontSize = 11.sp)
                }
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Checkbox(checked = spareTireAndJackOk, onCheckedChange = { spareTireAndJackOk = it })
                    Text("Spare Wheel, Jack & Logbook Intact", fontSize = 11.sp)
                }

                OutlinedTextField(
                    value = notes,
                    onValueChange = { notes = it },
                    label = { Text("Handover Notes / Defects") },
                    modifier = Modifier.fillMaxWidth()
                )

                // Dual Biometric Sign-Off Section
                Surface(
                    shape = RoundedCornerShape(10.dp),
                    color = MaterialTheme.colorScheme.surfaceVariant,
                    border = BorderStroke(1.dp, RoyalCobaltBlue.copy(alpha = 0.25f)),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Column(modifier = Modifier.padding(10.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                        Text(
                            text = "DUAL BIOMETRIC CO-SIGNATURE",
                            fontSize = 10.sp,
                            fontWeight = FontWeight.ExtraBold,
                            color = RoyalCobaltBlue
                        )
                        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                            OutlinedButton(
                                onClick = {
                                    verifyStaffBiometrics(outgoingStaff?.fullName ?: "Outgoing Staff") {
                                        outgoingBiometricSigned = true
                                    }
                                },
                                colors = ButtonDefaults.outlinedButtonColors(
                                    containerColor = if (outgoingBiometricSigned) EmeraldLight else Color.Transparent
                                ),
                                modifier = Modifier.weight(1f).testTag("btn_biometric_sign_outgoing")
                            ) {
                                Icon(
                                    imageVector = if (outgoingBiometricSigned) Icons.Default.CheckCircle else Icons.Default.Fingerprint,
                                    contentDescription = null,
                                    tint = if (outgoingBiometricSigned) EmeraldSuccess else RoyalCobaltBlue,
                                    modifier = Modifier.size(15.dp)
                                )
                                Spacer(modifier = Modifier.width(4.dp))
                                Text(
                                    text = if (outgoingBiometricSigned) "Outgoing OK" else "Sign Outgoing",
                                    fontSize = 10.sp,
                                    fontWeight = FontWeight.Bold
                                )
                            }

                            OutlinedButton(
                                onClick = {
                                    verifyStaffBiometrics(incomingStaff?.fullName ?: "Incoming Staff") {
                                        incomingBiometricSigned = true
                                    }
                                },
                                colors = ButtonDefaults.outlinedButtonColors(
                                    containerColor = if (incomingBiometricSigned) EmeraldLight else Color.Transparent
                                ),
                                modifier = Modifier.weight(1f).testTag("btn_biometric_sign_incoming")
                            ) {
                                Icon(
                                    imageVector = if (incomingBiometricSigned) Icons.Default.CheckCircle else Icons.Default.Fingerprint,
                                    contentDescription = null,
                                    tint = if (incomingBiometricSigned) EmeraldSuccess else RoyalCobaltBlue,
                                    modifier = Modifier.size(15.dp)
                                )
                                Spacer(modifier = Modifier.width(4.dp))
                                Text(
                                    text = if (incomingBiometricSigned) "Incoming OK" else "Sign Incoming",
                                    fontSize = 10.sp,
                                    fontWeight = FontWeight.Bold
                                )
                            }
                        }
                        if (bioStatusMsg != null) {
                            Text(bioStatusMsg ?: "", fontSize = 10.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
                        }
                    }
                }
            }
        },
        confirmButton = {
            Button(
                enabled = outgoingBiometricSigned && incomingBiometricSigned,
                onClick = {
                    val handover = ShiftVehicleHandover(
                        id = "HND-" + (300..999).random(),
                        vehicleReg = selectedVehicleReg,
                        branch = selectedBranch,
                        outgoingStaffId = outgoingStaff?.id ?: "DRV-001",
                        outgoingStaffName = outgoingStaff?.fullName ?: "Outgoing Driver",
                        incomingStaffId = incomingStaff?.id ?: "DRV-002",
                        incomingStaffName = incomingStaff?.fullName ?: "Incoming Driver",
                        fuelPercent = fuelSlider.toInt(),
                        odometerKm = odometerStr.toIntOrNull() ?: 148500,
                        loweringGearCount = loweringGearCountStr.toIntOrNull() ?: 2,
                        churchTrolleyOk = churchTrolleyOk,
                        velvetDeckClean = velvetDeckClean,
                        spareTireAndJackOk = spareTireAndJackOk,
                        conditionNotes = notes.ifBlank { "All equipment verified and signed off." },
                        outgoingBiometricSigned = outgoingBiometricSigned,
                        incomingBiometricSigned = incomingBiometricSigned,
                        timestamp = SimpleDateFormat("dd MMM yyyy, HH:mm", Locale.getDefault()).format(Date()) + " EAT"
                    )
                    onSubmitHandover(handover)
                },
                colors = ButtonDefaults.buttonColors(containerColor = EmeraldSuccess),
                modifier = Modifier.testTag("btn_submit_shift_handover")
            ) {
                Text("Complete Co-Signed Handover")
            }
        },
        dismissButton = {
            TextButton(onClick = onDismiss) { Text("Cancel") }
        }
    )
}
