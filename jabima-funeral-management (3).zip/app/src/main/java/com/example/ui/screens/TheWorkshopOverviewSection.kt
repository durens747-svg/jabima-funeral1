package com.example.ui.screens

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowForward
import androidx.compose.material.icons.filled.Build
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.FormatPaint
import androidx.compose.material.icons.filled.Handyman
import androidx.compose.material.icons.filled.Inventory
import androidx.compose.material.icons.filled.Layers
import androidx.compose.material.icons.filled.Person
import androidx.compose.material.icons.filled.PrecisionManufacturing
import androidx.compose.material.icons.filled.Schedule
import androidx.compose.material.icons.filled.Videocam
import androidx.compose.material.icons.filled.Visibility
import androidx.compose.material.icons.filled.Warning
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.model.CasketStockByBranchRow
import com.example.model.InventoryMaterialItem
import com.example.model.JABIMA_BRANCHES
import com.example.model.NavTab
import com.example.model.StaffAccount
import com.example.model.StaffRole
import com.example.model.Department
import com.example.model.WorkshopProductionItem
import com.example.model.WorkshopProductionStage
import com.example.ui.theme.AmberLight
import com.example.ui.theme.AmberWarning
import com.example.ui.theme.BorderLight
import com.example.ui.theme.CyanContainer
import com.example.ui.theme.CyanDark
import com.example.ui.theme.CyanLight
import com.example.ui.theme.CyanPrimary
import com.example.ui.theme.EmeraldLight
import com.example.ui.theme.EmeraldSuccess
import com.example.ui.theme.ForestGreenBorder
import com.example.ui.theme.ForestGreenDark
import com.example.ui.theme.ForestGreenLight
import com.example.ui.theme.ForestGreenPrimary
import com.example.ui.theme.Navy800
import com.example.ui.theme.Navy900
import com.example.ui.theme.PureWhite
import com.example.ui.theme.RoyalCobaltBlue
import com.example.ui.theme.RoyalCobaltIce
import com.example.ui.theme.TextSecondary

@Composable
fun TheWorkshopOverviewSection(
    workshopItems: List<WorkshopProductionItem>,
    craftsmenList: List<StaffAccount>,
    inventoryMaterials: List<InventoryMaterialItem>,
    casketStockByBranch: List<CasketStockByBranchRow>,
    onOpenLiveWorkshop: () -> Unit,
    onOpenInventory: () -> Unit,
    onNavigateTab: (NavTab) -> Unit
) {
    // Default mock items if none provided from backend
    val effectiveWorkshopItems = if (workshopItems.isNotEmpty()) workshopItems else listOf(
        WorkshopProductionItem(
            id = "JOB-001",
            casketType = "VIP Casket",
            woodType = "Hardwood Mahogany",
            currentStage = WorkshopProductionStage.SANDING_AND_PAINTING,
            percentageDone = 50,
            assignedCraftsmanId = "WRK-001",
            assignedCraftsmanName = "Brian Adoche",
            isDoneForDay = false,
            startedDate = "12 Oct",
            targetCompletionDate = "16 Oct",
            notes = "High-gloss walnut finish requested with gold swing handles"
        ),
        WorkshopProductionItem(
            id = "JOB-002",
            casketType = "Executive Dome",
            woodType = "Seasoned Cypress",
            currentStage = WorkshopProductionStage.CLOTH_LINING_AND_FINAL_ASSEMBLY,
            percentageDone = 75,
            assignedCraftsmanId = "WRK-003",
            assignedCraftsmanName = "John Hayoyo",
            isDoneForDay = true,
            startedDate = "11 Oct",
            targetCompletionDate = "15 Oct",
            notes = "Premium royal blue velvet lining & satin pillow fitted"
        ),
        WorkshopProductionItem(
            id = "JOB-003",
            casketType = "Modern High Roof",
            woodType = "Red Hardwood",
            currentStage = WorkshopProductionStage.GLASS_FITTING,
            percentageDone = 100,
            assignedCraftsmanId = "WRK-002",
            assignedCraftsmanName = "George Munono",
            isDoneForDay = false,
            startedDate = "13 Oct",
            targetCompletionDate = "17 Oct",
            notes = "Final glass inspection and airtight sealant verified"
        ),
        WorkshopProductionItem(
            id = "JOB-004",
            casketType = "Half Glass Dome",
            woodType = "Selected Pine",
            currentStage = WorkshopProductionStage.FRAME_AND_ASSEMBLY,
            percentageDone = 25,
            assignedCraftsmanId = "WRK-004",
            assignedCraftsmanName = "Stephen Odhiambo",
            isDoneForDay = false,
            startedDate = "14 Oct",
            targetCompletionDate = "18 Oct",
            notes = "Precision bevel cutting for reinforced tempered viewing glass"
        )
    )

    // Craftsmen list (All Stationed at Workshop)
    val effectiveCraftsmen = if (craftsmenList.isNotEmpty()) craftsmenList else listOf(
        StaffAccount(id = "WRK-001", fullName = "Brian Adoche", email = "badoche@jabimafuneral.co.ke", phone = "+254 711 201 001", role = StaffRole.WORKSHOP_WORKER, department = Department.WORKSHOP, password = "password123", nationalId = "28349101", branch = "Workshop"),
        StaffAccount(id = "WRK-002", fullName = "George Munono", email = "gmunono@jabimafuneral.co.ke", phone = "+254 711 201 002", role = StaffRole.WORKSHOP_WORKER, department = Department.WORKSHOP, password = "password123", nationalId = "28349102", branch = "Workshop"),
        StaffAccount(id = "WRK-003", fullName = "John Hayoyo", email = "jhayoyo@jabimafuneral.co.ke", phone = "+254 711 201 003", role = StaffRole.WORKSHOP_WORKER, department = Department.WORKSHOP, password = "password123", nationalId = "28349103", branch = "Workshop"),
        StaffAccount(id = "WRK-004", fullName = "Stephen Odhiambo", email = "sodhiambo@jabimafuneral.co.ke", phone = "+254 711 201 024", role = StaffRole.WORKSHOP_WORKER, department = Department.WORKSHOP, password = "password123", nationalId = "28349124", branch = "Workshop"),
        StaffAccount(id = "WRK-005", fullName = "Richard Opiyo", email = "ropiyo@jabimafuneral.co.ke", phone = "+254 711 201 005", role = StaffRole.WORKSHOP_WORKER, department = Department.WORKSHOP, password = "password123", nationalId = "28349105", branch = "Workshop"),
        StaffAccount(id = "WRK-006", fullName = "Daniel Wagweru", email = "dwagweru@jabimafuneral.co.ke", phone = "+254 711 201 006", role = StaffRole.WORKSHOP_WORKER, department = Department.WORKSHOP, password = "password123", nationalId = "28349106", branch = "Workshop"),
        StaffAccount(id = "WRK-007", fullName = "Noaah Wagweru", email = "nwagweru@jabimafuneral.co.ke", phone = "+254 711 201 007", role = StaffRole.WORKSHOP_WORKER, department = Department.WORKSHOP, password = "password123", nationalId = "28349107", branch = "Workshop")
    )

    // Materials list
    val effectiveMaterials = if (inventoryMaterials.isNotEmpty()) inventoryMaterials else listOf(
        InventoryMaterialItem("MAT-01", "Hardwood Mahogany Timber", "CAT-01", "Timber & Wood", 145, "Boards (12ft)", 2800.0, 30),
        InventoryMaterialItem("MAT-02", "Seasoned Cypress Planks", "CAT-01", "Timber & Wood", 210, "Boards (10ft)", 1650.0, 40),
        InventoryMaterialItem("MAT-03", "Clear High-Gloss Lacquer", "CAT-02", "Finishing & Paint", 38, "Litres (5L Tins)", 3200.0, 15),
        InventoryMaterialItem("MAT-04", "Royal Blue Velvet Fabric", "CAT-03", "Linings & Fabric", 75, "Metres (Rolls)", 950.0, 20),
        InventoryMaterialItem("MAT-05", "Gold Heavy Swing Handles", "CAT-04", "Fittings & Hardware", 160, "Pairs (Sets)", 1400.0, 25),
        InventoryMaterialItem("MAT-06", "Tempered Viewing Glass Panes", "CAT-05", "Glass & Panels", 28, "Pieces", 2200.0, 10)
    )

    val activeCount = effectiveWorkshopItems.count { !it.isCompleted }
    val doneTodayCount = effectiveWorkshopItems.count { it.isDoneForDay }
    val totalCraftsmen = effectiveCraftsmen.size

    Column(
        modifier = Modifier
            .fillMaxWidth()
            .testTag("the_workshop_overview_section"),
        verticalArrangement = Arrangement.spacedBy(14.dp)
    ) {
        // =========================================================================
        // 1. WORKSHOP HERO CARD
        // =========================================================================
        Card(
            shape = RoundedCornerShape(18.dp),
            colors = CardDefaults.cardColors(containerColor = Color.Transparent),
            modifier = Modifier
                .fillMaxWidth()
                .testTag("the_workshop_hero_card")
        ) {
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .background(
                        brush = Brush.linearGradient(
                            colors = listOf(Navy900, ForestGreenDark, ForestGreenPrimary)
                        )
                    )
                    .padding(18.dp)
            ) {
                Column {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Box(
                                modifier = Modifier
                                    .size(42.dp)
                                    .clip(CircleShape)
                                    .background(PureWhite.copy(alpha = 0.15f)),
                                contentAlignment = Alignment.Center
                            ) {
                                Icon(
                                    imageVector = Icons.Default.PrecisionManufacturing,
                                    contentDescription = null,
                                    tint = PureWhite,
                                    modifier = Modifier.size(24.dp)
                                )
                            }
                            Spacer(modifier = Modifier.width(12.dp))
                            Column {
                                Text(
                                    text = "The Workshop Operations & Stock",
                                    color = PureWhite,
                                    fontSize = 17.sp,
                                    fontWeight = FontWeight.ExtraBold
                                )
                                Text(
                                    text = "Central Production Depot • All Craftsmen Stationed at Workshop",
                                    color = PureWhite.copy(alpha = 0.85f),
                                    fontSize = 11.sp
                                )
                            }
                        }

                        Surface(
                            shape = RoundedCornerShape(8.dp),
                            color = PureWhite.copy(alpha = 0.2f)
                        ) {
                            Text(
                                text = "LIVE OPERATIONS",
                                fontSize = 10.sp,
                                fontWeight = FontWeight.Bold,
                                color = PureWhite,
                                modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp)
                            )
                        }
                    }

                    Spacer(modifier = Modifier.height(14.dp))

                    // 4 QUICK COUNTERS
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        WorkshopMetricBadge(
                            title = "In Production",
                            value = "$activeCount Jobs",
                            subtitle = "Active at benches",
                            modifier = Modifier.weight(1f)
                        )
                        WorkshopMetricBadge(
                            title = "Done Today",
                            value = "$doneTodayCount Caskets",
                            subtitle = "Stage milestone reached",
                            modifier = Modifier.weight(1f)
                        )
                        WorkshopMetricBadge(
                            title = "Station Craftsmen",
                            value = "$totalCraftsmen Artisans",
                            subtitle = "100% Based at Workshop",
                            modifier = Modifier.weight(1f)
                        )
                        WorkshopMetricBadge(
                            title = "Raw Materials",
                            value = "${effectiveMaterials.size} Catalogued",
                            subtitle = "Timber & Finishes",
                            modifier = Modifier.weight(1f)
                        )
                    }

                    Spacer(modifier = Modifier.height(14.dp))

                    // QUICK ACTION BUTTONS
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        Button(
                            onClick = {
                                onOpenLiveWorkshop()
                                onNavigateTab(NavTab.WORKSHOP_PRODUCTION)
                            },
                            colors = ButtonDefaults.buttonColors(containerColor = PureWhite),
                            shape = RoundedCornerShape(10.dp),
                            modifier = Modifier
                                .weight(1f)
                                .height(40.dp)
                                .testTag("btn_open_live_workshop_from_overview")
                        ) {
                            Icon(Icons.Default.PrecisionManufacturing, contentDescription = null, tint = ForestGreenDark, modifier = Modifier.size(16.dp))
                            Spacer(modifier = Modifier.width(6.dp))
                            Text("Live Production Hub", color = ForestGreenDark, fontSize = 12.sp, fontWeight = FontWeight.Bold)
                        }

                        OutlinedButton(
                            onClick = {
                                onOpenInventory()
                                onNavigateTab(NavTab.INVENTORY_MANAGEMENT)
                            },
                            colors = ButtonDefaults.outlinedButtonColors(contentColor = PureWhite),
                            border = BorderStroke(1.dp, PureWhite.copy(alpha = 0.6f)),
                            shape = RoundedCornerShape(10.dp),
                            modifier = Modifier
                                .weight(1f)
                                .height(40.dp)
                                .testTag("btn_open_inventory_from_overview")
                        ) {
                            Icon(Icons.Default.Inventory, contentDescription = null, tint = PureWhite, modifier = Modifier.size(16.dp))
                            Spacer(modifier = Modifier.width(6.dp))
                            Text("Manage Stock & Timber", color = PureWhite, fontSize = 12.sp, fontWeight = FontWeight.Bold)
                        }
                    }
                }
            }
        }

        // =========================================================================
        // 2. LIVE PRODUCTION JOBS (IN-PROGRESS CASKETS)
        // =========================================================================
        Card(
            shape = RoundedCornerShape(16.dp),
            colors = CardDefaults.cardColors(containerColor = PureWhite),
            border = BorderStroke(1.dp, BorderLight),
            modifier = Modifier
                .fillMaxWidth()
                .testTag("workshop_live_production_card")
        ) {
            Column(modifier = Modifier.padding(16.dp)) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Column {
                        Text(
                            text = "Live Workshop Production Jobs",
                            fontWeight = FontWeight.Bold,
                            fontSize = 15.sp,
                            color = Navy900
                        )
                        Text(
                            text = "Step-by-step casket fabrication stages at Central Workshop",
                            fontSize = 11.sp,
                            color = TextSecondary
                        )
                    }

                    Text(
                        text = "View All (${effectiveWorkshopItems.size})",
                        fontSize = 12.sp,
                        fontWeight = FontWeight.Bold,
                        color = ForestGreenPrimary,
                        modifier = Modifier
                            .clickable {
                                onOpenLiveWorkshop()
                                onNavigateTab(NavTab.WORKSHOP_PRODUCTION)
                            }
                            .padding(4.dp)
                    )
                }

                Spacer(modifier = Modifier.height(12.dp))

                effectiveWorkshopItems.take(4).forEach { item ->
                    ProductionJobRowItem(item = item)
                    Spacer(modifier = Modifier.height(10.dp))
                }
            }
        }

        // =========================================================================
        // 3. WORKSHOP CRAFTSMEN ON DUTY (ALL BASED AT WORKSHOP)
        // =========================================================================
        Card(
            shape = RoundedCornerShape(16.dp),
            colors = CardDefaults.cardColors(containerColor = PureWhite),
            border = BorderStroke(1.dp, BorderLight),
            modifier = Modifier
                .fillMaxWidth()
                .testTag("workshop_craftsmen_team_card")
        ) {
            Column(modifier = Modifier.padding(16.dp)) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Column {
                        Text(
                            text = "Station Craftsmen Team (7 Master Artisans)",
                            fontWeight = FontWeight.Bold,
                            fontSize = 15.sp,
                            color = Navy900
                        )
                        Text(
                            text = "All craftsmen are based at the Workshop for fabrication & carpentry",
                            fontSize = 11.sp,
                            color = ForestGreenPrimary,
                            fontWeight = FontWeight.SemiBold
                        )
                    }

                    Surface(
                        shape = RoundedCornerShape(8.dp),
                        color = ForestGreenLight
                    ) {
                        Text(
                            text = "Base: Workshop",
                            fontSize = 10.sp,
                            fontWeight = FontWeight.Bold,
                            color = ForestGreenPrimary,
                            modifier = Modifier.padding(horizontal = 8.dp, vertical = 3.dp)
                        )
                    }
                }

                Spacer(modifier = Modifier.height(12.dp))

                // Scrollable row of craftsmen tiles
                val craftsmenScroll = rememberScrollState()
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .horizontalScroll(craftsmenScroll),
                    horizontalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    effectiveCraftsmen.forEach { craftsman ->
                        CraftsmanSummaryTile(craftsman = craftsman)
                    }
                }
            }
        }

        // =========================================================================
        // 4. WORKSHOP RAW MATERIALS & TIMBER STOCK
        // =========================================================================
        Card(
            shape = RoundedCornerShape(16.dp),
            colors = CardDefaults.cardColors(containerColor = PureWhite),
            border = BorderStroke(1.dp, BorderLight),
            modifier = Modifier
                .fillMaxWidth()
                .testTag("workshop_raw_materials_card")
        ) {
            Column(modifier = Modifier.padding(16.dp)) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Column {
                        Text(
                            text = "Workshop Raw Materials & Supplies Stock",
                            fontWeight = FontWeight.Bold,
                            fontSize = 15.sp,
                            color = Navy900
                        )
                        Text(
                            text = "Hardwood timber, finishes, fabrics, glass & metal fittings",
                            fontSize = 11.sp,
                            color = TextSecondary
                        )
                    }

                    Text(
                        text = "Open Inventory",
                        fontSize = 12.sp,
                        fontWeight = FontWeight.Bold,
                        color = RoyalCobaltBlue,
                        modifier = Modifier
                            .clickable {
                                onOpenInventory()
                                onNavigateTab(NavTab.INVENTORY_MANAGEMENT)
                            }
                            .padding(4.dp)
                    )
                }

                Spacer(modifier = Modifier.height(12.dp))

                Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    effectiveMaterials.forEach { mat ->
                        MaterialStockSummaryRow(material = mat)
                    }
                }
            }
        }

        // =========================================================================
        // 5. COMPLETE 16 CASKET TYPES STOCK BY BRANCH (TABULATED MATRIX)
        // Products: Dragon, Dumu Mayai, English Coffin, Executive, Giraffe Flat,
        // Half Glass, Half Glass Dome, Kids, Kupa, Mini Executive, Modern High Roof,
        // Reagan, Saitoti, Simple, Tonny, VIP
        // =========================================================================
        Card(
            shape = RoundedCornerShape(16.dp),
            colors = CardDefaults.cardColors(containerColor = PureWhite),
            border = BorderStroke(1.dp, BorderLight),
            modifier = Modifier
                .fillMaxWidth()
                .testTag("the_workshop_casket_stock_matrix_card")
        ) {
            Column(modifier = Modifier.padding(16.dp)) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Column {
                        Text(
                            text = "Finished Casket Stock By Branch (16 Types)",
                            fontWeight = FontWeight.Bold,
                            fontSize = 15.sp,
                            color = Navy900
                        )
                        Text(
                            text = "16 casket models vertically • 8 branches tabulated horizontally",
                            fontSize = 11.sp,
                            color = TextSecondary
                        )
                    }

                    Surface(
                        shape = RoundedCornerShape(10.dp),
                        color = RoyalCobaltIce
                    ) {
                        Text(
                            text = "Tabulated Live Matrix",
                            fontSize = 10.sp,
                            fontWeight = FontWeight.Bold,
                            color = RoyalCobaltBlue,
                            modifier = Modifier.padding(horizontal = 8.dp, vertical = 3.dp)
                        )
                    }
                }

                Spacer(modifier = Modifier.height(12.dp))

                // Scrollable Table for 16 casket types across 8 branches
                val horizontalScroll = rememberScrollState()
                val branches = JABIMA_BRANCHES

                Box(
                    modifier = Modifier
                        .fillMaxWidth()
                        .clip(RoundedCornerShape(8.dp))
                        .border(1.dp, Color(0xFFCBD5E1), RoundedCornerShape(8.dp))
                ) {
                    Column(
                        modifier = Modifier
                            .horizontalScroll(horizontalScroll)
                            .background(PureWhite)
                    ) {
                        // TABLE HEADER
                        Row(
                            modifier = Modifier
                                .background(Color(0xFF0F172A))
                                .padding(vertical = 10.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Text(
                                text = "CASKET TYPE",
                                color = Color.White,
                                fontSize = 11.sp,
                                fontWeight = FontWeight.Bold,
                                modifier = Modifier
                                    .width(140.dp)
                                    .padding(start = 12.dp)
                            )

                            branches.forEach { branch ->
                                val shortBranch = when (branch) {
                                    "Siaya opposite Shell Petrol" -> "Siaya Shell"
                                    "Siaya Referral (Opposite Morgue)" -> "Siaya Referral"
                                    else -> branch
                                }
                                Text(
                                    text = shortBranch.uppercase(),
                                    color = Color(0xFF93C5FD),
                                    fontSize = 10.sp,
                                    fontWeight = FontWeight.Bold,
                                    modifier = Modifier
                                        .width(90.dp)
                                        .padding(horizontal = 6.dp)
                                )
                            }

                            Text(
                                text = "TOTAL STOCK",
                                color = EmeraldLight,
                                fontSize = 10.sp,
                                fontWeight = FontWeight.ExtraBold,
                                modifier = Modifier
                                    .width(95.dp)
                                    .padding(horizontal = 8.dp)
                            )
                        }

                        // 16 CASKET TYPES (VERTICAL ROWS)
                        val tableRows = if (casketStockByBranch.isNotEmpty()) casketStockByBranch else {
                            listOf(
                                CasketStockByBranchRow("Dragon", mapOf("Bama Branch" to 8, "Bondo" to 3, "Matibabu" to 2, "Siaya opposite Shell Petrol" to 4, "Ukwala" to 1, "Uradi" to 2, "Siaya Referral (Opposite Morgue)" to 5, "Rangala" to 1), 65000.0),
                                CasketStockByBranchRow("Dumu Mayai", mapOf("Bama Branch" to 6, "Bondo" to 2, "Matibabu" to 1, "Siaya opposite Shell Petrol" to 3, "Ukwala" to 1, "Uradi" to 1, "Siaya Referral (Opposite Morgue)" to 4, "Rangala" to 2), 55000.0),
                                CasketStockByBranchRow("English Coffin", mapOf("Bama Branch" to 10, "Bondo" to 4, "Matibabu" to 3, "Siaya opposite Shell Petrol" to 5, "Ukwala" to 2, "Uradi" to 3, "Siaya Referral (Opposite Morgue)" to 6, "Rangala" to 2), 48000.0),
                                CasketStockByBranchRow("Executive", mapOf("Bama Branch" to 12, "Bondo" to 5, "Matibabu" to 4, "Siaya opposite Shell Petrol" to 6, "Ukwala" to 3, "Uradi" to 2, "Siaya Referral (Opposite Morgue)" to 7, "Rangala" to 3), 110000.0),
                                CasketStockByBranchRow("Giraffe Flat", mapOf("Bama Branch" to 5, "Bondo" to 2, "Matibabu" to 1, "Siaya opposite Shell Petrol" to 2, "Ukwala" to 1, "Uradi" to 1, "Siaya Referral (Opposite Morgue)" to 3, "Rangala" to 1), 58000.0),
                                CasketStockByBranchRow("Half Glass", mapOf("Bama Branch" to 9, "Bondo" to 4, "Matibabu" to 2, "Siaya opposite Shell Petrol" to 5, "Ukwala" to 2, "Uradi" to 2, "Siaya Referral (Opposite Morgue)" to 6, "Rangala" to 2), 75000.0),
                                CasketStockByBranchRow("Half Glass Dome", mapOf("Bama Branch" to 8, "Bondo" to 3, "Matibabu" to 3, "Siaya opposite Shell Petrol" to 4, "Ukwala" to 2, "Uradi" to 1, "Siaya Referral (Opposite Morgue)" to 5, "Rangala" to 2), 85000.0),
                                CasketStockByBranchRow("Kids", mapOf("Bama Branch" to 7, "Bondo" to 2, "Matibabu" to 2, "Siaya opposite Shell Petrol" to 3, "Ukwala" to 1, "Uradi" to 1, "Siaya Referral (Opposite Morgue)" to 4, "Rangala" to 1), 30000.0),
                                CasketStockByBranchRow("Kupa", mapOf("Bama Branch" to 6, "Bondo" to 2, "Matibabu" to 1, "Siaya opposite Shell Petrol" to 3, "Ukwala" to 1, "Uradi" to 2, "Siaya Referral (Opposite Morgue)" to 3, "Rangala" to 1), 52000.0),
                                CasketStockByBranchRow("Mini Executive", mapOf("Bama Branch" to 8, "Bondo" to 3, "Matibabu" to 2, "Siaya opposite Shell Petrol" to 4, "Ukwala" to 2, "Uradi" to 1, "Siaya Referral (Opposite Morgue)" to 5, "Rangala" to 2), 88000.0),
                                CasketStockByBranchRow("Modern High Roof", mapOf("Bama Branch" to 11, "Bondo" to 4, "Matibabu" to 3, "Siaya opposite Shell Petrol" to 6, "Ukwala" to 2, "Uradi" to 3, "Siaya Referral (Opposite Morgue)" to 7, "Rangala" to 3), 125000.0),
                                CasketStockByBranchRow("Reagan", mapOf("Bama Branch" to 7, "Bondo" to 3, "Matibabu" to 2, "Siaya opposite Shell Petrol" to 4, "Ukwala" to 1, "Uradi" to 2, "Siaya Referral (Opposite Morgue)" to 4, "Rangala" to 2), 95000.0),
                                CasketStockByBranchRow("Saitoti", mapOf("Bama Branch" to 9, "Bondo" to 3, "Matibabu" to 2, "Siaya opposite Shell Petrol" to 4, "Ukwala" to 2, "Uradi" to 2, "Siaya Referral (Opposite Morgue)" to 5, "Rangala" to 2), 105000.0),
                                CasketStockByBranchRow("Simple", mapOf("Bama Branch" to 14, "Bondo" to 6, "Matibabu" to 5, "Siaya opposite Shell Petrol" to 8, "Ukwala" to 4, "Uradi" to 4, "Siaya Referral (Opposite Morgue)" to 9, "Rangala" to 5), 25000.0),
                                CasketStockByBranchRow("Tonny", mapOf("Bama Branch" to 6, "Bondo" to 2, "Matibabu" to 1, "Siaya opposite Shell Petrol" to 3, "Ukwala" to 1, "Uradi" to 1, "Siaya Referral (Opposite Morgue)" to 4, "Rangala" to 1), 60000.0),
                                CasketStockByBranchRow("VIP", mapOf("Bama Branch" to 10, "Bondo" to 4, "Matibabu" to 3, "Siaya opposite Shell Petrol" to 5, "Ukwala" to 2, "Uradi" to 2, "Siaya Referral (Opposite Morgue)" to 6, "Rangala" to 3), 140000.0)
                            )
                        }

                        tableRows.forEachIndexed { index, row ->
                            val rowBg = if (index % 2 == 0) PureWhite else Color(0xFFF8FAFC)
                            Row(
                                modifier = Modifier
                                    .background(rowBg)
                                    .padding(vertical = 8.dp),
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Text(
                                    text = row.casketType,
                                    fontWeight = FontWeight.Bold,
                                    fontSize = 12.sp,
                                    color = Navy900,
                                    modifier = Modifier
                                        .width(140.dp)
                                        .padding(start = 12.dp)
                                )

                                branches.forEach { branch ->
                                    val qty = row.branchStockMap[branch] ?: 0
                                    Text(
                                        text = "$qty",
                                        fontWeight = if (qty > 3) FontWeight.SemiBold else FontWeight.Normal,
                                        fontSize = 12.sp,
                                        color = if (qty <= 1) AmberWarning else Navy900,
                                        modifier = Modifier
                                            .width(90.dp)
                                            .padding(horizontal = 6.dp)
                                    )
                                }

                                Surface(
                                    shape = RoundedCornerShape(6.dp),
                                    color = if (row.totalStock >= 10) EmeraldLight else AmberLight,
                                    modifier = Modifier
                                        .width(85.dp)
                                        .padding(horizontal = 4.dp)
                                ) {
                                    Text(
                                        text = "${row.totalStock} units",
                                        fontSize = 11.sp,
                                        fontWeight = FontWeight.ExtraBold,
                                        color = if (row.totalStock >= 10) EmeraldSuccess else AmberWarning,
                                        modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp)
                                    )
                                }
                            }
                        }

                        // SUMMARY FOOTER ROW
                        Row(
                            modifier = Modifier
                                .background(Color(0xFFE2E8F0))
                                .padding(vertical = 10.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Text(
                                text = "BRANCH TOTALS",
                                color = Navy900,
                                fontSize = 11.sp,
                                fontWeight = FontWeight.ExtraBold,
                                modifier = Modifier
                                    .width(140.dp)
                                    .padding(start = 12.dp)
                            )

                            val grandTotal = tableRows.sumOf { it.totalStock }
                            branches.forEach { branch ->
                                val branchTotal = tableRows.sumOf { it.branchStockMap[branch] ?: 0 }
                                Text(
                                    text = "$branchTotal",
                                    color = RoyalCobaltBlue,
                                    fontSize = 11.sp,
                                    fontWeight = FontWeight.ExtraBold,
                                    modifier = Modifier
                                        .width(90.dp)
                                        .padding(horizontal = 6.dp)
                                )
                            }

                            Text(
                                text = "$grandTotal",
                                color = EmeraldSuccess,
                                fontSize = 12.sp,
                                fontWeight = FontWeight.ExtraBold,
                                modifier = Modifier
                                    .width(95.dp)
                                    .padding(horizontal = 8.dp)
                            )
                        }
                    }
                }
            }
        }
    }
}

@Composable
private fun WorkshopMetricBadge(
    title: String,
    value: String,
    subtitle: String,
    modifier: Modifier = Modifier
) {
    Surface(
        color = PureWhite.copy(alpha = 0.12f),
        shape = RoundedCornerShape(10.dp),
        border = BorderStroke(1.dp, PureWhite.copy(alpha = 0.2f)),
        modifier = modifier
    ) {
        Column(modifier = Modifier.padding(8.dp)) {
            Text(text = title, color = PureWhite.copy(alpha = 0.8f), fontSize = 10.sp, fontWeight = FontWeight.Medium)
            Spacer(modifier = Modifier.height(2.dp))
            Text(text = value, color = PureWhite, fontSize = 13.sp, fontWeight = FontWeight.ExtraBold)
            Spacer(modifier = Modifier.height(2.dp))
            Text(text = subtitle, color = PureWhite.copy(alpha = 0.7f), fontSize = 8.sp)
        }
    }
}

@Composable
private fun ProductionJobRowItem(item: WorkshopProductionItem) {
    Surface(
        color = Color(0xFFF8FAFC),
        shape = RoundedCornerShape(10.dp),
        border = BorderStroke(1.dp, BorderLight),
        modifier = Modifier.fillMaxWidth()
    ) {
        Column(modifier = Modifier.padding(10.dp)) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Box(
                        modifier = Modifier
                            .size(28.dp)
                            .clip(CircleShape)
                            .background(Color(item.currentStage.colorHex).copy(alpha = 0.15f)),
                        contentAlignment = Alignment.Center
                    ) {
                        Icon(
                            imageVector = when (item.currentStage) {
                                WorkshopProductionStage.FRAME_AND_ASSEMBLY -> Icons.Default.Build
                                WorkshopProductionStage.SANDING_AND_PAINTING -> Icons.Default.FormatPaint
                                WorkshopProductionStage.CLOTH_LINING_AND_FINAL_ASSEMBLY -> Icons.Default.Layers
                                WorkshopProductionStage.GLASS_FITTING -> Icons.Default.CheckCircle
                            },
                            contentDescription = null,
                            tint = Color(item.currentStage.colorHex),
                            modifier = Modifier.size(15.dp)
                        )
                    }

                    Spacer(modifier = Modifier.width(8.dp))

                    Column {
                        Text(
                            text = item.casketType,
                            fontWeight = FontWeight.Bold,
                            fontSize = 13.sp,
                            color = Navy900
                        )
                        Text(
                            text = "${item.woodType} • Assigned: ${item.assignedCraftsmanName}",
                            fontSize = 10.sp,
                            color = TextSecondary
                        )
                    }
                }

                Surface(
                    shape = RoundedCornerShape(6.dp),
                    color = Color(item.currentStage.colorHex).copy(alpha = 0.12f)
                ) {
                    Text(
                        text = item.currentStage.title,
                        fontSize = 10.sp,
                        fontWeight = FontWeight.Bold,
                        color = Color(item.currentStage.colorHex),
                        modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp)
                    )
                }
            }

            Spacer(modifier = Modifier.height(8.dp))

            Row(
                modifier = Modifier.fillMaxWidth(),
                verticalAlignment = Alignment.CenterVertically
            ) {
                LinearProgressIndicator(
                    progress = { item.percentageDone / 100f },
                    modifier = Modifier
                        .weight(1f)
                        .height(6.dp)
                        .clip(RoundedCornerShape(3.dp)),
                    color = Color(item.currentStage.colorHex),
                    trackColor = Color(0xFFE2E8F0)
                )
                Spacer(modifier = Modifier.width(8.dp))
                Text(
                    text = "${item.percentageDone}%",
                    fontSize = 11.sp,
                    fontWeight = FontWeight.ExtraBold,
                    color = Color(item.currentStage.colorHex)
                )
            }
        }
    }
}

@Composable
private fun CraftsmanSummaryTile(craftsman: StaffAccount) {
    Surface(
        color = Color(0xFFF1F5F9),
        shape = RoundedCornerShape(12.dp),
        border = BorderStroke(1.dp, Color(0xFFCBD5E1)),
        modifier = Modifier.width(155.dp)
    ) {
        Column(modifier = Modifier.padding(10.dp)) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Box(
                    modifier = Modifier
                        .size(32.dp)
                        .clip(CircleShape)
                        .background(ForestGreenPrimary),
                    contentAlignment = Alignment.Center
                ) {
                    Text(
                        text = craftsman.fullName.split(" ").mapNotNull { it.firstOrNull()?.toString() }.take(2).joinToString(""),
                        color = PureWhite,
                        fontSize = 11.sp,
                        fontWeight = FontWeight.Bold
                    )
                }

                Spacer(modifier = Modifier.width(8.dp))

                Column {
                    Text(
                        text = craftsman.fullName,
                        fontWeight = FontWeight.Bold,
                        fontSize = 11.sp,
                        color = Navy900,
                        maxLines = 1
                    )
                    Text(
                        text = craftsman.id,
                        fontSize = 9.sp,
                        color = TextSecondary
                    )
                }
            }

            Spacer(modifier = Modifier.height(6.dp))

            Surface(
                shape = RoundedCornerShape(4.dp),
                color = ForestGreenLight,
                modifier = Modifier.fillMaxWidth()
            ) {
                Text(
                    text = "Base: Workshop",
                    fontSize = 9.sp,
                    fontWeight = FontWeight.Bold,
                    color = ForestGreenPrimary,
                    modifier = Modifier.padding(horizontal = 4.dp, vertical = 2.dp)
                )
            }
        }
    }
}

@Composable
private fun MaterialStockSummaryRow(material: InventoryMaterialItem) {
    Surface(
        color = Color(0xFFF8FAFC),
        shape = RoundedCornerShape(8.dp),
        border = BorderStroke(1.dp, BorderLight),
        modifier = Modifier.fillMaxWidth()
    ) {
        Row(
            modifier = Modifier.padding(horizontal = 10.dp, vertical = 8.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.SpaceBetween
        ) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Icon(Icons.Default.Inventory, contentDescription = null, tint = RoyalCobaltBlue, modifier = Modifier.size(16.dp))
                Spacer(modifier = Modifier.width(8.dp))
                Column {
                    Text(
                        text = material.name,
                        fontSize = 12.sp,
                        fontWeight = FontWeight.SemiBold,
                        color = Navy900
                    )
                    Text(
                        text = "${material.categoryName} • Min: ${material.minThreshold} ${material.unit}",
                        fontSize = 9.sp,
                        color = TextSecondary
                    )
                }
            }

            Surface(
                shape = RoundedCornerShape(6.dp),
                color = if (material.isLowStock) AmberLight else EmeraldLight
            ) {
                Text(
                    text = "${material.quantity} ${material.unit}",
                    fontSize = 10.sp,
                    fontWeight = FontWeight.Bold,
                    color = if (material.isLowStock) AmberWarning else EmeraldSuccess,
                    modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp)
                )
            }
        }
    }
}
