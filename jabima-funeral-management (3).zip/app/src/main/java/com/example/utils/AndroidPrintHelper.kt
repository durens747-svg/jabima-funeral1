package com.example.utils

import android.content.Context
import android.content.Intent
import android.graphics.Bitmap
import android.os.Bundle
import android.os.CancellationSignal
import android.os.ParcelFileDescriptor
import android.print.PageRange
import android.print.PrintAttributes
import android.print.PrintDocumentAdapter
import android.print.PrintDocumentInfo
import android.print.PrintManager
import androidx.core.content.FileProvider
import java.io.File
import java.io.FileInputStream
import java.io.FileOutputStream

/**
 * Zero-permission Android Print Framework & FileProvider export helper.
 * Supports Wi-Fi, Mopria, USB, and system PDF printers directly via Android PrintManager.
 */
object AndroidPrintHelper {

    fun printPdfFile(
        context: Context,
        pdfFile: File,
        jobName: String
    ): Result<Unit> {
        return runCatching {
            val printManager = context.getSystemService(Context.PRINT_SERVICE) as? PrintManager
                ?: throw IllegalStateException("Android Print Service is unavailable on this device.")
            val safeJobName = jobName.trim().ifBlank { "Jabima Funeral Document" }.take(80)
            val adapter = object : PrintDocumentAdapter() {
                override fun onLayout(
                    oldAttributes: PrintAttributes?,
                    newAttributes: PrintAttributes?,
                    cancellationSignal: CancellationSignal?,
                    callback: LayoutResultCallback,
                    extras: Bundle?
                ) {
                    if (cancellationSignal?.isCanceled == true) {
                        callback.onLayoutCancelled()
                        return
                    }
                    val info = PrintDocumentInfo.Builder(pdfFile.name)
                        .setContentType(PrintDocumentInfo.CONTENT_TYPE_DOCUMENT)
                        .setPageCount(PrintDocumentInfo.PAGE_COUNT_UNKNOWN)
                        .build()
                    callback.onLayoutFinished(info, newAttributes != oldAttributes)
                }

                override fun onWrite(
                    pages: Array<out PageRange>?,
                    destination: ParcelFileDescriptor,
                    cancellationSignal: CancellationSignal?,
                    callback: WriteResultCallback
                ) {
                    if (cancellationSignal?.isCanceled == true) {
                        callback.onWriteCancelled()
                        return
                    }
                    try {
                        FileInputStream(pdfFile).use { input ->
                            FileOutputStream(destination.fileDescriptor).use { output ->
                                input.copyTo(output)
                            }
                        }
                        if (cancellationSignal?.isCanceled == true) {
                            callback.onWriteCancelled()
                        } else {
                            callback.onWriteFinished(arrayOf(PageRange.ALL_PAGES))
                        }
                    } catch (t: Throwable) {
                        callback.onWriteFailed(t.localizedMessage ?: "Failed to spool PDF to printer")
                    }
                }
            }
            printManager.print(safeJobName, adapter, PrintAttributes.Builder().build())
        }
    }

    fun saveBitmapToCacheAndShare(
        context: Context,
        bitmap: Bitmap,
        fileNamePrefix: String,
        shareTitle: String
    ): Result<File> {
        return runCatching {
            val outDir = File(context.cacheDir, "shared_images").apply { mkdirs() }
            val cleanPrefix = fileNamePrefix.replace(Regex("[^a-zA-Z0-9_\\-]"), "_").take(40).ifBlank { "case_doc" }
            val outFile = File(outDir, "${cleanPrefix}_${System.currentTimeMillis()}.jpg")
            FileOutputStream(outFile).use { stream ->
                bitmap.compress(Bitmap.CompressFormat.JPEG, 92, stream)
            }
            val uri = FileProvider.getUriForFile(
                context,
                "${context.packageName}.fileprovider",
                outFile
            )
            val intent = Intent(Intent.ACTION_SEND).apply {
                type = "image/jpeg"
                putExtra(Intent.EXTRA_STREAM, uri)
                putExtra(Intent.EXTRA_SUBJECT, shareTitle)
                addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
                addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            }
            val chooser = Intent.createChooser(intent, shareTitle).apply {
                addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
            }
            context.startActivity(chooser)
            outFile
        }
    }
}
