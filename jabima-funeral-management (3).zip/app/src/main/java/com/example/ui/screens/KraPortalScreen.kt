package com.example.ui.screens

import android.content.Intent
import android.net.Uri
import android.widget.Toast
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowForward
import androidx.compose.material.icons.filled.AccountBalance
import androidx.compose.material.icons.filled.Calculate
import androidx.compose.material.icons.filled.Check
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.ContentCopy
import androidx.compose.material.icons.filled.Download
import androidx.compose.material.icons.filled.EventNote
import androidx.compose.material.icons.filled.Launch
import androidx.compose.material.icons.filled.QrCode
import androidx.compose.material.icons.filled.ReceiptLong
import androidx.compose.material.icons.filled.Security
import androidx.compose.material.icons.filled.Share
import androidx.compose.material.icons.filled.Verified
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.ScrollableTabRow
import androidx.compose.material3.Surface
import androidx.compose.material3.Tab
import androidx.compose.material3.TabRowDefaults
import androidx.compose.material3.TabRowDefaults.tabIndicatorOffset
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateListOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalClipboardManager
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.AnnotatedString
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.model.MainAppTab
import com.example.ui.theme.BorderLight
import com.example.ui.theme.CyanContainer
import com.example.ui.theme.CyanDark
import com.example.ui.theme.CyanPrimary
import com.example.ui.theme.EmeraldLight
import com.example.ui.theme.EmeraldSuccess
import com.example.ui.theme.ForestGreenDark
import com.example.ui.theme.ForestGreenPrimary
import com.example.ui.theme.Navy800
import com.example.ui.theme.Navy900
import com.example.ui.theme.PureWhite
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

data class EtimsReceiptRecord(
    val invoiceNumber: String,
    val clientName: String,
    val clientPin: String,
    val date: String,
    val description: String,
    val taxableAmountKes: Double,
    val exemptAmountKes: Double,
    val vatKes: Double,
    val totalAmountKes: Double,
    val fiscalControlUnitCode: String
)

@Composable
fun KraPortalScreen(
    onNavigateTab: (MainAppTab) -> Unit = {}
) {
    val context = LocalContext.current
    val clipboardManager = LocalClipboardManager.current

    val kraItaxUrl = "https://itax.kra.go.ke/KRA-Portal/"
    val kraEtimsUrl = "https://etims.kra.go.ke/"
    val companyPin = "P051882940Z"
    val companyName = "Jabima Funeral Directors & Services Ltd"
    val etimsDeviceSerial = "ETIMS-JFD-SIAYA-01"
    val taxStation = "Siaya Station (Western Region)"

    var activeSubTab by remember { mutableIntStateOf(0) }
    val subTabs = listOf(
        "KRA Portals & Links",
        "eTIMS ETR Generator",
        "Funeral VAT Calculator",
        "Statutory Calendar"
    )

    // Calculator states
    var calcServiceAmountText by remember { mutableStateOf("150000") }
    var calcTaxExemptHearseText by remember { mutableStateOf("45000") }
    var isIncludeWht by remember { mutableStateOf(false) }

    // ETR Generator states
    var clientNameInput by remember { mutableStateOf("The Late Mzee Otieno Family") }
    var clientPinInput by remember { mutableStateOf("A009876543Z") }
    var serviceDescInput by remember { mutableStateOf("Executive Mahogany Casket, Hearse Escort & Lowering Gear") }
    var amountInput by remember { mutableStateOf("185000") }

    val recentEtimsReceipts = remember {
        mutableStateListOf(
            EtimsReceiptRecord(
                invoiceNumber = "ETR-2026-00892",
                clientName = "The Late Elder Ochieng Family",
                clientPin = "A011245892P",
                date = "22 Sep 2026, 14:30",
                description = "Royal Imperial Casket & VIP Hearse KDG 705Y",
                taxableAmountKes = 120000.0,
                exemptAmountKes = 40000.0,
                vatKes = 19200.0,
                totalAmountKes = 179200.0,
                fiscalControlUnitCode = "VSCU-7729-1142"
            ),
            EtimsReceiptRecord(
                invoiceNumber = "ETR-2026-00891",
                clientName = "Prof. Makau Family",
                clientPin = "P051992831B",
                date = "21 Sep 2026, 11:15",
                description = "Presidential Dome Casket & Full Lowering Setup",
                taxableAmountKes = 160000.0,
                exemptAmountKes = 50000.0,
                vatKes = 25600.0,
                totalAmountKes = 235600.0,
                fiscalControlUnitCode = "VSCU-7729-1141"
            )
        )
    }

    fun openBrowser(url: String) {
        try {
            val intent = Intent(Intent.ACTION_VIEW, Uri.parse(url)).apply {
                flags = Intent.FLAG_ACTIVITY_NEW_TASK
            }
            context.startActivity(intent)
        } catch (e: Exception) {
            clipboardManager.setText(AnnotatedString(url))
            Toast.makeText(context, "Link copied to clipboard", Toast.LENGTH_SHORT).show()
        }
    }

    fun copyToClipboard(text: String, label: String) {
        clipboardManager.setText(AnnotatedString(text))
        Toast.makeText(context, "$label copied to clipboard", Toast.LENGTH_SHORT).show()
    }

    LazyColumn(
        modifier = Modifier
            .fillMaxSize()
            .background(PureWhite)
            .padding(horizontal = 16.dp),
        verticalArrangement = Arrangement.spacedBy(14.dp)
    ) {
        item {
            Spacer(modifier = Modifier.height(6.dp))

            // KRA Top Official Header
            Card(
                shape = RoundedCornerShape(16.dp),
                colors = CardDefaults.cardColors(containerColor = Navy900),
                modifier = Modifier
                    .fillMaxWidth()
                    .testTag("kra_portal_header_card")
            ) {
                Column(modifier = Modifier.padding(18.dp)) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Box(
                                modifier = Modifier
                                    .size(46.dp)
                                    .clip(CircleShape)
                                    .background(com.example.ui.theme.StrokeRed),
                                contentAlignment = Alignment.Center
                            ) {
                                Icon(
                                    imageVector = Icons.Default.AccountBalance,
                                    contentDescription = "KRA Logo",
                                    tint = PureWhite,
                                    modifier = Modifier.size(24.dp)
                                )
                            }
                            Spacer(modifier = Modifier.width(12.dp))
                            Column {
                                Row(verticalAlignment = Alignment.CenterVertically) {
                                    Text(
                                        text = "KRA iTax & eTIMS COMPLIANCE",
                                        fontWeight = FontWeight.ExtraBold,
                                        fontSize = 14.sp,
                                        color = PureWhite,
                                        letterSpacing = 0.5.sp
                                    )
                                    Spacer(modifier = Modifier.width(6.dp))
                                    Surface(
                                        color = EmeraldSuccess,
                                        shape = RoundedCornerShape(4.dp)
                                    ) {
                                        Text(
                                            text = "ACTIVE TCC",
                                            fontSize = 8.sp,
                                            fontWeight = FontWeight.Bold,
                                            color = PureWhite,
                                            modifier = Modifier.padding(horizontal = 4.dp, vertical = 2.dp)
                                        )
                                    }
                                }
                                Text(
                                    text = companyName,
                                    fontSize = 11.sp,
                                    color = Color(0xFFBBF7D0),
                                    fontWeight = FontWeight.SemiBold
                                )
                                Text(
                                    text = "$taxStation • Fiscal ETR Compliant",
                                    fontSize = 10.sp,
                                    color = Color.White.copy(alpha = 0.8f)
                                )
                            }
                        }
                    }

                    Spacer(modifier = Modifier.height(14.dp))
                    HorizontalDivider(color = PureWhite.copy(alpha = 0.2f), thickness = 0.5.dp)
                    Spacer(modifier = Modifier.height(12.dp))

                    // PIN & Serial quick strip
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        Surface(
                            color = PureWhite.copy(alpha = 0.12f),
                            shape = RoundedCornerShape(8.dp),
                            modifier = Modifier
                                .weight(1f)
                                .clickable { copyToClipboard(companyPin, "KRA PIN") }
                        ) {
                            Row(
                                modifier = Modifier.padding(horizontal = 10.dp, vertical = 6.dp),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Column {
                                    Text("COMPANY PIN", fontSize = 9.sp, color = com.example.ui.theme.StrokeRedLight, fontWeight = FontWeight.Bold)
                                    Text(companyPin, fontSize = 12.sp, color = PureWhite, fontWeight = FontWeight.ExtraBold, fontFamily = FontFamily.Monospace)
                                }
                                Icon(Icons.Default.ContentCopy, contentDescription = null, tint = PureWhite, modifier = Modifier.size(14.dp))
                            }
                        }

                        Surface(
                            color = PureWhite.copy(alpha = 0.12f),
                            shape = RoundedCornerShape(8.dp),
                            modifier = Modifier
                                .weight(1f)
                                .clickable { copyToClipboard(etimsDeviceSerial, "eTIMS Serial") }
                        ) {
                            Row(
                                modifier = Modifier.padding(horizontal = 10.dp, vertical = 6.dp),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Column {
                                    Text("eTIMS SERIAL", fontSize = 9.sp, color = Color(0xFF86EFAC), fontWeight = FontWeight.Bold)
                                    Text(etimsDeviceSerial, fontSize = 11.sp, color = PureWhite, fontWeight = FontWeight.Bold, fontFamily = FontFamily.Monospace)
                                }
                                Icon(Icons.Default.ContentCopy, contentDescription = null, tint = PureWhite, modifier = Modifier.size(14.dp))
                            }
                        }
                    }

                    Spacer(modifier = Modifier.height(12.dp))

                    // Action buttons: Open iTax and Open eTIMS
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        Button(
                            onClick = { openBrowser(kraItaxUrl) },
                            colors = ButtonDefaults.buttonColors(containerColor = com.example.ui.theme.StrokeRed),
                            shape = RoundedCornerShape(8.dp),
                            modifier = Modifier
                                .weight(1f)
                                .height(38.dp)
                                .testTag("btn_open_kra_itax_portal")
                        ) {
                            Icon(Icons.Default.Launch, contentDescription = null, modifier = Modifier.size(14.dp))
                            Spacer(modifier = Modifier.width(4.dp))
                            Text("Open iTax Portal", fontSize = 11.sp, fontWeight = FontWeight.Bold)
                        }

                        Button(
                            onClick = { openBrowser(kraEtimsUrl) },
                            colors = ButtonDefaults.buttonColors(containerColor = EmeraldSuccess),
                            shape = RoundedCornerShape(8.dp),
                            modifier = Modifier
                                .weight(1f)
                                .height(38.dp)
                                .testTag("btn_open_kra_etims_portal")
                        ) {
                            Icon(Icons.Default.ReceiptLong, contentDescription = null, modifier = Modifier.size(14.dp))
                            Spacer(modifier = Modifier.width(4.dp))
                            Text("eTIMS System", fontSize = 11.sp, fontWeight = FontWeight.Bold)
                        }
                    }
                }
            }
        }

        // Sub Tabs Row
        item {
            ScrollableTabRow(
                selectedTabIndex = activeSubTab,
                containerColor = PureWhite,
                contentColor = ForestGreenPrimary,
                edgePadding = 0.dp,
                indicator = { tabPositions ->
                    if (activeSubTab < tabPositions.size) {
                        TabRowDefaults.SecondaryIndicator(
                            modifier = Modifier.tabIndicatorOffset(tabPositions[activeSubTab]),
                            color = if (activeSubTab == 0) com.example.ui.theme.StrokeRed else ForestGreenPrimary,
                            height = 3.dp
                        )
                    }
                },
                divider = { HorizontalDivider(color = BorderLight, thickness = 0.5.dp) },
                modifier = Modifier.fillMaxWidth()
            ) {
                subTabs.forEachIndexed { index, title ->
                    val isSelected = activeSubTab == index
                    Tab(
                        selected = isSelected,
                        onClick = { activeSubTab = index },
                        text = {
                            Text(
                                text = title,
                                fontSize = 11.sp,
                                fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Medium,
                                color = if (isSelected) Navy900 else Color(0xFF64748B),
                                maxLines = 1,
                                softWrap = false,
                                overflow = androidx.compose.ui.text.style.TextOverflow.Ellipsis
                            )
                        },
                        modifier = Modifier.testTag("kra_subtab_$index")
                    )
                }
            }
        }

        // TAB 0: PORTALS & DIRECT LINKS
        if (activeSubTab == 0) {
            item {
                Text(
                    text = "Official Kenya Revenue Authority Portals",
                    fontSize = 13.sp,
                    fontWeight = FontWeight.Bold,
                    color = Navy900
                )
            }

            item {
                Card(
                    shape = RoundedCornerShape(12.dp),
                    colors = CardDefaults.cardColors(containerColor = com.example.ui.theme.StrokeRedLight),
                    border = BorderStroke(1.dp, com.example.ui.theme.StrokeRedBorder),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Column(modifier = Modifier.padding(14.dp)) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Icon(Icons.Default.AccountBalance, contentDescription = null, tint = com.example.ui.theme.StrokeRed, modifier = Modifier.size(20.dp))
                            Spacer(modifier = Modifier.width(8.dp))
                            Column {
                                Text("KRA iTax Online Portal", fontWeight = FontWeight.Bold, fontSize = 13.sp, color = com.example.ui.theme.StrokeRedDark)
                                Text("itax.kra.go.ke • Returns, PAYE, VAT & Tax Compliance (TCC)", fontSize = 10.sp, color = com.example.ui.theme.StrokeRed)
                            }
                        }
                        Spacer(modifier = Modifier.height(10.dp))
                        Text(
                            text = "Access filed annual returns, generate payment registration numbers (PRN) for monthly PAYE and VAT, and renew Jabima's Tax Compliance Certificate.",
                            fontSize = 11.sp,
                            color = Navy900
                        )
                        Spacer(modifier = Modifier.height(10.dp))
                        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                            Button(
                                onClick = { openBrowser("https://itax.kra.go.ke/KRA-Portal/") },
                                colors = ButtonDefaults.buttonColors(containerColor = com.example.ui.theme.StrokeRed),
                                shape = RoundedCornerShape(8.dp),
                                modifier = Modifier.height(34.dp)
                            ) {
                                Text("Launch iTax Portal", fontSize = 11.sp, fontWeight = FontWeight.Bold)
                            }
                            OutlinedButton(
                                onClick = { openBrowser("https://itax.kra.go.ke/KRA-Portal/pinChecker.htm") },
                                shape = RoundedCornerShape(8.dp),
                                modifier = Modifier.height(34.dp)
                            ) {
                                Text("PIN Checker", fontSize = 11.sp)
                            }
                        }
                    }
                }
            }

            item {
                Card(
                    shape = RoundedCornerShape(12.dp),
                    colors = CardDefaults.cardColors(containerColor = Color(0xFFF0FDF4)),
                    border = BorderStroke(1.dp, Color(0xFFBBF7D0)),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Column(modifier = Modifier.padding(14.dp)) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Icon(Icons.Default.ReceiptLong, contentDescription = null, tint = ForestGreenPrimary, modifier = Modifier.size(20.dp))
                            Spacer(modifier = Modifier.width(8.dp))
                            Column {
                                Text("eTIMS Electronic Invoicing", fontWeight = FontWeight.Bold, fontSize = 13.sp, color = ForestGreenDark)
                                Text("etims.kra.go.ke • Real-time Electronic Tax Invoice & ETR Receipts", fontSize = 10.sp, color = ForestGreenPrimary)
                            }
                        }
                        Spacer(modifier = Modifier.height(10.dp))
                        Text(
                            text = "Statutory electronic invoice transmission for casket purchases and mortuary care services in accordance with Section 23A of Tax Procedures Act.",
                            fontSize = 11.sp,
                            color = Navy900
                        )
                        Spacer(modifier = Modifier.height(10.dp))
                        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                            Button(
                                onClick = { openBrowser("https://etims.kra.go.ke/") },
                                colors = ButtonDefaults.buttonColors(containerColor = ForestGreenPrimary),
                                shape = RoundedCornerShape(8.dp),
                                modifier = Modifier.height(34.dp)
                            ) {
                                Text("Launch eTIMS Portal", fontSize = 11.sp, fontWeight = FontWeight.Bold)
                            }
                            OutlinedButton(
                                onClick = { copyToClipboard(etimsDeviceSerial, "eTIMS Serial") },
                                shape = RoundedCornerShape(8.dp),
                                modifier = Modifier.height(34.dp)
                            ) {
                                Text("Copy Serial", fontSize = 11.sp)
                            }
                        }
                    }
                }
            }
        }

        // TAB 1: eTIMS ETR GENERATOR
        if (activeSubTab == 1) {
            item {
                Card(
                    shape = RoundedCornerShape(12.dp),
                    colors = CardDefaults.cardColors(containerColor = PureWhite),
                    border = BorderStroke(1.dp, BorderLight),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Column(modifier = Modifier.padding(14.dp)) {
                        Text(
                            text = "Issue Real-Time eTIMS ETR Receipt",
                            fontWeight = FontWeight.Bold,
                            fontSize = 13.sp,
                            color = Navy900
                        )
                        Spacer(modifier = Modifier.height(10.dp))

                        OutlinedTextField(
                            value = clientNameInput,
                            onValueChange = { clientNameInput = it },
                            label = { Text("Family / Buyer Name", fontSize = 11.sp) },
                            singleLine = true,
                            modifier = Modifier.fillMaxWidth(),
                            colors = OutlinedTextFieldDefaults.colors(
                                focusedBorderColor = ForestGreenPrimary,
                                unfocusedBorderColor = BorderLight
                            )
                        )

                        Spacer(modifier = Modifier.height(8.dp))

                        OutlinedTextField(
                            value = clientPinInput,
                            onValueChange = { clientPinInput = it },
                            label = { Text("Client KRA PIN (Optional for Individuals)", fontSize = 11.sp) },
                            singleLine = true,
                            modifier = Modifier.fillMaxWidth(),
                            colors = OutlinedTextFieldDefaults.colors(
                                focusedBorderColor = ForestGreenPrimary,
                                unfocusedBorderColor = BorderLight
                            )
                        )

                        Spacer(modifier = Modifier.height(8.dp))

                        OutlinedTextField(
                            value = serviceDescInput,
                            onValueChange = { serviceDescInput = it },
                            label = { Text("Service Description / Casket Package", fontSize = 11.sp) },
                            singleLine = true,
                            modifier = Modifier.fillMaxWidth(),
                            colors = OutlinedTextFieldDefaults.colors(
                                focusedBorderColor = ForestGreenPrimary,
                                unfocusedBorderColor = BorderLight
                            )
                        )

                        Spacer(modifier = Modifier.height(8.dp))

                        OutlinedTextField(
                            value = amountInput,
                            onValueChange = { amountInput = it },
                            label = { Text("Total Invoice Amount (KES)", fontSize = 11.sp) },
                            keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                            singleLine = true,
                            modifier = Modifier.fillMaxWidth(),
                            colors = OutlinedTextFieldDefaults.colors(
                                focusedBorderColor = ForestGreenPrimary,
                                unfocusedBorderColor = BorderLight
                            )
                        )

                        Spacer(modifier = Modifier.height(12.dp))

                        val amt = amountInput.toDoubleOrNull() ?: 0.0
                        val taxableAmt = (amt * 0.75) // typical taxable portion
                        val exemptAmt = (amt * 0.25)  // typical funeral exempt transit
                        val vat = (taxableAmt * 0.16)
                        val grandTotal = taxableAmt + exemptAmt + vat

                        Surface(
                            color = Color(0xFFF1F5F9),
                            shape = RoundedCornerShape(8.dp),
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            Column(modifier = Modifier.padding(10.dp)) {
                                Row(
                                    modifier = Modifier.fillMaxWidth(),
                                    horizontalArrangement = Arrangement.SpaceBetween
                                ) {
                                    Text("Taxable Base (16% VAT):", fontSize = 11.sp, color = Color(0xFF475569))
                                    Text("KES ${String.format("%,.2f", taxableAmt)}", fontSize = 11.sp, fontWeight = FontWeight.Bold)
                                }
                                Row(
                                    modifier = Modifier.fillMaxWidth(),
                                    horizontalArrangement = Arrangement.SpaceBetween
                                ) {
                                    Text("VAT (16%):", fontSize = 11.sp, color = Color(0xFF475569))
                                    Text("KES ${String.format("%,.2f", vat)}", fontSize = 11.sp, fontWeight = FontWeight.Bold, color = com.example.ui.theme.StrokeRed)
                                }
                                Row(
                                    modifier = Modifier.fillMaxWidth(),
                                    horizontalArrangement = Arrangement.SpaceBetween
                                ) {
                                    Text("Exempt Funeral Expenses:", fontSize = 11.sp, color = Color(0xFF475569))
                                    Text("KES ${String.format("%,.2f", exemptAmt)}", fontSize = 11.sp, fontWeight = FontWeight.Bold, color = ForestGreenPrimary)
                                }
                                HorizontalDivider(modifier = Modifier.padding(vertical = 4.dp), thickness = 0.5.dp)
                                Row(
                                    modifier = Modifier.fillMaxWidth(),
                                    horizontalArrangement = Arrangement.SpaceBetween
                                ) {
                                    Text("Total Fiscal Amount:", fontSize = 12.sp, fontWeight = FontWeight.ExtraBold, color = Navy900)
                                    Text("KES ${String.format("%,.2f", grandTotal)}", fontSize = 13.sp, fontWeight = FontWeight.ExtraBold, color = Navy900)
                                }
                            }
                        }

                        Spacer(modifier = Modifier.height(12.dp))

                        Button(
                            onClick = {
                                if (clientNameInput.isNotBlank() && amt > 0) {
                                    val newInvoice = "ETR-2026-" + (1000..9999).random().toString()
                                    recentEtimsReceipts.add(
                                        0,
                                        EtimsReceiptRecord(
                                            invoiceNumber = newInvoice,
                                            clientName = clientNameInput,
                                            clientPin = clientPinInput.ifBlank { "NOT PROVIDED" },
                                            date = SimpleDateFormat("dd MMM yyyy, HH:mm", Locale.getDefault()).format(Date()),
                                            description = serviceDescInput,
                                            taxableAmountKes = taxableAmt,
                                            exemptAmountKes = exemptAmt,
                                            vatKes = vat,
                                            totalAmountKes = grandTotal,
                                            fiscalControlUnitCode = "VSCU-" + (1000..9999).random() + "-01"
                                        )
                                    )
                                    Toast.makeText(context, "eTIMS Receipt $newInvoice generated & transmitted!", Toast.LENGTH_SHORT).show()
                                }
                            },
                            colors = ButtonDefaults.buttonColors(containerColor = EmeraldSuccess),
                            shape = RoundedCornerShape(8.dp),
                            modifier = Modifier
                                .fillMaxWidth()
                                .height(42.dp)
                                .testTag("btn_generate_etims_receipt")
                        ) {
                            Icon(Icons.Default.ReceiptLong, contentDescription = null, modifier = Modifier.size(16.dp))
                            Spacer(modifier = Modifier.width(6.dp))
                            Text("Generate & Transmit eTIMS ETR Receipt", fontWeight = FontWeight.Bold, fontSize = 12.sp)
                        }
                    }
                }
            }

            item {
                Text(
                    text = "Recent Transmitted Fiscal Receipts (${recentEtimsReceipts.size})",
                    fontSize = 12.sp,
                    fontWeight = FontWeight.Bold,
                    color = Navy900
                )
            }

            items(recentEtimsReceipts) { receipt ->
                Card(
                    shape = RoundedCornerShape(10.dp),
                    colors = CardDefaults.cardColors(containerColor = PureWhite),
                    border = BorderStroke(1.dp, BorderLight),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Column(modifier = Modifier.padding(12.dp)) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Icon(Icons.Default.Verified, contentDescription = null, tint = EmeraldSuccess, modifier = Modifier.size(16.dp))
                                Spacer(modifier = Modifier.width(4.dp))
                                Text(receipt.invoiceNumber, fontWeight = FontWeight.ExtraBold, fontSize = 12.sp, fontFamily = FontFamily.Monospace)
                            }
                            Text(receipt.date, fontSize = 10.sp, color = Color(0xFF64748B))
                        }
                        Spacer(modifier = Modifier.height(4.dp))
                        Text(receipt.clientName, fontWeight = FontWeight.Bold, fontSize = 12.sp, color = Navy900)
                        Text(receipt.description, fontSize = 10.sp, color = Color(0xFF475569))
                        Spacer(modifier = Modifier.height(6.dp))
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Text("Code: ${receipt.fiscalControlUnitCode}", fontSize = 9.sp, fontFamily = FontFamily.Monospace, color = Color(0xFF64748B))
                            Text("KES ${String.format("%,.0f", receipt.totalAmountKes)}", fontWeight = FontWeight.ExtraBold, fontSize = 13.sp, color = ForestGreenPrimary)
                        }
                    }
                }
            }
        }

        // TAB 2: FUNERAL VAT CALCULATOR
        if (activeSubTab == 2) {
            item {
                Card(
                    shape = RoundedCornerShape(12.dp),
                    colors = CardDefaults.cardColors(containerColor = PureWhite),
                    border = BorderStroke(1.dp, BorderLight),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Column(modifier = Modifier.padding(14.dp)) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Icon(Icons.Default.Calculate, contentDescription = null, tint = ForestGreenPrimary, modifier = Modifier.size(20.dp))
                            Spacer(modifier = Modifier.width(8.dp))
                            Text("Funeral VAT & Withholding Tax Estimator", fontSize = 13.sp, fontWeight = FontWeight.Bold, color = Navy900)
                        }
                        Spacer(modifier = Modifier.height(10.dp))

                        OutlinedTextField(
                            value = calcServiceAmountText,
                            onValueChange = { calcServiceAmountText = it },
                            label = { Text("Total Bill (KES)", fontSize = 11.sp) },
                            keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                            modifier = Modifier.fillMaxWidth()
                        )

                        Spacer(modifier = Modifier.height(8.dp))

                        OutlinedTextField(
                            value = calcTaxExemptHearseText,
                            onValueChange = { calcTaxExemptHearseText = it },
                            label = { Text("Tax-Exempt Logistics (Hearse, Permits KES)", fontSize = 11.sp) },
                            keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                            modifier = Modifier.fillMaxWidth()
                        )

                        val totalBill = calcServiceAmountText.toDoubleOrNull() ?: 0.0
                        val exemptLogistics = calcTaxExemptHearseText.toDoubleOrNull() ?: 0.0
                        val taxablePart = (totalBill - exemptLogistics).coerceAtLeast(0.0)
                        val vat16 = taxablePart * 0.16
                        val wht5 = taxablePart * 0.05
                        val grandTotalCalc = totalBill + vat16

                        Spacer(modifier = Modifier.height(12.dp))

                        Surface(
                            color = Color(0xFFF8FAFC),
                            shape = RoundedCornerShape(8.dp),
                            border = BorderStroke(1.dp, BorderLight),
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            Column(modifier = Modifier.padding(12.dp)) {
                                Text("Breakdown According to KRA VAT Act 2013:", fontSize = 11.sp, fontWeight = FontWeight.Bold, color = Navy900)
                                Spacer(modifier = Modifier.height(6.dp))
                                Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                                    Text("Standard Taxable Base:", fontSize = 11.sp)
                                    Text("KES ${String.format("%,.2f", taxablePart)}", fontWeight = FontWeight.Bold)
                                }
                                Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                                    Text("VAT Output Tax (16%):", fontSize = 11.sp, color = com.example.ui.theme.StrokeRed)
                                    Text("KES ${String.format("%,.2f", vat16)}", fontWeight = FontWeight.Bold, color = com.example.ui.theme.StrokeRed)
                                }
                                Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                                    Text("Withholding Tax 5% (Gov/Corporate):", fontSize = 11.sp, color = CyanDark)
                                    Text("KES ${String.format("%,.2f", wht5)}", fontWeight = FontWeight.Bold, color = CyanDark)
                                }
                                HorizontalDivider(modifier = Modifier.padding(vertical = 4.dp))
                                Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                                    Text("Net Bill to Client:", fontSize = 12.sp, fontWeight = FontWeight.ExtraBold)
                                    Text("KES ${String.format("%,.2f", grandTotalCalc)}", fontSize = 13.sp, fontWeight = FontWeight.ExtraBold, color = ForestGreenPrimary)
                                }
                            }
                        }
                    }
                }
            }
        }

        // TAB 3: STATUTORY CALENDAR
        if (activeSubTab == 3) {
            item {
                Text(
                    text = "Statutory Filing Deadlines & Compliance Ledger",
                    fontSize = 13.sp,
                    fontWeight = FontWeight.Bold,
                    color = Navy900
                )
            }

            item {
                Card(
                    shape = RoundedCornerShape(12.dp),
                    colors = CardDefaults.cardColors(containerColor = PureWhite),
                    border = BorderStroke(1.dp, BorderLight),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Column(modifier = Modifier.padding(14.dp)) {
                        val deadlines = listOf(
                            Triple("9th of Each Month", "PAYE, Housing Levy, NSSF & SHIF", "Payroll taxes deduction for all craftsmen and drivers"),
                            Triple("20th of Each Month", "VAT & Withholding Tax (WHT)", "Electronic submission of VAT-3 return via iTax"),
                            Triple("20th of Month Following Quarter", "Turnover Tax (TOT)", "Small branches quarterly compliance"),
                            Triple("30th April Every Year", "Annual Corporate Income Tax Return", "Audited company accounts and financial statements filing")
                        )

                        deadlines.forEachIndexed { idx, (date, title, desc) ->
                            Row(verticalAlignment = Alignment.Top) {
                                Box(
                                    modifier = Modifier
                                        .size(24.dp)
                                        .clip(CircleShape)
                                        .background(if (idx == 0 || idx == 1) EmeraldSuccess else CyanPrimary),
                                    contentAlignment = Alignment.Center
                                ) {
                                    Icon(Icons.Default.Check, contentDescription = null, tint = PureWhite, modifier = Modifier.size(13.dp))
                                }
                                Spacer(modifier = Modifier.width(10.dp))
                                Column {
                                    Text(date, fontWeight = FontWeight.ExtraBold, fontSize = 12.sp, color = Navy900)
                                    Text(title, fontWeight = FontWeight.Bold, fontSize = 11.sp, color = ForestGreenPrimary)
                                    Text(desc, fontSize = 10.sp, color = Color(0xFF64748B))
                                }
                            }
                            if (idx < deadlines.size - 1) {
                                HorizontalDivider(modifier = Modifier.padding(vertical = 10.dp), thickness = 0.5.dp)
                            }
                        }
                    }
                }
            }
        }

        item {
            Spacer(modifier = Modifier.height(80.dp)) // padding for bottom bar
        }
    }
}
