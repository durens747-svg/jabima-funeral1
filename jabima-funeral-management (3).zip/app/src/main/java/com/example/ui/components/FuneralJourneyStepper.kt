package com.example.ui.components

import androidx.compose.animation.animateColorAsState
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowForward
import androidx.compose.material.icons.filled.Assignment
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.Church
import androidx.compose.material.icons.filled.DirectionsCar
import androidx.compose.material.icons.filled.FactCheck
import androidx.compose.material.icons.filled.Inventory2
import androidx.compose.material.icons.filled.PlayCircle
import androidx.compose.material.icons.filled.PrecisionManufacturing
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.model.BurialScheduleEvent
import com.example.ui.theme.BorderLight
import com.example.ui.theme.CyanPrimary
import com.example.ui.theme.EmeraldSuccess
import com.example.ui.theme.ForestGreenPrimary
import com.example.ui.theme.Navy900
import com.example.ui.theme.PureWhite
import com.example.ui.theme.TextMuted

data class JourneyStageMeta(
    val stepIndex: Int,
    val title: String,
    val subtitle: String,
    val icon: ImageVector,
    val defaultEstimatedTime: String
)

val JABIMA_JOURNEY_STAGES = listOf(
    JourneyStageMeta(
        stepIndex = 0,
        title = "Family Intake & Planning",
        subtitle = "Consultation, program & statutory permits",
        icon = Icons.Default.Assignment,
        defaultEstimatedTime = "08:00 AM"
    ),
    JourneyStageMeta(
        stepIndex = 1,
        title = "Casket Crafting & QA",
        subtitle = "Hardwood woodwork, velvet lining & fittings",
        icon = Icons.Default.PrecisionManufacturing,
        defaultEstimatedTime = "09:30 AM"
    ),
    JourneyStageMeta(
        stepIndex = 2,
        title = "Hearse & Fleet Escort",
        subtitle = "Cortege motorcade, driver & route flags",
        icon = Icons.Default.DirectionsCar,
        defaultEstimatedTime = "10:30 AM"
    ),
    JourneyStageMeta(
        stepIndex = 3,
        title = "Chapel & Church Vigil",
        subtitle = "Sound equipment, bier trolley & eulogies",
        icon = Icons.Default.Church,
        defaultEstimatedTime = "12:00 PM"
    ),
    JourneyStageMeta(
        stepIndex = 4,
        title = "Gravesite Lowering",
        subtitle = "Hydraulic lowering gear, canopy & red carpet",
        icon = Icons.Default.CheckCircle,
        defaultEstimatedTime = "02:30 PM"
    ),
    JourneyStageMeta(
        stepIndex = 5,
        title = "Debrief & Gear Return",
        subtitle = "Sanitization, gear check-in & family sign-off",
        icon = Icons.Default.FactCheck,
        defaultEstimatedTime = "04:30 PM"
    )
)

@Composable
fun FuneralJourneyStepper(
    event: BurialScheduleEvent?,
    currentStepIndex: Int = 2, // defaults to Fleet Cortege for live visual demonstration
    onStepSelected: (Int) -> Unit = {},
    modifier: Modifier = Modifier
) {
    var activeStep by remember(currentStepIndex) { mutableIntStateOf(currentStepIndex) }

    Surface(
        color = MaterialTheme.colorScheme.surface,
        shape = RoundedCornerShape(14.dp),
        border = BorderStroke(1.dp, MaterialTheme.colorScheme.outline.copy(alpha = 0.3f)),
        shadowElevation = 2.dp,
        modifier = modifier
            .fillMaxWidth()
            .testTag("funeral_journey_stepper_card")
    ) {
        Column(modifier = Modifier.padding(14.dp)) {
            // Header Row
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Surface(
                        color = ForestGreenPrimary.copy(alpha = 0.12f),
                        shape = CircleShape,
                        modifier = Modifier.size(28.dp)
                    ) {
                        Box(contentAlignment = Alignment.Center) {
                            Icon(
                                imageVector = Icons.Default.PlayCircle,
                                contentDescription = null,
                                tint = ForestGreenPrimary,
                                modifier = Modifier.size(16.dp)
                            )
                        }
                    }
                    Spacer(modifier = Modifier.width(8.dp))
                    Column {
                        Text(
                            text = "LIVE ARRANGEMENT JOURNEY TRACKER",
                            fontSize = 11.sp,
                            fontWeight = FontWeight.Bold,
                            color = ForestGreenPrimary,
                            letterSpacing = 0.5.sp
                        )
                        Text(
                            text = if (event != null) "${event.caseReference} • ${event.deceasedName}" else "Active Service Procession Flow",
                            fontSize = 12.sp,
                            fontWeight = FontWeight.SemiBold,
                            color = MaterialTheme.colorScheme.onSurface
                        )
                    }
                }

                Surface(
                    color = Color(0xFF107C41).copy(alpha = 0.15f),
                    shape = RoundedCornerShape(6.dp)
                ) {
                    Text(
                        text = "Stage ${activeStep + 1} of ${JABIMA_JOURNEY_STAGES.size}",
                        fontSize = 10.sp,
                        fontWeight = FontWeight.Bold,
                        color = Color(0xFF107C41),
                        modifier = Modifier.padding(horizontal = 8.dp, vertical = 3.dp)
                    )
                }
            }

            Spacer(modifier = Modifier.height(14.dp))

            // Horizontal Stepper Track
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .horizontalScroll(rememberScrollState()),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(6.dp)
            ) {
                JABIMA_JOURNEY_STAGES.forEachIndexed { index, stage ->
                    val isCompleted = index < activeStep
                    val isCurrent = index == activeStep
                    val isUpcoming = index > activeStep

                    val circleBgColor by animateColorAsState(
                        targetValue = when {
                            isCompleted -> EmeraldSuccess
                            isCurrent -> ForestGreenPrimary
                            else -> Color(0xFFF1F5F9)
                        },
                        label = "circle_bg"
                    )

                    val circleContentColor = when {
                        isCompleted || isCurrent -> PureWhite
                        else -> Color(0xFF94A3B8)
                    }

                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        modifier = Modifier.clickable {
                            activeStep = index
                            onStepSelected(index)
                        }
                    ) {
                        // Node circle + text
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            modifier = Modifier
                                .clip(RoundedCornerShape(8.dp))
                                .background(if (isCurrent) ForestGreenPrimary.copy(alpha = 0.08f) else Color.Transparent)
                                .padding(horizontal = 6.dp, vertical = 4.dp)
                        ) {
                            Surface(
                                shape = CircleShape,
                                color = circleBgColor,
                                modifier = Modifier.size(24.dp)
                            ) {
                                Box(contentAlignment = Alignment.Center) {
                                    Icon(
                                        imageVector = if (isCompleted) Icons.Default.CheckCircle else stage.icon,
                                        contentDescription = stage.title,
                                        tint = circleContentColor,
                                        modifier = Modifier.size(13.dp)
                                    )
                                }
                            }

                            Spacer(modifier = Modifier.width(6.dp))

                            Column {
                                Text(
                                    text = stage.title,
                                    fontSize = 11.sp,
                                    fontWeight = if (isCurrent) FontWeight.Bold else FontWeight.Medium,
                                    color = if (isCurrent) ForestGreenPrimary else if (isCompleted) Navy900 else TextMuted
                                )
                                Text(
                                    text = if (isCurrent) "● ACTIVE NOW" else stage.defaultEstimatedTime,
                                    fontSize = 9.sp,
                                    fontWeight = if (isCurrent) FontWeight.Bold else FontWeight.Normal,
                                    color = if (isCurrent) MaterialTheme.colorScheme.secondary else TextMuted
                                )
                            }
                        }

                        if (index < JABIMA_JOURNEY_STAGES.size - 1) {
                            Spacer(modifier = Modifier.width(4.dp))
                            HorizontalDivider(
                                modifier = Modifier.width(18.dp),
                                color = if (index < activeStep) EmeraldSuccess else BorderLight,
                                thickness = 2.dp
                            )
                            Spacer(modifier = Modifier.width(4.dp))
                        }
                    }
                }
            }

            Spacer(modifier = Modifier.height(12.dp))

            // Active Stage Info Box
            val selectedMeta = JABIMA_JOURNEY_STAGES.getOrElse(activeStep) { JABIMA_JOURNEY_STAGES.first() }
            Surface(
                color = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.45f),
                shape = RoundedCornerShape(10.dp),
                border = BorderStroke(1.dp, MaterialTheme.colorScheme.outline.copy(alpha = 0.25f)),
                modifier = Modifier.fillMaxWidth()
            ) {
                Row(
                    modifier = Modifier.padding(10.dp),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Column(modifier = Modifier.weight(1f)) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Text(
                                text = "Current Milestone: ${selectedMeta.title}",
                                fontSize = 12.sp,
                                fontWeight = FontWeight.Bold,
                                color = MaterialTheme.colorScheme.onSurface
                            )
                            Spacer(modifier = Modifier.width(8.dp))
                            if (event?.assignedHearseReg != null) {
                                Surface(
                                    color = CyanPrimary.copy(alpha = 0.15f),
                                    shape = RoundedCornerShape(4.dp)
                                ) {
                                    Text(
                                        text = event.assignedHearseReg,
                                        fontSize = 9.sp,
                                        fontWeight = FontWeight.Bold,
                                        color = CyanPrimary,
                                        modifier = Modifier.padding(horizontal = 4.dp, vertical = 2.dp)
                                    )
                                }
                            }
                        }
                        Text(
                            text = selectedMeta.subtitle,
                            fontSize = 10.sp,
                            color = Color(0xFF64748B)
                        )
                        if (event != null) {
                            Text(
                                text = "Venue: ${event.gravesiteLocation} • Church: ${event.churchVenue}",
                                fontSize = 10.sp,
                                color = Color(0xFF107C41),
                                fontWeight = FontWeight.Medium
                            )
                        }
                    }

                    Surface(
                        onClick = {
                            if (activeStep < JABIMA_JOURNEY_STAGES.size - 1) {
                                activeStep++
                                onStepSelected(activeStep)
                            }
                        },
                        shape = RoundedCornerShape(8.dp),
                        color = ForestGreenPrimary,
                        modifier = Modifier.testTag("btn_advance_arrangement_stage")
                    ) {
                        Row(
                            modifier = Modifier.padding(horizontal = 8.dp, vertical = 6.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Text(
                                text = if (activeStep < JABIMA_JOURNEY_STAGES.size - 1) "Advance Stage" else "Completed",
                                fontSize = 10.sp,
                                fontWeight = FontWeight.Bold,
                                color = PureWhite
                            )
                            Spacer(modifier = Modifier.width(4.dp))
                            Icon(
                                imageVector = Icons.AutoMirrored.Filled.ArrowForward,
                                contentDescription = null,
                                tint = PureWhite,
                                modifier = Modifier.size(12.dp)
                            )
                        }
                    }
                }
            }
        }
    }
}
