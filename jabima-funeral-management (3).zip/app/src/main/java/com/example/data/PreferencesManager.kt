package com.example.data

import android.content.Context
import androidx.datastore.core.DataStore
import androidx.datastore.preferences.core.Preferences
import androidx.datastore.preferences.core.booleanPreferencesKey
import androidx.datastore.preferences.core.edit
import androidx.datastore.preferences.core.emptyPreferences
import androidx.datastore.preferences.core.stringPreferencesKey
import androidx.datastore.preferences.preferencesDataStore
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.catch
import kotlinx.coroutines.flow.map
import java.io.IOException

val Context.jabimaDataStore: DataStore<Preferences> by preferencesDataStore(name = "jabima_preferences")

data class AppPreferencesState(
    val isDarkMode: Boolean = false,
    val autoNightShiftScheduled: Boolean = false,
    val nightShiftEyeProtection: Boolean = true,
    val isOutdoorHighContrastMode: Boolean = false,
    val lastLinkedStaffId: String = "CEO-001",
    val offlineQueueJson: String = "[]",
    val rotatedPasswordsJson: String = "{}"
)

class PreferencesManager(
    private val dataStore: DataStore<Preferences>
) {
    private object Keys {
        val IS_DARK_MODE = booleanPreferencesKey("is_dark_mode")
        val AUTO_NIGHT_SHIFT = booleanPreferencesKey("auto_night_shift_scheduled")
        val EYE_PROTECTION = booleanPreferencesKey("night_shift_eye_protection")
        val OUTDOOR_CONTRAST = booleanPreferencesKey("outdoor_high_contrast_mode")
        val LAST_STAFF_ID = stringPreferencesKey("last_linked_staff_id")
        val OFFLINE_QUEUE_JSON = stringPreferencesKey("offline_field_queue_json")
        val ROTATED_PASSWORDS_JSON = stringPreferencesKey("rotated_staff_passwords_json")
    }

    val preferencesFlow: Flow<AppPreferencesState> = dataStore.data
        .catch { e ->
            if (e is IOException) emit(emptyPreferences()) else throw e
        }
        .map { prefs ->
            AppPreferencesState(
                isDarkMode = prefs[Keys.IS_DARK_MODE] ?: false,
                autoNightShiftScheduled = prefs[Keys.AUTO_NIGHT_SHIFT] ?: false,
                nightShiftEyeProtection = prefs[Keys.EYE_PROTECTION] ?: true,
                isOutdoorHighContrastMode = prefs[Keys.OUTDOOR_CONTRAST] ?: false,
                lastLinkedStaffId = prefs[Keys.LAST_STAFF_ID] ?: "CEO-001",
                offlineQueueJson = prefs[Keys.OFFLINE_QUEUE_JSON] ?: "[]",
                rotatedPasswordsJson = prefs[Keys.ROTATED_PASSWORDS_JSON] ?: "{}"
            )
        }

    suspend fun setDarkMode(enabled: Boolean) {
        dataStore.edit { it[Keys.IS_DARK_MODE] = enabled }
    }

    suspend fun setAutoNightShiftScheduled(enabled: Boolean) {
        dataStore.edit { it[Keys.AUTO_NIGHT_SHIFT] = enabled }
    }

    suspend fun setNightShiftEyeProtection(enabled: Boolean) {
        dataStore.edit { it[Keys.EYE_PROTECTION] = enabled }
    }

    suspend fun setOutdoorHighContrastMode(enabled: Boolean) {
        dataStore.edit { it[Keys.OUTDOOR_CONTRAST] = enabled }
    }

    suspend fun setLastLinkedStaffId(staffId: String) {
        dataStore.edit { it[Keys.LAST_STAFF_ID] = staffId }
    }

    suspend fun saveOfflineQueueJson(json: String) {
        dataStore.edit { it[Keys.OFFLINE_QUEUE_JSON] = json }
    }

    suspend fun saveRotatedPasswordsJson(json: String) {
        dataStore.edit { it[Keys.ROTATED_PASSWORDS_JSON] = json }
    }
}
