package com.example.network

import android.util.Base64
import com.example.BuildConfig
import okhttp3.OkHttpClient
import okhttp3.logging.HttpLoggingInterceptor
import retrofit2.Response
import retrofit2.Retrofit
import retrofit2.converter.gson.GsonConverterFactory
import retrofit2.http.Body
import retrofit2.http.Field
import retrofit2.http.FormUrlEncoded
import retrofit2.http.GET
import retrofit2.http.Header
import retrofit2.http.POST
import retrofit2.http.Query
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import java.util.concurrent.TimeUnit

data class DarajaTokenResponse(
    val access_token: String? = null,
    val expires_in: String? = null
)

data class DarajaStkPushRequest(
    val BusinessShortCode: String,
    val Password: String,
    val Timestamp: String,
    val TransactionType: String = "CustomerPayBillOnline",
    val Amount: Int,
    val PartyA: String,
    val PartyB: String,
    val PhoneNumber: String,
    val CallBackURL: String,
    val AccountReference: String,
    val TransactionDesc: String
)

data class DarajaStkPushResponse(
    val MerchantRequestID: String? = null,
    val CheckoutRequestID: String? = null,
    val ResponseCode: String? = null,
    val ResponseDescription: String? = null,
    val CustomerMessage: String? = null
)

data class BulkSmsSendResponse(
    val SMSMessageData: SmsMessageData? = null
) {
    data class SmsMessageData(
        val Message: String? = null,
        val Recipients: List<RecipientStatus>? = null
    )
    data class RecipientStatus(
        val number: String? = null,
        val status: String? = null,
        val messageId: String? = null,
        val cost: String? = null
    )
}

interface DarajaApiService {
    @GET("oauth/v1/generate")
    suspend fun getAccessToken(
        @Header("Authorization") basicAuthHeader: String,
        @Query("grant_type") grantType: String = "client_credentials"
    ): Response<DarajaTokenResponse>

    @POST("mpesa/stkpush/v1/processrequest")
    suspend fun sendStkPush(
        @Header("Authorization") bearerHeader: String,
        @Body request: DarajaStkPushRequest
    ): Response<DarajaStkPushResponse>
}

interface BulkSmsApiService {
    @FormUrlEncoded
    @POST("version1/messaging")
    suspend fun sendBulkSms(
        @Header("apiKey") apiKey: String,
        @Header("Accept") accept: String = "application/json",
        @Field("username") username: String,
        @Field("to") recipientsCsv: String,
        @Field("message") message: String,
        @Field("from") senderId: String
    ): Response<BulkSmsSendResponse>
}

data class ExternalGatewayStatus(
    val mpesaLiveConfigured: Boolean,
    val mpesaShortcode: String,
    val mpesaStatusLabel: String,
    val bulkSmsLiveConfigured: Boolean,
    val bulkSmsUsername: String,
    val bulkSmsStatusLabel: String
)

data class GatewayDispatchResult(
    val isLiveApiCall: Boolean,
    val succeeded: Boolean,
    val referenceCode: String,
    val summaryMessage: String
)

class ExternalServiceBridge {
    private val okHttpClient: OkHttpClient by lazy {
        val logging = HttpLoggingInterceptor().apply {
            level = if (BuildConfig.DEBUG) HttpLoggingInterceptor.Level.BASIC else HttpLoggingInterceptor.Level.NONE
        }
        OkHttpClient.Builder()
            .connectTimeout(15, TimeUnit.SECONDS)
            .readTimeout(20, TimeUnit.SECONDS)
            .addInterceptor(logging)
            .build()
    }

    private val darajaService: DarajaApiService by lazy {
        Retrofit.Builder()
            .baseUrl("https://sandbox.safaricom.co.ke/")
            .client(okHttpClient)
            .addConverterFactory(GsonConverterFactory.create())
            .build()
            .create(DarajaApiService::class.java)
    }

    private val bulkSmsService: BulkSmsApiService by lazy {
        Retrofit.Builder()
            .baseUrl("https://api.africastalking.com/")
            .client(okHttpClient)
            .addConverterFactory(GsonConverterFactory.create())
            .build()
            .create(BulkSmsApiService::class.java)
    }

    fun inspectGatewayStatus(): ExternalGatewayStatus {
        val mpesaKey = BuildConfig.MPESA_CONSUMER_KEY.trim()
        val mpesaSecret = BuildConfig.MPESA_CONSUMER_SECRET.trim()
        val mpesaPasskey = BuildConfig.MPESA_PASSKEY.trim()
        val mpesaShortcode = BuildConfig.MPESA_SHORTCODE.trim().ifBlank { "889420" }
        val mpesaConfigured = isConfiguredSecret(mpesaKey) && isConfiguredSecret(mpesaSecret) && isConfiguredSecret(mpesaPasskey)

        val smsApiKey = BuildConfig.BULK_SMS_API_KEY.trim()
        val smsUsername = BuildConfig.BULK_SMS_USERNAME.trim().ifBlank { "jabima_funeral" }
        val smsConfigured = isConfiguredSecret(smsApiKey)

        return ExternalGatewayStatus(
            mpesaLiveConfigured = mpesaConfigured,
            mpesaShortcode = mpesaShortcode,
            mpesaStatusLabel = if (mpesaConfigured) {
                "Daraja Live Credentials Ready (Paybill $mpesaShortcode)"
            } else {
                "Sandbox Local Mode — Set MPESA_* keys in AI Studio Secrets for live Daraja STK"
            },
            bulkSmsLiveConfigured = smsConfigured,
            bulkSmsUsername = smsUsername,
            bulkSmsStatusLabel = if (smsConfigured) {
                "Gateway Live Credentials Ready ($smsUsername)"
            } else {
                "Local Log Mode — Set BULK_SMS_API_KEY in AI Studio Secrets for carrier delivery"
            }
        )
    }

    suspend fun dispatchMpesaStkPush(
        phoneNumber: String,
        amountKes: Double,
        accountReference: String,
        description: String
    ): GatewayDispatchResult {
        val status = inspectGatewayStatus()
        val normalizedPhone = normalizeKenyanMsisdn(phoneNumber)
        if (!status.mpesaLiveConfigured) {
            return GatewayDispatchResult(
                isLiveApiCall = false,
                succeeded = true,
                referenceCode = "STK-LCL-${System.currentTimeMillis() % 1000000}",
                summaryMessage = "Recorded locally (Daraja API secrets not yet configured). Reference generated for Cashier reconciliation."
            )
        }

        return try {
            val rawCreds = "${BuildConfig.MPESA_CONSUMER_KEY}:${BuildConfig.MPESA_CONSUMER_SECRET}"
            val encodedCreds = Base64.encodeToString(rawCreds.toByteArray(Charsets.UTF_8), Base64.NO_WRAP)
            val tokenResp = darajaService.getAccessToken("Basic $encodedCreds")
            val token = tokenResp.body()?.access_token
            if (!tokenResp.isSuccessful || token.isNullOrBlank()) {
                return GatewayDispatchResult(
                    isLiveApiCall = true,
                    succeeded = false,
                    referenceCode = "STK-ERR-${tokenResp.code()}",
                    summaryMessage = "Daraja OAuth failed (${tokenResp.code()}). Verify MPESA_CONSUMER_KEY/SECRET."
                )
            }

            val timestamp = SimpleDateFormat("yyyyMMddHHmmss", Locale.US).format(Date())
            val rawPassword = "${status.mpesaShortcode}${BuildConfig.MPESA_PASSKEY}$timestamp"
            val encodedPassword = Base64.encodeToString(rawPassword.toByteArray(Charsets.UTF_8), Base64.NO_WRAP)

            val stkReq = DarajaStkPushRequest(
                BusinessShortCode = status.mpesaShortcode,
                Password = encodedPassword,
                Timestamp = timestamp,
                Amount = amountKes.toInt().coerceAtLeast(1),
                PartyA = normalizedPhone,
                PartyB = status.mpesaShortcode,
                PhoneNumber = normalizedPhone,
                CallBackURL = "https://jabimafuneral.co.ke/api/mpesa/callback",
                AccountReference = accountReference.take(12),
                TransactionDesc = description.take(20)
            )
            val stkResp = darajaService.sendStkPush("Bearer $token", stkReq)
            val body = stkResp.body()
            if (stkResp.isSuccessful && body?.ResponseCode == "0") {
                GatewayDispatchResult(
                    isLiveApiCall = true,
                    succeeded = true,
                    referenceCode = body.CheckoutRequestID ?: "DAR-${System.currentTimeMillis() % 1000000}",
                    summaryMessage = body.CustomerMessage ?: "Live Daraja STK Push sent to $normalizedPhone."
                )
            } else {
                GatewayDispatchResult(
                    isLiveApiCall = true,
                    succeeded = false,
                    referenceCode = "DAR-FAIL-${stkResp.code()}",
                    summaryMessage = body?.ResponseDescription ?: "Daraja STK error (${stkResp.code()})."
                )
            }
        } catch (t: Throwable) {
            GatewayDispatchResult(
                isLiveApiCall = true,
                succeeded = false,
                referenceCode = "DAR-NET-ERR",
                summaryMessage = "Daraja network failure: ${t.localizedMessage ?: "Check connectivity"}"
            )
        }
    }

    suspend fun dispatchBulkSms(
        recipients: String,
        message: String,
        senderId: String
    ): GatewayDispatchResult {
        val status = inspectGatewayStatus()
        if (!status.bulkSmsLiveConfigured) {
            return GatewayDispatchResult(
                isLiveApiCall = false,
                succeeded = true,
                referenceCode = "SMS-LCL-${System.currentTimeMillis() % 100000}",
                summaryMessage = "Logged locally (BULK_SMS_API_KEY not configured in AI Studio Secrets)."
            )
        }

        val cleanRecipients = recipients
            .split(",", ";")
            .mapNotNull { token ->
                val digits = token.filter { it.isDigit() || it == '+' }
                if (digits.length >= 9) normalizeKenyanMsisdn(digits).let { "+$it" } else null
            }
            .joinToString(",")
            .ifBlank { "+254793553434" }

        return try {
            val response = bulkSmsService.sendBulkSms(
                apiKey = BuildConfig.BULK_SMS_API_KEY,
                username = status.bulkSmsUsername,
                recipientsCsv = cleanRecipients,
                message = message,
                senderId = senderId
            )
            val data = response.body()?.SMSMessageData
            if (response.isSuccessful && data != null) {
                val firstId = data.Recipients?.firstOrNull()?.messageId ?: "AT-${System.currentTimeMillis() % 100000}"
                GatewayDispatchResult(
                    isLiveApiCall = true,
                    succeeded = true,
                    referenceCode = firstId,
                    summaryMessage = data.Message ?: "Dispatched via live SMS carrier."
                )
            } else {
                GatewayDispatchResult(
                    isLiveApiCall = true,
                    succeeded = false,
                    referenceCode = "SMS-ERR-${response.code()}",
                    summaryMessage = "Carrier API error (${response.code()}). Verify BULK_SMS_API_KEY."
                )
            }
        } catch (t: Throwable) {
            GatewayDispatchResult(
                isLiveApiCall = true,
                succeeded = false,
                referenceCode = "SMS-NET-ERR",
                summaryMessage = "SMS gateway network error: ${t.localizedMessage ?: "Timeout"}"
            )
        }
    }

    private fun isConfiguredSecret(value: String): Boolean {
        return value.isNotBlank() && !value.contains("PLACEHOLDER", ignoreCase = true)
    }

    private fun normalizeKenyanMsisdn(raw: String): String {
        val digits = raw.filter { it.isDigit() }
        return when {
            digits.startsWith("254") -> digits
            digits.startsWith("0") && digits.length >= 10 -> "254${digits.drop(1)}"
            digits.length == 9 -> "254$digits"
            else -> digits.ifBlank { "254793553434" }
        }
    }
}
