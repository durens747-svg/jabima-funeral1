package com.example.ui.components

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.AccountBalanceWallet
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.Edit
import androidx.compose.material.icons.filled.Key
import androidx.compose.material.icons.filled.Login
import androidx.compose.material.icons.filled.Payments
import androidx.compose.material.icons.filled.Phone
import androidx.compose.material.icons.filled.Security
import androidx.compose.material.icons.filled.Tune
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.window.Dialog
import com.example.model.StaffAccount
import com.example.model.StaffWalletSummary
import com.example.ui.theme.AmberLight
import com.example.ui.theme.AmberWarning
import com.example.ui.theme.CyanContainer
import com.example.ui.theme.CyanPrimary
import com.example.ui.theme.EmeraldLight
import com.example.ui.theme.EmeraldSuccess
import com.example.ui.theme.Navy900

@Composable
fun AdminStaffDetailSheet(
    staff: StaffAccount,
    walletSummary: StaffWalletSummary,
    activityCount: Int,
    onDismiss: () -> Unit,
    onAccessAccount: (StaffAccount) -> Unit,
    onCreditWallet: (StaffAccount) -> Unit,
    onResetPassword: (staffId: String, newPass: String) -> Unit,
    onEditRoleAndValues: (StaffAccount) -> Unit = {},
    onOpenWallet: (StaffAccount) -> Unit = { onAccessAccount(it) }
) {
    var showPasswordResetInput by remember { mutableStateOf(false) }
    var newPasswordInput by remember { mutableStateOf("") }
    var passwordResetSuccess by remember { mutableStateOf(false) }

    Dialog(onDismissRequest = onDismiss) {
        Card(
            shape = RoundedCornerShape(18.dp),
            colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
            modifier = Modifier
                .fillMaxWidth()
                .padding(vertical = 16.dp)
                .testTag("admin_staff_detail_sheet")
        ) {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .verticalScroll(rememberScrollState())
                    .padding(20.dp)
            ) {
                // Top close
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text(
                        text = "Staff Account Admin Inspection",
                        style = MaterialTheme.typography.titleMedium,
                        fontWeight = FontWeight.Bold,
                        color = MaterialTheme.colorScheme.onSurface
                    )

                    IconButton(onClick = onDismiss) {
                        Icon(imageVector = Icons.Default.Close, contentDescription = "Close")
                    }
                }

                Spacer(modifier = Modifier.height(14.dp))

                // Profile Header Card
                Surface(
                    color = MaterialTheme.colorScheme.surfaceVariant,
                    shape = RoundedCornerShape(12.dp),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Row(
                        modifier = Modifier.padding(14.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Box(
                            modifier = Modifier
                                .size(50.dp)
                                .clip(CircleShape)
                                .background(Color(staff.avatarColor)),
                            contentAlignment = Alignment.Center
                        ) {
                            Text(
                                text = staff.fullName.split(" ").mapNotNull { it.firstOrNull()?.toString() }.take(2).joinToString(""),
                                color = Color.White,
                                fontWeight = FontWeight.Bold,
                                fontSize = 18.sp
                            )
                        }

                        Spacer(modifier = Modifier.width(12.dp))

                        Column {
                            Text(
                                text = staff.fullName,
                                fontWeight = FontWeight.Bold,
                                fontSize = 16.sp
                            )
                            Text(
                                text = staff.role.title,
                                fontSize = 12.sp,
                                color = CyanPrimary,
                                fontWeight = FontWeight.SemiBold
                            )
                            Text(
                                text = "${staff.id} • ${staff.branch}",
                                fontSize = 11.sp,
                                color = MaterialTheme.colorScheme.onSurfaceVariant
                            )
                        }
                    }
                }

                Spacer(modifier = Modifier.height(14.dp))

                // Stats row 1: Available Wallet & Logged Tasks
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    Surface(
                        color = CyanContainer,
                        shape = RoundedCornerShape(10.dp),
                        modifier = Modifier.weight(1f)
                    ) {
                        Column(modifier = Modifier.padding(10.dp)) {
                            Text("Available Wallet", fontSize = 10.sp, color = Color(0xFF075985))
                            Text(
                                text = "KES ${String.format("%,.0f", walletSummary.availableBalance)}",
                                fontWeight = FontWeight.Bold,
                                fontSize = 14.sp,
                                color = Color(0xFF0C4A6E)
                            )
                        }
                    }

                    Surface(
                        color = EmeraldLight,
                        shape = RoundedCornerShape(10.dp),
                        modifier = Modifier.weight(1f)
                    ) {
                        Column(modifier = Modifier.padding(10.dp)) {
                            Text("Logged Tasks", fontSize = 10.sp, color = EmeraldSuccess)
                            Text(
                                text = "$activityCount Activities",
                                fontWeight = FontWeight.Bold,
                                fontSize = 14.sp,
                                color = EmeraldSuccess
                            )
                        }
                    }
                }

                Spacer(modifier = Modifier.height(8.dp))

                // Stats row 2: Earned Commissions & Service Payouts
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    Surface(
                        color = AmberLight,
                        shape = RoundedCornerShape(10.dp),
                        modifier = Modifier.weight(1f)
                    ) {
                        Column(modifier = Modifier.padding(10.dp)) {
                            Text("Earned Commissions", fontSize = 10.sp, color = Color(0xFF92400E))
                            Text(
                                text = "KES ${String.format("%,.0f", walletSummary.casketCommissionTotal)}",
                                fontWeight = FontWeight.Bold,
                                fontSize = 14.sp,
                                color = Color(0xFF78350F)
                            )
                        }
                    }

                    Surface(
                        color = EmeraldLight,
                        shape = RoundedCornerShape(10.dp),
                        modifier = Modifier.weight(1f)
                    ) {
                        Column(modifier = Modifier.padding(10.dp)) {
                            Text("Service Payouts", fontSize = 10.sp, color = EmeraldSuccess)
                            Text(
                                text = "KES ${String.format("%,.0f", walletSummary.servicePayoutsTotal)}",
                                fontWeight = FontWeight.Bold,
                                fontSize = 14.sp,
                                color = EmeraldSuccess
                            )
                        }
                    }
                }

                Spacer(modifier = Modifier.height(14.dp))

                // Staff Account Credentials (Admin Can View & Reset Desired Password)
                Surface(
                    color = AmberLight.copy(alpha = 0.6f),
                    shape = RoundedCornerShape(10.dp),
                    border = androidx.compose.foundation.BorderStroke(1.dp, AmberWarning.copy(alpha = 0.5f)),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Column(modifier = Modifier.padding(12.dp)) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Icon(
                                    imageVector = Icons.Default.Key,
                                    contentDescription = null,
                                    tint = Navy900,
                                    modifier = Modifier.size(16.dp)
                                )
                                Spacer(modifier = Modifier.width(6.dp))
                                Text(
                                    text = "Password Status: ",
                                    fontSize = 12.sp,
                                    color = Navy900
                                )
                                Text(
                                    text = if (staff.mustRotatePassword) "Factory Default (Rotation Req.)" else "Secured (Salted SHA-256)",
                                    fontSize = 12.sp,
                                    fontWeight = FontWeight.ExtraBold,
                                    color = Navy900
                                )
                            }

                            Button(
                                onClick = { showPasswordResetInput = !showPasswordResetInput },
                                colors = ButtonDefaults.buttonColors(containerColor = Navy900),
                                shape = RoundedCornerShape(6.dp),
                                contentPadding = androidx.compose.foundation.layout.PaddingValues(horizontal = 8.dp, vertical = 2.dp),
                                modifier = Modifier.height(26.dp)
                            ) {
                                Text(if (showPasswordResetInput) "Cancel" else "Change", fontSize = 10.sp)
                            }
                        }

                        if (showPasswordResetInput) {
                            Spacer(modifier = Modifier.height(8.dp))
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                OutlinedTextField(
                                    value = newPasswordInput,
                                    onValueChange = { newPasswordInput = it },
                                    placeholder = { Text("New password", fontSize = 11.sp) },
                                    modifier = Modifier.weight(1f),
                                    singleLine = true
                                )
                                Spacer(modifier = Modifier.width(8.dp))
                                Button(
                                    onClick = {
                                        if (newPasswordInput.isNotBlank()) {
                                            onResetPassword(staff.id, newPasswordInput)
                                            showPasswordResetInput = false
                                            passwordResetSuccess = true
                                        }
                                    },
                                    colors = ButtonDefaults.buttonColors(containerColor = CyanPrimary),
                                    shape = RoundedCornerShape(6.dp),
                                    modifier = Modifier.height(48.dp)
                                ) {
                                    Text("Save", fontSize = 11.sp)
                                }
                            }
                        }

                        if (passwordResetSuccess) {
                            Spacer(modifier = Modifier.height(4.dp))
                            Text(
                                text = "Password updated successfully!",
                                color = EmeraldSuccess,
                                fontSize = 11.sp,
                                fontWeight = FontWeight.Bold
                            )
                        }
                    }
                }

                Spacer(modifier = Modifier.height(14.dp))

                // Detail entries
                InfoRow("Role & Title", staff.role.title)
                InfoRow("Department", staff.department.displayName)
                InfoRow("Duty Branch", staff.branch)
                InfoRow("Assigned Fleet Vehicle", staff.assignedVehicle ?: "None (Unassigned)")
                InfoRow("Base Salary", "KES ${String.format("%,.0f", staff.baseSalaryKes)}")
                InfoRow("Monthly Allowance", "KES ${String.format("%,.0f", staff.allowanceKes)}")
                InfoRow("Casket Commission Rate", "${staff.commissionRatePercent}%")
                InfoRow("Staff Status", if (staff.isActive) "Active Duty" else "Suspended / Inactive")
                InfoRow("Email Address", staff.email)
                InfoRow("Phone Number", staff.phone)
                InfoRow("National ID", staff.nationalId)
                InfoRow("M-PESA Number", staff.defaultMpesaNumber)
                InfoRow("Bank Details", staff.defaultBankDetails)
                InfoRow("Date Joined", staff.joinedDate)
                if (staff.notes.isNotBlank()) {
                    InfoRow("Executive Remarks", staff.notes)
                }

                Spacer(modifier = Modifier.height(18.dp))

                // ACTION: EDIT STAFF VALUES & ROLES
                Button(
                    onClick = {
                        onDismiss()
                        onEditRoleAndValues(staff)
                    },
                    colors = ButtonDefaults.buttonColors(containerColor = CyanPrimary),
                    shape = RoundedCornerShape(10.dp),
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(46.dp)
                        .testTag("admin_edit_staff_role_button")
                ) {
                    Icon(imageVector = Icons.Default.Edit, contentDescription = null)
                    Spacer(modifier = Modifier.width(8.dp))
                    Text("Edit Role & Values (Salary / Branch / Role)", fontWeight = FontWeight.Bold)
                }

                Spacer(modifier = Modifier.height(8.dp))

                // PRIMARY ACTION: OPEN INDEPENDENT PORTAL AS THIS STAFF MEMBER
                OutlinedButton(
                    onClick = {
                        onAccessAccount(staff)
                        onDismiss()
                    },
                    shape = RoundedCornerShape(10.dp),
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(46.dp)
                        .testTag("access_staff_account_button")
                ) {
                    Icon(imageVector = Icons.Default.Login, contentDescription = null, tint = CyanPrimary)
                    Spacer(modifier = Modifier.width(8.dp))
                    Text("Open Independent Portal (${staff.fullName.split(" ").first()})", color = CyanPrimary, fontWeight = FontWeight.Bold)
                }

                Spacer(modifier = Modifier.height(8.dp))

                // OPEN STAFF DIGITAL WALLET DIRECTLY
                Button(
                    onClick = {
                        onOpenWallet(staff)
                        onDismiss()
                    },
                    colors = ButtonDefaults.buttonColors(containerColor = EmeraldSuccess),
                    shape = RoundedCornerShape(10.dp),
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(46.dp)
                        .testTag("open_staff_wallet_button")
                ) {
                    Icon(imageVector = Icons.Default.AccountBalanceWallet, contentDescription = null)
                    Spacer(modifier = Modifier.width(8.dp))
                    Text("Open Digital Wallet & Commissions", fontWeight = FontWeight.Bold)
                }

                Spacer(modifier = Modifier.height(8.dp))

                // SECONDARY ACTION: CREDIT STAFF WALLET
                OutlinedButton(
                    onClick = {
                        onCreditWallet(staff)
                        onDismiss()
                    },
                    shape = RoundedCornerShape(10.dp),
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(44.dp)
                        .testTag("admin_credit_staff_button")
                ) {
                    Icon(imageVector = Icons.Default.Payments, contentDescription = null, tint = EmeraldSuccess)
                    Spacer(modifier = Modifier.width(8.dp))
                    Text("Credit Wallet / Disburse Funds", color = EmeraldSuccess, fontWeight = FontWeight.Bold)
                }
            }
        }
    }
}

@Composable
private fun InfoRow(label: String, value: String) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .padding(vertical = 4.dp),
        horizontalArrangement = Arrangement.SpaceBetween
    ) {
        Text(text = label, fontSize = 11.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
        Text(text = value.ifBlank { "Not provided" }, fontSize = 11.sp, fontWeight = FontWeight.Medium)
    }
    HorizontalDivider(thickness = 0.5.dp, color = MaterialTheme.colorScheme.outline.copy(alpha = 0.3f))
}
