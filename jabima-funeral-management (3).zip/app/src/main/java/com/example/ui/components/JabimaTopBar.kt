package com.example.ui.components

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.automirrored.filled.ExitToApp
import androidx.compose.material.icons.filled.AdminPanelSettings
import androidx.compose.material.icons.filled.Church
import androidx.compose.material.icons.filled.AccountBalance
import androidx.compose.material.icons.filled.Share
import androidx.compose.material.icons.filled.Fingerprint
import androidx.compose.material.icons.filled.Lock
import androidx.compose.material.icons.filled.MedicalServices
import androidx.compose.material.icons.filled.CloudDone
import androidx.compose.material.icons.filled.CloudOff
import androidx.compose.material.icons.filled.CloudSync
import androidx.compose.material.icons.filled.Security
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import com.example.ui.theme.ForestGreenDark
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.material.icons.filled.TableChart
import androidx.compose.material.icons.filled.Search
import androidx.compose.material.icons.filled.FileDownload
import androidx.compose.material.icons.filled.NotificationsActive
import androidx.compose.material.icons.filled.WbSunny
import androidx.compose.material.icons.filled.Nightlight
import androidx.compose.material.icons.filled.AutoAwesome
import com.example.R
import com.example.data.firebase.CloudSyncState
import com.example.model.MainAppTab
import com.example.model.StaffAccount
import com.example.model.StaffRole
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.material3.HorizontalDivider
import com.example.ui.theme.AmberLight
import com.example.ui.theme.AmberWarning
import com.example.ui.theme.CyanContainer
import com.example.ui.theme.CyanDark
import com.example.ui.theme.CyanPrimary
import com.example.ui.theme.EmeraldSuccess
import com.example.ui.theme.ForestGreenLight
import com.example.ui.theme.ForestGreenPrimary
import com.example.ui.theme.Navy800
import com.example.ui.theme.Navy900
import com.example.ui.theme.PureWhite
import com.example.ui.theme.RoseLight
import com.example.ui.theme.StrokeRed

@Composable
fun JabimaTopBar(
    currentAccount: StaffAccount?,
    adminImpersonator: StaffAccount?,
    onSignOut: () -> Unit,
    onReturnToAdmin: () -> Unit,
    onChangePassword: () -> Unit,
    onBiometricClick: (() -> Unit)? = null,
    onAdminClick: (() -> Unit)? = null,
    onOpenServices: (() -> Unit)? = null,
    onOpenMemorials: (() -> Unit)? = null,
    currentMainTab: MainAppTab = MainAppTab.STAFF_OPERATIONS,
    onOpenKraPortal: (() -> Unit)? = null,
    onOpenAppShareLink: (() -> Unit)? = null,
    onOpenExcelImport: (() -> Unit)? = null,
    onOpenSpotlight: (() -> Unit)? = null,
    onOpenExcelExport: (() -> Unit)? = null,
    isOutdoorMode: Boolean = false,
    onToggleOutdoorMode: (() -> Unit)? = null,
    isDarkMode: Boolean = false,
    onToggleDarkMode: (() -> Unit)? = null,
    isOnline: Boolean = true,
    pendingSyncCount: Int = 0,
    onOpenOfflineQueue: (() -> Unit)? = null,
    unreadAlertCount: Int = 0,
    onOpenShiftAlerts: (() -> Unit)? = null,
    onOpenGeminiAi: (() -> Unit)? = null,
    cloudUserEmail: String? = null,
    cloudSyncState: CloudSyncState = CloudSyncState.SignedOut,
    onCloudSyncClick: (() -> Unit)? = null
) {
    Surface(
        color = ForestGreenPrimary,
        tonalElevation = 4.dp,
        modifier = Modifier
            .fillMaxWidth()
            .testTag("jabima_top_bar")
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .background(
                    Brush.horizontalGradient(
                        colors = listOf(
                            ForestGreenDark,
                            ForestGreenPrimary,
                            ForestGreenLight
                        )
                    )
                )
                .statusBarsPadding()
        ) {
            // Main Header Row: Logo, Brand & Primary Account Controls
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 14.dp, vertical = 8.dp),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                // Left: Logo & Company Name
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    modifier = Modifier.weight(1f)
                ) {
                    Box(
                        modifier = Modifier
                            .size(42.dp)
                            .clip(CircleShape)
                            .background(Color.White)
                            .border(2.dp, StrokeRed, CircleShape),
                        contentAlignment = Alignment.Center
                    ) {
                        Image(
                            painter = painterResource(id = R.drawable.jfd_logo),
                            contentDescription = "Jabima Funeral Directors Primary Logo",
                            contentScale = ContentScale.Crop,
                            modifier = Modifier.size(38.dp).clip(CircleShape)
                        )
                    }

                    Spacer(modifier = Modifier.width(10.dp))

                    Column {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Text(
                                text = "JABIMA FUNERAL",
                                color = Color.White,
                                fontWeight = FontWeight.Bold,
                                fontSize = 14.sp,
                                letterSpacing = 0.4.sp,
                                maxLines = 1,
                                overflow = TextOverflow.Ellipsis
                            )
                            Spacer(modifier = Modifier.width(6.dp))
                            val (badgeText, badgeColor) = when (currentMainTab) {
                                MainAppTab.CASKET_SELECTION -> "CASKET ORDER" to Color(0xFF60A5FA)
                                MainAppTab.ORDERS_PAYMENTS -> "ORDER & PAY" to Color(0xFF34D399)
                                MainAppTab.COMMUNICATION_3CX -> "3CX COMMS" to Color(0xFF38BDF8)
                                MainAppTab.BULK_SMS -> "BULK SMS" to Color(0xFF34D399)
                                MainAppTab.SALES_SERVICES -> "SALES SERVICES" to Color(0xFF93C5FD)
                                MainAppTab.STAFF_OPERATIONS -> "STAFF PORTAL" to Color(0xFF86EFAC)
                                MainAppTab.ADMIN_CONSOLE -> "ADMIN CONSOLE" to Color(0xFFF87171)
                                MainAppTab.STAFF_WALLET -> "STAFF WALLET" to Color(0xFF4ADE80)
                                MainAppTab.MANAGEMENT_STRUCTURE -> "LEADERSHIP" to Color(0xFF93C5FD)
                                MainAppTab.ROSTER_CALENDAR -> "ROSTER SHIFTS" to Color(0xFF38BDF8)
                                MainAppTab.DAILY_LOG -> "DAILY LOG" to Color(0xFF10B981)
                                MainAppTab.STOCK_MOVEMENT -> "STOCK TRANSIT" to Color(0xFF60A5FA)
                                MainAppTab.BRANCH_BOARDS -> "STATUS BOARDS" to Color(0xFF93C5FD)
                                MainAppTab.VENDOR_MANAGEMENT -> "VENDORS" to Color(0xFF38BDF8)
                                MainAppTab.BRANCHES_FLEET -> "BRANCHES & FLEET" to Color(0xFF60A5FA)
                                MainAppTab.THERMAL_POS -> "THERMAL POS" to Color(0xFF93C5FD)
                                MainAppTab.SERVICES -> "SERVICES" to Color(0xFF38BDF8)
                                MainAppTab.MEMORIALS -> "MEMORIALS" to Color(0xFFBFDBFE)
                                MainAppTab.CRM_INTEGRATIONS -> "CRM & INTEGRATIONS" to Color(0xFFF59E0B)
                                MainAppTab.FLEET_TRACKING -> "FLEET GPS MAP" to Color(0xFF10B981)
                                MainAppTab.WORKSHOP_PRODUCTION -> "LIVE WORKSHOP" to Color(0xFFF59E0B)
                                MainAppTab.INVENTORY_MANAGEMENT -> "INVENTORY MGMT" to Color(0xFF38BDF8)
                                MainAppTab.BURIAL_SCHEDULING -> "BURIAL SCHEDULE" to Color(0xFF60A5FA)
                                MainAppTab.DAILY_REPORT -> "DAILY REPORTS" to Color(0xFF10B981)
                                MainAppTab.REMOTE_SURVEILLANCE -> "CCTV SURVEILLANCE" to Color(0xFF34D399)
                                MainAppTab.KRA_PORTAL -> "KRA iTAX & eTIMS" to Color(0xFFEF4444)
                                MainAppTab.COSTINGS_AND_PRICING -> "COSTINGS & BOM" to Color(0xFF34D399)
                                MainAppTab.ORDER_DASHBOARD -> "ORDER DASHBOARD" to Color(0xFF34D399)
                                MainAppTab.COST_ANALYTICS -> "COST ANALYTICS" to Color(0xFFF59E0B)
                                MainAppTab.AI_ASSISTANT -> "GEMINI AI" to Color(0xFF6EE7B7)
                            }
                            Box(
                                modifier = Modifier
                                    .background(badgeColor.copy(alpha = 0.22f), RoundedCornerShape(4.dp))
                                    .padding(horizontal = 5.dp, vertical = 2.dp)
                            ) {
                                Text(
                                    text = badgeText,
                                    color = badgeColor,
                                    fontSize = 8.sp,
                                    fontWeight = FontWeight.ExtraBold,
                                    maxLines = 1,
                                    softWrap = false
                                )
                            }
                        }
                        Text(
                            text = "Directors Ltd • Care • Dignity • Respect",
                            color = Color(0xFFD1FAE5),
                            fontSize = 10.sp,
                            maxLines = 1,
                            overflow = TextOverflow.Ellipsis
                        )
                    }
                }

                // Right Top Compact Controls: Alerts + Biometric + Lock + Sign Out
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(2.dp)
                ) {
                    if (onOpenShiftAlerts != null) {
                        val hasUnread = unreadAlertCount > 0
                        Surface(
                            onClick = onOpenShiftAlerts,
                            shape = RoundedCornerShape(12.dp),
                            color = if (hasUnread) Color(0xFFF59E0B).copy(alpha = 0.28f) else Color.White.copy(alpha = 0.12f),
                            border = BorderStroke(
                                1.dp,
                                if (hasUnread) Color(0xFFFBBF24) else Color.White.copy(alpha = 0.25f)
                            ),
                            modifier = Modifier
                                .height(30.dp)
                                .testTag("top_bar_shift_alerts_button")
                        ) {
                            Row(
                                modifier = Modifier.padding(horizontal = 7.dp, vertical = 4.dp),
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Icon(
                                    imageVector = Icons.Default.NotificationsActive,
                                    contentDescription = "Open Shift Alert Center",
                                    tint = if (hasUnread) Color(0xFFFBBF24) else Color(0xFFCBD5E1),
                                    modifier = Modifier.size(14.dp)
                                )
                                if (hasUnread) {
                                    Spacer(modifier = Modifier.width(3.dp))
                                    Text(
                                        text = "$unreadAlertCount",
                                        color = Color(0xFFFDE68A),
                                        fontSize = 10.sp,
                                        fontWeight = FontWeight.ExtraBold,
                                        maxLines = 1,
                                        softWrap = false
                                    )
                                }
                            }
                        }
                    }

                    if (currentAccount != null) {
                        if (onBiometricClick != null) {
                            IconButton(
                                onClick = onBiometricClick,
                                modifier = Modifier
                                    .size(34.dp)
                                    .testTag("top_bar_biometric_button")
                            ) {
                                Icon(
                                    imageVector = Icons.Default.Fingerprint,
                                    contentDescription = "Biometric Lock",
                                    tint = if (currentAccount.isBiometricEnabled) Color(0xFF34D399) else Color(0xFF94A3B8),
                                    modifier = Modifier.size(18.dp)
                                )
                            }
                        }
                        IconButton(
                            onClick = onChangePassword,
                            modifier = Modifier
                                .size(34.dp)
                                .testTag("change_password_button")
                        ) {
                            Icon(
                                imageVector = Icons.Default.Lock,
                                contentDescription = "Change Password",
                                tint = Color(0xFFCBD5E1),
                                modifier = Modifier.size(17.dp)
                            )
                        }
                        IconButton(
                            onClick = onSignOut,
                            modifier = Modifier
                                .size(34.dp)
                                .testTag("sign_out_button")
                        ) {
                            Icon(
                                imageVector = Icons.AutoMirrored.Filled.ExitToApp,
                                contentDescription = "Sign Out",
                                tint = Color(0xFFFCA5A5),
                                modifier = Modifier.size(17.dp)
                            )
                        }
                    }
                }
            }

            // Secondary Scrollable Utility Action Strip (guaranteed reachable on every phone screen width)
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .horizontalScroll(rememberScrollState())
                    .padding(start = 12.dp, end = 12.dp, bottom = 8.dp),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(6.dp)
            ) {
                    // Pending Field Sync / Offline Indicator Pill
                    if (onOpenOfflineQueue != null) {
                        val syncBg = when {
                            !isOnline -> Color(0xFFF59E0B).copy(alpha = 0.25f)
                            pendingSyncCount > 0 -> Color(0xFF0284C7).copy(alpha = 0.28f)
                            else -> Color(0xFF10B981).copy(alpha = 0.2f)
                        }
                        val syncBorder = when {
                            !isOnline -> Color(0xFFFBBF24)
                            pendingSyncCount > 0 -> Color(0xFF7DD3FC)
                            else -> Color(0xFF6EE7B7)
                        }
                        val syncText = when {
                            !isOnline && pendingSyncCount > 0 -> "Offline ($pendingSyncCount)"
                            !isOnline -> "Offline"
                            pendingSyncCount > 0 -> "Sync ($pendingSyncCount)"
                            else -> "Online"
                        }
                        Surface(
                            onClick = onOpenOfflineQueue,
                            shape = RoundedCornerShape(12.dp),
                            color = syncBg,
                            border = BorderStroke(1.dp, syncBorder.copy(alpha = 0.7f)),
                            modifier = Modifier
                                .height(32.dp)
                                .testTag("top_bar_offline_sync_badge")
                        ) {
                            Row(
                                modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp),
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Icon(
                                    imageVector = when {
                                        !isOnline -> Icons.Default.CloudOff
                                        pendingSyncCount > 0 -> Icons.Default.CloudSync
                                        else -> Icons.Default.CloudDone
                                    },
                                    contentDescription = "Field Sync Queue Status",
                                    tint = syncBorder,
                                    modifier = Modifier.size(14.dp)
                                )
                                Spacer(modifier = Modifier.width(4.dp))
                                Text(
                                    text = syncText,
                                    color = syncBorder,
                                    fontSize = 10.sp,
                                    fontWeight = FontWeight.Bold
                                )
                            }
                        }
                    }

                    // Multi-Device Cloud Sync Status Pill
                    if (onCloudSyncClick != null) {
                        val cloudBg = when {
                            cloudUserEmail == null -> Color(0xFF94A3B8).copy(alpha = 0.2f)
                            cloudSyncState is CloudSyncState.Syncing -> Color(0xFF0284C7).copy(alpha = 0.28f)
                            cloudSyncState is CloudSyncState.Error -> Color(0xFFF59E0B).copy(alpha = 0.28f)
                            else -> Color(0xFF10B981).copy(alpha = 0.24f)
                        }
                        val cloudBorder = when {
                            cloudUserEmail == null -> Color(0xFFCBD5E1)
                            cloudSyncState is CloudSyncState.Syncing -> Color(0xFF7DD3FC)
                            cloudSyncState is CloudSyncState.Error -> Color(0xFFFBBF24)
                            else -> Color(0xFF6EE7B7)
                        }
                        val cloudLabel = when {
                            cloudUserEmail == null -> "Cloud: Off"
                            cloudSyncState is CloudSyncState.Syncing -> "Syncing..."
                            cloudSyncState is CloudSyncState.Error -> "Cloud Retry"
                            else -> "Cloud: Synced"
                        }
                        val cloudIcon = when {
                            cloudUserEmail == null -> Icons.Default.CloudOff
                            cloudSyncState is CloudSyncState.Syncing -> Icons.Default.CloudSync
                            cloudSyncState is CloudSyncState.Error -> Icons.Default.CloudSync
                            else -> Icons.Default.CloudDone
                        }
                        Surface(
                            onClick = onCloudSyncClick,
                            shape = RoundedCornerShape(12.dp),
                            color = cloudBg,
                            border = BorderStroke(1.dp, cloudBorder.copy(alpha = 0.75f)),
                            modifier = Modifier
                                .height(32.dp)
                                .testTag("top_bar_cloud_auth_button")
                        ) {
                            Row(
                                modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp),
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Icon(
                                    imageVector = cloudIcon,
                                    contentDescription = "Google Cloud Sync Status",
                                    tint = cloudBorder,
                                    modifier = Modifier.size(14.dp)
                                )
                                Spacer(modifier = Modifier.width(4.dp))
                                Text(
                                    text = cloudLabel,
                                    color = cloudBorder,
                                    fontSize = 10.sp,
                                    fontWeight = FontWeight.Bold,
                                    maxLines = 1,
                                    softWrap = false
                                )
                            }
                        }
                    }

                    // Gemini AI Copilot quick action button
                    if (onOpenGeminiAi != null) {
                        Surface(
                            onClick = onOpenGeminiAi,
                            shape = RoundedCornerShape(12.dp),
                            color = Color(0xFF10B981).copy(alpha = 0.25f),
                            border = BorderStroke(1.dp, Color(0xFF6EE7B7).copy(alpha = 0.7f)),
                            modifier = Modifier
                                .height(32.dp)
                                .testTag("top_bar_gemini_ai_button")
                        ) {
                            Row(
                                modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp),
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Icon(
                                    imageVector = Icons.Default.AutoAwesome,
                                    contentDescription = "Open Gemini AI Copilot",
                                    tint = Color(0xFF6EE7B7),
                                    modifier = Modifier.size(14.dp)
                                )
                                Spacer(modifier = Modifier.width(4.dp))
                                Text(
                                    text = "Gemini AI",
                                    color = Color(0xFFD1FAE5),
                                    fontSize = 11.sp,
                                    fontWeight = FontWeight.Bold
                                )
                            }
                        }
                    }

                    // KRA Tax Portal Quick Action Button
                    if (onOpenKraPortal != null) {
                        Surface(
                            onClick = onOpenKraPortal,
                            shape = RoundedCornerShape(12.dp),
                            color = Color(0xFFDC2626).copy(alpha = 0.2f),
                            border = BorderStroke(1.dp, Color(0xFFDC2626).copy(alpha = 0.5f)),
                            modifier = Modifier
                                .height(32.dp)
                                .testTag("top_bar_kra_portal_button")
                        ) {
                            Row(
                                modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp),
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Icon(
                                    imageVector = Icons.Default.AccountBalance,
                                    contentDescription = "KRA Tax Portal",
                                    tint = Color(0xFFF87171),
                                    modifier = Modifier.size(14.dp)
                                )
                                Spacer(modifier = Modifier.width(4.dp))
                                Text(
                                    text = "KRA",
                                    color = Color(0xFFF87171),
                                    fontSize = 11.sp,
                                    fontWeight = FontWeight.Bold
                                )
                            }
                        }
                    }

                    // Universal Excel Import Hub Button
                    if (onOpenExcelImport != null) {
                        Surface(
                            onClick = onOpenExcelImport,
                            shape = RoundedCornerShape(12.dp),
                            color = Color(0xFF107C41).copy(alpha = 0.22f),
                            border = BorderStroke(1.dp, Color(0xFF107C41).copy(alpha = 0.6f)),
                            modifier = Modifier
                                .height(32.dp)
                                .testTag("top_bar_excel_import_button")
                        ) {
                            Row(
                                modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp),
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Icon(
                                    imageVector = Icons.Default.TableChart,
                                    contentDescription = "Import Various Data from Excel",
                                    tint = Color(0xFF4ADE80),
                                    modifier = Modifier.size(14.dp)
                                )
                                Spacer(modifier = Modifier.width(4.dp))
                                Text(
                                    text = "Import Excel",
                                    color = Color(0xFF4ADE80),
                                    fontSize = 11.sp,
                                    fontWeight = FontWeight.Bold
                                )
                            }
                        }
                    }

                    // Export Excel / Manifests Button
                    if (onOpenExcelExport != null) {
                        IconButton(
                            onClick = onOpenExcelExport,
                            modifier = Modifier
                                .size(36.dp)
                                .testTag("top_bar_export_manifest_button")
                        ) {
                            Icon(
                                imageVector = Icons.Default.FileDownload,
                                contentDescription = "Export Excel & Route Manifests",
                                tint = Color(0xFF67E8F9),
                                modifier = Modifier.size(19.dp)
                            )
                        }
                    }

                    // Spotlight Command Palette Search Button
                    if (onOpenSpotlight != null) {
                        IconButton(
                            onClick = onOpenSpotlight,
                            modifier = Modifier
                                .size(36.dp)
                                .testTag("top_bar_spotlight_search_button")
                        ) {
                            Icon(
                                imageVector = Icons.Default.Search,
                                contentDescription = "Spotlight Search (All Business Data)",
                                tint = PureWhite,
                                modifier = Modifier.size(19.dp)
                            )
                        }
                    }

                    // 24/7 Operations Dark Mode Toggle Button (Eye Strain Relief)
                    if (onToggleDarkMode != null) {
                        IconButton(
                            onClick = onToggleDarkMode,
                            modifier = Modifier
                                .size(36.dp)
                                .testTag("top_bar_dark_mode_button")
                        ) {
                            Icon(
                                imageVector = if (isDarkMode) Icons.Default.WbSunny else Icons.Default.Nightlight,
                                contentDescription = if (isDarkMode) "Switch to Daytime Light Mode" else "Switch to 24/7 Night Dark Mode (Eye Comfort)",
                                tint = if (isDarkMode) Color(0xFFFBBF24) else Color(0xFF86EFAC),
                                modifier = Modifier.size(19.dp)
                            )
                        }
                    }

                    // Outdoor Sunlight / Night Vigil Mode Toggle
                    if (onToggleOutdoorMode != null) {
                        IconButton(
                            onClick = onToggleOutdoorMode,
                            modifier = Modifier
                                .size(36.dp)
                                .testTag("top_bar_outdoor_mode_button")
                        ) {
                            Icon(
                                imageVector = if (isOutdoorMode) Icons.Default.WbSunny else Icons.Default.Nightlight,
                                contentDescription = "Toggle Outdoor Sunlight / Night Vigil Mode",
                                tint = if (isOutdoorMode) Color(0xFFFBBF24) else Color(0xFF94A3B8),
                                modifier = Modifier.size(18.dp)
                            )
                        }
                    }

                    // Share App Link Action Button
                    if (onOpenAppShareLink != null) {
                        IconButton(
                            onClick = onOpenAppShareLink,
                            modifier = Modifier
                                .size(36.dp)
                                .testTag("top_bar_app_link_button")
                        ) {
                            Icon(
                                imageVector = Icons.Default.Share,
                                contentDescription = "Share App & Web Portal Link",
                                tint = Color(0xFF7DD3FC),
                                modifier = Modifier.size(18.dp)
                            )
                        }
                    }

                    // Quick access to Funeral Packages Catalog
                    if (onOpenServices != null) {
                        IconButton(
                            onClick = onOpenServices,
                            modifier = Modifier
                                .size(36.dp)
                                .testTag("top_bar_services_button")
                                .testTag("nav_services")
                        ) {
                            Icon(
                                imageVector = Icons.Default.MedicalServices,
                                contentDescription = "Funeral Services Catalog",
                                tint = Color(0xFF6EE7B7),
                                modifier = Modifier.size(19.dp)
                            )
                        }
                    }

                    // Quick access to Memorials & Vigils
                    if (onOpenMemorials != null) {
                        IconButton(
                            onClick = onOpenMemorials,
                            modifier = Modifier
                                .size(36.dp)
                                .testTag("top_bar_memorials_button")
                                .testTag("nav_memorials")
                        ) {
                            Icon(
                                imageVector = Icons.Default.Church,
                                contentDescription = "Memorial Vigils & Livestreams",
                                tint = AmberLight,
                                modifier = Modifier.size(19.dp)
                            )
                        }
                    }

                }

            // Impersonation banner when Admin is accessing a staff account
            if (adminImpersonator != null && currentAccount != null) {
                Surface(
                    color = AmberWarning,
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(horizontal = 14.dp, vertical = 6.dp),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            modifier = Modifier.weight(1f)
                        ) {
                            Icon(
                                imageVector = Icons.Default.Security,
                                contentDescription = null,
                                tint = Navy900,
                                modifier = Modifier.size(18.dp)
                            )
                            Spacer(modifier = Modifier.width(6.dp))
                            Text(
                                text = "Admin Accessing: ${currentAccount.fullName} (${currentAccount.id})",
                                color = Navy900,
                                fontWeight = FontWeight.Bold,
                                fontSize = 12.sp,
                                maxLines = 1,
                                overflow = TextOverflow.Ellipsis
                            )
                        }

                        Button(
                            onClick = onReturnToAdmin,
                            colors = ButtonDefaults.buttonColors(
                                containerColor = Navy900,
                                contentColor = Color.White
                            ),
                            shape = RoundedCornerShape(6.dp),
                            contentPadding = androidx.compose.foundation.layout.PaddingValues(horizontal = 10.dp, vertical = 4.dp),
                            modifier = Modifier
                                .height(28.dp)
                                .testTag("return_to_admin_button")
                        ) {
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Icon(
                                    imageVector = Icons.AutoMirrored.Filled.ArrowBack,
                                    contentDescription = null,
                                    modifier = Modifier.size(12.dp)
                                )
                                Spacer(modifier = Modifier.width(4.dp))
                                Text("Back to Admin", fontSize = 11.sp, fontWeight = FontWeight.Bold)
                            }
                        }
                    }
                }
            }
            // Signature Stroke of Red hairline along the bottom edge of the green top bar
            HorizontalDivider(thickness = 2.dp, color = StrokeRed)
        }
    }
}
