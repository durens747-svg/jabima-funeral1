package com.example.ai

import com.example.data.StaffPortalRepository
import com.google.common.truth.Truth.assertThat
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.ExperimentalCoroutinesApi
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.flow
import kotlinx.coroutines.test.UnconfinedTestDispatcher
import kotlinx.coroutines.test.resetMain
import kotlinx.coroutines.test.runTest
import kotlinx.coroutines.test.setMain
import org.junit.After
import org.junit.Before
import org.junit.Test

@OptIn(ExperimentalCoroutinesApi::class)
class JabimaGeminiAssistantTest {

    private val testDispatcher = UnconfinedTestDispatcher()

    @Before
    fun setUp() {
        Dispatchers.setMain(testDispatcher)
    }

    @After
    fun tearDown() {
        Dispatchers.resetMain()
    }

    @Test
    fun buildSnapshot_and_parseStructuredCarePlan_extractExpectedFields() {
        val repo = StaffPortalRepository()
        val snapshot = JabimaPromptContextBuilder.buildSnapshot(
            currentAccount = repo.accounts.value.first(),
            activities = repo.activities.value,
            burials = repo.burialSchedules.value,
            caskets = repo.caskets.value,
            fleet = repo.fleetGpsVehicles.value,
            orders = repo.customerOrders.value,
            alerts = repo.staffAlerts.value
        )

        assertThat(snapshot.activeDutiesCount).isGreaterThan(0)
        assertThat(snapshot.staffName).isNotEmpty()

        val rawJson = """
            {
              "planTitle": "Bama Cortege Coordination",
              "prioritySummary": "Confirm hearse inspection and family liaison 2 hours prior.",
              "estimatedBudgetKes": 145000,
              "checklistSteps": ["Dispatch hearse KDQ 412B", "Verify mahogany casket polish"],
              "assignedRoles": ["Branch Lead", "Senior Driver"],
              "recommendedSmsNotice": "Jabima Funeral confirms cortege departure at 08:30 AM."
            }
        """.trimIndent()

        val parsed = JabimaPromptContextBuilder.parseStructuredCarePlan(rawJson)
        assertThat(parsed.planTitle).isEqualTo("Bama Cortege Coordination")
        assertThat(parsed.estimatedBudgetKes).isEqualTo(145000)
        assertThat(parsed.checklistSteps).hasSize(2)
        assertThat(parsed.assignedRoles).containsExactly("Branch Lead", "Senior Driver")
    }

    @Test
    fun streamingPrompt_accumulatesChunksAndTransitionsToSuccess() = runTest {
        val gateway = object : JabimaAiGateway {
            override fun generateChatStream(
                history: List<Pair<Boolean, String>>,
                prompt: String
            ): Flow<String> = flow {
                emit("Handover ")
                emit("Summary: ")
                emit("All 6 hearses active.")
            }

            override suspend fun generateStructuredPlanJson(prompt: String): String? = null
        }

        val vm = JabimaGeminiViewModel(aiGateway = gateway, errorLogger = { _, _ -> })
        vm.sendStreamingPrompt("Give shift briefing")

        assertThat(vm.uiState.value).isEqualTo(GeminiUiState.Success("Handover Summary: All 6 hearses active."))
        assertThat(vm.messages.value).hasSize(2)
        assertThat(vm.messages.value[0].isUser).isTrue()
        assertThat(vm.messages.value[1].isUser).isFalse()
        assertThat(vm.messages.value[1].isStreaming).isFalse()
        assertThat(vm.messages.value[1].text).isEqualTo("Handover Summary: All 6 hearses active.")
    }

    @Test
    fun errorPropagation_surfacesRealMessageAndSupportsRetry() = runTest {
        var shouldFail = true
        val gateway = object : JabimaAiGateway {
            override fun generateChatStream(
                history: List<Pair<Boolean, String>>,
                prompt: String
            ): Flow<String> = flow {
                if (shouldFail) throw IllegalStateException("HTTP 403 App Check token rejected")
                emit("Recovered response")
            }

            override suspend fun generateStructuredPlanJson(prompt: String): String? = null
        }

        val loggedErrors = mutableListOf<String>()
        val vm = JabimaGeminiViewModel(
            aiGateway = gateway,
            errorLogger = { msg, _ -> loggedErrors += msg }
        )
        vm.sendStreamingPrompt("Draft notice")

        val state = vm.uiState.value
        assertThat(state).isInstanceOf(GeminiUiState.Error::class.java)
        assertThat((state as GeminiUiState.Error).message).contains("HTTP 403")
        assertThat(loggedErrors).hasSize(1)

        shouldFail = false
        vm.retryLastRequest()
        assertThat(vm.uiState.value).isEqualTo(GeminiUiState.Success("Recovered response"))
    }
}
