package com.example.ui.screens

import android.content.Context
import android.content.Intent
import android.net.Uri
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.CameraAlt
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.Fullscreen
import androidx.compose.material.icons.filled.Info
import androidx.compose.material.icons.filled.Mic
import androidx.compose.material.icons.filled.MicOff
import androidx.compose.material.icons.filled.MotionPhotosOn
import androidx.compose.material.icons.automirrored.filled.OpenInNew
import androidx.compose.material.icons.automirrored.filled.VolumeOff
import androidx.compose.material.icons.automirrored.filled.VolumeUp
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material.icons.filled.Refresh
import androidx.compose.material.icons.filled.Security
import androidx.compose.material.icons.filled.Shield
import androidx.compose.material.icons.filled.Videocam
import androidx.compose.material.icons.filled.Warning
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.FilterChip
import androidx.compose.material3.FilterChipDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.ui.StaffPortalViewModel
import com.example.ui.theme.BorderLight
import com.example.ui.theme.ForestGreenBorder
import com.example.ui.theme.ForestGreenDark
import com.example.ui.theme.ForestGreenPrimary
import com.example.ui.theme.Navy900
import com.example.ui.theme.PureWhite
import com.example.ui.theme.StrokeRed
import com.example.ui.theme.StrokeRedLight
import kotlinx.coroutines.delay
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

data class CctvCameraFeed(
    val id: String,
    val name: String,
    val branch: String,
    val locationDescription: String,
    val appSource: String, // "V380 Pro" or "DMSS"
    val streamResolution: String = "1080P HD • 30 FPS",
    val status: String = "LIVE",
    val hasAudio: Boolean = true,
    val hasPtz: Boolean = true,
    val currentViewNotes: String
)

@Composable
fun RemoteSurveillanceScreen(
    viewModel: StaffPortalViewModel
) {
    val context = LocalContext.current
    var selectedFilter by remember { mutableStateOf("ALL") }
    var selectedCameraId by remember { mutableStateOf<String?>("CAM-01") }
    var audioEnabled by remember { mutableStateOf(false) }
    var nightVisionMode by remember { mutableStateOf(false) }
    var ptzZoomLevel by remember { mutableIntStateOf(1) }
    var feedbackBanner by remember { mutableStateOf<String?>(null) }

    // Live clock for CCTV timestamp overlay
    var liveTimestamp by remember {
        mutableStateOf(SimpleDateFormat("yyyy-MM-dd HH:mm:ss", Locale.getDefault()).format(Date()))
    }

    LaunchedEffect(Unit) {
        while (true) {
            delay(1000)
            liveTimestamp = SimpleDateFormat("yyyy-MM-dd HH:mm:ss", Locale.getDefault()).format(Date())
        }
    }

    val cameraFeeds = remember {
        listOf(
            CctvCameraFeed(
                id = "CAM-01",
                name = "Workshop Woodcraft & Fabrication Bay",
                branch = "Workshop",
                locationDescription = "Main timber sawing, joinery & casket assembly tables",
                appSource = "V380 Pro",
                streamResolution = "1080P HD • 30 FPS • 2.4Mbps",
                status = "LIVE",
                hasAudio = true,
                hasPtz = true,
                currentViewNotes = "Craftsmen active on Mahogany Imperial dome order #2026-094"
            ),
            CctvCameraFeed(
                id = "CAM-02",
                name = "Bama Branch Fleet Depot & Hearse Gate",
                branch = "Bama Branch",
                locationDescription = "Vehicle garage, cortege departure lane & main gate",
                appSource = "DMSS",
                streamResolution = "4K Ultra HD • 30 FPS • 4.1Mbps",
                status = "LIVE",
                hasAudio = true,
                hasPtz = true,
                currentViewNotes = "Hearse KDG 705Y & Caravan KCL 703C stationed on standby"
            ),
            CctvCameraFeed(
                id = "CAM-03",
                name = "Central Executive Casket Showroom",
                branch = "Siaya Main",
                locationDescription = "Customer presentation gallery & consultation alcove",
                appSource = "V380 Pro",
                streamResolution = "1080P HD • 25 FPS • 1.8Mbps",
                status = "LIVE",
                hasAudio = true,
                hasPtz = true,
                currentViewNotes = "18 Premium polished caskets displayed; lighting normal"
            ),
            CctvCameraFeed(
                id = "CAM-04",
                name = "Siaya Referal Emergency Intake Gate",
                branch = "Siaya Referal",
                locationDescription = "Opposite Hospital Morgue Gate • 24/7 First-Call desk",
                appSource = "DMSS",
                streamResolution = "1080P HD • 30 FPS • 2.2Mbps",
                status = "LIVE",
                hasAudio = true,
                hasPtz = true,
                currentViewNotes = "Night and day 24/7 security watch; driveway clear"
            ),
            CctvCameraFeed(
                id = "CAM-05",
                name = "Bama Accounts Office & Thermal Till",
                branch = "Bama Branch",
                locationDescription = "Cashier desk, safe storage & M-PESA B2C terminal",
                appSource = "V380 Pro",
                streamResolution = "4K Ultra HD • 25 FPS • 3.5Mbps",
                status = "LIVE",
                hasAudio = true,
                hasPtz = false,
                currentViewNotes = "Accounts Officer in attendance; safe door locked"
            ),
            CctvCameraFeed(
                id = "CAM-06",
                name = "Workshop Spray Painting & Finishing Chamber",
                branch = "Workshop",
                locationDescription = "High-gloss lacquer spray booth & brass handle station",
                appSource = "DMSS",
                streamResolution = "1080P HD • 30 FPS • 2.0Mbps",
                status = "LIVE",
                hasAudio = false,
                hasPtz = true,
                currentViewNotes = "Ventilation active; 3 caskets curing under infrared"
            )
        )
    }

    fun openExternalCctvApp(packageName: String, appName: String, playStoreUrl: String) {
        try {
            val launchIntent = context.packageManager.getLaunchIntentForPackage(packageName)
            if (launchIntent != null) {
                context.startActivity(launchIntent)
                viewModel.actionFeedbackMessage.value = "Launching $appName CCTV surveillance app..."
            } else {
                // Not installed: redirect to Play Store or browser
                val playIntent = Intent(Intent.ACTION_VIEW, Uri.parse("market://details?id=$packageName"))
                playIntent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                context.startActivity(playIntent)
                viewModel.actionFeedbackMessage.value = "Opening Google Play to install $appName..."
            }
        } catch (e: Exception) {
            try {
                val webIntent = Intent(Intent.ACTION_VIEW, Uri.parse(playStoreUrl))
                webIntent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                context.startActivity(webIntent)
                viewModel.actionFeedbackMessage.value = "Opening $appName download page..."
            } catch (err: Exception) {
                viewModel.actionFeedbackMessage.value = "Please install $appName from Google Play Store."
            }
        }
    }

    LazyColumn(
        modifier = Modifier
            .fillMaxSize()
            .background(Color(0xFFF0FDF4))
            .padding(horizontal = 14.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        item {
            Spacer(modifier = Modifier.height(6.dp))

            // EXECUTIVE SURVEILLANCE BANNER (Green & Stroke of Red Theme)
            Surface(
                color = Navy900,
                shape = RoundedCornerShape(14.dp),
                border = BorderStroke(1.dp, ForestGreenBorder),
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(modifier = Modifier.padding(16.dp)) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Box(
                                modifier = Modifier
                                    .size(42.dp)
                                    .clip(CircleShape)
                                    .background(Color(0xFF16A34A)),
                                contentAlignment = Alignment.Center
                            ) {
                                Icon(
                                    imageVector = Icons.Default.Videocam,
                                    contentDescription = "CCTV Cameras",
                                    tint = PureWhite,
                                    modifier = Modifier.size(24.dp)
                                )
                            }
                            Spacer(modifier = Modifier.width(10.dp))
                            Column {
                                Row(verticalAlignment = Alignment.CenterVertically) {
                                    Text(
                                        text = "24/7 REMOTE SURVEILLANCE",
                                        fontSize = 15.sp,
                                        fontWeight = FontWeight.Bold,
                                        color = PureWhite
                                    )
                                    Spacer(modifier = Modifier.width(6.dp))
                                    Box(
                                        modifier = Modifier
                                            .background(StrokeRed, RoundedCornerShape(4.dp))
                                            .padding(horizontal = 5.dp, vertical = 2.dp)
                                    ) {
                                        Text(
                                            text = "LIVE",
                                            fontSize = 9.sp,
                                            fontWeight = FontWeight.ExtraBold,
                                            color = PureWhite
                                        )
                                    }
                                }
                                Text(
                                    text = "Integrated V380 Pro & DMSS CCTV Feeds across Workshop & Branches",
                                    fontSize = 11.sp,
                                    color = Color(0xFFBBF7D0)
                                )
                            }
                        }
                    }

                    Spacer(modifier = Modifier.height(14.dp))

                    // APP INTEGRATION LAUNCH BUTTONS: V380 Pro & DMSS
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        // V380 PRO APP BUTTON
                        Button(
                            onClick = {
                                openExternalCctvApp(
                                    packageName = "com.macrovideo.v380pro",
                                    appName = "V380 Pro",
                                    playStoreUrl = "https://play.google.com/store/apps/details?id=com.macrovideo.v380pro"
                                )
                            },
                            colors = ButtonDefaults.buttonColors(
                                containerColor = Color(0xFF0284C7),
                                contentColor = PureWhite
                            ),
                            shape = RoundedCornerShape(8.dp),
                            contentPadding = androidx.compose.foundation.layout.PaddingValues(horizontal = 10.dp, vertical = 6.dp),
                            modifier = Modifier
                                .weight(1f)
                                .height(42.dp)
                                .testTag("launch_v380_pro_button")
                        ) {
                            Icon(Icons.AutoMirrored.Filled.OpenInNew, contentDescription = null, modifier = Modifier.size(15.dp))
                            Spacer(modifier = Modifier.width(6.dp))
                            Column {
                                Text("Open V380 Pro", fontSize = 11.sp, fontWeight = FontWeight.Bold)
                                Text("Cloud & WiFi IP Cams", fontSize = 9.sp, color = Color(0xFFE0F2FE))
                            }
                        }

                        // DMSS APP BUTTON
                        Button(
                            onClick = {
                                openExternalCctvApp(
                                    packageName = "com.mm.android.DMSS",
                                    appName = "DMSS CCTV",
                                    playStoreUrl = "https://play.google.com/store/apps/details?id=com.mm.android.DMSS"
                                )
                            },
                            colors = ButtonDefaults.buttonColors(
                                containerColor = Color(0xFF0F766E),
                                contentColor = PureWhite
                            ),
                            shape = RoundedCornerShape(8.dp),
                            contentPadding = androidx.compose.foundation.layout.PaddingValues(horizontal = 10.dp, vertical = 6.dp),
                            modifier = Modifier
                                .weight(1f)
                                .height(42.dp)
                                .testTag("launch_dmss_button")
                        ) {
                            Icon(Icons.Default.Security, contentDescription = null, modifier = Modifier.size(15.dp))
                            Spacer(modifier = Modifier.width(6.dp))
                            Column {
                                Text("Open DMSS", fontSize = 11.sp, fontWeight = FontWeight.Bold)
                                Text("Dahua NVR & HD Feeds", fontSize = 9.sp, color = Color(0xFFCCFBF1))
                            }
                        }
                    }
                }
            }
        }

        // Active Camera Preview Monitor
        item {
            val activeCam = cameraFeeds.firstOrNull { it.id == selectedCameraId } ?: cameraFeeds.first()

            Card(
                shape = RoundedCornerShape(14.dp),
                colors = CardDefaults.cardColors(containerColor = Color(0xFF0F172A)),
                border = BorderStroke(1.5.dp, if (nightVisionMode) Color(0xFF10B981) else Color(0xFF334155)),
                modifier = Modifier
                    .fillMaxWidth()
                    .testTag("cctv_live_monitor_card")
            ) {
                Column(modifier = Modifier.padding(12.dp)) {
                    // Monitor Top Bar
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Box(
                                modifier = Modifier
                                    .size(8.dp)
                                    .clip(CircleShape)
                                    .background(StrokeRed)
                            )
                            Spacer(modifier = Modifier.width(6.dp))
                            Text(
                                text = "REC • ${activeCam.appSource} • ${activeCam.id}",
                                fontSize = 11.sp,
                                fontFamily = FontFamily.Monospace,
                                fontWeight = FontWeight.Bold,
                                color = StrokeRed
                            )
                        }

                        Text(
                            text = liveTimestamp,
                            fontSize = 11.sp,
                            fontFamily = FontFamily.Monospace,
                            fontWeight = FontWeight.Bold,
                            color = Color(0xFF94A3B8)
                        )
                    }

                    Spacer(modifier = Modifier.height(8.dp))

                    // Video Viewport Canvas Simulation
                    Box(
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(200.dp)
                            .clip(RoundedCornerShape(8.dp))
                            .background(
                                if (nightVisionMode) Brush.verticalGradient(listOf(Color(0xFF064E3B), Color(0xFF022C22)))
                                else Brush.verticalGradient(listOf(Color(0xFF1E293B), Color(0xFF090D16)))
                            )
                            .border(1.dp, Color(0xFF334155), RoundedCornerShape(8.dp)),
                        contentAlignment = Alignment.Center
                    ) {
                        // Scanlines & Watermark
                        Column(
                            modifier = Modifier
                                .fillMaxSize()
                                .padding(12.dp),
                            verticalArrangement = Arrangement.SpaceBetween
                        ) {
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.SpaceBetween
                            ) {
                                Text(
                                    text = "JABIMA FUNERAL DIRECTORS • ${activeCam.branch.uppercase()}",
                                    fontSize = 10.sp,
                                    fontFamily = FontFamily.Monospace,
                                    fontWeight = FontWeight.Bold,
                                    color = if (nightVisionMode) Color(0xFFA7F3D0) else Color(0xFF38BDF8)
                                )
                                Text(
                                    text = "${ptzZoomLevel}X ZOOM",
                                    fontSize = 10.sp,
                                    fontFamily = FontFamily.Monospace,
                                    color = Color.White
                                )
                            }

                            // Center Camera Focal Reticle
                            Box(
                                modifier = Modifier
                                    .align(Alignment.CenterHorizontally)
                                    .size(54.dp)
                                    .border(1.dp, Color.White.copy(alpha = 0.35f), CircleShape),
                                contentAlignment = Alignment.Center
                            ) {
                                Icon(
                                    imageVector = Icons.Default.CameraAlt,
                                    contentDescription = null,
                                    tint = if (nightVisionMode) Color(0xFF34D399) else Color.White.copy(alpha = 0.6f),
                                    modifier = Modifier.size(24.dp)
                                )
                            }

                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.Bottom
                            ) {
                                Text(
                                    text = activeCam.name,
                                    fontSize = 11.sp,
                                    fontWeight = FontWeight.Bold,
                                    color = Color.White
                                )
                                Text(
                                    text = activeCam.streamResolution,
                                    fontSize = 9.sp,
                                    fontFamily = FontFamily.Monospace,
                                    color = Color(0xFFCBD5E1)
                                )
                            }
                        }
                    }

                    Spacer(modifier = Modifier.height(10.dp))

                    // Live Status Notes & Stream Controls
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Text(
                            text = "Status: ${activeCam.currentViewNotes}",
                            fontSize = 11.sp,
                            color = Color(0xFFCBD5E1),
                            modifier = Modifier.weight(1f)
                        )

                        Row(horizontalArrangement = Arrangement.spacedBy(4.dp)) {
                            // Night vision toggle
                            IconButton(
                                onClick = { nightVisionMode = !nightVisionMode },
                                modifier = Modifier.size(34.dp)
                            ) {
                                Icon(
                                    imageVector = Icons.Default.MotionPhotosOn,
                                    contentDescription = "Night Vision",
                                    tint = if (nightVisionMode) Color(0xFF10B981) else Color(0xFF94A3B8),
                                    modifier = Modifier.size(18.dp)
                                )
                            }

                            // Audio toggle
                            IconButton(
                                onClick = { audioEnabled = !audioEnabled },
                                modifier = Modifier.size(34.dp)
                            ) {
                                Icon(
                                    imageVector = if (audioEnabled) Icons.AutoMirrored.Filled.VolumeUp else Icons.AutoMirrored.Filled.VolumeOff,
                                    contentDescription = "Audio Feed",
                                    tint = if (audioEnabled) Color(0xFF38BDF8) else Color(0xFF94A3B8),
                                    modifier = Modifier.size(18.dp)
                                )
                            }

                            // Zoom In/Out
                            IconButton(
                                onClick = { ptzZoomLevel = if (ptzZoomLevel >= 3) 1 else ptzZoomLevel + 1 },
                                modifier = Modifier.size(34.dp)
                            ) {
                                Icon(
                                    imageVector = Icons.Default.Fullscreen,
                                    contentDescription = "Zoom",
                                    tint = Color(0xFFF59E0B),
                                    modifier = Modifier.size(18.dp)
                                )
                            }
                        }
                    }
                }
            }
        }

        // Camera Feed Filter Chips
        item {
            LazyRow(
                horizontalArrangement = Arrangement.spacedBy(6.dp),
                modifier = Modifier.fillMaxWidth()
            ) {
                val filters = listOf("ALL", "Workshop", "Bama Branch", "Siaya Main", "Siaya Referal")
                items(filters) { filter ->
                    FilterChip(
                        selected = selectedFilter == filter,
                        onClick = { selectedFilter = filter },
                        label = { Text(filter, fontSize = 11.sp) },
                        colors = FilterChipDefaults.filterChipColors(
                            selectedContainerColor = ForestGreenPrimary,
                            selectedLabelColor = PureWhite
                        )
                    )
                }
            }
        }

        // Available Camera Channels List
        val filteredFeeds = if (selectedFilter == "ALL") cameraFeeds else cameraFeeds.filter { it.branch == selectedFilter }
        items(filteredFeeds, key = { it.id }) { cam ->
            val isSelected = cam.id == selectedCameraId

            Surface(
                color = PureWhite,
                shape = RoundedCornerShape(12.dp),
                border = BorderStroke(
                    if (isSelected) 2.dp else 1.dp,
                    if (isSelected) ForestGreenPrimary else BorderLight
                ),
                modifier = Modifier
                    .fillMaxWidth()
                    .clickable { selectedCameraId = cam.id }
                    .testTag("camera_channel_${cam.id}")
            ) {
                Row(
                    modifier = Modifier
                        .padding(12.dp)
                        .fillMaxWidth(),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        modifier = Modifier.weight(1f)
                    ) {
                        Box(
                            modifier = Modifier
                                .size(36.dp)
                                .clip(CircleShape)
                                .background(if (isSelected) ForestGreenPrimary else Color(0xFFE2E8F0)),
                            contentAlignment = Alignment.Center
                        ) {
                            Icon(
                                imageVector = Icons.Default.Videocam,
                                contentDescription = null,
                                tint = if (isSelected) PureWhite else Color(0xFF475569),
                                modifier = Modifier.size(18.dp)
                            )
                        }

                        Spacer(modifier = Modifier.width(10.dp))

                        Column {
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Text(
                                    text = cam.id,
                                    fontSize = 11.sp,
                                    fontWeight = FontWeight.ExtraBold,
                                    color = ForestGreenPrimary
                                )
                                Spacer(modifier = Modifier.width(6.dp))
                                Text(
                                    text = cam.name,
                                    fontSize = 12.sp,
                                    fontWeight = FontWeight.Bold,
                                    color = Color(0xFF0F172A)
                                )
                            }
                            Text(
                                text = "${cam.branch} • App: ${cam.appSource}",
                                fontSize = 10.sp,
                                color = Color(0xFF64748B)
                            )
                            Text(
                                text = cam.locationDescription,
                                fontSize = 9.sp,
                                color = Color(0xFF94A3B8)
                            )
                        }
                    }

                    Button(
                        onClick = {
                            selectedCameraId = cam.id
                            if (cam.appSource == "V380 Pro") {
                                openExternalCctvApp(
                                    packageName = "com.macrovideo.v380pro",
                                    appName = "V380 Pro",
                                    playStoreUrl = "https://play.google.com/store/apps/details?id=com.macrovideo.v380pro"
                                )
                            } else {
                                openExternalCctvApp(
                                    packageName = "com.mm.android.DMSS",
                                    appName = "DMSS",
                                    playStoreUrl = "https://play.google.com/store/apps/details?id=com.mm.android.DMSS"
                                )
                            }
                        },
                        colors = ButtonDefaults.buttonColors(
                            containerColor = if (cam.appSource == "V380 Pro") Color(0xFF0284C7) else Color(0xFF0F766E)
                        ),
                        shape = RoundedCornerShape(6.dp),
                        contentPadding = androidx.compose.foundation.layout.PaddingValues(horizontal = 8.dp, vertical = 2.dp),
                        modifier = Modifier.height(28.dp)
                    ) {
                        Text(text = "View in ${cam.appSource}", fontSize = 9.sp, fontWeight = FontWeight.Bold)
                    }
                }
            }
        }

        item {
            Spacer(modifier = Modifier.height(40.dp))
        }
    }
}
