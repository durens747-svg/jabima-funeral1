package com.example.domain

import com.example.data.StaffPortalRepository
import com.example.model.CasketStockByBranchRow
import com.example.model.CustomerOrderRecord
import com.example.model.Department
import com.example.model.ExpenseCategory
import com.example.model.ExpenseStatus
import com.example.model.InventoryMaterialItem
import com.example.model.ProductItem
import com.example.model.StaffExpenseClaim
import com.example.model.VendorTransaction
import com.example.model.VendorTransactionType
import com.example.model.WorkshopProductionItem
import com.example.model.WorkshopProductionStage
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertNotNull
import org.junit.Assert.assertTrue
import org.junit.Test

class OperationsAnalyticsEngineTest {

    private val sampleMaterials = listOf(
        InventoryMaterialItem(
            id = "M-1",
            name = "12mm Chipboard",
            categoryId = "CAT-1",
            categoryName = "Boards & Timber",
            quantity = 0,
            unit = "Sheets",
            unitCostKes = 2500.0,
            minThreshold = 5,
            branchWarehouse = "Bama Branch",
            status = "OUT_OF_STOCK"
        ),
        InventoryMaterialItem(
            id = "M-2",
            name = "Woodworking Glue",
            categoryId = "CAT-2",
            categoryName = "Finishing Materials",
            quantity = 3,
            unit = "Litres",
            unitCostKes = 1000.0,
            minThreshold = 4,
            branchWarehouse = "Bama Branch",
            status = "LOW_STOCK"
        ),
        InventoryMaterialItem(
            id = "M-3",
            name = "Swing Bar Handles",
            categoryId = "CAT-3",
            categoryName = "Handles & Hardware",
            quantity = 12,
            unit = "Sets",
            unitCostKes = 6500.0,
            minThreshold = 3,
            branchWarehouse = "Siaya Main",
            status = "IN_STOCK"
        )
    )

    private val sampleOrders = listOf(
        CustomerOrderRecord(
            orderId = "ORD-1",
            clientName = "Jane Achieng",
            clientPhone = "0712345678",
            deceasedName = "Late Ochieng",
            selectedPackage = "Executive Package",
            selectedCasket = "Executive (KES 125,000)",
            selectedAddons = listOf("Lowering Gear"),
            totalAmountKes = 130000.0,
            totalAmountUsd = 1000.0,
            paymentMethod = "M-PESA",
            paymentTerms = "Full payment",
            paymentStatus = "Confirmed (M-PESA STK Verified)",
            referenceCode = "MPESA-111",
            orderDate = "15 Nov 2026",
            branch = "Siaya Main",
            salesAgentName = "Mary Sales",
            commissionEarnedKes = 6250.0
        ),
        CustomerOrderRecord(
            orderId = "ORD-2",
            clientName = "Peter Otieno",
            clientPhone = "0722334455",
            deceasedName = "Late Otieno",
            selectedPackage = "Standard Package",
            selectedCasket = "Kupa (KES 65,000)",
            selectedAddons = emptyList(),
            totalAmountKes = 70000.0,
            totalAmountUsd = 538.46,
            paymentMethod = "BANK_TRANSFER",
            paymentTerms = "Lipa pole pole Option (2 installments)",
            paymentStatus = "Installment 1 Received",
            referenceCode = "SCB-222",
            orderDate = "15 Nov 2026",
            branch = "Bondo Branch",
            salesAgentName = "John Sales",
            commissionEarnedKes = 3250.0
        )
    )

    @Test
    fun buildInventoryTrackerSummary_prioritizesCriticalStockAndComputesValuation() {
        val products = listOf(
            ProductItem("P-1", "Simple Coffin", "Casket", "Simple", 4, 15000.0, 25000.0, "Bama Branch", "15 Nov 2026", "Admin")
        )
        val branchRows = listOf(
            CasketStockByBranchRow("Simple", mapOf("Bama Branch" to 3, "Siaya Main" to 0), 25000.0)
        )

        val summary = OperationsAnalyticsEngine.buildInventoryTrackerSummary(
            materials = sampleMaterials,
            products = products,
            casketStockByBranch = branchRows
        )

        assertEquals(3, summary.totalMaterialSkus)
        assertEquals(15, summary.totalMaterialUnits)
        assertEquals(81000.0, summary.totalMaterialValuationKes, 0.01) // 0 + 3000 + 78000
        assertEquals(1, summary.outOfStockCount)
        assertEquals(1, summary.lowStockCount)
        assertEquals(1, summary.healthyStockCount)
        // Reorder: M-1 needs 10*2500=25,000; M-2 needs (8-3)*1000=5,000 => 30,000
        assertEquals(30000.0, summary.estimatedReorderCostKes, 0.01)
        assertEquals("M-1", summary.prioritizedMaterials.first().id)

        val lowOnly = OperationsAnalyticsEngine.buildInventoryTrackerSummary(
            materials = sampleMaterials,
            products = products,
            casketStockByBranch = branchRows,
            healthFilter = InventoryHealthStatus.LOW_STOCK
        )
        assertEquals(1, lowOnly.prioritizedMaterials.size)
        assertEquals("M-2", lowOnly.prioritizedMaterials.first().id)
    }

    @Test
    fun buildOrderDashboardSummary_computesCollectionRateChannelsAndFilters() {
        val summary = OperationsAnalyticsEngine.buildOrderDashboardSummary(
            orders = sampleOrders
        )

        assertEquals(2, summary.totalOrders)
        assertEquals(1, summary.confirmedOrders)
        assertEquals(1, summary.installmentOrders)
        assertEquals(200000.0, summary.totalRevenueKes, 0.01)
        assertEquals(130000.0, summary.confirmedRevenueKes, 0.01)
        assertEquals(65.0, summary.collectionRatePercent, 0.1)
        assertEquals(100000.0, summary.averageOrderValueKes, 0.01)
        assertEquals(9500.0, summary.totalCommissionPoolKes, 0.01)
        assertEquals(2, summary.channelMetrics.size)
        assertEquals("M-PESA / STK", summary.channelMetrics.first().channelLabel)

        val installmentsOnly = OperationsAnalyticsEngine.buildOrderDashboardSummary(
            orders = sampleOrders,
            statusFilter = OrderStatusFilter.INSTALLMENT
        )
        assertEquals(1, installmentsOnly.filteredOrders.size)
        assertEquals("ORD-2", installmentsOnly.filteredOrders.first().orderId)
    }

    @Test
    fun buildCostAnalyticsSummary_evaluatesWorkshopVarianceOrderMarginAndCostPools() {
        val execModel = CasketCostingEngine.casketProductionModels.first { it.id == "MOD-EXEC-DOME" }
        val overBudgetExecJob = WorkshopProductionItem(
            id = "WRK-1",
            casketType = "Executive",
            currentStage = WorkshopProductionStage.SANDING_AND_PAINTING,
            percentageDone = 50,
            assignedCraftsmanId = "WRK-01",
            assignedCraftsmanName = "Silas Hayoyo",
            startedDate = "14 Nov 2026",
            targetCompletionDate = "16 Nov 2026",
            sellingPriceKes = 125000.0,
            materialCostKes = execModel.baseBodyMaterialCostKes + 4000.0,
            laborCostKes = execModel.crewLaborCostKes,
            finishingCostKes = execModel.finishingMaterialCostKes + execModel.paintAndAbrasivesCostKes
        )

        val vendorTxns = listOf(
            VendorTransaction(
                id = "VT-1",
                vendorId = "V-1",
                vendorName = "Timber Yard",
                transactionType = VendorTransactionType.PAYMENT_SUBMITTED,
                amount = 15000.0,
                description = "Plywood Batch",
                invoiceNumber = "INV-1",
                date = "15 Nov 2026",
                paymentMethod = "M-PESA",
                mpesaOrBankRef = "MP1",
                authorizedBy = "Admin"
            )
        )

        val expenses = listOf(
            StaffExpenseClaim(
                id = "EXP-1",
                staffId = "STF-1",
                staffName = "Driver 1",
                department = Department.DRIVERS,
                category = ExpenseCategory.FUEL_TOLLS,
                title = "Hearse Diesel",
                amount = 4500.0,
                date = "15 Nov 2026",
                caseReference = "CASE-1",
                receiptNumber = "RCP-1",
                status = ExpenseStatus.APPROVED_REIMBURSED
            )
        )

        val summary = OperationsAnalyticsEngine.buildCostAnalyticsSummary(
            materials = sampleMaterials,
            workshopJobs = listOf(overBudgetExecJob),
            orders = sampleOrders,
            vendorTransactions = vendorTxns,
            expenseClaims = expenses
        )

        assertEquals(81000.0, summary.totalInventoryAssetCostKes, 0.01)
        assertEquals(4000.0, summary.workshopNetVarianceKes, 0.01)
        assertTrue(summary.workshopVariances.first().isOverBudget)
        assertEquals(200000.0, summary.realizedOrderRevenueKes, 0.01)
        assertTrue(summary.estimatedOrderCogsKes > 0.0)
        assertTrue(summary.netOperatingProfitKes > 0.0)
        assertTrue(summary.monthlyBulkGlueSavingsPotentialKes >= 300.0)
        assertTrue(summary.costPoolSlices.isNotEmpty())
        assertEquals(9, summary.modelUnitEconomics.size)
    }

    @Test
    fun repositoryActions_adjustStockAndConfirmOrderSettlementWorkCorrectly() {
        val repo = StaffPortalRepository()
        val firstMaterial = repo.inventoryMaterials.value.first()
        val initialQty = firstMaterial.quantity

        val afterAdd = repo.adjustInventoryMaterialQuantity(firstMaterial.id, 5)
        assertNotNull(afterAdd)
        assertEquals(initialQty + 5, afterAdd!!.quantity)

        val afterSub = repo.adjustInventoryMaterialQuantity(firstMaterial.id, -2)
        assertEquals(initialQty + 3, afterSub!!.quantity)

        // Ensure repository floor is 0 (never negative)
        val afterZeroClamp = repo.adjustInventoryMaterialQuantity(firstMaterial.id, -99999)
        assertEquals(0, afterZeroClamp!!.quantity)
        assertEquals("OUT_OF_STOCK", afterZeroClamp.status)

        val firstOrder = repo.customerOrders.value.first()
        val updated = repo.updateCustomerOrderPaymentStatus(firstOrder.orderId, "Confirmed (Settled)", "REF-NEW-999")
        assertTrue(updated)
        val fetched = repo.customerOrders.value.first { it.orderId == firstOrder.orderId }
        assertEquals("Confirmed (Settled)", fetched.paymentStatus)
        assertEquals("REF-NEW-999", fetched.referenceCode)
        assertFalse(repo.updateCustomerOrderPaymentStatus("NON-EXISTENT", "Confirmed"))
    }
}
