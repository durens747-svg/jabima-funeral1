package com.example.domain

import com.example.model.CustomerOrderRecord
import com.example.model.KenyanStatutoryBreakdown
import com.example.model.MarginEvaluation
import com.example.model.MarginStatus
import com.example.model.PaymentStatus
import com.example.model.StaffAccount
import com.example.model.StaffBreakageRecord
import com.example.model.StaffWalletSummary
import com.example.model.TransactionType
import com.example.model.WalletTransaction
import kotlin.math.roundToLong

data class CommissionCalculationResult(
    val casketPriceKes: Double,
    val baseCommissionRatePercent: Double,
    val executiveBonusApplied: Boolean,
    val effectiveRatePercent: Double,
    val commissionAmountKes: Double,
    val referenceNumber: String,
    val isDuplicatePrevented: Boolean
)

data class MonthlyPayrollRunItem(
    val staffId: String,
    val staffName: String,
    val baseSalaryKes: Double,
    val allowanceKes: Double,
    val earnedCommissionsKes: Double,
    val breakageDeductionsKes: Double,
    val netPayableKes: Double,
    val generatedTransaction: WalletTransaction
)

data class BatchPayrollRunSummary(
    val periodLabel: String,
    val processedCount: Int,
    val skippedDuplicateCount: Int,
    val totalGrossDisbursedKes: Double,
    val totalBreakagesOffsetKes: Double,
    val totalNetDisbursedKes: Double,
    val items: List<MonthlyPayrollRunItem>
)

/**
 * Pure, deterministic commission, breakage deduction, and payroll rules engine.
 */
object PayrollRulesEngine {

    private const val EXECUTIVE_ORDER_THRESHOLD_KES = 150_000.0
    private const val EXECUTIVE_TIER_BONUS_PERCENT = 1.5

    /**
     * Computes casket commission with executive high-value tier bonus and duplicate COM-<orderId> guard.
     */
    fun calculateOrderCommission(
        order: CustomerOrderRecord,
        agent: StaffAccount,
        existingTransactions: List<WalletTransaction>,
        explicitCasketBaseKes: Double? = null
    ): CommissionCalculationResult {
        val referenceNumber = "COM-${order.orderId}"
        val alreadyAwarded = existingTransactions.any {
            it.referenceNumber.equals(referenceNumber, ignoreCase = true) &&
                it.type == TransactionType.COMMISSION &&
                it.status != PaymentStatus.REJECTED
        }

        val casketPriceKes = (explicitCasketBaseKes
            ?: extractCasketPriceFromLabel(order.selectedCasket)
            ?: order.totalAmountKes).coerceAtLeast(0.0)

        val baseRate = agent.commissionRatePercent.coerceAtLeast(0.0)
        val executiveBonus = order.totalAmountKes >= EXECUTIVE_ORDER_THRESHOLD_KES
        val effectiveRate = if (executiveBonus) baseRate + EXECUTIVE_TIER_BONUS_PERCENT else baseRate
        val rawCommission = casketPriceKes * (effectiveRate / 100.0)
        val roundedCommission = ((rawCommission * 100.0).roundToLong()) / 100.0

        return CommissionCalculationResult(
            casketPriceKes = casketPriceKes,
            baseCommissionRatePercent = baseRate,
            executiveBonusApplied = executiveBonus,
            effectiveRatePercent = effectiveRate,
            commissionAmountKes = if (alreadyAwarded) 0.0 else roundedCommission,
            referenceNumber = referenceNumber,
            isDuplicatePrevented = alreadyAwarded
        )
    }

    /**
     * Computes deterministic StaffWalletSummary across credits, payouts, pending requests, and breakage deductions.
     */
    fun computeWalletSummary(
        staffId: String,
        transactions: List<WalletTransaction>,
        breakageRecords: List<StaffBreakageRecord> = emptyList()
    ): StaffWalletSummary {
        val staffTxns = transactions.filter { it.staffId == staffId }

        var totalEarned = 0.0
        var totalWithdrawn = 0.0
        var pendingPayouts = 0.0
        var casketCommissionTotal = 0.0
        var breakageFromTxns = 0.0
        var servicePayoutsTotal = 0.0

        for (txn in staffTxns) {
            when {
                txn.amount > 0.0 -> {
                    if (txn.status == PaymentStatus.DISBURSED) {
                        totalEarned += txn.amount
                        if (txn.type == TransactionType.COMMISSION || txn.type == TransactionType.ADMIN_ADJUSTMENT) {
                            casketCommissionTotal += txn.amount
                        }
                        if (txn.type == TransactionType.ACTIVITY_ALLOWANCE ||
                            txn.type == TransactionType.OVERTIME_BONUS ||
                            txn.type == TransactionType.OPERATOR_TRANSPORT_FEE ||
                            txn.type == TransactionType.OPERATOR_DAILY_WAGE ||
                            txn.type == TransactionType.PER_DIEM
                        ) {
                            servicePayoutsTotal += txn.amount
                        }
                    }
                }
                txn.amount < 0.0 -> {
                    if (txn.type == TransactionType.BREAKAGE_DEDUCTION && txn.status == PaymentStatus.DISBURSED) {
                        breakageFromTxns += -txn.amount
                    } else if (txn.status == PaymentStatus.DISBURSED) {
                        totalWithdrawn += -txn.amount
                    } else if (txn.status == PaymentStatus.PENDING_APPROVAL || txn.status == PaymentStatus.PROCESSING) {
                        pendingPayouts += -txn.amount
                    }
                }
            }
        }

        // Only count executed breakages not yet backed by a txn if breakageFromTxns is zero, otherwise take max to avoid double subtraction
        val executedBreakageRecordsTotal = breakageRecords
            .filter { it.staffId == staffId && it.isDeducted }
            .sumOf { it.breakageCostKes.coerceAtLeast(0.0) }
        val totalBreakageDeductions = maxOf(breakageFromTxns, executedBreakageRecordsTotal)

        val available = (totalEarned - totalWithdrawn - pendingPayouts - totalBreakageDeductions).coerceAtLeast(0.0)

        return StaffWalletSummary(
            staffId = staffId,
            availableBalance = available,
            totalEarned = totalEarned,
            totalWithdrawn = totalWithdrawn,
            pendingPayouts = pendingPayouts,
            casketCommissionTotal = casketCommissionTotal,
            breakageDeductionsTotal = totalBreakageDeductions,
            servicePayoutsTotal = servicePayoutsTotal,
            pendingServicePayoutsTotal = pendingPayouts
        )
    }

    /**
     * Generates monthly payroll disbursements (Base Salary + Allowance) for all active staff,
     * guarding against duplicate payroll reference codes for the same period.
     */
    fun generateMonthlyPayrollRun(
        periodLabel: String,
        dateFormatted: String,
        staffAccounts: List<StaffAccount>,
        existingTransactions: List<WalletTransaction>,
        breakageRecords: List<StaffBreakageRecord>
    ): BatchPayrollRunSummary {
        val cleanPeriodKey = periodLabel.trim().uppercase().replace(" ", "-")
        val runItems = mutableListOf<MonthlyPayrollRunItem>()
        var skipped = 0
        var totalGross = 0.0
        var totalBreakageOffset = 0.0
        var totalNet = 0.0

        for (staff in staffAccounts) {
            if (!staff.isActive) continue
            val refCode = "PAYROLL-${staff.id}-$cleanPeriodKey"
            val alreadyProcessed = existingTransactions.any {
                it.staffId == staff.id &&
                    it.referenceNumber.equals(refCode, ignoreCase = true) &&
                    it.status != PaymentStatus.REJECTED
            }
            if (alreadyProcessed) {
                skipped++
                continue
            }

            val base = staff.baseSalaryKes.coerceAtLeast(0.0)
            val allowance = staff.allowanceKes.coerceAtLeast(0.0)
            val gross = base + allowance

            val commissionEarned = existingTransactions
                .filter { it.staffId == staff.id && it.type == TransactionType.COMMISSION && it.status == PaymentStatus.DISBURSED }
                .sumOf { it.amount }

            val pendingBreakages = breakageRecords
                .filter { it.staffId == staff.id && !it.isDeducted }
                .sumOf { it.breakageCostKes.coerceAtLeast(0.0) }

            val netPayable = (gross - pendingBreakages).coerceAtLeast(0.0)

            val txn = WalletTransaction(
                id = "TXN-PAY-${staff.id}-${cleanPeriodKey.take(8)}",
                staffId = staff.id,
                type = TransactionType.SALARY_BASE,
                title = "Automated Payroll Run • $periodLabel",
                referenceNumber = refCode,
                amount = netPayable,
                date = dateFormatted,
                status = PaymentStatus.DISBURSED,
                notes = "Base KES ${base.toLong()} + Allowance KES ${allowance.toLong()}" +
                    if (pendingBreakages > 0) " - Breakage Offset KES ${pendingBreakages.toLong()}" else ""
            )

            runItems.add(
                MonthlyPayrollRunItem(
                    staffId = staff.id,
                    staffName = staff.fullName,
                    baseSalaryKes = base,
                    allowanceKes = allowance,
                    earnedCommissionsKes = commissionEarned,
                    breakageDeductionsKes = pendingBreakages,
                    netPayableKes = netPayable,
                    generatedTransaction = txn
                )
            )

            totalGross += gross
            totalBreakageOffset += pendingBreakages
            totalNet += netPayable
        }

        return BatchPayrollRunSummary(
            periodLabel = periodLabel,
            processedCount = runItems.size,
            skippedDuplicateCount = skipped,
            totalGrossDisbursedKes = totalGross,
            totalBreakagesOffsetKes = totalBreakageOffset,
            totalNetDisbursedKes = totalNet,
            items = runItems
        )
    }

    /**
     * Computes monthly Kenyan statutory payroll deductions:
     * - SHIF (2.75% of gross, min KES 300 if gross > 0)
     * - NSSF Tier I + II (6% up to KES 72,000 pensionable cap => max KES 4,320)
     * - Affordable Housing Levy (1.5% of gross)
     * - Graduated KRA PAYE on taxable pay (allowable SHIF, NSSF & AHL deducted) minus KES 2,400 Personal Relief.
     */
    fun computeKenyanStatutoryBreakdown(
        grossMonthlyPayKes: Double,
        applyStatutory: Boolean = true
    ): KenyanStatutoryBreakdown {
        val gross = grossMonthlyPayKes.coerceAtLeast(0.0)
        if (!applyStatutory || gross <= 0.0) {
            return KenyanStatutoryBreakdown(
                grossPayKes = round2(gross),
                shifDeductionKes = 0.0,
                nssfDeductionKes = 0.0,
                housingLevyKes = 0.0,
                taxablePayKes = round2(gross),
                grossPayeKes = 0.0,
                personalReliefKes = 0.0,
                netPayeKes = 0.0,
                totalStatutoryDeductionsKes = 0.0,
                netTakeHomeBeforeBreakageKes = round2(gross)
            )
        }

        val shif = round2(maxOf(300.0, gross * 0.0275))
        val pensionablePay = minOf(gross, 72_000.0)
        val nssf = round2(pensionablePay * 0.06)
        val housingLevy = round2(gross * 0.015)

        val taxablePay = (gross - shif - nssf - housingLevy).coerceAtLeast(0.0)

        var remaining = taxablePay
        var paye = 0.0

        val band1 = minOf(remaining, 24_000.0)
        paye += band1 * 0.10
        remaining -= band1

        if (remaining > 0.0) {
            val band2 = minOf(remaining, 8_333.0)
            paye += band2 * 0.25
            remaining -= band2
        }
        if (remaining > 0.0) {
            val band3 = minOf(remaining, 467_667.0)
            paye += band3 * 0.30
            remaining -= band3
        }
        if (remaining > 0.0) {
            val band4 = minOf(remaining, 300_000.0)
            paye += band4 * 0.325
            remaining -= band4
        }
        if (remaining > 0.0) {
            paye += remaining * 0.35
        }

        val grossPaye = round2(paye)
        val personalRelief = 2_400.0
        val netPaye = round2((grossPaye - personalRelief).coerceAtLeast(0.0))
        val totalStatutory = round2(shif + nssf + housingLevy + netPaye)
        val netTakeHome = round2((gross - totalStatutory).coerceAtLeast(0.0))

        return KenyanStatutoryBreakdown(
            grossPayKes = round2(gross),
            shifDeductionKes = shif,
            nssfDeductionKes = nssf,
            housingLevyKes = housingLevy,
            taxablePayKes = round2(taxablePay),
            grossPayeKes = grossPaye,
            personalReliefKes = personalRelief,
            netPayeKes = netPaye,
            totalStatutoryDeductionsKes = totalStatutory,
            netTakeHomeBeforeBreakageKes = netTakeHome
        )
    }

    /**
     * Evaluates BOM production cost vs selling price and flags low/negative margins for Admin Margin Guard.
     */
    fun evaluateBomMargin(
        sellingPriceKes: Double,
        materialCostKes: Double,
        laborCostKes: Double,
        finishingCostKes: Double,
        minTargetMarginPercent: Double = 15.0
    ): MarginEvaluation {
        val sell = sellingPriceKes.coerceAtLeast(0.0)
        val totalCost = (materialCostKes + laborCostKes + finishingCostKes).coerceAtLeast(0.0)
        val profit = sell - totalCost
        val marginPct = if (sell > 0.0) {
            round2((profit / sell) * 100.0)
        } else if (totalCost > 0.0) {
            -100.0
        } else {
            0.0
        }

        val (status, warning) = when {
            sell <= 0.0 || profit < 0.0 -> {
                MarginStatus.BELOW_COST to
                    "MARGIN GUARD ALERT: Selling price KES ${sell.toLong()} is below production cost KES ${totalCost.toLong()} (Loss KES ${kotlin.math.abs(profit).toLong()})."
            }
            marginPct < minTargetMarginPercent -> {
                MarginStatus.LOW_MARGIN to
                    "LOW MARGIN WARNING: Margin is ${marginPct}% (target >= ${minTargetMarginPercent.toInt()}%). Review timber/labor BOM or increase price."
            }
            else -> MarginStatus.HEALTHY to null
        }

        return MarginEvaluation(
            sellingPriceKes = round2(sell),
            totalCostKes = round2(totalCost),
            profitKes = round2(profit),
            marginPercent = marginPct,
            status = status,
            warningMessage = warning
        )
    }

    private fun round2(value: Double): Double = ((value * 100.0).roundToLong()) / 100.0

    internal fun extractCasketPriceFromLabel(label: String): Double? {
        val match = Regex("""KES\s*([0-9,]+(?:\.[0-9]+)?)""", RegexOption.IGNORE_CASE).find(label)
        return match?.groupValues?.getOrNull(1)?.replace(",", "")?.toDoubleOrNull()
    }
}
