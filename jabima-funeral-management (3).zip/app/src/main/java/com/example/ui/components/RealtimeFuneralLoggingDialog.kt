package com.example.ui.components

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ExperimentalLayoutApi
import androidx.compose.foundation.layout.FlowRow
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.AssignmentTurnedIn
import androidx.compose.material.icons.filled.Check
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.Church
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.DirectionsCar
import androidx.compose.material.icons.filled.Flag
import androidx.compose.material.icons.filled.Handyman
import androidx.compose.material.icons.filled.LocationOn
import androidx.compose.material.icons.filled.Notes
import androidx.compose.material.icons.filled.Person
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material.icons.filled.Schedule
import androidx.compose.material.icons.filled.Security
import androidx.compose.material.icons.filled.Today
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Checkbox
import androidx.compose.material3.CheckboxDefaults
import androidx.compose.material3.FilterChip
import androidx.compose.material3.FilterChipDefaults
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableDoubleStateOf
import androidx.compose.runtime.mutableStateListOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.window.Dialog
import com.example.model.ActivityCategory
import com.example.model.ActivityStatus
import com.example.model.Department
import com.example.model.FuneralArrangementStage
import com.example.model.JABIMA_FLEET
import com.example.model.StaffAccount
import com.example.model.StaffActivity
import com.example.model.TaskPriority
import com.example.ui.theme.AmberLight
import com.example.ui.theme.AmberWarning
import com.example.ui.theme.BorderLight
import com.example.ui.theme.CyanContainer
import com.example.ui.theme.CyanDark
import com.example.ui.theme.CyanLight
import com.example.ui.theme.CyanPrimary
import com.example.ui.theme.EmeraldLight
import com.example.ui.theme.EmeraldSuccess
import com.example.ui.theme.ForestGreenBorder
import com.example.ui.theme.ForestGreenDark
import com.example.ui.theme.ForestGreenLight
import com.example.ui.theme.ForestGreenPrimary
import com.example.ui.theme.Navy800
import com.example.ui.theme.Navy900
import com.example.ui.theme.PureWhite
import com.example.ui.theme.RoyalCobaltBlue
import com.example.ui.theme.RoyalCobaltIce
import kotlinx.coroutines.delay
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

data class FieldMilestonePreset(
    val title: String,
    val stage: FuneralArrangementStage,
    val category: ActivityCategory,
    val defaultLocation: String,
    val defaultEquipment: String,
    val allowanceKes: Double,
    val defaultNotes: String,
    val checklist: List<String>
)

@OptIn(ExperimentalLayoutApi::class)
@Composable
fun RealtimeFuneralLoggingDialog(
    currentStaffAccount: StaffAccount?,
    onDismiss: () -> Unit,
    onSubmitUpdate: (StaffActivity) -> Unit
) {
    // Real-time live clock ticking every second
    var liveTimestamp by remember {
        mutableStateOf(SimpleDateFormat("hh:mm:ss a • dd MMM yyyy", Locale.getDefault()).format(Date()))
    }
    LaunchedEffect(Unit) {
        while (true) {
            delay(1000)
            liveTimestamp = SimpleDateFormat("hh:mm:ss a • dd MMM yyyy", Locale.getDefault()).format(Date())
        }
    }

    val milestones = listOf(
        FieldMilestonePreset(
            title = "Hearse & Cortege Escort Departure",
            stage = FuneralArrangementStage.FLEET_CORTEGE,
            category = ActivityCategory.FLEET_TRANSPORT,
            defaultLocation = "Siaya Referral Mortuary Departure Bay",
            defaultEquipment = "VIP Hearse KDG 705Y, Lead Pilot Car, Cortege Flags",
            allowanceKes = 2500.0,
            defaultNotes = "Cortege departed mortuary on schedule. Family convoy following at recommended 40km/h escort speed.",
            checklist = listOf(
                "Deceased casket secure in hearse hydraulic locks",
                "Burial permit & police escort clearance verified",
                "Vehicle fuel & tyre pressure inspected",
                "Family lead car coordinated with driver"
            )
        ),
        FieldMilestonePreset(
            title = "Church / Requiem Service Arrival",
            stage = FuneralArrangementStage.CHAPEL_VIGIL,
            category = ActivityCategory.CASE_HANDLING,
            defaultLocation = "St. Peter's Cathedral Siaya",
            defaultEquipment = "Chrome Church Trolley, Pallbearer Gloves, Order of Service Stands",
            allowanceKes = 2000.0,
            defaultNotes = "Hearse arrived at church grounds. Casket wheeled onto nave on chrome trolley. Service in progress.",
            checklist = listOf(
                "Church trolley positioned smoothly at church doors",
                "Pallbearers guided on ceremonial casket shoulder carry",
                "Floral arrangements placed gracefully around altar",
                "Sound check and family front row seating confirmed"
            )
        ),
        FieldMilestonePreset(
            title = "Gravesite Setup & Lowering Gear Rigging",
            stage = FuneralArrangementStage.GRAVESITE_LOWERING,
            category = ActivityCategory.GRAVESITE_SETUP,
            defaultLocation = "Family Homestead, Nyagondo",
            defaultEquipment = "Bi-directional Lowering Gear, Green Grass Mats, Red Carpet, Canopy Tents",
            allowanceKes = 3000.0,
            defaultNotes = "Lowering device rigged over grave and tested with 250kg test cycle. Artificial turf laid.",
            checklist = listOf(
                "Grave depth and width verified (6ft x 3ft standard)",
                "Lowering machine brake straps locked & safety tested",
                "Artificial turf / green grass mats fully carpeted",
                "Canopy tents & VIP family chairs arranged"
            )
        ),
        FieldMilestonePreset(
            title = "Body Viewing & Final Tribute Session",
            stage = FuneralArrangementStage.GRAVESITE_LOWERING,
            category = ActivityCategory.CASE_HANDLING,
            defaultLocation = "Nyagondo Grounds Homestead",
            defaultEquipment = "Casket Viewing Stand, Clean White Gloves, Sanitizer Stand",
            allowanceKes = 1800.0,
            defaultNotes = "Public and family viewing underway. Casket half-glass opened gracefully for final respects.",
            checklist = listOf(
                "Viewing glass cleaned with anti-fog solution",
                "Family elder invited first for private viewing",
                "Public queue organized with respectful distancing",
                "Floral sprays presented to immediate next-of-kin"
            )
        ),
        FieldMilestonePreset(
            title = "Casket Lowering & Committal Service",
            stage = FuneralArrangementStage.GRAVESITE_LOWERING,
            category = ActivityCategory.GRAVESITE_SETUP,
            defaultLocation = "Gravesite, Homestead Lawn",
            defaultEquipment = "Bi-directional Lowering Gear, Floral Trough, Soil Sprinkling Bowl",
            allowanceKes = 3500.0,
            defaultNotes = "Committal prayer conducted. Casket lowered smoothly to bottom of vault without tilt. Soil sprinkled.",
            checklist = listOf(
                "Lowering straps synchronized for level descent",
                "Clergy signal acknowledged for lowering countdown",
                "Earth sprinkling bowl handed to clergy and widow/children",
                "Floral wreaths lowered onto casket surface"
            )
        ),
        FieldMilestonePreset(
            title = "Grave Backfilling & Mound Floral Placement",
            stage = FuneralArrangementStage.DEBRIEF_COMPLETION,
            category = ActivityCategory.GRAVESITE_SETUP,
            defaultLocation = "Gravesite, Homestead Lawn",
            defaultEquipment = "Vault Slabs, Concrete Mix, Wreath Racks, Wooden Cross",
            allowanceKes = 2000.0,
            defaultNotes = "Grave vault slabs positioned and sealed. Mound constructed and all floral arrangements placed.",
            checklist = listOf(
                "Concrete vault covers placed securely",
                "Grave backfilled and compacted neatly",
                "Wreaths and crosses arranged in order of precedence",
                "Artificial turf retrieved and rolled for cleaning"
            )
        ),
        FieldMilestonePreset(
            title = "Field Repatriation & Return to Depot",
            stage = FuneralArrangementStage.DEBRIEF_COMPLETION,
            category = ActivityCategory.FLEET_TRANSPORT,
            defaultLocation = "En route to Bama Branch Depot",
            defaultEquipment = "All field gear packed in support vehicle KCT 871D",
            allowanceKes = 2000.0,
            defaultNotes = "All equipment retrieved, accounted for, and stowed. Hearse and crew returning to Bama Branch.",
            checklist = listOf(
                "Lowering gear wiped clean and oiled for next service",
                "Church trolley folded into protective casing",
                "Sign-off docket signed by family representative",
                "Vehicle returned and parked in Bama Fleet Bay"
            )
        ),
        FieldMilestonePreset(
            title = "Mortuary Reception & Embalming Preparation",
            stage = FuneralArrangementStage.INTAKE_MORTUARY,
            category = ActivityCategory.CASE_HANDLING,
            defaultLocation = "Siaya Referral Hospital Mortuary",
            defaultEquipment = "Hydraulic Morgue Stretcher, Cold Room Tag #084, Embalming Kit",
            allowanceKes = 2800.0,
            defaultNotes = "Deceased received from family with official notice. Body tagged and preservation begun.",
            checklist = listOf(
                "Death notification document verified & filed",
                "Deceased wrist and ankle identification tags checked",
                "Personal effects logged and stored in secure locker",
                "Cold room tray #084 assigned and recorded in ledger"
            )
        )
    )

    var selectedMilestoneIndex by remember { mutableStateOf(0) }
    val currentPreset = milestones[selectedMilestoneIndex]

    var caseReference by remember { mutableStateOf("JFD-2026-088") }
    var clientFamily by remember { mutableStateOf("The Late Mzee Otieno Family") }
    var location by remember { mutableStateOf(currentPreset.defaultLocation) }
    var assignedVehicle by remember { mutableStateOf("KDG 705Y (Mercedes Hearse)") }
    var assignedEquipment by remember { mutableStateOf(currentPreset.defaultEquipment) }
    var operationalNotes by remember { mutableStateOf(currentPreset.defaultNotes) }
    var selectedStatus by remember { mutableStateOf(ActivityStatus.IN_PROGRESS) }
    var selectedStage by remember { mutableStateOf(currentPreset.stage) }
    var allowanceKes by remember { mutableDoubleStateOf(currentPreset.allowanceKes) }

    // Checklist state
    val checklistItems = remember(selectedMilestoneIndex) {
        mutableStateListOf<String>().apply { addAll(currentPreset.checklist) }
    }
    val completedChecklist = remember(selectedMilestoneIndex) {
        mutableStateListOf<String>().apply {
            // First 2 checked by default
            if (currentPreset.checklist.isNotEmpty()) add(currentPreset.checklist[0])
            if (currentPreset.checklist.size > 1) add(currentPreset.checklist[1])
        }
    }

    // Fast location chips
    val locationPresets = listOf(
        "Siaya Referral Mortuary",
        "Bama Branch Base",
        "Bondo Anglican Cathedral",
        "Nyagondo Grounds Homestead",
        "St. Peter's Ukwala",
        "Rangala Catholic Parish",
        "Matibabu Branch Center",
        "Uradi Chapel & Cemetery"
    )

    Dialog(onDismissRequest = onDismiss) {
        Card(
            shape = RoundedCornerShape(16.dp),
            colors = CardDefaults.cardColors(containerColor = PureWhite),
            border = BorderStroke(1.dp, ForestGreenBorder),
            modifier = Modifier
                .fillMaxWidth()
                .padding(vertical = 12.dp)
                .testTag("realtime_funeral_logging_dialog")
        ) {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .verticalScroll(rememberScrollState())
                    .padding(18.dp)
            ) {
                // Header
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Box(
                            modifier = Modifier
                                .size(38.dp)
                                .clip(CircleShape)
                                .background(ForestGreenLight),
                            contentAlignment = Alignment.Center
                        ) {
                            Icon(
                                imageVector = Icons.Default.DirectionsCar,
                                contentDescription = null,
                                tint = ForestGreenPrimary,
                                modifier = Modifier.size(20.dp)
                            )
                        }
                        Spacer(modifier = Modifier.width(10.dp))
                        Column {
                            Text(
                                text = "Real-Time Field Service Logger",
                                fontWeight = FontWeight.ExtraBold,
                                fontSize = 15.sp,
                                color = Navy900
                            )
                            Text(
                                text = "Record live cortege, church & gravesite operations",
                                fontSize = 10.sp,
                                color = Color(0xFF64748B)
                            )
                        }
                    }

                    IconButton(
                        onClick = onDismiss,
                        modifier = Modifier.size(28.dp)
                    ) {
                        Icon(Icons.Default.Close, contentDescription = "Close", tint = Color(0xFF64748B))
                    }
                }

                Spacer(modifier = Modifier.height(10.dp))

                // Live Timestamp & Staff Identity Card
                Surface(
                    color = Color(0xFF0F172A),
                    shape = RoundedCornerShape(10.dp),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Row(
                        modifier = Modifier.padding(horizontal = 12.dp, vertical = 8.dp),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Box(
                                modifier = Modifier
                                    .size(8.dp)
                                    .clip(CircleShape)
                                    .background(EmeraldSuccess)
                            )
                            Spacer(modifier = Modifier.width(6.dp))
                            Text(
                                text = "LIVE: $liveTimestamp",
                                color = EmeraldLight,
                                fontSize = 10.sp,
                                fontFamily = FontFamily.Monospace,
                                fontWeight = FontWeight.Bold
                            )
                        }

                        Text(
                            text = "${currentStaffAccount?.id ?: "STAFF-01"} • ${currentStaffAccount?.fullName?.split(" ")?.firstOrNull() ?: "Officer"}",
                            color = Color(0xFF93C5FD),
                            fontSize = 10.sp,
                            fontWeight = FontWeight.Bold
                        )
                    }
                }

                Spacer(modifier = Modifier.height(14.dp))

                // Step 1: Real-Time Operational Milestone Selection (Horizontal tabs)
                Text(
                    text = "Select Operational Milestone",
                    fontSize = 11.sp,
                    fontWeight = FontWeight.Bold,
                    color = Navy900
                )
                Spacer(modifier = Modifier.height(6.dp))

                LazyRow(
                    horizontalArrangement = Arrangement.spacedBy(6.dp),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    items(milestones.indices.toList()) { index ->
                        val preset = milestones[index]
                        val isSelected = selectedMilestoneIndex == index
                        Surface(
                            shape = RoundedCornerShape(8.dp),
                            color = if (isSelected) ForestGreenPrimary else Color(0xFFF1F5F9),
                            border = BorderStroke(1.dp, if (isSelected) ForestGreenPrimary else Color(0xFFCBD5E1)),
                            modifier = Modifier
                                .clickable {
                                    selectedMilestoneIndex = index
                                    location = preset.defaultLocation
                                    assignedEquipment = preset.defaultEquipment
                                    operationalNotes = preset.defaultNotes
                                    selectedStage = preset.stage
                                    allowanceKes = preset.allowanceKes
                                }
                                .testTag("milestone_chip_$index")
                        ) {
                            Text(
                                text = preset.title,
                                fontSize = 10.sp,
                                fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Medium,
                                color = if (isSelected) PureWhite else Navy900,
                                modifier = Modifier.padding(horizontal = 10.dp, vertical = 6.dp)
                            )
                        }
                    }
                }

                Spacer(modifier = Modifier.height(12.dp))

                // Case Reference & Family Name
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    OutlinedTextField(
                        value = caseReference,
                        onValueChange = { caseReference = it },
                        label = { Text("Case Ref #", fontSize = 11.sp) },
                        modifier = Modifier
                            .weight(1f)
                            .testTag("input_realtime_case_ref"),
                        singleLine = true,
                        textStyle = MaterialTheme.typography.bodySmall.copy(fontWeight = FontWeight.Bold)
                    )

                    OutlinedTextField(
                        value = clientFamily,
                        onValueChange = { clientFamily = it },
                        label = { Text("Client Family / Deceased", fontSize = 11.sp) },
                        modifier = Modifier
                            .weight(1.6f)
                            .testTag("input_realtime_family"),
                        singleLine = true,
                        textStyle = MaterialTheme.typography.bodySmall
                    )
                }

                Spacer(modifier = Modifier.height(10.dp))

                // Location & Fast Location Chips
                OutlinedTextField(
                    value = location,
                    onValueChange = { location = it },
                    label = { Text("Field Location / Cemetery / Church", fontSize = 11.sp) },
                    leadingIcon = { Icon(Icons.Default.LocationOn, contentDescription = null, tint = ForestGreenPrimary, modifier = Modifier.size(16.dp)) },
                    modifier = Modifier
                        .fillMaxWidth()
                        .testTag("input_realtime_location"),
                    singleLine = true,
                    textStyle = MaterialTheme.typography.bodySmall
                )

                Spacer(modifier = Modifier.height(6.dp))

                // Fast Location Chips
                FlowRow(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(4.dp),
                    verticalArrangement = Arrangement.spacedBy(4.dp)
                ) {
                    locationPresets.take(5).forEach { loc ->
                        Surface(
                            shape = RoundedCornerShape(6.dp),
                            color = if (location == loc) RoyalCobaltIce else Color(0xFFF8FAFC),
                            border = BorderStroke(1.dp, if (location == loc) RoyalCobaltBlue else Color(0xFFE2E8F0)),
                            modifier = Modifier.clickable { location = loc }
                        ) {
                            Text(
                                text = loc,
                                fontSize = 9.sp,
                                color = if (location == loc) RoyalCobaltBlue else Color(0xFF475569),
                                modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp)
                            )
                        }
                    }
                }

                Spacer(modifier = Modifier.height(10.dp))

                // Fleet Vehicle & Gear Equipment
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    OutlinedTextField(
                        value = assignedVehicle,
                        onValueChange = { assignedVehicle = it },
                        label = { Text("Assigned Hearse", fontSize = 11.sp) },
                        leadingIcon = { Icon(Icons.Default.DirectionsCar, contentDescription = null, tint = RoyalCobaltBlue, modifier = Modifier.size(16.dp)) },
                        modifier = Modifier
                            .weight(1f)
                            .testTag("input_realtime_hearse"),
                        singleLine = true,
                        textStyle = MaterialTheme.typography.bodySmall
                    )

                    OutlinedTextField(
                        value = assignedEquipment,
                        onValueChange = { assignedEquipment = it },
                        label = { Text("Gear / Equipment", fontSize = 11.sp) },
                        leadingIcon = { Icon(Icons.Default.Handyman, contentDescription = null, tint = AmberWarning, modifier = Modifier.size(16.dp)) },
                        modifier = Modifier
                            .weight(1f)
                            .testTag("input_realtime_gear"),
                        singleLine = true,
                        textStyle = MaterialTheme.typography.bodySmall
                    )
                }

                Spacer(modifier = Modifier.height(10.dp))

                // Operational Status Selection
                Text(
                    text = "Live Status",
                    fontSize = 11.sp,
                    fontWeight = FontWeight.Bold,
                    color = Navy900
                )
                Spacer(modifier = Modifier.height(4.dp))
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(6.dp)
                ) {
                    listOf(
                        Triple(ActivityStatus.IN_PROGRESS, "In Progress", ForestGreenPrimary),
                        Triple(ActivityStatus.IN_TRANSIT, "En Route", RoyalCobaltBlue),
                        Triple(ActivityStatus.COMPLETED, "Milestone Done", EmeraldSuccess)
                    ).forEach { (status, label, color) ->
                        val isSel = selectedStatus == status
                        Surface(
                            shape = RoundedCornerShape(8.dp),
                            color = if (isSel) color else Color(0xFFF1F5F9),
                            border = BorderStroke(1.dp, if (isSel) color else Color(0xFFCBD5E1)),
                            modifier = Modifier
                                .weight(1f)
                                .clickable { selectedStatus = status }
                        ) {
                            Text(
                                text = label,
                                fontSize = 10.sp,
                                fontWeight = FontWeight.Bold,
                                color = if (isSel) PureWhite else Navy900,
                                modifier = Modifier
                                    .padding(vertical = 6.dp)
                                    .fillMaxWidth(),
                                textAlign = androidx.compose.ui.text.style.TextAlign.Center
                            )
                        }
                    }
                }

                Spacer(modifier = Modifier.height(12.dp))

                // Real-Time Safety & Verification Checklist
                Surface(
                    color = Color(0xFFF8FAFC),
                    shape = RoundedCornerShape(10.dp),
                    border = BorderStroke(1.dp, Color(0xFFE2E8F0)),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Column(modifier = Modifier.padding(10.dp)) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Icon(Icons.Default.AssignmentTurnedIn, contentDescription = null, tint = ForestGreenPrimary, modifier = Modifier.size(16.dp))
                                Spacer(modifier = Modifier.width(6.dp))
                                Text(
                                    text = "Field Checklist Verification",
                                    fontSize = 11.sp,
                                    fontWeight = FontWeight.Bold,
                                    color = Navy900
                                )
                            }
                            Text(
                                text = "${completedChecklist.size}/${checklistItems.size} Verified",
                                fontSize = 9.sp,
                                fontWeight = FontWeight.Bold,
                                color = if (completedChecklist.size == checklistItems.size) EmeraldSuccess else AmberWarning
                            )
                        }

                        Spacer(modifier = Modifier.height(6.dp))

                        checklistItems.forEach { item ->
                            val isChecked = completedChecklist.contains(item)
                            Row(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .clickable {
                                        if (isChecked) completedChecklist.remove(item)
                                        else completedChecklist.add(item)
                                    }
                                    .padding(vertical = 2.dp),
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Checkbox(
                                    checked = isChecked,
                                    onCheckedChange = {
                                        if (it) completedChecklist.add(item)
                                        else completedChecklist.remove(item)
                                    },
                                    colors = CheckboxDefaults.colors(
                                        checkedColor = ForestGreenPrimary,
                                        uncheckedColor = Color(0xFF94A3B8)
                                    ),
                                    modifier = Modifier.size(24.dp)
                                )
                                Spacer(modifier = Modifier.width(6.dp))
                                Text(
                                    text = item,
                                    fontSize = 10.sp,
                                    color = if (isChecked) Navy900 else Color(0xFF64748B),
                                    fontWeight = if (isChecked) FontWeight.SemiBold else FontWeight.Normal
                                )
                            }
                        }
                    }
                }

                Spacer(modifier = Modifier.height(10.dp))

                // Operational Notes
                OutlinedTextField(
                    value = operationalNotes,
                    onValueChange = { operationalNotes = it },
                    label = { Text("Live Operational Observations / Family Notes", fontSize = 11.sp) },
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(75.dp)
                        .testTag("input_realtime_notes"),
                    textStyle = MaterialTheme.typography.bodySmall
                )

                Spacer(modifier = Modifier.height(14.dp))

                // Bottom Action Buttons
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    OutlinedButton(
                        onClick = onDismiss,
                        modifier = Modifier
                            .weight(1f)
                            .height(42.dp),
                        shape = RoundedCornerShape(8.dp)
                    ) {
                        Text("Cancel", fontSize = 12.sp, color = Color(0xFF475569))
                    }

                    Button(
                        onClick = {
                            val now = System.currentTimeMillis()
                            val dateStr = SimpleDateFormat("dd MMM yyyy", Locale.getDefault()).format(Date())
                            val timeStr = SimpleDateFormat("hh:mm a", Locale.getDefault()).format(Date())

                            val newActivity = StaffActivity(
                                id = "ACT-RT-" + (1000..9999).random(),
                                staffId = currentStaffAccount?.id ?: "STAFF-01",
                                staffName = currentStaffAccount?.fullName ?: "Staff Member",
                                department = currentStaffAccount?.department ?: Department.DRIVERS,
                                category = currentPreset.category,
                                title = "${currentPreset.title} ($caseReference)",
                                caseReference = caseReference.ifBlank { "JFD-2026-LIVE" },
                                clientFamily = clientFamily.ifBlank { "Client Family" },
                                location = location.ifBlank { "Field Operation" },
                                date = dateStr,
                                time = timeStr,
                                durationMinutes = 90,
                                status = selectedStatus,
                                notes = operationalNotes,
                                allowanceEarned = allowanceKes,
                                verifiedByAdmin = false,
                                timestamp = now,
                                arrangementStage = selectedStage,
                                priority = TaskPriority.HIGH,
                                assignedVehicle = assignedVehicle,
                                assignedEquipment = assignedEquipment,
                                checklistItems = checklistItems.toList(),
                                completedChecklistItems = completedChecklist.toList(),
                                startedTimestamp = now
                            )

                            onSubmitUpdate(newActivity)
                            onDismiss()
                        },
                        colors = ButtonDefaults.buttonColors(containerColor = ForestGreenPrimary),
                        shape = RoundedCornerShape(8.dp),
                        modifier = Modifier
                            .weight(1.8f)
                            .height(42.dp)
                            .testTag("btn_submit_realtime_update")
                    ) {
                        Icon(Icons.Default.CheckCircle, contentDescription = null, modifier = Modifier.size(16.dp))
                        Spacer(modifier = Modifier.width(6.dp))
                        Text(
                            text = "Broadcast Field Update",
                            fontSize = 12.sp,
                            fontWeight = FontWeight.Bold,
                            color = PureWhite
                        )
                    }
                }
            }
        }
    }
}
