package com.example.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.AddShoppingCart
import androidx.compose.material.icons.filled.Business
import androidx.compose.material.icons.filled.Check
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.Info
import androidx.compose.material.icons.filled.MedicalServices
import androidx.compose.material.icons.filled.PhoneAndroid
import androidx.compose.material.icons.filled.Verified
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.ExposedDropdownMenuBox
import androidx.compose.material3.ExposedDropdownMenuDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.window.Dialog
import com.example.model.Department
import com.example.model.JABIMA_BRANCHES
import com.example.model.MPESA_STK_NUMBER
import com.example.model.SalesServiceItem
import com.example.model.StaffRole
import com.example.ui.StaffPortalViewModel
import com.example.ui.theme.EmeraldLight
import com.example.ui.theme.EmeraldSuccess
import com.example.ui.theme.Navy800
import com.example.ui.theme.Navy900
import com.example.ui.theme.ObsidianBlack
import com.example.ui.theme.PureWhite
import com.example.ui.theme.RoyalCobaltBlue
import com.example.ui.theme.RoyalCobaltIce
import java.util.Locale

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun SalesServicesScreen(
    viewModel: StaffPortalViewModel,
    onBookServiceCheckout: (SalesServiceItem) -> Unit = {}
) {
    val salesServices by viewModel.salesServices.collectAsState()
    val currentAccount by viewModel.currentAccount.collectAsState()

    var selectedBranch by remember { mutableStateOf(currentAccount?.branch ?: JABIMA_BRANCHES.first()) }
    var serviceToBook by remember { mutableStateOf<SalesServiceItem?>(null) }

    val isAuthorized = currentAccount?.department == Department.SALES_MARKETING ||
            currentAccount?.role == StaffRole.MANAGING_DIRECTOR_CEO ||
            currentAccount?.role == StaffRole.OPERATIONS_ADMIN ||
            currentAccount?.role == StaffRole.SALES_MARKETING

    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(Color(0xFFF8FAFC))
            .padding(16.dp)
            .testTag("sales_services_screen")
    ) {
        // HEADER
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Column {
                Text(
                    text = "Authorized Sales & Auxiliary Services",
                    fontSize = 20.sp,
                    fontWeight = FontWeight.Bold,
                    color = ObsidianBlack
                )
                Text(
                    text = "Business Development (Sale) Catalog • Order Delivery at Branch Level",
                    fontSize = 12.sp,
                    color = Color(0xFF64748B)
                )
            }

            // BRANCH SELECTOR
            var branchExpanded by remember { mutableStateOf(false) }
            ExposedDropdownMenuBox(
                expanded = branchExpanded,
                onExpandedChange = { branchExpanded = it },
                modifier = Modifier.width(180.dp)
            ) {
                OutlinedTextField(
                    value = selectedBranch,
                    onValueChange = {},
                    readOnly = true,
                    label = { Text("Service Branch", fontSize = 10.sp) },
                    trailingIcon = { ExposedDropdownMenuDefaults.TrailingIcon(expanded = branchExpanded) },
                    modifier = Modifier.menuAnchor(),
                    textStyle = androidx.compose.ui.text.TextStyle(fontSize = 11.sp, fontWeight = FontWeight.SemiBold)
                )
                ExposedDropdownMenu(
                    expanded = branchExpanded,
                    onDismissRequest = { branchExpanded = false }
                ) {
                    JABIMA_BRANCHES.forEach { b ->
                        DropdownMenuItem(
                            text = { Text(b, fontSize = 11.sp) },
                            onClick = {
                                selectedBranch = b
                                branchExpanded = false
                            }
                        )
                    }
                }
            }
        }

        Spacer(modifier = Modifier.height(10.dp))

        // IMPORTANT COMMISSION NOTICE
        Surface(
            color = RoyalCobaltIce,
            shape = RoundedCornerShape(8.dp),
            border = androidx.compose.foundation.BorderStroke(1.dp, Color(0xFF93C5FD)),
            modifier = Modifier.fillMaxWidth()
        ) {
            Row(
                modifier = Modifier.padding(10.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                Icon(Icons.Default.Info, contentDescription = null, tint = RoyalCobaltBlue, modifier = Modifier.size(20.dp))
                Spacer(modifier = Modifier.width(8.dp))
                Column {
                    Text(
                        text = "Department Policy: Business Development (Sale) Staff Commission",
                        fontSize = 12.sp,
                        fontWeight = FontWeight.Bold,
                        color = RoyalCobaltBlue
                    )
                    Text(
                        text = "Notice: Sales people only earn through 5% commissions on caskets sold. All other auxiliary services listed below carry 0% commission. All delivery orders are scheduled at branch level.",
                        fontSize = 11.sp,
                        color = Color(0xFF1E3A8A)
                    )
                }
            }
        }

        Spacer(modifier = Modifier.height(12.dp))

        // SERVICES LIST (The 14 exact authorized services)
        LazyColumn(
            modifier = Modifier.weight(1f),
            verticalArrangement = Arrangement.spacedBy(10.dp)
        ) {
            items(salesServices) { srv ->
                Card(
                    shape = RoundedCornerShape(10.dp),
                    colors = CardDefaults.cardColors(containerColor = PureWhite),
                    border = androidx.compose.foundation.BorderStroke(1.dp, Color(0xFFE2E8F0)),
                    modifier = Modifier
                        .fillMaxWidth()
                        .testTag("service_item_card_${srv.id}")
                ) {
                    Row(
                        modifier = Modifier.padding(14.dp),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Column(modifier = Modifier.weight(1f)) {
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Surface(
                                    color = Color(0xFFEFF6FF),
                                    shape = RoundedCornerShape(4.dp)
                                ) {
                                    Text(
                                        text = srv.category.uppercase(),
                                        fontSize = 9.sp,
                                        fontWeight = FontWeight.Bold,
                                        color = RoyalCobaltBlue,
                                        modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp)
                                    )
                                }
                                Spacer(modifier = Modifier.width(6.dp))
                                Text(
                                    text = "0% Sales Comm",
                                    fontSize = 9.sp,
                                    fontWeight = FontWeight.SemiBold,
                                    color = Color(0xFF94A3B8)
                                )
                            }
                            Spacer(modifier = Modifier.height(4.dp))
                            Text(
                                text = srv.name,
                                fontSize = 15.sp,
                                fontWeight = FontWeight.Bold,
                                color = ObsidianBlack
                            )
                            Text(
                                text = srv.description,
                                fontSize = 11.sp,
                                color = Color(0xFF64748B)
                            )
                        }

                        Column(horizontalAlignment = Alignment.End) {
                            Text(
                                text = "KES ${String.format(Locale.getDefault(), "%,.0f", srv.priceKes)}",
                                fontSize = 16.sp,
                                fontWeight = FontWeight.Bold,
                                color = RoyalCobaltBlue
                            )
                            Text(
                                text = srv.unit,
                                fontSize = 10.sp,
                                color = Color(0xFF64748B)
                            )
                            Spacer(modifier = Modifier.height(6.dp))
                            Button(
                                onClick = { serviceToBook = srv },
                                colors = ButtonDefaults.buttonColors(containerColor = RoyalCobaltBlue),
                                shape = RoundedCornerShape(6.dp),
                                modifier = Modifier
                                    .height(34.dp)
                                    .testTag("book_service_btn_${srv.id}")
                            ) {
                                Icon(Icons.Default.AddShoppingCart, contentDescription = null, modifier = Modifier.size(13.dp))
                                Spacer(modifier = Modifier.width(4.dp))
                                Text("Book at Branch", fontSize = 10.sp, fontWeight = FontWeight.SemiBold)
                            }
                        }
                    }
                }
            }
        }
    }

    // DIALOG: CONFIRM SERVICE BOOKING AT BRANCH
    if (serviceToBook != null) {
        val srv = serviceToBook!!
        var familyClientName by remember { mutableStateOf("") }
        var familyPhone by remember { mutableStateOf("") }

        Dialog(onDismissRequest = { serviceToBook = null }) {
            Surface(
                shape = RoundedCornerShape(12.dp),
                color = PureWhite,
                modifier = Modifier.fillMaxWidth().padding(8.dp).testTag("dialog_book_service")
            ) {
                Column(modifier = Modifier.padding(16.dp)) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text(
                            text = "Book Service at $selectedBranch",
                            fontSize = 15.sp,
                            fontWeight = FontWeight.Bold,
                            color = ObsidianBlack
                        )
                        IconButton(onClick = { serviceToBook = null }) {
                            Icon(Icons.Default.Close, contentDescription = "Close", tint = Color(0xFF64748B))
                        }
                    }

                    Spacer(modifier = Modifier.height(6.dp))

                    Surface(
                        color = RoyalCobaltIce,
                        shape = RoundedCornerShape(8.dp),
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Column(modifier = Modifier.padding(10.dp)) {
                            Text(text = srv.name, fontWeight = FontWeight.Bold, fontSize = 13.sp, color = RoyalCobaltBlue)
                            Text(text = "Branch: $selectedBranch | Fleet Dispatch from Bama Branch", fontSize = 11.sp, color = Color(0xFF1E3A8A))
                            Text(text = "Amount: KES ${String.format(Locale.getDefault(), "%,.0f", srv.priceKes)} (0% commission)", fontWeight = FontWeight.Bold, fontSize = 12.sp, color = ObsidianBlack)
                        }
                    }

                    Spacer(modifier = Modifier.height(10.dp))

                    OutlinedTextField(
                        value = familyClientName,
                        onValueChange = { familyClientName = it },
                        label = { Text("Client Family Name", fontSize = 12.sp) },
                        placeholder = { Text("e.g. Family of Mzee Owino", fontSize = 12.sp) },
                        modifier = Modifier.fillMaxWidth(),
                        singleLine = true
                    )

                    Spacer(modifier = Modifier.height(8.dp))

                    OutlinedTextField(
                        value = familyPhone,
                        onValueChange = { familyPhone = it },
                        label = { Text("Family Contact Phone", fontSize = 12.sp) },
                        placeholder = { Text("+254 7XX XXX XXX", fontSize = 12.sp) },
                        modifier = Modifier.fillMaxWidth(),
                        singleLine = true
                    )

                    Spacer(modifier = Modifier.height(12.dp))

                    Button(
                        onClick = {
                            viewModel.actionFeedbackMessage.value = "Service '${srv.name}' booked for ${familyClientName.ifBlank { "Client" }} at $selectedBranch! Logistics alert dispatched."
                            serviceToBook = null
                        },
                        colors = ButtonDefaults.buttonColors(containerColor = RoyalCobaltBlue),
                        shape = RoundedCornerShape(6.dp),
                        modifier = Modifier.fillMaxWidth().height(42.dp)
                    ) {
                        Icon(Icons.Default.Check, contentDescription = null, modifier = Modifier.size(16.dp))
                        Spacer(modifier = Modifier.width(6.dp))
                        Text("Confirm Service Order", fontWeight = FontWeight.Bold)
                    }
                }
            }
        }
    }
}
