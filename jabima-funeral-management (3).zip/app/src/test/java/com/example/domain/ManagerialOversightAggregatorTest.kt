package com.example.domain

import com.example.model.ActivityCategory
import com.example.model.ActivityStatus
import com.example.model.Department
import com.example.model.FuneralArrangementStage
import com.example.model.StaffAccount
import com.example.model.StaffActivity
import com.example.model.StaffRole
import com.example.model.TaskPriority
import com.google.common.truth.Truth.assertThat
import org.junit.Test

class ManagerialOversightAggregatorTest {

    private fun staff(
        id: String,
        name: String,
        dept: Department,
        role: StaffRole = StaffRole.OPERATOR
    ) = StaffAccount(
        id = id,
        fullName = name,
        email = "$id@jabima.co.ke",
        phone = "0712000000",
        role = role,
        department = dept,
        password = "pass",
        nationalId = "123456",
        branch = "Bama Branch"
    )

    private fun activity(
        id: String,
        staffId: String,
        staffName: String,
        dept: Department,
        status: ActivityStatus,
        priority: TaskPriority = TaskPriority.NORMAL,
        stage: FuneralArrangementStage = FuneralArrangementStage.FLEET_CORTEGE,
        date: String = "23 Sep 2026",
        time: String = "09:00 AM",
        durationMinutes: Int = 60,
        allowanceEarned: Double = 1000.0
    ) = StaffActivity(
        id = id,
        staffId = staffId,
        staffName = staffName,
        department = dept,
        category = ActivityCategory.FLEET_TRANSPORT,
        title = "Service Task $id",
        caseReference = "JFD-$id",
        clientFamily = "Family $id",
        location = "Bondo",
        date = date,
        time = time,
        durationMinutes = durationMinutes,
        status = status,
        allowanceEarned = allowanceEarned,
        arrangementStage = stage,
        priority = priority
    )

    @Test
    fun buildOversightSummary_byDepartment_aggregatesActivePendingCompletedAndHoursAccurately() {
        val accounts = listOf(
            staff("DRV-1", "Victor Owino", Department.DRIVERS, StaffRole.DRIVER),
            staff("WRK-1", "John Ochieng", Department.WORKSHOP, StaffRole.WORKSHOP_WORKER),
            staff("OPR-1", "David Omondi", Department.OPERATORS, StaffRole.OPERATOR)
        )
        val tasks = listOf(
            activity("A1", "DRV-1", "Victor Owino", Department.DRIVERS, ActivityStatus.IN_TRANSIT, durationMinutes = 90),
            activity("A2", "DRV-1", "Victor Owino", Department.DRIVERS, ActivityStatus.SCHEDULED, priority = TaskPriority.URGENT, durationMinutes = 120, allowanceEarned = 2500.0),
            activity("A3", "WRK-1", "John Ochieng", Department.WORKSHOP, ActivityStatus.ON_HOLD, priority = TaskPriority.HIGH, durationMinutes = 60, allowanceEarned = 1500.0),
            activity("A4", "WRK-1", "John Ochieng", Department.WORKSHOP, ActivityStatus.VERIFIED_BY_ADMIN, durationMinutes = 60),
            activity("A5", "OPR-1", "David Omondi", Department.OPERATORS, ActivityStatus.COMPLETED, durationMinutes = 30)
        )

        val summary = ManagerialOversightAggregator.buildOversightSummary(
            staffAccounts = accounts,
            activities = tasks,
            dimension = OversightChartDimension.DEPARTMENT
        )

        assertThat(summary.totalTasks).isEqualTo(5)
        assertThat(summary.activeCount).isEqualTo(1)
        assertThat(summary.pendingCount).isEqualTo(2)
        assertThat(summary.urgentHighPendingCount).isEqualTo(2)
        assertThat(summary.completedCount).isEqualTo(2)
        assertThat(summary.completionRatePercent).isEqualTo(40)
        assertThat(summary.totalHours).isWithin(0.01).of(6.0)
        assertThat(summary.pendingHoursTotal).isWithin(0.01).of(3.0)
        assertThat(summary.pendingAllowanceTotalKes).isWithin(0.01).of(4000.0)

        val driversBar = summary.bars.first { it.key == Department.DRIVERS.name }
        assertThat(driversBar.activeCount).isEqualTo(1)
        assertThat(driversBar.pendingCount).isEqualTo(1)
        assertThat(driversBar.completedCount).isEqualTo(0)
        assertThat(driversBar.urgentPendingCount).isEqualTo(1)

        val workshopBar = summary.bars.first { it.key == Department.WORKSHOP.name }
        assertThat(workshopBar.pendingCount).isEqualTo(1)
        assertThat(workshopBar.completedCount).isEqualTo(1)
    }

    @Test
    fun buildOversightSummary_byStaff_ordersStaffWithHighestActiveAndPendingLoadFirst() {
        val accounts = listOf(
            staff("S1", "Alice Achieng", Department.SALES_MARKETING, StaffRole.SALES_MARKETING),
            staff("S2", "Brian Odongo", Department.DRIVERS, StaffRole.DRIVER)
        )
        val tasks = listOf(
            activity("T1", "S1", "Alice Achieng", Department.SALES_MARKETING, ActivityStatus.COMPLETED),
            activity("T2", "S2", "Brian Odongo", Department.DRIVERS, ActivityStatus.IN_PROGRESS),
            activity("T3", "S2", "Brian Odongo", Department.DRIVERS, ActivityStatus.SCHEDULED)
        )

        val summary = ManagerialOversightAggregator.buildOversightSummary(
            staffAccounts = accounts,
            activities = tasks,
            dimension = OversightChartDimension.STAFF
        )

        assertThat(summary.bars).hasSize(2)
        assertThat(summary.bars.first().key).isEqualTo("S2")
        assertThat(summary.bars.first().shortLabel).isEqualTo("Brian O.")
        assertThat(summary.bars.first().activeCount).isEqualTo(1)
        assertThat(summary.bars.first().pendingCount).isEqualTo(1)
    }

    @Test
    fun buildOversightSummary_byStageAndDateFilter_scopesCorrectlyAndSortsPendingByPriorityThenTime() {
        val tasks = listOf(
            activity(
                id = "LATE_URGENT",
                staffId = "S1",
                staffName = "Staff One",
                dept = Department.DRIVERS,
                status = ActivityStatus.SCHEDULED,
                priority = TaskPriority.URGENT,
                stage = FuneralArrangementStage.GRAVESITE_LOWERING,
                date = "23 Sep 2026",
                time = "02:00 PM"
            ),
            activity(
                id = "EARLY_NORMAL",
                staffId = "S1",
                staffName = "Staff One",
                dept = Department.DRIVERS,
                status = ActivityStatus.SCHEDULED,
                priority = TaskPriority.NORMAL,
                stage = FuneralArrangementStage.CHAPEL_VIGIL,
                date = "23 Sep 2026",
                time = "07:30 AM"
            ),
            activity(
                id = "PREV_DAY",
                staffId = "S1",
                staffName = "Staff One",
                dept = Department.DRIVERS,
                status = ActivityStatus.ON_HOLD,
                priority = TaskPriority.URGENT,
                stage = FuneralArrangementStage.CHAPEL_VIGIL,
                date = "22 Sep 2026",
                time = "08:00 AM"
            )
        )

        val todaySummary = ManagerialOversightAggregator.buildOversightSummary(
            staffAccounts = emptyList(),
            activities = tasks,
            dimension = OversightChartDimension.STAGE,
            dateFilter = "23 Sep 2026"
        )

        assertThat(todaySummary.totalTasks).isEqualTo(2)
        assertThat(todaySummary.availableDates).containsExactly("23 Sep 2026", "22 Sep 2026").inOrder()
        assertThat(todaySummary.pendingTasks.map { it.id }).containsExactly("LATE_URGENT", "EARLY_NORMAL").inOrder()
        assertThat(todaySummary.bars.map { it.key }).containsExactly(
            FuneralArrangementStage.CHAPEL_VIGIL.name,
            FuneralArrangementStage.GRAVESITE_LOWERING.name
        )
    }

    @Test
    fun buildOversightSummary_emptyActivities_returnsZeroKpisSafely() {
        val summary = ManagerialOversightAggregator.buildOversightSummary(
            staffAccounts = emptyList(),
            activities = emptyList(),
            dimension = OversightChartDimension.DEPARTMENT
        )

        assertThat(summary.totalTasks).isEqualTo(0)
        assertThat(summary.activeCount).isEqualTo(0)
        assertThat(summary.pendingCount).isEqualTo(0)
        assertThat(summary.completedCount).isEqualTo(0)
        assertThat(summary.completionRatePercent).isEqualTo(0)
        assertThat(summary.bars).isEmpty()
        assertThat(summary.pendingTasks).isEmpty()
    }
}
