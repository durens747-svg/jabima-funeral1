package com.example.ui.components

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material.icons.filled.Edit
import androidx.compose.material.icons.filled.Warning
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.ExposedDropdownMenuBox
import androidx.compose.material3.ExposedDropdownMenuDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.MenuAnchorType
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.window.Dialog
import com.example.model.ActivityCategory
import com.example.model.ActivityStatus
import com.example.model.BranchStatusBoard
import com.example.model.CasketItem
import com.example.model.CustomerOrderRecord
import com.example.model.Department
import com.example.model.FleetGpsVehicle
import com.example.model.FuneralArrangementStage
import com.example.model.InventoryMaterialItem
import com.example.model.StaffAccount
import com.example.model.StaffActivity
import com.example.model.StaffRole
import com.example.model.TaskPriority
import com.example.model.WorkshopProductionItem
import com.example.model.WorkshopProductionStage
import com.example.ui.theme.BorderLight
import com.example.ui.theme.EmeraldSuccess
import com.example.ui.theme.ForestGreenPrimary
import com.example.ui.theme.Navy900
import com.example.ui.theme.PureWhite
import com.example.ui.theme.StrokeRed

@Composable
fun AdminConfirmDeleteDialog(
    itemName: String,
    itemCategory: String,
    onDismiss: () -> Unit,
    onConfirmDelete: () -> Unit
) {
    AlertDialog(
        onDismissRequest = onDismiss,
        icon = {
            Icon(Icons.Default.Warning, contentDescription = null, tint = StrokeRed, modifier = Modifier.size(28.dp))
        },
        title = {
            Text("Delete $itemCategory?", fontWeight = FontWeight.Bold, fontSize = 15.sp, color = StrokeRed)
        },
        text = {
            Text(
                "Are you sure you want to permanently delete \"$itemName\"? This will remove this record completely from all app modules and cannot be undone.",
                fontSize = 12.sp,
                color = Color(0xFF334155)
            )
        },
        confirmButton = {
            Button(
                onClick = onConfirmDelete,
                colors = ButtonDefaults.buttonColors(containerColor = StrokeRed),
                shape = RoundedCornerShape(8.dp),
                modifier = Modifier.testTag("btn_confirm_delete")
            ) {
                Icon(Icons.Default.Delete, contentDescription = null, modifier = Modifier.size(14.dp))
                Spacer(modifier = Modifier.width(4.dp))
                Text("Delete Record", fontWeight = FontWeight.Bold, fontSize = 12.sp)
            }
        },
        dismissButton = {
            TextButton(onClick = onDismiss) {
                Text("Cancel", color = Color(0xFF64748B))
            }
        }
    )
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun AdminAddEditStaffDialog(
    existingStaff: StaffAccount? = null,
    onDismiss: () -> Unit,
    onSave: (StaffAccount) -> Unit
) {
    val isEdit = existingStaff != null
    var id by remember { mutableStateOf(existingStaff?.id ?: "STF-${(100..999).random()}") }
    var fullName by remember { mutableStateOf(existingStaff?.fullName ?: "") }
    var phone by remember { mutableStateOf(existingStaff?.phone ?: "+254 7") }
    var role by remember { mutableStateOf(existingStaff?.role ?: StaffRole.WORKSHOP_WORKER) }
    var department by remember { mutableStateOf(existingStaff?.department ?: Department.WORKSHOP) }
    var branch by remember { mutableStateOf(existingStaff?.branch ?: "Bama Branch") }
    var baseSalaryText by remember { mutableStateOf((existingStaff?.baseSalaryKes ?: 45000.0).toLong().toString()) }
    var allowanceText by remember { mutableStateOf((existingStaff?.allowanceKes ?: 10000.0).toLong().toString()) }
    var password by remember { mutableStateOf(if (isEdit) "" else "123456") }
    var roleExpanded by remember { mutableStateOf(false) }

    Dialog(onDismissRequest = onDismiss) {
        Card(
            shape = RoundedCornerShape(14.dp),
            colors = CardDefaults.cardColors(containerColor = PureWhite),
            border = BorderStroke(1.dp, BorderLight),
            modifier = Modifier.fillMaxWidth()
        ) {
            Column(
                modifier = Modifier
                    .padding(16.dp)
                    .verticalScroll(rememberScrollState())
            ) {
                Text(
                    text = if (isEdit) "Edit Staff Account (${existingStaff?.id})" else "Add New Staff Member",
                    fontWeight = FontWeight.Bold,
                    fontSize = 14.sp,
                    color = Navy900
                )
                Spacer(modifier = Modifier.height(10.dp))

                OutlinedTextField(
                    value = fullName,
                    onValueChange = { fullName = it },
                    label = { Text("Full Name", fontSize = 11.sp) },
                    modifier = Modifier.fillMaxWidth()
                )
                Spacer(modifier = Modifier.height(6.dp))

                OutlinedTextField(
                    value = phone,
                    onValueChange = { phone = it },
                    label = { Text("Phone / M-PESA Number", fontSize = 11.sp) },
                    modifier = Modifier.fillMaxWidth()
                )
                Spacer(modifier = Modifier.height(6.dp))

                OutlinedTextField(
                    value = branch,
                    onValueChange = { branch = it },
                    label = { Text("Branch Station", fontSize = 11.sp) },
                    modifier = Modifier.fillMaxWidth()
                )
                Spacer(modifier = Modifier.height(6.dp))

                ExposedDropdownMenuBox(
                    expanded = roleExpanded,
                    onExpandedChange = { roleExpanded = it }
                ) {
                    OutlinedTextField(
                        value = role.title,
                        onValueChange = {},
                        readOnly = true,
                        label = { Text("Role", fontSize = 11.sp) },
                        trailingIcon = { ExposedDropdownMenuDefaults.TrailingIcon(expanded = roleExpanded) },
                        modifier = Modifier.menuAnchor(MenuAnchorType.PrimaryNotEditable).fillMaxWidth()
                    )
                    ExposedDropdownMenu(
                        expanded = roleExpanded,
                        onDismissRequest = { roleExpanded = false }
                    ) {
                        StaffRole.entries.forEach { r ->
                            DropdownMenuItem(
                                text = { Text(r.title, fontSize = 11.sp) },
                                onClick = {
                                    role = r
                                    department = when (r) {
                                        StaffRole.WORKSHOP_WORKER, StaffRole.CASKET_ARTISAN -> Department.WORKSHOP
                                        StaffRole.DRIVER, StaffRole.FLEET_OPERATOR -> Department.DRIVERS
                                        StaffRole.OPERATOR -> Department.OPERATORS
                                        StaffRole.SALES_MARKETING -> Department.SALES_MARKETING
                                        StaffRole.MANAGING_DIRECTOR_CEO -> Department.CEO
                                        else -> Department.ADMINISTRATION
                                    }
                                    roleExpanded = false
                                }
                            )
                        }
                    }
                }
                Spacer(modifier = Modifier.height(6.dp))

                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    OutlinedTextField(
                        value = baseSalaryText,
                        onValueChange = { baseSalaryText = it },
                        label = { Text("Base Salary (KES)", fontSize = 10.sp) },
                        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                        modifier = Modifier.weight(1f)
                    )
                    OutlinedTextField(
                        value = allowanceText,
                        onValueChange = { allowanceText = it },
                        label = { Text("Allowance (KES)", fontSize = 10.sp) },
                        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                        modifier = Modifier.weight(1f)
                    )
                }
                Spacer(modifier = Modifier.height(6.dp))

                OutlinedTextField(
                    value = password,
                    onValueChange = { password = it },
                    label = { Text(if (isEdit) "Reset Password (leave blank to keep)" else "Initial Login Password", fontSize = 11.sp) },
                    modifier = Modifier.fillMaxWidth()
                )

                Spacer(modifier = Modifier.height(14.dp))
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.End
                ) {
                    TextButton(onClick = onDismiss) { Text("Cancel") }
                    Spacer(modifier = Modifier.width(8.dp))
                    Button(
                        onClick = {
                            if (fullName.isNotBlank()) {
                                val updated = existingStaff?.copy(
                                    fullName = fullName,
                                    phone = phone,
                                    role = role,
                                    department = department,
                                    branch = branch,
                                    baseSalaryKes = baseSalaryText.toDoubleOrNull() ?: 45000.0,
                                    allowanceKes = allowanceText.toDoubleOrNull() ?: 10000.0,
                                    password = password.trim(),
                                    passwordHash = if (password.isNotBlank()) "" else existingStaff.passwordHash,
                                    mustRotatePassword = if (password.isNotBlank()) {
                                        com.example.utils.PasswordSecurityHelper.isDefaultOrWeakPassword(password.trim())
                                    } else {
                                        existingStaff.mustRotatePassword
                                    }
                                ) ?: StaffAccount(
                                    id = id,
                                    fullName = fullName,
                                    email = "${fullName.lowercase().replace(" ", "")}@jabimafuneral.co.ke",
                                    phone = phone,
                                    role = role,
                                    department = department,
                                    branch = branch,
                                    baseSalaryKes = baseSalaryText.toDoubleOrNull() ?: 45000.0,
                                    allowanceKes = allowanceText.toDoubleOrNull() ?: 10000.0,
                                    password = password,
                                    nationalId = "ID-${(10000000..99999999).random()}",
                                    defaultMpesaNumber = phone
                                )
                                onSave(updated)
                            }
                        },
                        colors = ButtonDefaults.buttonColors(containerColor = EmeraldSuccess)
                    ) {
                        Text(if (isEdit) "Save Changes" else "Create Staff")
                    }
                }
            }
        }
    }
}

@Composable
fun AdminAddEditCasketDialog(
    existingCasket: CasketItem? = null,
    onDismiss: () -> Unit,
    onSave: (CasketItem) -> Unit
) {
    val isEdit = existingCasket != null
    var id by remember { mutableStateOf(existingCasket?.id ?: "CSK-${(100..999).random()}") }
    var name by remember { mutableStateOf(existingCasket?.name ?: "") }
    var priceKesText by remember { mutableStateOf((existingCasket?.priceKes ?: 95000.0).toLong().toString()) }
    var woodType by remember { mutableStateOf(existingCasket?.woodType ?: "Solid Hardwood Mahogany") }
    var tier by remember { mutableStateOf(existingCasket?.tier ?: "EXECUTIVE") }
    var stockText by remember { mutableStateOf((existingCasket?.stockCount ?: 4).toString()) }

    Dialog(onDismissRequest = onDismiss) {
        Card(
            shape = RoundedCornerShape(14.dp),
            colors = CardDefaults.cardColors(containerColor = PureWhite),
            border = BorderStroke(1.dp, BorderLight),
            modifier = Modifier.fillMaxWidth()
        ) {
            Column(
                modifier = Modifier
                    .padding(16.dp)
                    .verticalScroll(rememberScrollState())
            ) {
                Text(
                    text = if (isEdit) "Edit Casket (${existingCasket?.name})" else "Add New Casket Model",
                    fontWeight = FontWeight.Bold,
                    fontSize = 14.sp,
                    color = Navy900
                )
                Spacer(modifier = Modifier.height(10.dp))

                OutlinedTextField(
                    value = name,
                    onValueChange = { name = it },
                    label = { Text("Casket Model Name", fontSize = 11.sp) },
                    modifier = Modifier.fillMaxWidth()
                )
                Spacer(modifier = Modifier.height(6.dp))

                OutlinedTextField(
                    value = priceKesText,
                    onValueChange = { priceKesText = it },
                    label = { Text("Price (KES)", fontSize = 11.sp) },
                    keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                    modifier = Modifier.fillMaxWidth()
                )
                Spacer(modifier = Modifier.height(6.dp))

                OutlinedTextField(
                    value = woodType,
                    onValueChange = { woodType = it },
                    label = { Text("Wood Species / Finishing", fontSize = 11.sp) },
                    modifier = Modifier.fillMaxWidth()
                )
                Spacer(modifier = Modifier.height(6.dp))

                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    OutlinedTextField(
                        value = tier,
                        onValueChange = { tier = it },
                        label = { Text("Tier / Category", fontSize = 10.sp) },
                        modifier = Modifier.weight(1f)
                    )
                    OutlinedTextField(
                        value = stockText,
                        onValueChange = { stockText = it },
                        label = { Text("Stock Qty", fontSize = 10.sp) },
                        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                        modifier = Modifier.weight(1f)
                    )
                }

                Spacer(modifier = Modifier.height(14.dp))
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.End
                ) {
                    TextButton(onClick = onDismiss) { Text("Cancel") }
                    Spacer(modifier = Modifier.width(8.dp))
                    Button(
                        onClick = {
                            if (name.isNotBlank()) {
                                val pKes = priceKesText.toDoubleOrNull() ?: 95000.0
                                val item = existingCasket?.copy(
                                    name = name,
                                    priceKes = pKes,
                                    priceUsd = pKes / 130.0,
                                    woodType = woodType,
                                    tier = tier,
                                    stockCount = stockText.toIntOrNull() ?: 4
                                ) ?: CasketItem(
                                    id = id,
                                    name = name,
                                    tier = tier,
                                    finish = "High-Gloss Polyurethane Lacquer",
                                    interiorLining = "Premium Quilted Velvet",
                                    priceKes = pKes,
                                    priceUsd = pKes / 130.0,
                                    woodType = woodType,
                                    features = listOf("Luxury Velvet Lining", "Solid Brass Handles", "High-Gloss Polyurethane"),
                                    stockCount = stockText.toIntOrNull() ?: 4
                                )
                                onSave(item)
                            }
                        },
                        colors = ButtonDefaults.buttonColors(containerColor = EmeraldSuccess)
                    ) {
                        Text(if (isEdit) "Save Casket" else "Add Casket")
                    }
                }
            }
        }
    }
}

@Composable
fun AdminAddEditMaterialDialog(
    existingMaterial: InventoryMaterialItem? = null,
    onDismiss: () -> Unit,
    onSave: (InventoryMaterialItem) -> Unit
) {
    val isEdit = existingMaterial != null
    var id by remember { mutableStateOf(existingMaterial?.id ?: "MAT-${(100..999).random()}") }
    var name by remember { mutableStateOf(existingMaterial?.name ?: "") }
    var categoryName by remember { mutableStateOf(existingMaterial?.categoryName ?: "Timber & Wood") }
    var quantityText by remember { mutableStateOf((existingMaterial?.quantity ?: 100).toString()) }
    var unit by remember { mutableStateOf(existingMaterial?.unit ?: "Board Feet") }
    var unitCostText by remember { mutableStateOf((existingMaterial?.unitCostKes ?: 350.0).toLong().toString()) }
    var minThresholdText by remember { mutableStateOf((existingMaterial?.minThreshold ?: 20).toString()) }
    var warehouse by remember { mutableStateOf(existingMaterial?.branchWarehouse ?: "Bama Workshop") }

    Dialog(onDismissRequest = onDismiss) {
        Card(
            shape = RoundedCornerShape(14.dp),
            colors = CardDefaults.cardColors(containerColor = PureWhite),
            border = BorderStroke(1.dp, BorderLight),
            modifier = Modifier.fillMaxWidth()
        ) {
            Column(
                modifier = Modifier
                    .padding(16.dp)
                    .verticalScroll(rememberScrollState())
            ) {
                Text(
                    text = if (isEdit) "Edit Material (${existingMaterial?.name})" else "Add Raw Material",
                    fontWeight = FontWeight.Bold,
                    fontSize = 14.sp,
                    color = Navy900
                )
                Spacer(modifier = Modifier.height(10.dp))

                OutlinedTextField(
                    value = name,
                    onValueChange = { name = it },
                    label = { Text("Material Name", fontSize = 11.sp) },
                    modifier = Modifier.fillMaxWidth()
                )
                Spacer(modifier = Modifier.height(6.dp))

                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    OutlinedTextField(
                        value = categoryName,
                        onValueChange = { categoryName = it },
                        label = { Text("Category", fontSize = 10.sp) },
                        modifier = Modifier.weight(1f)
                    )
                    OutlinedTextField(
                        value = warehouse,
                        onValueChange = { warehouse = it },
                        label = { Text("Warehouse", fontSize = 10.sp) },
                        modifier = Modifier.weight(1f)
                    )
                }
                Spacer(modifier = Modifier.height(6.dp))

                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    OutlinedTextField(
                        value = quantityText,
                        onValueChange = { quantityText = it },
                        label = { Text("Quantity", fontSize = 10.sp) },
                        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                        modifier = Modifier.weight(1f)
                    )
                    OutlinedTextField(
                        value = unit,
                        onValueChange = { unit = it },
                        label = { Text("Unit (Pcs/L/Ft)", fontSize = 10.sp) },
                        modifier = Modifier.weight(1f)
                    )
                }
                Spacer(modifier = Modifier.height(6.dp))

                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    OutlinedTextField(
                        value = unitCostText,
                        onValueChange = { unitCostText = it },
                        label = { Text("Unit Cost (KES)", fontSize = 10.sp) },
                        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                        modifier = Modifier.weight(1f)
                    )
                    OutlinedTextField(
                        value = minThresholdText,
                        onValueChange = { minThresholdText = it },
                        label = { Text("Min Threshold", fontSize = 10.sp) },
                        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                        modifier = Modifier.weight(1f)
                    )
                }

                Spacer(modifier = Modifier.height(14.dp))
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.End
                ) {
                    TextButton(onClick = onDismiss) { Text("Cancel") }
                    Spacer(modifier = Modifier.width(8.dp))
                    Button(
                        onClick = {
                            if (name.isNotBlank()) {
                                val item = existingMaterial?.copy(
                                    name = name,
                                    categoryName = categoryName,
                                    quantity = quantityText.toIntOrNull() ?: 100,
                                    unit = unit,
                                    unitCostKes = unitCostText.toDoubleOrNull() ?: 350.0,
                                    minThreshold = minThresholdText.toIntOrNull() ?: 20,
                                    branchWarehouse = warehouse
                                ) ?: InventoryMaterialItem(
                                    id = id,
                                    name = name,
                                    categoryId = "CAT-01",
                                    categoryName = categoryName,
                                    quantity = quantityText.toIntOrNull() ?: 100,
                                    unit = unit,
                                    unitCostKes = unitCostText.toDoubleOrNull() ?: 350.0,
                                    minThreshold = minThresholdText.toIntOrNull() ?: 20,
                                    branchWarehouse = warehouse
                                )
                                onSave(item)
                            }
                        },
                        colors = ButtonDefaults.buttonColors(containerColor = EmeraldSuccess)
                    ) {
                        Text(if (isEdit) "Save Material" else "Add Material")
                    }
                }
            }
        }
    }
}
