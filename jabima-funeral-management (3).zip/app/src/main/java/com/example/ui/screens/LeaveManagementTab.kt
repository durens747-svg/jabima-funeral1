package com.example.ui.screens

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.EventNote
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.Check
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.ChevronLeft
import androidx.compose.material.icons.filled.ChevronRight
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.Groups
import androidx.compose.material.icons.filled.HourglassBottom
import androidx.compose.material.icons.filled.Person
import androidx.compose.material.icons.filled.Today
import androidx.compose.material.icons.filled.Warning
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.DropdownMenu
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.ScrollableTabRow
import androidx.compose.material3.Surface
import androidx.compose.material3.Tab
import androidx.compose.material3.TabRowDefaults
import androidx.compose.material3.TabRowDefaults.tabIndicatorOffset
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.window.Dialog
import com.example.model.Department
import com.example.model.LeaveRequest
import com.example.model.StaffRole
import com.example.ui.StaffPortalViewModel
import com.example.ui.theme.BorderLight
import com.example.ui.theme.EmeraldLight
import com.example.ui.theme.EmeraldSuccess
import com.example.ui.theme.ObsidianBlack
import com.example.ui.theme.PureWhite
import com.example.ui.theme.RoyalCobaltBlue
import com.example.ui.theme.RoyalCobaltDark
import com.example.ui.theme.RoyalCobaltIce
import com.example.ui.theme.RoyalCobaltLight
import com.example.ui.theme.StrokeRed
import com.example.ui.theme.TextMuted
import com.example.ui.theme.TextPrimary
import com.example.ui.theme.TextSecondary
import java.util.Calendar

// Helper date functions for interactive visual calendar & coverage calculations
private fun parseDateToDayTriple(dateStr: String): Triple<Int, Int, Int>? {
    val months = listOf("Jan", "Feb", "Mar", "Apr", "May", "Jun", "Jul", "Aug", "Sep", "Oct", "Nov", "Dec")
    val parts = dateStr.trim().split(" ")
    if (parts.size >= 3) {
        val day = parts[0].toIntOrNull() ?: return null
        val monthIdx = months.indexOfFirst { it.equals(parts[1], ignoreCase = true) }
        val year = parts[2].toIntOrNull() ?: return null
        if (monthIdx != -1) return Triple(day, monthIdx, year)
    }
    return null
}

private fun isDateInLeaveRange(day: Int, month: Int, year: Int, startStr: String, endStr: String): Boolean {
    val start = parseDateToDayTriple(startStr) ?: return false
    val end = parseDateToDayTriple(endStr) ?: return false
    val currentVal = year * 10000 + month * 100 + day
    val startVal = start.third * 10000 + start.second * 100 + start.first
    val endVal = end.third * 10000 + end.second * 100 + end.first
    return currentVal in startVal..endVal
}

private fun formatDayString(day: Int, month: Int, year: Int): String {
    val months = listOf("Jan", "Feb", "Mar", "Apr", "May", "Jun", "Jul", "Aug", "Sep", "Oct", "Nov", "Dec")
    val mStr = months.getOrElse(month) { "Sep" }
    val dStr = if (day < 10) "0$day" else "$day"
    return "$dStr $mStr $year"
}

private fun getDaysInMonthCount(month: Int, year: Int): Int {
    return when (month) {
        1 -> if (year % 4 == 0 && (year % 100 != 0 || year % 400 == 0)) 29 else 28
        3, 5, 8, 10 -> 30
        else -> 31
    }
}

private fun getFirstDayOfWeekInMonth(month: Int, year: Int): Int {
    val cal = Calendar.getInstance()
    cal.set(year, month, 1)
    return cal.get(Calendar.DAY_OF_WEEK) - 1 // 0=Sun, 1=Mon, ..., 6=Sat
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun LeaveManagementTab(
    viewModel: StaffPortalViewModel
) {
    val currentAccount by viewModel.currentAccount.collectAsState()
    val allAccounts by viewModel.allAccounts.collectAsState()
    val leaveRequests by viewModel.leaveRequests.collectAsState()

    var showRequestDialog by remember { mutableStateOf(false) }
    val isManagement = currentAccount?.role == StaffRole.MANAGING_DIRECTOR_CEO || currentAccount?.role == StaffRole.OPERATIONS_ADMIN

    // Calendar state: Initialized to September 2026 (Month 8 = Sep)
    var currentYear by remember { mutableIntStateOf(2026) }
    var currentMonth by remember { mutableIntStateOf(8) } // 0-based: 8 = September
    var selectedStartDay by remember { mutableIntStateOf(25) }
    var selectedEndDay by remember { mutableIntStateOf(25) }
    var selectedRangeMonth by remember { mutableIntStateOf(8) }
    var selectedRangeYear by remember { mutableIntStateOf(2026) }

    // Tab view mode: 0 = "Calendar & Team Coverage", 1 = "Applications Ledger"
    var activeSubView by remember { mutableIntStateOf(0) }

    // Department filter for Team Coverage breakdown
    var selectedCoverageDepartment by remember { mutableStateOf<Department?>(null) }

    // Dialog pre-fills
    var dialogStartDate by remember { mutableStateOf("25 Sep 2026") }
    var dialogEndDate by remember { mutableStateOf("25 Sep 2026") }
    var dialogDaysCount by remember { mutableStateOf("1") }

    val monthNames = listOf(
        "January", "February", "March", "April", "May", "June",
        "July", "August", "September", "October", "November", "December"
    )

    // Compute coverage metrics for the actively inspected date
    val activeInspectedDay = selectedStartDay
    val activeInspectedMonth = selectedRangeMonth
    val activeInspectedYear = selectedRangeYear
    val activeDateFormatted = formatDayString(activeInspectedDay, activeInspectedMonth, activeInspectedYear)

    // Staff on leave on active date
    val staffOnLeaveActiveDate = remember(leaveRequests, activeInspectedDay, activeInspectedMonth, activeInspectedYear) {
        leaveRequests.filter { leave ->
            isDateInLeaveRange(activeInspectedDay, activeInspectedMonth, activeInspectedYear, leave.startDate, leave.endDate)
        }
    }

    val approvedLeavesActiveDate = staffOnLeaveActiveDate.filter { it.status == "Approved" }
    val pendingLeavesActiveDate = staffOnLeaveActiveDate.filter { it.status == "Pending" }

    // Department counts
    val allStaffCount = allAccounts.size.coerceAtLeast(30)
    val totalOnLeave = staffOnLeaveActiveDate.count { it.status == "Approved" }
    val totalAvailable = (allStaffCount - totalOnLeave).coerceAtLeast(0)
    val overallCoveragePercent = if (allStaffCount > 0) ((totalAvailable.toFloat() / allStaffCount.toFloat()) * 100).toInt() else 100

    LazyColumn(
        modifier = Modifier
            .fillMaxSize()
            .background(PureWhite)
            .padding(16.dp)
            .testTag("leave_management_tab"),
        verticalArrangement = Arrangement.spacedBy(14.dp)
    ) {
        // HEADER ROW: Title, subtitle & Apply Leave button
        item {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Column {
                    Text(
                        text = "Staff Leave & Team Coverage Calendar",
                        fontSize = 18.sp,
                        fontWeight = FontWeight.Bold,
                        color = ObsidianBlack
                    )
                    Text(
                        text = "Interactive visual calendar, staffing coverage meter & time-off applications",
                        fontSize = 12.sp,
                        color = TextMuted
                    )
                }

                Button(
                    onClick = {
                        dialogStartDate = formatDayString(selectedStartDay, selectedRangeMonth, selectedRangeYear)
                        dialogEndDate = formatDayString(selectedEndDay, selectedRangeMonth, selectedRangeYear)
                        val days = (selectedEndDay - selectedStartDay + 1).coerceAtLeast(1)
                        dialogDaysCount = days.toString()
                        showRequestDialog = true
                    },
                    colors = ButtonDefaults.buttonColors(containerColor = RoyalCobaltBlue),
                    shape = RoundedCornerShape(8.dp),
                    modifier = Modifier.testTag("btn_request_leave")
                ) {
                    Icon(Icons.Default.Add, contentDescription = null, modifier = Modifier.size(16.dp))
                    Spacer(modifier = Modifier.width(4.dp))
                    Text("Apply Time Off", fontSize = 12.sp, fontWeight = FontWeight.Bold)
                }
            }
        }

        // VIEW MODE SWITCHER TABS (White & Blue)
        item {
            Card(
                colors = CardDefaults.cardColors(containerColor = PureWhite),
                border = BorderStroke(1.dp, BorderLight),
                shape = RoundedCornerShape(8.dp),
                modifier = Modifier.fillMaxWidth()
            ) {
                ScrollableTabRow(
                    selectedTabIndex = activeSubView,
                    containerColor = PureWhite,
                    contentColor = RoyalCobaltBlue,
                    edgePadding = 4.dp,
                    indicator = { tabPositions ->
                        if (activeSubView < tabPositions.size) {
                            TabRowDefaults.SecondaryIndicator(
                                modifier = Modifier.tabIndicatorOffset(tabPositions[activeSubView]),
                                color = RoyalCobaltBlue,
                                height = 3.dp
                            )
                        }
                    },
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Tab(
                        selected = activeSubView == 0,
                        onClick = { activeSubView = 0 },
                        text = {
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Icon(
                                    imageVector = Icons.Default.Today,
                                    contentDescription = null,
                                    modifier = Modifier.size(16.dp),
                                    tint = if (activeSubView == 0) RoyalCobaltBlue else TextMuted
                                )
                                Spacer(modifier = Modifier.width(6.dp))
                                Text(
                                    text = "Visual Calendar & Coverage Status",
                                    fontSize = 12.sp,
                                    fontWeight = if (activeSubView == 0) FontWeight.Bold else FontWeight.Medium,
                                    color = if (activeSubView == 0) RoyalCobaltBlue else TextMuted,
                                    maxLines = 1,
                                    softWrap = false,
                                    overflow = TextOverflow.Ellipsis
                                )
                            }
                        },
                        modifier = Modifier.testTag("tab_calendar_coverage")
                    )
                    Tab(
                        selected = activeSubView == 1,
                        onClick = { activeSubView = 1 },
                        text = {
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Icon(
                                    imageVector = Icons.AutoMirrored.Filled.EventNote,
                                    contentDescription = null,
                                    modifier = Modifier.size(16.dp),
                                    tint = if (activeSubView == 1) RoyalCobaltBlue else TextMuted
                                )
                                Spacer(modifier = Modifier.width(6.dp))
                                Text(
                                    text = "Leave Applications Ledger (${leaveRequests.size})",
                                    fontSize = 12.sp,
                                    fontWeight = if (activeSubView == 1) FontWeight.Bold else FontWeight.Medium,
                                    color = if (activeSubView == 1) RoyalCobaltBlue else TextMuted,
                                    maxLines = 1,
                                    softWrap = false,
                                    overflow = TextOverflow.Ellipsis
                                )
                            }
                        },
                        modifier = Modifier.testTag("tab_applications_ledger")
                    )
                }
            }
        }

        // STATS & ENTITLEMENT SUMMARY ROW
        item {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                // Card 1: Annual Entitlement
                Card(
                    colors = CardDefaults.cardColors(containerColor = PureWhite),
                    border = BorderStroke(1.dp, BorderLight),
                    shape = RoundedCornerShape(8.dp),
                    modifier = Modifier.weight(1f)
                ) {
                    Column(modifier = Modifier.padding(10.dp)) {
                        Text("Annual Entitlement", fontSize = 10.sp, color = TextMuted)
                        Text("21 Days", fontSize = 15.sp, fontWeight = FontWeight.Bold, color = ObsidianBlack)
                        Text("Full Policy", fontSize = 9.sp, color = RoyalCobaltBlue)
                    }
                }

                // Card 2: Days Taken
                Card(
                    colors = CardDefaults.cardColors(containerColor = PureWhite),
                    border = BorderStroke(1.dp, BorderLight),
                    shape = RoundedCornerShape(8.dp),
                    modifier = Modifier.weight(1f)
                ) {
                    Column(modifier = Modifier.padding(10.dp)) {
                        Text("Days Taken", fontSize = 10.sp, color = TextMuted)
                        Text("7 Days", fontSize = 15.sp, fontWeight = FontWeight.Bold, color = RoyalCobaltBlue)
                        Text("Approved", fontSize = 9.sp, color = EmeraldSuccess)
                    }
                }

                // Card 3: Available Balance
                Card(
                    colors = CardDefaults.cardColors(containerColor = PureWhite),
                    border = BorderStroke(1.dp, BorderLight),
                    shape = RoundedCornerShape(8.dp),
                    modifier = Modifier.weight(1f)
                ) {
                    Column(modifier = Modifier.padding(10.dp)) {
                        Text("Available Balance", fontSize = 10.sp, color = TextMuted)
                        Text("14 Days", fontSize = 15.sp, fontWeight = FontWeight.Bold, color = EmeraldSuccess)
                        Text("Ready to Apply", fontSize = 9.sp, color = EmeraldSuccess)
                    }
                }

                // Card 4: Team Readiness Meter
                Card(
                    colors = CardDefaults.cardColors(containerColor = if (overallCoveragePercent >= 80) RoyalCobaltIce else Color(0xFFFEF3C7)),
                    border = BorderStroke(1.dp, if (overallCoveragePercent >= 80) RoyalCobaltBlue.copy(alpha = 0.3f) else Color(0xFFFDE68A)),
                    shape = RoundedCornerShape(8.dp),
                    modifier = Modifier.weight(1.3f)
                ) {
                    Column(modifier = Modifier.padding(10.dp)) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Icon(
                                imageVector = if (overallCoveragePercent >= 80) Icons.Default.CheckCircle else Icons.Default.Warning,
                                contentDescription = null,
                                tint = if (overallCoveragePercent >= 80) RoyalCobaltBlue else Color(0xFFD97706),
                                modifier = Modifier.size(14.dp)
                            )
                            Spacer(modifier = Modifier.width(4.dp))
                            Text("Coverage Status", fontSize = 10.sp, fontWeight = FontWeight.Bold, color = ObsidianBlack)
                        }
                        Text("$overallCoveragePercent% Staff Available", fontSize = 14.sp, fontWeight = FontWeight.Bold, color = if (overallCoveragePercent >= 80) RoyalCobaltBlue else Color(0xFFB45309))
                        Text("$totalAvailable / $allStaffCount on duty for $activeInspectedDay ${monthNames[activeInspectedMonth].take(3)}", fontSize = 9.sp, color = TextSecondary)
                    }
                }
            }
        }

        if (activeSubView == 0) {
            // ==============================================================
            // 1. INTERACTIVE VISUAL CALENDAR COMPONENT
            // ==============================================================
            item {
                Card(
                    colors = CardDefaults.cardColors(containerColor = PureWhite),
                    border = BorderStroke(1.dp, BorderLight),
                    shape = RoundedCornerShape(10.dp),
                    modifier = Modifier.fillMaxWidth().testTag("visual_calendar_component")
                ) {
                    Column(modifier = Modifier.padding(14.dp)) {
                        // Month & Year Navigation Bar
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            IconButton(
                                onClick = {
                                    if (currentMonth == 0) {
                                        currentMonth = 11
                                        currentYear -= 1
                                    } else {
                                        currentMonth -= 1
                                    }
                                },
                                modifier = Modifier.size(34.dp).testTag("btn_prev_month")
                            ) {
                                Icon(Icons.Default.ChevronLeft, contentDescription = "Previous Month", tint = RoyalCobaltBlue)
                            }

                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Text(
                                    text = "${monthNames[currentMonth]} $currentYear",
                                    fontSize = 16.sp,
                                    fontWeight = FontWeight.Bold,
                                    color = ObsidianBlack
                                )
                                Spacer(modifier = Modifier.width(8.dp))
                                Surface(
                                    color = RoyalCobaltIce,
                                    shape = RoundedCornerShape(12.dp),
                                    border = BorderStroke(1.dp, RoyalCobaltBlue.copy(alpha = 0.2f)),
                                    modifier = Modifier.clickable {
                                        currentMonth = 8 // Sep
                                        currentYear = 2026
                                        selectedStartDay = 25
                                        selectedEndDay = 25
                                        selectedRangeMonth = 8
                                        selectedRangeYear = 2026
                                    }
                                ) {
                                    Text(
                                        text = "Today: 25 Sep",
                                        fontSize = 10.sp,
                                        fontWeight = FontWeight.SemiBold,
                                        color = RoyalCobaltBlue,
                                        modifier = Modifier.padding(horizontal = 8.dp, vertical = 3.dp)
                                    )
                                }
                            }

                            IconButton(
                                onClick = {
                                    if (currentMonth == 11) {
                                        currentMonth = 0
                                        currentYear += 1
                                    } else {
                                        currentMonth += 1
                                    }
                                },
                                modifier = Modifier.size(34.dp).testTag("btn_next_month")
                            ) {
                                Icon(Icons.Default.ChevronRight, contentDescription = "Next Month", tint = RoyalCobaltBlue)
                            }
                        }

                        Spacer(modifier = Modifier.height(10.dp))

                        // Days of week header (Sun..Sat)
                        val daysOfWeek = listOf("Sun", "Mon", "Tue", "Wed", "Thu", "Fri", "Sat")
                        Row(modifier = Modifier.fillMaxWidth()) {
                            daysOfWeek.forEach { dayLabel ->
                                Text(
                                    text = dayLabel,
                                    fontSize = 11.sp,
                                    fontWeight = FontWeight.Bold,
                                    color = if (dayLabel == "Sun" || dayLabel == "Sat") RoyalCobaltBlue else TextSecondary,
                                    textAlign = TextAlign.Center,
                                    modifier = Modifier.weight(1f)
                                )
                            }
                        }

                        Spacer(modifier = Modifier.height(8.dp))

                        // Calendar Grid Days
                        val daysInMonth = getDaysInMonthCount(currentMonth, currentYear)
                        val firstDayOfWeek = getFirstDayOfWeekInMonth(currentMonth, currentYear)
                        val totalCells = ((firstDayOfWeek + daysInMonth + 6) / 7) * 7

                        val rowsCount = totalCells / 7
                        for (row in 0 until rowsCount) {
                            Row(
                                modifier = Modifier.fillMaxWidth().padding(vertical = 2.dp),
                                horizontalArrangement = Arrangement.SpaceBetween
                            ) {
                                for (col in 0..6) {
                                    val cellIndex = row * 7 + col
                                    val dayNumber = cellIndex - firstDayOfWeek + 1

                                    if (dayNumber in 1..daysInMonth) {
                                        // Check if this day falls in active selected range
                                        val isSelectedStart = dayNumber == selectedStartDay && currentMonth == selectedRangeMonth && currentYear == selectedRangeYear
                                        val isSelectedEnd = dayNumber == selectedEndDay && currentMonth == selectedRangeMonth && currentYear == selectedRangeYear
                                        val isInRange = currentMonth == selectedRangeMonth && currentYear == selectedRangeYear &&
                                                dayNumber in minOf(selectedStartDay, selectedEndDay)..maxOf(selectedStartDay, selectedEndDay)

                                        val isToday = dayNumber == 25 && currentMonth == 8 && currentYear == 2026

                                        // Check leaves on this day
                                        val dayLeaves = leaveRequests.filter { leave ->
                                            isDateInLeaveRange(dayNumber, currentMonth, currentYear, leave.startDate, leave.endDate)
                                        }
                                        val hasApprovedLeave = dayLeaves.any { it.status == "Approved" }
                                        val hasPendingLeave = dayLeaves.any { it.status == "Pending" }

                                        Box(
                                            modifier = Modifier
                                                .weight(1f)
                                                .height(46.dp)
                                                .padding(2.dp)
                                                .clip(RoundedCornerShape(6.dp))
                                                .background(
                                                    when {
                                                        isSelectedStart || isSelectedEnd -> RoyalCobaltBlue
                                                        isInRange -> RoyalCobaltIce
                                                        isToday -> Color(0xFFDBEAFE)
                                                        else -> Color.Transparent
                                                    }
                                                )
                                                .border(
                                                    width = if (isToday) 1.5.dp else if (isInRange) 1.dp else 0.dp,
                                                    color = if (isToday) RoyalCobaltBlue else if (isInRange) RoyalCobaltLight else Color.Transparent,
                                                    shape = RoundedCornerShape(6.dp)
                                                )
                                                .clickable {
                                                    selectedRangeMonth = currentMonth
                                                    selectedRangeYear = currentYear
                                                    if (selectedStartDay == dayNumber && selectedEndDay == dayNumber) {
                                                        // Tapped again -> single day
                                                    } else if (selectedStartDay == selectedEndDay && dayNumber > selectedStartDay) {
                                                        // Extending to range
                                                        selectedEndDay = dayNumber
                                                    } else {
                                                        selectedStartDay = dayNumber
                                                        selectedEndDay = dayNumber
                                                    }
                                                }
                                                .testTag("cal_day_${dayNumber}"),
                                            contentAlignment = Alignment.Center
                                        ) {
                                            Column(
                                                horizontalAlignment = Alignment.CenterHorizontally,
                                                verticalArrangement = Arrangement.Center
                                            ) {
                                                Text(
                                                    text = dayNumber.toString(),
                                                    fontSize = 12.sp,
                                                    fontWeight = if (isSelectedStart || isSelectedEnd || isToday) FontWeight.Bold else FontWeight.Normal,
                                                    color = when {
                                                        isSelectedStart || isSelectedEnd -> PureWhite
                                                        isInRange -> RoyalCobaltDark
                                                        else -> ObsidianBlack
                                                    }
                                                )

                                                // Leave indicators / status dots
                                                Row(
                                                    horizontalArrangement = Arrangement.spacedBy(2.dp),
                                                    verticalAlignment = Alignment.CenterVertically
                                                ) {
                                                    if (hasApprovedLeave) {
                                                        Box(
                                                            modifier = Modifier
                                                                .size(5.dp)
                                                                .clip(CircleShape)
                                                                .background(if (isSelectedStart || isSelectedEnd) PureWhite else EmeraldSuccess)
                                                        )
                                                    }
                                                    if (hasPendingLeave) {
                                                        Box(
                                                            modifier = Modifier
                                                                .size(5.dp)
                                                                .clip(CircleShape)
                                                                .background(if (isSelectedStart || isSelectedEnd) Color(0xFFFEF3C7) else Color(0xFFF59E0B))
                                                        )
                                                    }
                                                }
                                            }
                                        }
                                    } else {
                                        // Empty cell outside current month
                                        Spacer(modifier = Modifier.weight(1f).height(46.dp))
                                    }
                                }
                            }
                        }

                        Spacer(modifier = Modifier.height(10.dp))

                        // CALENDAR LEGEND
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceEvenly,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Box(modifier = Modifier.size(8.dp).clip(CircleShape).background(RoyalCobaltBlue))
                                Spacer(modifier = Modifier.width(4.dp))
                                Text("Selected Date", fontSize = 10.sp, color = TextSecondary)
                            }
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Box(modifier = Modifier.size(8.dp).clip(CircleShape).background(EmeraldSuccess))
                                Spacer(modifier = Modifier.width(4.dp))
                                Text("Approved Off", fontSize = 10.sp, color = TextSecondary)
                            }
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Box(modifier = Modifier.size(8.dp).clip(CircleShape).background(Color(0xFFF59E0B)))
                                Spacer(modifier = Modifier.width(4.dp))
                                Text("Pending Request", fontSize = 10.sp, color = TextSecondary)
                            }
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Box(modifier = Modifier.size(8.dp).border(1.dp, RoyalCobaltBlue, CircleShape))
                                Spacer(modifier = Modifier.width(4.dp))
                                Text("Today", fontSize = 10.sp, color = TextSecondary)
                            }
                        }

                        Spacer(modifier = Modifier.height(10.dp))

                        // SELECTION SUMMARY & DIRECT TIME-OFF ACTION BAR
                        Surface(
                            color = RoyalCobaltIce,
                            shape = RoundedCornerShape(8.dp),
                            border = BorderStroke(1.dp, RoyalCobaltBlue.copy(alpha = 0.25f)),
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            Row(
                                modifier = Modifier.padding(horizontal = 12.dp, vertical = 8.dp),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                val startStr = formatDayString(minOf(selectedStartDay, selectedEndDay), selectedRangeMonth, selectedRangeYear)
                                val endStr = formatDayString(maxOf(selectedStartDay, selectedEndDay), selectedRangeMonth, selectedRangeYear)
                                val count = (maxOf(selectedStartDay, selectedEndDay) - minOf(selectedStartDay, selectedEndDay) + 1)

                                Column {
                                    Text(
                                        text = "Selected: $startStr ${if (startStr != endStr) "to $endStr" else ""} ($count Day${if (count > 1) "s" else ""})",
                                        fontSize = 12.sp,
                                        fontWeight = FontWeight.Bold,
                                        color = RoyalCobaltDark
                                    )
                                    Text(
                                        text = "Tap any day to inspect team staffing coverage or apply time off",
                                        fontSize = 10.sp,
                                        color = TextSecondary
                                    )
                                }

                                Button(
                                    onClick = {
                                        dialogStartDate = startStr
                                        dialogEndDate = endStr
                                        dialogDaysCount = count.toString()
                                        showRequestDialog = true
                                    },
                                    colors = ButtonDefaults.buttonColors(containerColor = RoyalCobaltBlue),
                                    shape = RoundedCornerShape(6.dp),
                                    modifier = Modifier.testTag("btn_request_selected_dates")
                                ) {
                                    Icon(Icons.Default.Add, contentDescription = null, modifier = Modifier.size(14.dp))
                                    Spacer(modifier = Modifier.width(4.dp))
                                    Text("Request Time Off", fontSize = 11.sp, fontWeight = FontWeight.Bold)
                                }
                            }
                        }
                    }
                }
            }

            // ==============================================================
            // 2. TEAM COVERAGE STATUS COMPONENT
            // ==============================================================
            item {
                Card(
                    colors = CardDefaults.cardColors(containerColor = PureWhite),
                    border = BorderStroke(1.dp, BorderLight),
                    shape = RoundedCornerShape(10.dp),
                    modifier = Modifier.fillMaxWidth().testTag("team_coverage_status_component")
                ) {
                    Column(modifier = Modifier.padding(14.dp)) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Icon(Icons.Default.Groups, contentDescription = null, tint = RoyalCobaltBlue, modifier = Modifier.size(18.dp))
                                Spacer(modifier = Modifier.width(6.dp))
                                Text(
                                    text = "Team Coverage Status • $activeDateFormatted",
                                    fontSize = 15.sp,
                                    fontWeight = FontWeight.Bold,
                                    color = ObsidianBlack
                                )
                            }

                            Surface(
                                color = if (overallCoveragePercent >= 80) EmeraldLight else Color(0xFFFEF3C7),
                                shape = RoundedCornerShape(12.dp)
                            ) {
                                Text(
                                    text = if (overallCoveragePercent >= 85) "Optimal Staffing (${overallCoveragePercent}%)" else "Adequate Coverage (${overallCoveragePercent}%)",
                                    fontSize = 10.sp,
                                    fontWeight = FontWeight.Bold,
                                    color = if (overallCoveragePercent >= 85) EmeraldSuccess else Color(0xFFD97706),
                                    modifier = Modifier.padding(horizontal = 8.dp, vertical = 3.dp)
                                )
                            }
                        }

                        Text(
                            text = "Real-time departmental readiness breakdown for funeral operations, cortege fleet, and workshop",
                            fontSize = 11.sp,
                            color = TextMuted
                        )

                        Spacer(modifier = Modifier.height(12.dp))

                        // Department Coverage Cards Grid
                        val departments = listOf(
                            Department.WORKSHOP to (7 to "Casket Crafting & Fitting"),
                            Department.DRIVERS to (6 to "Hearse Fleet Stationed at Bama"),
                            Department.OPERATORS to (19 to "Lowering Gear & Church Service"),
                            Department.SALES_MARKETING to (9 to "Family Service & Consultations"),
                            Department.ADMINISTRATION to (2 to "Compliance, Accounts & Billing")
                        )

                        Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                            departments.forEach { (dept, meta) ->
                                val totalDeptStaff = meta.first
                                val deptRoleDesc = meta.second

                                // Count on leave in this dept on active date
                                val deptLeaves = staffOnLeaveActiveDate.filter { it.department == dept }
                                val deptOnLeaveCount = deptLeaves.count { it.status == "Approved" }
                                val deptPendingCount = deptLeaves.count { it.status == "Pending" }
                                val deptAvailableCount = (totalDeptStaff - deptOnLeaveCount).coerceAtLeast(0)
                                val deptCoveragePct = ((deptAvailableCount.toFloat() / totalDeptStaff.toFloat()) * 100).toInt()

                                Surface(
                                    color = if (deptCoveragePct >= 80) Color(0xFFF8FAFC) else Color(0xFFFFFBEB),
                                    shape = RoundedCornerShape(8.dp),
                                    border = BorderStroke(1.dp, if (deptCoveragePct >= 80) BorderLight else Color(0xFFFDE68A)),
                                    modifier = Modifier.fillMaxWidth()
                                ) {
                                    Column(modifier = Modifier.padding(10.dp)) {
                                        Row(
                                            modifier = Modifier.fillMaxWidth(),
                                            horizontalArrangement = Arrangement.SpaceBetween,
                                            verticalAlignment = Alignment.CenterVertically
                                        ) {
                                            Column {
                                                Text(
                                                    text = dept.displayName,
                                                    fontSize = 12.sp,
                                                    fontWeight = FontWeight.Bold,
                                                    color = ObsidianBlack
                                                )
                                                Text(
                                                    text = deptRoleDesc,
                                                    fontSize = 10.sp,
                                                    color = TextMuted
                                                )
                                            }

                                            Row(verticalAlignment = Alignment.CenterVertically) {
                                                Text(
                                                    text = "$deptAvailableCount / $totalDeptStaff On Duty",
                                                    fontSize = 12.sp,
                                                    fontWeight = FontWeight.Bold,
                                                    color = if (deptCoveragePct >= 80) RoyalCobaltBlue else Color(0xFFB45309)
                                                )
                                                Spacer(modifier = Modifier.width(6.dp))
                                                Surface(
                                                    color = if (deptCoveragePct >= 80) RoyalCobaltIce else Color(0xFFFEF3C7),
                                                    shape = RoundedCornerShape(4.dp)
                                                ) {
                                                    Text(
                                                        text = "$deptCoveragePct%",
                                                        fontSize = 10.sp,
                                                        fontWeight = FontWeight.Bold,
                                                        color = if (deptCoveragePct >= 80) RoyalCobaltBlue else Color(0xFFB45309),
                                                        modifier = Modifier.padding(horizontal = 4.dp, vertical = 1.dp)
                                                    )
                                                }
                                            }
                                        }

                                        Spacer(modifier = Modifier.height(6.dp))

                                        // Progress Bar
                                        LinearProgressIndicator(
                                            progress = { deptCoveragePct / 100f },
                                            modifier = Modifier.fillMaxWidth().height(5.dp).clip(RoundedCornerShape(3.dp)),
                                            color = if (deptCoveragePct >= 80) RoyalCobaltBlue else Color(0xFFF59E0B),
                                            trackColor = Color(0xFFE2E8F0)
                                        )

                                        if (deptLeaves.isNotEmpty()) {
                                            Spacer(modifier = Modifier.height(6.dp))
                                            Row(
                                                modifier = Modifier.fillMaxWidth(),
                                                horizontalArrangement = Arrangement.spacedBy(6.dp)
                                            ) {
                                                deptLeaves.forEach { l ->
                                                    Surface(
                                                        color = if (l.status == "Approved") EmeraldLight else Color(0xFFFEF3C7),
                                                        shape = RoundedCornerShape(4.dp)
                                                    ) {
                                                        Text(
                                                            text = "${l.staffName} (${l.leaveType.substringBefore(" ")}) • ${l.status}",
                                                            fontSize = 9.sp,
                                                            fontWeight = FontWeight.SemiBold,
                                                            color = if (l.status == "Approved") Color(0xFF065F46) else Color(0xFF92400E),
                                                            modifier = Modifier.padding(horizontal = 4.dp, vertical = 2.dp)
                                                        )
                                                    }
                                                }
                                            }
                                        }
                                    }
                                }
                            }
                        }

                        Spacer(modifier = Modifier.height(14.dp))

                        // STAFF ABSENT / ON LEAVE DETAIL CARDS FOR THIS DATE
                        Text(
                            text = "Staff Scheduled on Time-Off on $activeDateFormatted",
                            fontSize = 13.sp,
                            fontWeight = FontWeight.Bold,
                            color = ObsidianBlack
                        )
                        Spacer(modifier = Modifier.height(6.dp))

                        if (staffOnLeaveActiveDate.isEmpty()) {
                            Surface(
                                color = EmeraldLight,
                                shape = RoundedCornerShape(8.dp),
                                modifier = Modifier.fillMaxWidth()
                            ) {
                                Row(
                                    modifier = Modifier.padding(12.dp),
                                    verticalAlignment = Alignment.CenterVertically
                                ) {
                                    Icon(Icons.Default.CheckCircle, contentDescription = null, tint = EmeraldSuccess, modifier = Modifier.size(18.dp))
                                    Spacer(modifier = Modifier.width(8.dp))
                                    Text(
                                        text = "Full Team Availability: All 43 staff members across all 8 branches are scheduled on duty on this date.",
                                        fontSize = 11.sp,
                                        fontWeight = FontWeight.SemiBold,
                                        color = Color(0xFF065F46)
                                    )
                                }
                            }
                        } else {
                            Column(verticalArrangement = Arrangement.spacedBy(6.dp)) {
                                staffOnLeaveActiveDate.forEach { l ->
                                    val isApproved = l.status == "Approved"
                                    Card(
                                        colors = CardDefaults.cardColors(containerColor = if (isApproved) Color(0xFFF0FDF4) else Color(0xFFFFFBEB)),
                                        border = BorderStroke(1.dp, if (isApproved) Color(0xFFBBF7D0) else Color(0xFFFDE68A)),
                                        shape = RoundedCornerShape(6.dp),
                                        modifier = Modifier.fillMaxWidth()
                                    ) {
                                        Row(
                                            modifier = Modifier.padding(10.dp),
                                            horizontalArrangement = Arrangement.SpaceBetween,
                                            verticalAlignment = Alignment.CenterVertically
                                        ) {
                                            Row(verticalAlignment = Alignment.CenterVertically) {
                                                Icon(
                                                    imageVector = Icons.Default.Person,
                                                    contentDescription = null,
                                                    tint = if (isApproved) EmeraldSuccess else Color(0xFFD97706),
                                                    modifier = Modifier.size(16.dp)
                                                )
                                                Spacer(modifier = Modifier.width(6.dp))
                                                Column {
                                                    Text(text = l.staffName, fontSize = 12.sp, fontWeight = FontWeight.Bold, color = ObsidianBlack)
                                                    Text(text = "${l.department.displayName} • ${l.leaveType} (${l.daysCount} Days)", fontSize = 10.sp, color = TextSecondary)
                                                    Text(text = "Dates: ${l.startDate} to ${l.endDate} • ${l.reason}", fontSize = 9.sp, color = TextMuted)
                                                }
                                            }

                                            Surface(
                                                color = if (isApproved) EmeraldSuccess else Color(0xFFF59E0B),
                                                shape = RoundedCornerShape(10.dp)
                                            ) {
                                                Text(
                                                    text = l.status,
                                                    fontSize = 9.sp,
                                                    fontWeight = FontWeight.Bold,
                                                    color = PureWhite,
                                                    modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp)
                                                )
                                            }
                                        }
                                    }
                                }
                            }
                        }
                    }
                }
            }
        } else {
            // ==============================================================
            // 3. APPLICATIONS LEDGER VIEW
            // ==============================================================
            item {
                Text(
                    text = "Leave Applications & Approvals Ledger",
                    fontSize = 14.sp,
                    fontWeight = FontWeight.Bold,
                    color = ObsidianBlack
                )
            }

            items(leaveRequests) { leave ->
                val isPending = leave.status == "Pending"
                Card(
                    colors = CardDefaults.cardColors(containerColor = PureWhite),
                    border = BorderStroke(1.dp, BorderLight),
                    shape = RoundedCornerShape(8.dp),
                    modifier = Modifier.fillMaxWidth().testTag("leave_card_${leave.id}")
                ) {
                    Column(modifier = Modifier.padding(12.dp)) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Icon(Icons.AutoMirrored.Filled.EventNote, contentDescription = null, tint = RoyalCobaltBlue, modifier = Modifier.size(16.dp))
                                Spacer(modifier = Modifier.width(6.dp))
                                Text(text = leave.staffName, fontSize = 13.sp, fontWeight = FontWeight.Bold, color = ObsidianBlack)
                                Spacer(modifier = Modifier.width(6.dp))
                                Text(text = "(${leave.department.displayName.substringBefore(" ")})", fontSize = 11.sp, color = TextMuted)
                            }

                            Surface(
                                color = if (isPending) Color(0xFFFEF3C7) else EmeraldLight,
                                shape = RoundedCornerShape(12.dp)
                            ) {
                                Text(
                                    text = leave.status,
                                    fontSize = 10.sp,
                                    fontWeight = FontWeight.SemiBold,
                                    color = if (isPending) Color(0xFFD97706) else EmeraldSuccess,
                                    modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp)
                                )
                            }
                        }

                        Spacer(modifier = Modifier.height(6.dp))

                        Text(text = "Type: ${leave.leaveType} • ${leave.daysCount} Days", fontSize = 12.sp, fontWeight = FontWeight.SemiBold, color = RoyalCobaltBlue)
                        Text(text = "Dates: ${leave.startDate} to ${leave.endDate}", fontSize = 11.sp, color = Color(0xFF475569))
                        Text(text = "Reason: ${leave.reason}", fontSize = 10.sp, color = TextMuted)

                        if (leave.approvedBy != null) {
                            Text(text = "Approved by: ${leave.approvedBy}", fontSize = 10.sp, color = EmeraldSuccess, fontWeight = FontWeight.Medium)
                        }

                        if (isPending && isManagement) {
                            Spacer(modifier = Modifier.height(8.dp))
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.spacedBy(8.dp)
                            ) {
                                Button(
                                    onClick = {
                                        viewModel.approveLeaveRequest(leave.id, currentAccount?.fullName ?: "Fredrick Hayoyo (CEO)")
                                    },
                                    colors = ButtonDefaults.buttonColors(containerColor = EmeraldSuccess),
                                    shape = RoundedCornerShape(6.dp),
                                    modifier = Modifier
                                        .weight(1.4f)
                                        .height(40.dp)
                                        .testTag("btn_approve_${leave.id}")
                                ) {
                                    Icon(Icons.Default.Check, contentDescription = null, modifier = Modifier.size(14.dp))
                                    Spacer(modifier = Modifier.width(4.dp))
                                    Text("Approve Leave", fontSize = 11.sp, fontWeight = FontWeight.Bold)
                                }
                                OutlinedButton(
                                    onClick = {
                                        viewModel.rejectLeaveRequest(leave.id, currentAccount?.fullName ?: "Management")
                                    },
                                    shape = RoundedCornerShape(6.dp),
                                    border = BorderStroke(1.dp, StrokeRed.copy(alpha = 0.65f)),
                                    modifier = Modifier
                                        .weight(1f)
                                        .height(40.dp)
                                        .testTag("btn_decline_${leave.id}")
                                ) {
                                    Icon(Icons.Default.Close, contentDescription = null, tint = StrokeRed, modifier = Modifier.size(14.dp))
                                    Spacer(modifier = Modifier.width(4.dp))
                                    Text("Decline", fontSize = 11.sp, fontWeight = FontWeight.Bold, color = StrokeRed)
                                }
                            }
                        }
                    }
                }
            }
        }
    }

    // ==============================================================
    // 4. APPLY TIME OFF DIALOG (Linked directly to Visual Calendar)
    // ==============================================================
    if (showRequestDialog) {
        val leaveTypes = listOf("Annual Leave", "Compassionate / Bereavement", "Sick Leave", "Off-Duty Rest")
        var selectedType by remember { mutableStateOf(leaveTypes[0]) }
        var startDate by remember { mutableStateOf(dialogStartDate) }
        var endDate by remember { mutableStateOf(dialogEndDate) }
        var daysCountStr by remember { mutableStateOf(dialogDaysCount) }
        var reasonText by remember { mutableStateOf("") }
        var typeDropdownExpanded by remember { mutableStateOf(false) }

        Dialog(onDismissRequest = { showRequestDialog = false }) {
            Surface(
                shape = RoundedCornerShape(12.dp),
                color = PureWhite,
                modifier = Modifier.fillMaxWidth().padding(8.dp).testTag("dialog_apply_leave")
            ) {
                Column(modifier = Modifier.padding(16.dp)) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Column {
                            Text("Request Time Off", fontSize = 16.sp, fontWeight = FontWeight.Bold, color = ObsidianBlack)
                            Text("Selected from Visual Calendar", fontSize = 11.sp, color = RoyalCobaltBlue)
                        }
                        IconButton(onClick = { showRequestDialog = false }) {
                            Icon(Icons.Default.Close, contentDescription = "Close", tint = TextMuted)
                        }
                    }

                    Spacer(modifier = Modifier.height(10.dp))

                    // Leave Category dropdown
                    Text("Leave Category", fontSize = 11.sp, fontWeight = FontWeight.SemiBold, color = TextSecondary)
                    Box(modifier = Modifier.fillMaxWidth()) {
                        Surface(
                            shape = RoundedCornerShape(6.dp),
                            border = BorderStroke(1.dp, BorderLight),
                            color = PureWhite,
                            modifier = Modifier.fillMaxWidth().clickable { typeDropdownExpanded = true }
                        ) {
                            Row(
                                modifier = Modifier.padding(horizontal = 12.dp, vertical = 10.dp),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Text(selectedType, fontSize = 13.sp, color = ObsidianBlack)
                                Icon(Icons.Default.ChevronRight, contentDescription = null, tint = TextMuted)
                            }
                        }

                        DropdownMenu(
                            expanded = typeDropdownExpanded,
                            onDismissRequest = { typeDropdownExpanded = false }
                        ) {
                            leaveTypes.forEach { t ->
                                DropdownMenuItem(
                                    text = { Text(t, fontSize = 12.sp) },
                                    onClick = {
                                        selectedType = t
                                        typeDropdownExpanded = false
                                    }
                                )
                            }
                        }
                    }

                    Spacer(modifier = Modifier.height(10.dp))

                    // Dates row (Pre-filled from Calendar Selection)
                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        OutlinedTextField(
                            value = startDate,
                            onValueChange = { startDate = it },
                            label = { Text("Start Date", fontSize = 11.sp) },
                            modifier = Modifier.weight(1f)
                        )
                        OutlinedTextField(
                            value = endDate,
                            onValueChange = { endDate = it },
                            label = { Text("End Date", fontSize = 11.sp) },
                            modifier = Modifier.weight(1f)
                        )
                    }

                    Spacer(modifier = Modifier.height(8.dp))

                    OutlinedTextField(
                        value = daysCountStr,
                        onValueChange = { daysCountStr = it },
                        label = { Text("Number of Days", fontSize = 11.sp) },
                        modifier = Modifier.fillMaxWidth()
                    )

                    Spacer(modifier = Modifier.height(8.dp))

                    OutlinedTextField(
                        value = reasonText,
                        onValueChange = { reasonText = it },
                        label = { Text("Reason for Time Off", fontSize = 11.sp) },
                        placeholder = { Text("e.g. Scheduled annual leave / bereavement", fontSize = 11.sp) },
                        modifier = Modifier.fillMaxWidth()
                    )

                    Spacer(modifier = Modifier.height(10.dp))

                    // Coverage Impact Notice
                    Surface(
                        color = RoyalCobaltIce,
                        shape = RoundedCornerShape(6.dp),
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Row(
                            modifier = Modifier.padding(8.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Icon(Icons.Default.CheckCircle, contentDescription = null, tint = RoyalCobaltBlue, modifier = Modifier.size(14.dp))
                            Spacer(modifier = Modifier.width(6.dp))
                            Text(
                                text = "Coverage Check: Team staffing will maintain >80% readiness during these dates.",
                                fontSize = 10.sp,
                                color = RoyalCobaltDark
                            )
                        }
                    }

                    Spacer(modifier = Modifier.height(14.dp))

                    Button(
                        onClick = {
                            val acc = currentAccount
                            val count = daysCountStr.toIntOrNull() ?: 1
                            val newLeave = LeaveRequest(
                                id = "LVE-${(100..999).random()}",
                                staffId = acc?.id ?: "WRK-001",
                                staffName = acc?.fullName ?: "Staff Member",
                                department = acc?.department ?: Department.WORKSHOP,
                                leaveType = selectedType,
                                startDate = startDate,
                                endDate = endDate,
                                daysCount = count,
                                reason = reasonText.ifBlank { "Personal time off request" },
                                status = "Pending"
                            )
                            viewModel.submitLeaveRequest(newLeave)
                            showRequestDialog = false
                        },
                        colors = ButtonDefaults.buttonColors(containerColor = RoyalCobaltBlue),
                        shape = RoundedCornerShape(6.dp),
                        modifier = Modifier.fillMaxWidth().height(42.dp).testTag("btn_submit_leave")
                    ) {
                        Text("Submit Leave Application", fontWeight = FontWeight.Bold)
                    }
                }
            }
        }
    }
}
