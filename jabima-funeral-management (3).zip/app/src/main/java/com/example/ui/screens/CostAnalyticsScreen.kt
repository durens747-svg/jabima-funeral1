package com.example.ui.screens

import androidx.compose.animation.core.Spring
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.spring
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Build
import androidx.compose.material.icons.filled.Calculate
import androidx.compose.material.icons.filled.Savings
import androidx.compose.material.icons.filled.ShoppingCart
import androidx.compose.material.icons.filled.TrendingDown
import androidx.compose.material.icons.filled.TrendingUp
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.FilterChip
import androidx.compose.material3.FilterChipDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.CornerRadius
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.domain.OperationsAnalyticsEngine
import com.example.model.MainAppTab
import com.example.model.MarginStatus
import com.example.ui.StaffPortalViewModel
import com.example.ui.theme.AmberLight
import com.example.ui.theme.AmberWarning
import com.example.ui.theme.BorderLight
import com.example.ui.theme.EmeraldLight
import com.example.ui.theme.EmeraldSuccess
import com.example.ui.theme.ForestGreenDark
import com.example.ui.theme.ForestGreenLight
import com.example.ui.theme.ForestGreenPrimary
import com.example.ui.theme.Navy900
import com.example.ui.theme.PureWhite
import com.example.ui.theme.RoyalCobaltBlue
import com.example.ui.theme.RoyalCobaltIce
import com.example.ui.theme.StrokeRed
import com.example.ui.theme.StrokeRedLight
import com.example.ui.theme.TextMuted
import com.example.ui.theme.TextSecondary
import java.util.Locale
import kotlin.math.abs

@Composable
fun CostAnalyticsScreen(
    viewModel: StaffPortalViewModel,
    onOpenBomCostings: () -> Unit = { viewModel.setMainAppTab(MainAppTab.COSTINGS_AND_PRICING) },
    onOpenOrderDashboard: () -> Unit = { viewModel.setMainAppTab(MainAppTab.ORDER_DASHBOARD) }
) {
    val materials by viewModel.inventoryMaterials.collectAsState()
    val workshopJobs by viewModel.workshopItems.collectAsState()
    val orders by viewModel.customerOrders.collectAsState()
    val vendorTxns by viewModel.vendorTransactions.collectAsState()
    val expenseClaims by viewModel.allExpenses.collectAsState()

    var currencyMode by remember { mutableStateOf("KES") }
    var activeFocusFilter by remember { mutableIntStateOf(0) } // 0: All, 1: Workshop Variance, 2: Order Margins, 3: Model Economics

    val summary = remember(materials, workshopJobs, orders, vendorTxns, expenseClaims) {
        OperationsAnalyticsEngine.buildCostAnalyticsSummary(
            materials = materials,
            workshopJobs = workshopJobs,
            orders = orders,
            vendorTransactions = vendorTxns,
            expenseClaims = expenseClaims
        )
    }

    val fmt: (Double) -> String = { kes ->
        if (currencyMode == "KES") {
            "KES ${String.format(Locale.US, "%,.0f", kes)}"
        } else {
            "$ ${String.format(Locale.US, "%,.0f", kes / 130.0)}"
        }
    }

    LazyColumn(
        modifier = Modifier
            .fillMaxSize()
            .background(MaterialTheme.colorScheme.background)
            .testTag("cost_analytics_screen"),
        contentPadding = PaddingValues(14.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        // 1. Hero Header + Financial KPIs
        item(key = "cost_analytics_hero") {
            Card(
                shape = RoundedCornerShape(16.dp),
                border = BorderStroke(1.5.dp, StrokeRed.copy(alpha = 0.5f)),
                colors = CardDefaults.cardColors(containerColor = PureWhite),
                modifier = Modifier.fillMaxWidth()
            ) {
                Column {
                    Box(
                        modifier = Modifier
                            .fillMaxWidth()
                            .background(Brush.linearGradient(listOf(ForestGreenDark, ForestGreenPrimary, ForestGreenLight)))
                            .padding(16.dp)
                    ) {
                        Column {
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Column(modifier = Modifier.weight(1f)) {
                                    Text(
                                        text = "COST & MARGIN ANALYTICS",
                                        fontSize = 10.sp,
                                        fontWeight = FontWeight.ExtraBold,
                                        color = Color(0xFF86EFAC),
                                        letterSpacing = 0.8.sp
                                    )
                                    Text(
                                        text = "COGS, Workshop Variance & Net Profitability",
                                        fontSize = 16.sp,
                                        fontWeight = FontWeight.Bold,
                                        color = Color.White,
                                        maxLines = 1,
                                        overflow = TextOverflow.Ellipsis
                                    )
                                }

                                Surface(
                                    shape = RoundedCornerShape(16.dp),
                                    color = Color.White.copy(alpha = 0.16f)
                                ) {
                                    Row(modifier = Modifier.padding(3.dp)) {
                                        listOf("KES", "USD").forEach { curr ->
                                            val active = currencyMode == curr
                                            Surface(
                                                shape = RoundedCornerShape(12.dp),
                                                color = if (active) Color.White else Color.Transparent,
                                                modifier = Modifier
                                                    .clickable { currencyMode = curr }
                                                    .testTag("cost_analytics_currency_$curr")
                                            ) {
                                                Text(
                                                    text = curr,
                                                    fontSize = 10.sp,
                                                    fontWeight = FontWeight.ExtraBold,
                                                    color = if (active) Navy900 else Color.White,
                                                    modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp)
                                                )
                                            }
                                        }
                                    }
                                }
                            }

                            Spacer(modifier = Modifier.height(10.dp))

                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.spacedBy(8.dp)
                            ) {
                                Button(
                                    onClick = onOpenBomCostings,
                                    colors = ButtonDefaults.buttonColors(containerColor = EmeraldSuccess),
                                    shape = RoundedCornerShape(8.dp),
                                    contentPadding = PaddingValues(horizontal = 10.dp),
                                    modifier = Modifier.weight(1f).height(38.dp).testTag("cost_analytics_bom_btn")
                                ) {
                                    Icon(Icons.Default.Calculate, contentDescription = null, modifier = Modifier.size(14.dp))
                                    Spacer(modifier = Modifier.width(5.dp))
                                    Text("BOM Guide", fontSize = 11.sp, fontWeight = FontWeight.Bold, maxLines = 1, softWrap = false)
                                }
                                OutlinedButton(
                                    onClick = onOpenOrderDashboard,
                                    colors = ButtonDefaults.outlinedButtonColors(contentColor = Color.White),
                                    border = BorderStroke(1.dp, Color.White.copy(alpha = 0.45f)),
                                    shape = RoundedCornerShape(8.dp),
                                    contentPadding = PaddingValues(horizontal = 10.dp),
                                    modifier = Modifier.weight(1f).height(38.dp).testTag("cost_analytics_orders_btn")
                                ) {
                                    Icon(Icons.Default.ShoppingCart, contentDescription = null, modifier = Modifier.size(14.dp))
                                    Spacer(modifier = Modifier.width(5.dp))
                                    Text("Order Dashboard", fontSize = 11.sp, fontWeight = FontWeight.Bold, maxLines = 1, softWrap = false)
                                }
                            }
                        }
                    }

                    // 4 Analytical KPI Tiles
                    Column(
                        modifier = Modifier.padding(12.dp),
                        verticalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.spacedBy(8.dp)
                        ) {
                            CostKpiCard(
                                title = "Order Revenue vs COGS",
                                value = fmt(summary.realizedOrderRevenueKes),
                                sub = "Est COGS: ${fmt(summary.estimatedOrderCogsKes)}",
                                fg = RoyalCobaltBlue,
                                bg = RoyalCobaltIce,
                                modifier = Modifier.weight(1f)
                            )
                            CostKpiCard(
                                title = "Net Operating Margin",
                                value = "${summary.netOperatingMarginPercent}%",
                                sub = "Net: ${fmt(summary.netOperatingProfitKes)}",
                                fg = if (summary.netOperatingProfitKes >= 0.0) EmeraldSuccess else StrokeRed,
                                bg = if (summary.netOperatingProfitKes >= 0.0) EmeraldLight else StrokeRedLight,
                                modifier = Modifier.weight(1f)
                            )
                        }
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.spacedBy(8.dp)
                        ) {
                            CostKpiCard(
                                title = "Workshop Cost Spend",
                                value = fmt(summary.totalWorkshopSpendKes),
                                sub = "Variance vs BOM: ${if (summary.workshopNetVarianceKes >= 0) "+" else "-"}${fmt(abs(summary.workshopNetVarianceKes))}",
                                fg = if (summary.workshopNetVarianceKes > 1000) AmberWarning else Navy900,
                                bg = if (summary.workshopNetVarianceKes > 1000) AmberLight else Color(0xFFF1F5F9),
                                modifier = Modifier.weight(1f)
                            )
                            CostKpiCard(
                                title = "Inventory + Vendor OpEx",
                                value = fmt(summary.totalInventoryAssetCostKes),
                                sub = "Vendor & Field: ${fmt(summary.vendorOutflowsKes + summary.staffFieldExpensesKes)}",
                                fg = Color(0xFF7C3AED),
                                bg = Color(0xFFEDE9FE),
                                modifier = Modifier.weight(1f)
                            )
                        }
                    }
                }
            }
        }

        // 2. Bulk Glue Optimization Insight Banner
        item(key = "cost_analytics_optimization") {
            Surface(
                color = EmeraldLight,
                shape = RoundedCornerShape(12.dp),
                border = BorderStroke(1.dp, EmeraldSuccess.copy(alpha = 0.35f)),
                modifier = Modifier.fillMaxWidth().testTag("cost_analytics_bulk_savings_banner")
            ) {
                Row(
                    modifier = Modifier.padding(12.dp),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    Icon(Icons.Default.Savings, contentDescription = null, tint = EmeraldSuccess, modifier = Modifier.size(22.dp))
                    Column(modifier = Modifier.weight(1f)) {
                        Text(
                            text = "Procurement Savings Insight: Bulk Glue Rate",
                            fontSize = 12.sp,
                            fontWeight = FontWeight.Bold,
                            color = Navy900
                        )
                        Text(
                            text = "Switching from Standard Glue (KES 1,000/Ltr) to Bulk Glue (KES 900/Ltr) saves approx. ${fmt(summary.monthlyBulkGlueSavingsPotentialKes)} across monthly workshop runs.",
                            fontSize = 11.sp,
                            color = TextSecondary
                        )
                    }
                }
            }
        }

        // 3. Cost Pool Donut Ring Canvas Chart
        if (summary.costPoolSlices.isNotEmpty()) {
            item(key = "cost_pool_donut") {
                Card(
                    shape = RoundedCornerShape(14.dp),
                    colors = CardDefaults.cardColors(containerColor = PureWhite),
                    border = BorderStroke(1.dp, BorderLight),
                    modifier = Modifier.fillMaxWidth().testTag("cost_pool_chart_card")
                ) {
                    Column(modifier = Modifier.padding(14.dp)) {
                        Text(
                            text = "Enterprise Cost Pool Breakdown",
                            fontSize = 13.sp,
                            fontWeight = FontWeight.ExtraBold,
                            color = Navy900
                        )
                        Spacer(modifier = Modifier.height(10.dp))

                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.spacedBy(14.dp)
                        ) {
                            val totalPoolKes = summary.costPoolSlices.sumOf { it.amountKes }.coerceAtLeast(1.0)
                            Box(
                                contentAlignment = Alignment.Center,
                                modifier = Modifier.size(112.dp)
                            ) {
                                Canvas(modifier = Modifier.size(104.dp)) {
                                    val strokeWidth = 18.dp.toPx()
                                    val arcSize = Size(size.width - strokeWidth, size.height - strokeWidth)
                                    val topLeft = Offset(strokeWidth / 2f, strokeWidth / 2f)
                                    var startAngle = -90f
                                    summary.costPoolSlices.forEach { slice ->
                                        val sweep = ((slice.amountKes / totalPoolKes) * 360.0).toFloat()
                                        drawArc(
                                            color = Color(slice.colorHex),
                                            startAngle = startAngle,
                                            sweepAngle = (sweep - 2f).coerceAtLeast(4f),
                                            useCenter = false,
                                            topLeft = topLeft,
                                            size = arcSize,
                                            style = Stroke(width = strokeWidth, cap = StrokeCap.Butt)
                                        )
                                        startAngle += sweep
                                    }
                                }
                                Column(horizontalAlignment = Alignment.CenterHorizontally) {
                                    Text("Cost Mix", fontSize = 10.sp, fontWeight = FontWeight.Bold, color = Navy900)
                                    Text("${summary.costPoolSlices.size} Pools", fontSize = 9.sp, color = TextMuted)
                                }
                            }

                            Column(
                                modifier = Modifier.weight(1f),
                                verticalArrangement = Arrangement.spacedBy(6.dp)
                            ) {
                                summary.costPoolSlices.forEach { slice ->
                                    Row(
                                        modifier = Modifier.fillMaxWidth(),
                                        horizontalArrangement = Arrangement.SpaceBetween,
                                        verticalAlignment = Alignment.CenterVertically
                                    ) {
                                        Row(verticalAlignment = Alignment.CenterVertically, modifier = Modifier.weight(1f)) {
                                            Box(
                                                modifier = Modifier
                                                    .size(9.dp)
                                                    .clip(CircleShape)
                                                    .background(Color(slice.colorHex))
                                            )
                                            Spacer(modifier = Modifier.width(6.dp))
                                            Text(
                                                text = "${slice.label} (${slice.sharePercent}%)",
                                                fontSize = 10.sp,
                                                fontWeight = FontWeight.SemiBold,
                                                color = Navy900,
                                                maxLines = 1,
                                                overflow = TextOverflow.Ellipsis
                                            )
                                        }
                                        Text(fmt(slice.amountKes), fontSize = 10.sp, fontWeight = FontWeight.Bold, color = Navy900)
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }

        // 4. Focus Switcher Chips
        item(key = "cost_analytics_focus_chips") {
            Row(
                modifier = Modifier.fillMaxWidth().horizontalScroll(rememberScrollState()),
                horizontalArrangement = Arrangement.spacedBy(6.dp)
            ) {
                listOf("All Views", "Workshop Variance", "Order Margins", "Model Margin Bars").forEachIndexed { idx, label ->
                    FilterChip(
                        selected = activeFocusFilter == idx,
                        onClick = { activeFocusFilter = idx },
                        label = { Text(label, fontSize = 11.sp, maxLines = 1, softWrap = false) },
                        colors = FilterChipDefaults.filterChipColors(
                            selectedContainerColor = Navy900,
                            selectedLabelColor = Color.White
                        ),
                        modifier = Modifier.testTag("cost_focus_chip_$idx")
                    )
                }
            }
        }

        // 5. Workshop Job Variance vs BOM Benchmark
        if (activeFocusFilter == 0 || activeFocusFilter == 1) {
            item(key = "header_workshop_variance") {
                Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                    Icon(Icons.Default.Build, contentDescription = null, tint = RoyalCobaltBlue, modifier = Modifier.size(16.dp))
                    Text(
                        text = "Workshop Job Cost vs BOM Benchmark (${summary.workshopVariances.size})",
                        fontSize = 13.sp,
                        fontWeight = FontWeight.ExtraBold,
                        color = Navy900
                    )
                }
            }

            items(summary.workshopVariances, key = { "wv_${it.jobId}" }) { item ->
                Card(
                    shape = RoundedCornerShape(12.dp),
                    colors = CardDefaults.cardColors(containerColor = PureWhite),
                    border = BorderStroke(1.dp, if (item.isOverBudget) StrokeRed.copy(alpha = 0.4f) else BorderLight),
                    modifier = Modifier.fillMaxWidth().testTag("variance_card_${item.jobId}")
                ) {
                    Column(modifier = Modifier.padding(12.dp)) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Column(modifier = Modifier.weight(1f)) {
                                Text("${item.casketType} (${item.jobId})", fontSize = 13.sp, fontWeight = FontWeight.Bold, color = Navy900)
                                Text("${item.stageLabel} • ${item.craftsmanName}", fontSize = 10.sp, color = TextMuted)
                            }
                            Surface(
                                color = if (item.isOverBudget) StrokeRedLight else EmeraldLight,
                                shape = RoundedCornerShape(8.dp)
                            ) {
                                Text(
                                    text = if (item.varianceKes >= 0) "+${fmt(item.varianceKes)} Over" else "-${fmt(abs(item.varianceKes))} Saved",
                                    fontSize = 10.sp,
                                    fontWeight = FontWeight.Bold,
                                    color = if (item.isOverBudget) StrokeRed else EmeraldSuccess,
                                    modifier = Modifier.padding(horizontal = 7.dp, vertical = 3.dp)
                                )
                            }
                        }
                        Spacer(modifier = Modifier.height(6.dp))
                        Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                            Text("Actual: ${fmt(item.actualCostKes)}", fontSize = 11.sp, fontWeight = FontWeight.SemiBold, color = Navy900)
                            Text("BOM Guide: ${fmt(item.benchmarkBomCostKes)}", fontSize = 11.sp, color = TextSecondary)
                            Text("Margin: ${item.realizedMarginPercent}%", fontSize = 11.sp, fontWeight = FontWeight.Bold, color = RoyalCobaltBlue)
                        }
                    }
                }
            }
        }

        // 6. Order Profitability Analysis
        if (activeFocusFilter == 0 || activeFocusFilter == 2) {
            item(key = "header_order_profitability") {
                Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                    Icon(Icons.Default.TrendingUp, contentDescription = null, tint = EmeraldSuccess, modifier = Modifier.size(16.dp))
                    Text(
                        text = "Order Profitability & 5% Commission Impact (${summary.orderProfitabilities.size})",
                        fontSize = 13.sp,
                        fontWeight = FontWeight.ExtraBold,
                        color = Navy900
                    )
                }
            }

            items(summary.orderProfitabilities, key = { "op_${it.orderId}" }) { item ->
                val isHealthy = item.marginEvaluation.status == MarginStatus.HEALTHY
                Card(
                    shape = RoundedCornerShape(12.dp),
                    colors = CardDefaults.cardColors(containerColor = PureWhite),
                    border = BorderStroke(1.dp, BorderLight),
                    modifier = Modifier.fillMaxWidth().testTag("order_profit_card_${item.orderId}")
                ) {
                    Column(modifier = Modifier.padding(12.dp)) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Column(modifier = Modifier.weight(1f)) {
                                Text("${item.orderId} • ${item.clientName}", fontSize = 12.sp, fontWeight = FontWeight.Bold, color = Navy900)
                                Text("${item.casketLabel} -> BOM: ${item.matchedBomModelName}", fontSize = 10.sp, color = TextMuted)
                            }
                            Surface(
                                color = if (isHealthy) EmeraldLight else AmberLight,
                                shape = RoundedCornerShape(8.dp)
                            ) {
                                Text(
                                    text = "${item.netMarginPercent}% Net",
                                    fontSize = 10.sp,
                                    fontWeight = FontWeight.ExtraBold,
                                    color = if (isHealthy) EmeraldSuccess else AmberWarning,
                                    modifier = Modifier.padding(horizontal = 7.dp, vertical = 3.dp)
                                )
                            }
                        }
                        Spacer(modifier = Modifier.height(6.dp))
                        Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                            Text("Rev: ${fmt(item.orderRevenueKes)}", fontSize = 10.sp, color = Navy900, fontWeight = FontWeight.SemiBold)
                            Text("COGS: ${fmt(item.estimatedProductionCostKes)}", fontSize = 10.sp, color = TextSecondary)
                            Text("Comm: ${fmt(item.salesCommissionKes)}", fontSize = 10.sp, color = AmberWarning)
                            Text("Profit: ${fmt(item.netProfitKes)}", fontSize = 11.sp, fontWeight = FontWeight.ExtraBold, color = EmeraldSuccess)
                        }
                    }
                }
            }
        }

        // 7. 9-Model Unit Economics Margin Ranking
        if (activeFocusFilter == 0 || activeFocusFilter == 3) {
            item(key = "model_unit_economics_chart") {
                Card(
                    shape = RoundedCornerShape(14.dp),
                    colors = CardDefaults.cardColors(containerColor = PureWhite),
                    border = BorderStroke(1.dp, BorderLight),
                    modifier = Modifier.fillMaxWidth().testTag("model_unit_economics_card")
                ) {
                    Column(modifier = Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                        Text(
                            text = "Unit Economics: Gross Margin % by Casket Model",
                            fontSize = 13.sp,
                            fontWeight = FontWeight.ExtraBold,
                            color = Navy900
                        )
                        summary.modelUnitEconomics.forEach { m ->
                            val ratio by animateFloatAsState(
                                targetValue = (m.grossMarginPercent / 100.0).toFloat().coerceIn(0.08f, 1f),
                                animationSpec = spring(stiffness = Spring.StiffnessMediumLow),
                                label = "margin_${m.id}"
                            )
                            Column {
                                Row(
                                    modifier = Modifier.fillMaxWidth(),
                                    horizontalArrangement = Arrangement.SpaceBetween
                                ) {
                                    Text(
                                        text = "${m.modelName} (Cost ${fmt(m.totalProductionCostKes)})",
                                        fontSize = 11.sp,
                                        fontWeight = FontWeight.SemiBold,
                                        color = Navy900,
                                        maxLines = 1,
                                        overflow = TextOverflow.Ellipsis,
                                        modifier = Modifier.weight(1f)
                                    )
                                    Text(
                                        text = "${m.grossMarginPercent}%",
                                        fontSize = 11.sp,
                                        fontWeight = FontWeight.ExtraBold,
                                        color = EmeraldSuccess
                                    )
                                }
                                Spacer(modifier = Modifier.height(3.dp))
                                Canvas(modifier = Modifier.fillMaxWidth().height(7.dp)) {
                                    drawRoundRect(color = Color(0xFFE2E8F0), cornerRadius = CornerRadius(4.dp.toPx()))
                                    drawRoundRect(
                                        color = if (m.grossMarginPercent >= 60.0) EmeraldSuccess else RoyalCobaltBlue,
                                        size = Size(size.width * ratio, size.height),
                                        cornerRadius = CornerRadius(4.dp.toPx())
                                    )
                                }
                            }
                        }
                    }
                }
            }
        }
    }
}

@Composable
private fun CostKpiCard(
    title: String,
    value: String,
    sub: String,
    fg: Color,
    bg: Color,
    modifier: Modifier = Modifier
) {
    Surface(
        color = bg,
        shape = RoundedCornerShape(10.dp),
        border = BorderStroke(1.dp, fg.copy(alpha = 0.25f)),
        modifier = modifier
    ) {
        Column(modifier = Modifier.padding(10.dp)) {
            Text(title, fontSize = 10.sp, fontWeight = FontWeight.SemiBold, color = fg, maxLines = 1, overflow = TextOverflow.Ellipsis)
            Spacer(modifier = Modifier.height(2.dp))
            Text(value, fontSize = 14.sp, fontWeight = FontWeight.ExtraBold, color = Navy900, maxLines = 1, overflow = TextOverflow.Ellipsis)
            Text(sub, fontSize = 10.sp, color = TextSecondary, maxLines = 1, overflow = TextOverflow.Ellipsis)
        }
    }
}
