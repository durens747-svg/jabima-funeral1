package com.example.ui.theme

import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color

// ============================================================================
// Jabima Green, Pure White & Stroke of Red Material 3 Color Schemes
// ============================================================================
private val CorporateLightColorScheme = lightColorScheme(
    primary = ForestGreenPrimary,           // #145A32 (Jabima Forest Green)
    onPrimary = PureWhite,
    primaryContainer = EmeraldGreenIce,     // #ECFDF5 (Soft Sage Container)
    onPrimaryContainer = ForestGreenDark,   // #0B3B22
    secondary = ForestGreenLight,           // #1E7E48 (Vibrant Jabima Green Accent)
    onSecondary = PureWhite,
    secondaryContainer = EmeraldLight,      // #D1FAE5 (Mint Green Container)
    onSecondaryContainer = ForestGreenDark, // #0B3B22
    tertiary = StrokeRed,                   // #DC2626 (Signature Stroke of Red)
    onTertiary = PureWhite,
    tertiaryContainer = StrokeRedLight,     // #FEE2E2
    onTertiaryContainer = StrokeRedDark,    // #991B1B
    background = PureWhite,                 // #FFFFFF (Pure White Canvas)
    onBackground = TextPrimary,
    surface = PureWhite,                    // #FFFFFF (Pure White Card Surface)
    onSurface = TextPrimary,
    surfaceVariant = SurfaceVariantLight,   // #F6F9F7 (Subtle Sage-White Surface)
    onSurfaceVariant = TextSecondary,
    outline = BorderLight,
    outlineVariant = BorderLightGreen,
    error = StrokeRed,
    onError = PureWhite
)

private val CorporateDarkColorScheme = darkColorScheme(
    primary = NocturnalEmerald,             // #34D399 (Dignified Luminous Emerald)
    onPrimary = Color(0xFF042F1A),
    primaryContainer = NocturnalContainer,  // #0E3B26 (Deep Executive Forest)
    onPrimaryContainer = Color(0xFFA7F3D0),
    secondary = NocturnalBlue,              // #60A5FA (Corporate Sky Sapphire)
    onSecondary = Color(0xFF0A2540),
    secondaryContainer = NocturnalBlueContainer, // #15385A (Deep Sapphire Container)
    onSecondaryContainer = Color(0xFFDBEAFE),
    tertiary = Color(0xFF2DD4BF),           // Balanced Corporate Teal
    onTertiary = Color(0xFF042F2E),
    tertiaryContainer = Color(0xFF115E59),
    onTertiaryContainer = Color(0xFFCCFBF1),
    background = MidnightBackground,        // #08121E (Deep Corporate Midnight Slate)
    onBackground = NocturnalTextPrimary,
    surface = NocturnalSurface,             // #102131 (Corporate Navy Card Surface)
    onSurface = NocturnalTextPrimary,
    surfaceVariant = NocturnalSurfaceVariant, // #182F44
    onSurfaceVariant = NocturnalTextSecondary,
    outline = NocturnalBorder,
    outlineVariant = Color(0xFF1E3750),
    error = NocturnalCrimson,
    onError = Color(0xFF450A0A)
)

@Composable
fun JabimaTheme(
    darkTheme: Boolean = false,
    content: @Composable () -> Unit
) {
    val colorScheme = if (darkTheme) CorporateDarkColorScheme else CorporateLightColorScheme

    MaterialTheme(
        colorScheme = colorScheme,
        typography = JabimaTypography,
        content = content
    )
}
