package com.example.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.ArrowDownward
import androidx.compose.material.icons.filled.ArrowUpward
import androidx.compose.material.icons.filled.Check
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.CurrencyExchange
import androidx.compose.material.icons.filled.Info
import androidx.compose.material.icons.filled.Inventory2
import androidx.compose.material.icons.filled.LocalShipping
import androidx.compose.material.icons.filled.Paid
import androidx.compose.material.icons.filled.ShoppingBag
import androidx.compose.material.icons.filled.Sync
import androidx.compose.material.icons.filled.Verified
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.ExposedDropdownMenuBox
import androidx.compose.material3.ExposedDropdownMenuDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.ScrollableTabRow
import androidx.compose.material3.Surface
import androidx.compose.material3.Tab
import androidx.compose.material3.TabRowDefaults
import androidx.compose.material3.TabRowDefaults.tabIndicatorOffset
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.filled.Edit
import androidx.compose.material.icons.filled.Tune
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.window.Dialog
import com.example.domain.CasketCostingEngine
import com.example.model.CasketExchangeRecord
import com.example.model.CasketItem
import com.example.model.CasketReturnType
import com.example.model.JABIMA_BRANCHES
import com.example.ui.StaffPortalViewModel
import com.example.ui.theme.EmeraldLight
import com.example.ui.theme.EmeraldSuccess
import com.example.ui.theme.Navy800
import com.example.ui.theme.Navy900
import com.example.ui.theme.ObsidianBlack
import com.example.ui.theme.PureWhite
import com.example.ui.theme.RoyalCobaltBlue
import com.example.ui.theme.RoyalCobaltIce
import com.example.ui.theme.RoyalCobaltLight
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun CasketSelectionScreen(
    viewModel: StaffPortalViewModel,
    onNavigateToCheckout: (String) -> Unit = {}
) {
    val caskets by viewModel.caskets.collectAsState()
    val exchanges by viewModel.casketExchanges.collectAsState()
    val currentAccount by viewModel.currentAccount.collectAsState()
    val isAdmin = viewModel.isAuthorizedForAdminChanges()

    var selectedSection by remember { mutableStateOf(0) } // 0: Available Caskets, 1: Other Design, 2: Return Inwards / Outwards Ledger
    var showExchangeDialog by remember { mutableStateOf(false) }
    var selectedCasketForExchange by remember { mutableStateOf<CasketItem?>(null) }
    var editingCasketForAdmin by remember { mutableStateOf<CasketItem?>(null) }
    var currencyMode by remember { mutableStateOf("KES") } // "KES" or "USD"

    // Custom Other Design state
    var customName by remember { mutableStateOf("") }
    var customWood by remember { mutableStateOf("Solid African Mahogany") }
    var customTier by remember { mutableStateOf("Bespoke Design") }
    var customFinish by remember { mutableStateOf("Mirror Lacquer") }
    var customLining by remember { mutableStateOf("Quilted Ivory Velvet") }
    var customPriceText by remember { mutableStateOf("140000") }
    var customStockText by remember { mutableStateOf("1") }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(PureWhite)
            .padding(16.dp)
            .testTag("casket_selection_screen")
    ) {
        // HEADER TITLE & CURRENCY TOGGLE
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Column {
                Text(
                    text = "Casket Selection & Exchange",
                    fontSize = 20.sp,
                    fontWeight = FontWeight.Bold,
                    color = ObsidianBlack
                )
                Text(
                    text = "Handcrafted workshop timber, velvet lining & client exchange portal",
                    fontSize = 12.sp,
                    color = Color(0xFF64748B)
                )
            }

            // KES / USD TOGGLE BUTTON
            Surface(
                shape = RoundedCornerShape(20.dp),
                color = RoyalCobaltIce,
                border = androidx.compose.foundation.BorderStroke(1.dp, Color(0xFFBFDBFE))
            ) {
                Row(modifier = Modifier.padding(4.dp)) {
                    Surface(
                        shape = RoundedCornerShape(16.dp),
                        color = if (currencyMode == "KES") RoyalCobaltBlue else Color.Transparent,
                        modifier = Modifier
                            .clickable { currencyMode = "KES" }
                            .padding(horizontal = 8.dp, vertical = 4.dp)
                    ) {
                        Text(
                            text = "KES",
                            fontSize = 11.sp,
                            fontWeight = FontWeight.Bold,
                            color = if (currencyMode == "KES") Color.White else RoyalCobaltBlue
                        )
                    }
                    Surface(
                        shape = RoundedCornerShape(16.dp),
                        color = if (currencyMode == "USD") RoyalCobaltBlue else Color.Transparent,
                        modifier = Modifier
                            .clickable { currencyMode = "USD" }
                            .padding(horizontal = 8.dp, vertical = 4.dp)
                    ) {
                        Text(
                            text = "USD ($)",
                            fontSize = 11.sp,
                            fontWeight = FontWeight.Bold,
                            color = if (currencyMode == "USD") Color.White else RoyalCobaltBlue
                        )
                    }
                }
            }
        }

        Spacer(modifier = Modifier.height(10.dp))

        // SALES COMMISSION RULE BANNER
        Surface(
            color = RoyalCobaltIce,
            shape = RoundedCornerShape(8.dp),
            border = androidx.compose.foundation.BorderStroke(1.dp, Color(0xFF93C5FD)),
            modifier = Modifier.fillMaxWidth()
        ) {
            Row(
                modifier = Modifier.padding(10.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                Icon(
                    imageVector = Icons.Default.Paid,
                    contentDescription = null,
                    tint = RoyalCobaltBlue,
                    modifier = Modifier.size(20.dp)
                )
                Spacer(modifier = Modifier.width(8.dp))
                Column {
                    Text(
                        text = "Sales Commission Policy: 5% on Caskets Sold",
                        fontSize = 12.sp,
                        fontWeight = FontWeight.Bold,
                        color = RoyalCobaltBlue
                    )
                    Text(
                        text = "Business Development (Sale) wallets earn exclusively via 5% commission on caskets. All other auxiliary services do not earn commission.",
                        fontSize = 11.sp,
                        color = Color(0xFF1E3A8A)
                    )
                }
            }
        }

        Spacer(modifier = Modifier.height(12.dp))

        // SUB-TABS: AVAILABLE CASKETS vs RETURN INWARDS / OUTWARDS
        ScrollableTabRow(
            selectedTabIndex = selectedSection,
            containerColor = Color.White,
            contentColor = RoyalCobaltBlue,
            edgePadding = 0.dp,
            indicator = { tabPositions ->
                if (selectedSection < tabPositions.size) {
                    TabRowDefaults.SecondaryIndicator(
                        modifier = Modifier.tabIndicatorOffset(tabPositions[selectedSection]),
                        color = RoyalCobaltBlue,
                        height = 3.dp
                    )
                }
            },
            modifier = Modifier
                .fillMaxWidth()
                .clip(RoundedCornerShape(8.dp))
                .border(1.dp, Color(0xFFE2E8F0), RoundedCornerShape(8.dp))
        ) {
            Tab(
                selected = selectedSection == 0,
                onClick = { selectedSection = 0 },
                text = {
                    Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                        Icon(Icons.Default.Inventory2, contentDescription = null, modifier = Modifier.size(15.dp))
                        Text(
                            text = "Available Caskets (${caskets.size})",
                            fontSize = 12.sp,
                            fontWeight = if (selectedSection == 0) FontWeight.Bold else FontWeight.Medium,
                            maxLines = 1,
                            softWrap = false,
                            overflow = TextOverflow.Ellipsis
                        )
                    }
                },
                modifier = Modifier.testTag("tab_available_caskets")
            )

            Tab(
                selected = selectedSection == 1,
                onClick = { selectedSection = 1 },
                text = {
                    Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                        Icon(Icons.Default.Tune, contentDescription = null, modifier = Modifier.size(15.dp))
                        Text(
                            text = "Other Design",
                            fontSize = 12.sp,
                            fontWeight = if (selectedSection == 1) FontWeight.Bold else FontWeight.Medium,
                            maxLines = 1,
                            softWrap = false,
                            overflow = TextOverflow.Ellipsis
                        )
                    }
                },
                modifier = Modifier.testTag("tab_casket_other_design")
            )

            Tab(
                selected = selectedSection == 2,
                onClick = { selectedSection = 2 },
                text = {
                    Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                        Icon(Icons.Default.Sync, contentDescription = null, modifier = Modifier.size(15.dp))
                        Text(
                            text = "Return Inwards / Outwards (${exchanges.size})",
                            fontSize = 12.sp,
                            fontWeight = if (selectedSection == 2) FontWeight.Bold else FontWeight.Medium,
                            maxLines = 1,
                            softWrap = false,
                            overflow = TextOverflow.Ellipsis
                        )
                    }
                },
                modifier = Modifier.testTag("tab_casket_exchanges")
            )
        }

        Spacer(modifier = Modifier.height(12.dp))

        // TAB 0: AVAILABLE CASKETS
        if (selectedSection == 0) {
            LazyColumn(
                modifier = Modifier.weight(1f),
                verticalArrangement = Arrangement.spacedBy(12.dp)
            ) {
                items(caskets) { casket ->
                    val commissionAmount = casket.priceKes * 0.05
                    Card(
                        shape = RoundedCornerShape(12.dp),
                        colors = CardDefaults.cardColors(containerColor = PureWhite),
                        elevation = CardDefaults.cardElevation(2.dp),
                        modifier = Modifier
                            .fillMaxWidth()
                            .testTag("casket_card_${casket.id}")
                    ) {
                        Column(modifier = Modifier.padding(14.dp)) {
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.Top
                            ) {
                                Column(modifier = Modifier.weight(1f)) {
                                    Surface(
                                        color = RoyalCobaltIce,
                                        shape = RoundedCornerShape(4.dp)
                                    ) {
                                        Text(
                                            text = casket.tier.uppercase(),
                                            fontSize = 9.sp,
                                            fontWeight = FontWeight.Bold,
                                            color = RoyalCobaltBlue,
                                            modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp)
                                        )
                                    }
                                    Spacer(modifier = Modifier.height(4.dp))
                                    Text(
                                        text = casket.name,
                                        fontSize = 16.sp,
                                        fontWeight = FontWeight.Bold,
                                        color = ObsidianBlack
                                    )
                                    Text(
                                        text = "Timber: ${casket.woodType} • Finish: ${casket.finish}",
                                        fontSize = 11.sp,
                                        color = Color(0xFF64748B)
                                    )
                                    Text(
                                        text = "Lining: ${casket.interiorLining}",
                                        fontSize = 11.sp,
                                        color = Color(0xFF475569)
                                    )
                                }

                                Column(horizontalAlignment = Alignment.End) {
                                    val priceDisplay = if (currencyMode == "KES") {
                                        "KES ${String.format(Locale.getDefault(), "%,.0f", casket.priceKes)}"
                                    } else {
                                        "$ ${String.format(Locale.getDefault(), "%,.0f", casket.priceUsd)}"
                                    }
                                    Text(
                                        text = priceDisplay,
                                        fontSize = 16.sp,
                                        fontWeight = FontWeight.Bold,
                                        color = RoyalCobaltBlue
                                    )
                                    Text(
                                        text = "In stock: ${casket.stockCount} units",
                                        fontSize = 10.sp,
                                        color = Color(0xFF059669),
                                        fontWeight = FontWeight.SemiBold
                                    )
                                    Text(
                                        text = "Sales 5% comm: KES ${String.format(Locale.getDefault(), "%,.0f", commissionAmount)}",
                                        fontSize = 10.sp,
                                        color = RoyalCobaltLight,
                                        fontWeight = FontWeight.Medium
                                    )
                                    val bomGuide = CasketCostingEngine.findModelForCasketName(casket.name)
                                    if (bomGuide != null) {
                                        Text(
                                            text = "Est. Prod: KES ${String.format(Locale.getDefault(), "%,.0f", bomGuide.totalProductionCostKes)}",
                                            fontSize = 9.sp,
                                            color = Color(0xFFB45309),
                                            fontWeight = FontWeight.Bold
                                        )
                                    }
                                }
                            }

                            Spacer(modifier = Modifier.height(8.dp))

                            // Features Pills
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.spacedBy(6.dp)
                            ) {
                                casket.features.take(3).forEach { feat ->
                                    Surface(
                                        color = Color(0xFFF1F5F9),
                                        shape = RoundedCornerShape(12.dp)
                                    ) {
                                        Text(
                                            text = "• $feat",
                                            fontSize = 10.sp,
                                            color = Color(0xFF334155),
                                            modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp)
                                        )
                                    }
                                }
                            }

                            Spacer(modifier = Modifier.height(12.dp))

                            // Action Buttons: Upgrade / Downgrade or Order
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.spacedBy(8.dp)
                            ) {
                                OutlinedButton(
                                    onClick = {
                                        selectedCasketForExchange = casket
                                        showExchangeDialog = true
                                    },
                                    modifier = Modifier
                                        .weight(1f)
                                        .height(38.dp)
                                        .testTag("exchange_casket_button_${casket.id}"),
                                    shape = RoundedCornerShape(6.dp)
                                ) {
                                    Icon(Icons.Default.Sync, contentDescription = null, modifier = Modifier.size(14.dp))
                                    Spacer(modifier = Modifier.width(4.dp))
                                    Text(text = "Exchange", fontSize = 11.sp, fontWeight = FontWeight.SemiBold, maxLines = 1, softWrap = false)
                                }

                                if (isAdmin) {
                                    OutlinedButton(
                                        onClick = { editingCasketForAdmin = casket },
                                        modifier = Modifier
                                            .weight(0.95f)
                                            .height(38.dp)
                                            .testTag("edit_casket_type_price_${casket.id}"),
                                        shape = RoundedCornerShape(6.dp)
                                    ) {
                                        Icon(Icons.Default.Edit, contentDescription = null, modifier = Modifier.size(14.dp))
                                        Spacer(modifier = Modifier.width(3.dp))
                                        Text(text = "Edit Price", fontSize = 11.sp, fontWeight = FontWeight.SemiBold, maxLines = 1, softWrap = false)
                                    }
                                }

                                Button(
                                    onClick = { onNavigateToCheckout(casket.name) },
                                    modifier = Modifier
                                        .weight(1f)
                                        .height(38.dp)
                                        .testTag("select_casket_button_${casket.id}"),
                                    colors = ButtonDefaults.buttonColors(containerColor = RoyalCobaltBlue),
                                    shape = RoundedCornerShape(6.dp)
                                ) {
                                    Icon(Icons.Default.ShoppingBag, contentDescription = null, modifier = Modifier.size(14.dp))
                                    Spacer(modifier = Modifier.width(4.dp))
                                    Text(text = "Order", fontSize = 11.sp, fontWeight = FontWeight.SemiBold, maxLines = 1, softWrap = false)
                                }
                            }
                        }
                    }
                }
            }
        } else if (selectedSection == 1) {
            // TAB 1: OTHER DESIGN (CUSTOM COFFIN WITH EDITABLE PRICE TAG)
            val parsedPrice = customPriceText.toDoubleOrNull()?.coerceAtLeast(0.0) ?: 0.0
            val priceUsd = parsedPrice / 130.0
            val salesComm = parsedPrice * 0.05

            Column(
                modifier = Modifier
                    .weight(1f)
                    .verticalScroll(rememberScrollState()),
                verticalArrangement = Arrangement.spacedBy(12.dp)
            ) {
                Card(
                    shape = RoundedCornerShape(12.dp),
                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                    elevation = CardDefaults.cardElevation(2.dp),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Column(modifier = Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                        Text(
                            text = "Bespoke \"Other Design\" Casket Configuration",
                            fontSize = 15.sp,
                            fontWeight = FontWeight.Bold,
                            color = MaterialTheme.colorScheme.onSurface
                        )
                        Text(
                            text = "Set custom casket type details and an editable price tag for direct ordering or catalog sync.",
                            fontSize = 11.sp,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )

                        OutlinedTextField(
                            value = customName,
                            onValueChange = { customName = it },
                            label = { Text("Custom Casket / Design Name") },
                            placeholder = { Text("e.g. Executive Dome Walnut Custom") },
                            singleLine = true,
                            modifier = Modifier.fillMaxWidth().testTag("casket_other_design_name")
                        )

                        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                            OutlinedTextField(
                                value = customWood,
                                onValueChange = { customWood = it },
                                label = { Text("Wood / Material") },
                                singleLine = true,
                                modifier = Modifier.weight(1f)
                            )
                            OutlinedTextField(
                                value = customTier,
                                onValueChange = { customTier = it },
                                label = { Text("Design Tier") },
                                singleLine = true,
                                modifier = Modifier.weight(1f)
                            )
                        }

                        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                            OutlinedTextField(
                                value = customFinish,
                                onValueChange = { customFinish = it },
                                label = { Text("Polish / Finish") },
                                singleLine = true,
                                modifier = Modifier.weight(1f)
                            )
                            OutlinedTextField(
                                value = customLining,
                                onValueChange = { customLining = it },
                                label = { Text("Interior Lining") },
                                singleLine = true,
                                modifier = Modifier.weight(1f)
                            )
                        }

                        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                            OutlinedTextField(
                                value = customPriceText,
                                onValueChange = { customPriceText = it },
                                label = { Text("Set Price Tag (KES)") },
                                keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                                singleLine = true,
                                modifier = Modifier.weight(1.3f).testTag("casket_other_design_price")
                            )
                            OutlinedTextField(
                                value = customStockText,
                                onValueChange = { customStockText = it },
                                label = { Text("Stock Units") },
                                keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                                singleLine = true,
                                modifier = Modifier.weight(0.7f)
                            )
                        }

                        Surface(
                            color = RoyalCobaltIce,
                            shape = RoundedCornerShape(8.dp),
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            Row(
                                modifier = Modifier.padding(10.dp),
                                horizontalArrangement = Arrangement.SpaceBetween
                            ) {
                                Text(
                                    text = "USD Equiv: $${String.format(Locale.getDefault(), "%,.0f", priceUsd)}",
                                    fontSize = 11.sp,
                                    fontWeight = FontWeight.Bold,
                                    color = RoyalCobaltBlue
                                )
                                Text(
                                    text = "5% Sales Comm: KES ${String.format(Locale.getDefault(), "%,.0f", salesComm)}",
                                    fontSize = 11.sp,
                                    fontWeight = FontWeight.Bold,
                                    color = EmeraldSuccess
                                )
                            }
                        }

                        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                            OutlinedButton(
                                onClick = {
                                    val id = "CSK-CUST-${(100..999).random()}"
                                    val newItem = CasketItem(
                                        id = id,
                                        name = customName.trim().ifBlank { "Custom Casket #$id" },
                                        woodType = customWood.trim().ifBlank { "Hardwood" },
                                        tier = customTier.trim().ifBlank { "Bespoke Design" },
                                        priceKes = parsedPrice,
                                        priceUsd = priceUsd,
                                        finish = customFinish.trim().ifBlank { "Mirror Lacquer" },
                                        interiorLining = customLining.trim().ifBlank { "Velvet Crepe" },
                                        features = listOf("Custom Build", customWood, customFinish),
                                        inStock = true,
                                        stockCount = customStockText.toIntOrNull() ?: 1
                                    )
                                    viewModel.addOrReplaceCasketItem(newItem)
                                    selectedSection = 0
                                },
                                shape = RoundedCornerShape(8.dp),
                                modifier = Modifier.weight(1f).height(44.dp).testTag("btn_save_custom_casket_catalog")
                            ) {
                                Text("Save to Catalog", fontSize = 11.sp, fontWeight = FontWeight.Bold, maxLines = 1, softWrap = false)
                            }

                            Button(
                                onClick = {
                                    val id = "CSK-CUST-${(100..999).random()}"
                                    val name = customName.trim().ifBlank { "Custom Casket #$id" }
                                    val newItem = CasketItem(
                                        id = id,
                                        name = name,
                                        woodType = customWood.trim().ifBlank { "Hardwood" },
                                        tier = customTier.trim().ifBlank { "Bespoke Design" },
                                        priceKes = parsedPrice,
                                        priceUsd = priceUsd,
                                        finish = customFinish.trim().ifBlank { "Mirror Lacquer" },
                                        interiorLining = customLining.trim().ifBlank { "Velvet Crepe" },
                                        features = listOf("Custom Build", customWood, customFinish),
                                        inStock = true,
                                        stockCount = customStockText.toIntOrNull() ?: 1
                                    )
                                    viewModel.addOrReplaceCasketItem(newItem)
                                    onNavigateToCheckout(name)
                                },
                                colors = ButtonDefaults.buttonColors(containerColor = RoyalCobaltBlue),
                                shape = RoundedCornerShape(8.dp),
                                modifier = Modifier.weight(1.2f).height(44.dp).testTag("btn_order_custom_casket")
                            ) {
                                Text("Order Custom Casket", fontSize = 11.sp, fontWeight = FontWeight.Bold, maxLines = 1, softWrap = false)
                            }
                        }
                    }
                }
            }
        } else {
            // TAB 2: RETURN INWARDS / OUTWARDS LEDGER
            Column(modifier = Modifier.weight(1f)) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Column {
                        Text(
                            text = "Casket Exchange Ledger",
                            fontSize = 14.sp,
                            fontWeight = FontWeight.Bold,
                            color = ObsidianBlack
                        )
                        Text(
                            text = "Exchanges available exclusively for caskets (Return Inward & Return Outward)",
                            fontSize = 11.sp,
                            color = Color(0xFF64748B)
                        )
                    }

                    Button(
                        onClick = {
                            selectedCasketForExchange = caskets.firstOrNull()
                            showExchangeDialog = true
                        },
                        colors = ButtonDefaults.buttonColors(containerColor = RoyalCobaltBlue),
                        shape = RoundedCornerShape(6.dp),
                        modifier = Modifier.testTag("new_casket_exchange_button")
                    ) {
                        Icon(Icons.Default.Add, contentDescription = null, modifier = Modifier.size(14.dp))
                        Spacer(modifier = Modifier.width(4.dp))
                        Text("Log Exchange", fontSize = 11.sp)
                    }
                }

                Spacer(modifier = Modifier.height(10.dp))

                LazyColumn(
                    modifier = Modifier.fillMaxSize(),
                    verticalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    items(exchanges) { item ->
                        Card(
                            shape = RoundedCornerShape(8.dp),
                            colors = CardDefaults.cardColors(containerColor = PureWhite),
                            border = androidx.compose.foundation.BorderStroke(1.dp, Color(0xFFE2E8F0)),
                            modifier = Modifier
                                .fillMaxWidth()
                                .testTag("casket_exchange_card_${item.id}")
                        ) {
                            Column(modifier = Modifier.padding(12.dp)) {
                                Row(
                                    modifier = Modifier.fillMaxWidth(),
                                    horizontalArrangement = Arrangement.SpaceBetween,
                                    verticalAlignment = Alignment.CenterVertically
                                ) {
                                    Row(verticalAlignment = Alignment.CenterVertically) {
                                        val isOutward = item.returnType == CasketReturnType.RETURN_OUTWARD
                                        Surface(
                                            color = if (isOutward) Color(0xFFEFF6FF) else Color(0xFFFEF3C7),
                                            shape = RoundedCornerShape(4.dp)
                                        ) {
                                            Row(
                                                modifier = Modifier.padding(horizontal = 6.dp, vertical = 3.dp),
                                                verticalAlignment = Alignment.CenterVertically
                                            ) {
                                                Icon(
                                                    imageVector = if (isOutward) Icons.Default.ArrowUpward else Icons.Default.ArrowDownward,
                                                    contentDescription = null,
                                                    tint = if (isOutward) RoyalCobaltBlue else Color(0xFFD97706),
                                                    modifier = Modifier.size(12.dp)
                                                )
                                                Spacer(modifier = Modifier.width(3.dp))
                                                Text(
                                                    text = if (isOutward) "RETURN OUTWARD (UPGRADE)" else "RETURN INWARD (DOWNGRADE)",
                                                    fontSize = 9.sp,
                                                    fontWeight = FontWeight.Bold,
                                                    color = if (isOutward) RoyalCobaltBlue else Color(0xFFD97706)
                                                )
                                            }
                                        }
                                        Spacer(modifier = Modifier.width(8.dp))
                                        Text(text = item.id, fontSize = 11.sp, fontWeight = FontWeight.Bold, color = Color(0xFF64748B))
                                    }

                                    Surface(
                                        color = EmeraldLight,
                                        shape = RoundedCornerShape(12.dp)
                                    ) {
                                        Text(
                                            text = item.status,
                                            fontSize = 10.sp,
                                            fontWeight = FontWeight.SemiBold,
                                            color = EmeraldSuccess,
                                            modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp)
                                        )
                                    }
                                }

                                Spacer(modifier = Modifier.height(6.dp))

                                Text(
                                    text = item.clientFamily,
                                    fontSize = 14.sp,
                                    fontWeight = FontWeight.Bold,
                                    color = ObsidianBlack
                                )
                                Text(
                                    text = "Case Ref: ${item.caseReference} • Branch: ${item.branch}",
                                    fontSize = 11.sp,
                                    color = Color(0xFF475569)
                                )

                                Spacer(modifier = Modifier.height(6.dp))

                                Surface(
                                    color = Color(0xFFF8FAFC),
                                    shape = RoundedCornerShape(6.dp),
                                    modifier = Modifier.fillMaxWidth()
                                ) {
                                    Row(
                                        modifier = Modifier.padding(8.dp),
                                        horizontalArrangement = Arrangement.SpaceBetween,
                                        verticalAlignment = Alignment.CenterVertically
                                    ) {
                                        Column {
                                            Text(text = "Previous Casket:", fontSize = 10.sp, color = Color(0xFF64748B))
                                            Text(text = item.originalCasketName, fontSize = 11.sp, fontWeight = FontWeight.SemiBold, color = ObsidianBlack)
                                            Text(text = "KES ${String.format(Locale.getDefault(), "%,.0f", item.originalCasketPrice)}", fontSize = 10.sp, color = Color(0xFF64748B))
                                        }

                                        Icon(Icons.Default.Sync, contentDescription = null, tint = RoyalCobaltBlue, modifier = Modifier.size(16.dp))

                                        Column(horizontalAlignment = Alignment.End) {
                                            Text(text = "New Replacement:", fontSize = 10.sp, color = Color(0xFF64748B))
                                            Text(text = item.newCasketName, fontSize = 11.sp, fontWeight = FontWeight.SemiBold, color = ObsidianBlack)
                                            Text(text = "KES ${String.format(Locale.getDefault(), "%,.0f", item.newCasketPrice)}", fontSize = 10.sp, color = Color(0xFF64748B))
                                        }
                                    }
                                }

                                Spacer(modifier = Modifier.height(6.dp))

                                Row(
                                    modifier = Modifier.fillMaxWidth(),
                                    horizontalArrangement = Arrangement.SpaceBetween
                                ) {
                                    Text(
                                        text = if (item.priceDifferenceKes >= 0) "Top-Up Paid by Client: KES ${String.format(Locale.getDefault(), "%,.0f", item.priceDifferenceKes)}"
                                        else "Credit Refund Due to Client: KES ${String.format(Locale.getDefault(), "%,.0f", -item.priceDifferenceKes)}",
                                        fontSize = 11.sp,
                                        fontWeight = FontWeight.Bold,
                                        color = if (item.priceDifferenceKes >= 0) RoyalCobaltBlue else Color(0xFFD97706)
                                    )

                                    Text(
                                        text = "Processed by: ${item.processedByStaffName}",
                                        fontSize = 10.sp,
                                        color = Color(0xFF64748B)
                                    )
                                }

                                Text(
                                    text = "Reason: ${item.reason}",
                                    fontSize = 10.sp,
                                    color = Color(0xFF334155),
                                    modifier = Modifier.padding(top = 4.dp)
                                )
                                Text(
                                    text = "Condition: ${item.conditionAssessment}",
                                    fontSize = 10.sp,
                                    color = Color(0xFF059669),
                                    fontWeight = FontWeight.Medium
                                )
                            }
                        }
                    }
                }
            }
        }
    }

    // ==========================================
    // DIALOG: LOG CASKET UPGRADE / DOWNGRADE / EXCHANGE
    // ==========================================
    if (showExchangeDialog) {
        var clientFamilyName by remember { mutableStateOf("") }
        var caseRef by remember { mutableStateOf("JFD-2026-${(100..999).random()}") }
        var originCasket by remember { mutableStateOf(selectedCasketForExchange ?: caskets.first()) }
        var targetCasket by remember { mutableStateOf(caskets.firstOrNull { it.id != originCasket.id } ?: originCasket) }
        var selectedBranch by remember { mutableStateOf(currentAccount?.branch ?: JABIMA_BRANCHES.first()) }
        var exchangeReason by remember { mutableStateOf("Client requested executive upgrade upon family meeting") }
        var conditionNote by remember { mutableStateOf("Inspected by workshop supervisor: Sealed lining undamaged, mirror finish perfect") }

        val priceDiff = targetCasket.priceKes - originCasket.priceKes
        val isUpgrade = priceDiff >= 0

        Dialog(onDismissRequest = { showExchangeDialog = false }) {
            Surface(
                shape = RoundedCornerShape(12.dp),
                color = PureWhite,
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(8.dp)
                    .testTag("casket_exchange_dialog")
            ) {
                Column(
                    modifier = Modifier.padding(16.dp)
                ) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text(
                            text = if (isUpgrade) "Upgrade Casket Selection" else "Downgrade Casket Selection",
                            fontSize = 16.sp,
                            fontWeight = FontWeight.Bold,
                            color = ObsidianBlack
                        )
                        IconButton(onClick = { showExchangeDialog = false }) {
                            Icon(Icons.Default.Close, contentDescription = "Close", tint = Color(0xFF64748B))
                        }
                    }

                    Text(
                        text = "Exchanges are strictly permitted for caskets only. System recalculates price variance automatically.",
                        fontSize = 11.sp,
                        color = Color(0xFF64748B)
                    )

                    Spacer(modifier = Modifier.height(10.dp))

                    OutlinedTextField(
                        value = clientFamilyName,
                        onValueChange = { clientFamilyName = it },
                        label = { Text("Client / Family Name", fontSize = 12.sp) },
                        placeholder = { Text("e.g. Family of Elder Odhiambo", fontSize = 12.sp) },
                        modifier = Modifier
                            .fillMaxWidth()
                            .testTag("exchange_client_name_input"),
                        singleLine = true
                    )

                    Spacer(modifier = Modifier.height(8.dp))

                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        OutlinedTextField(
                            value = caseRef,
                            onValueChange = { caseRef = it },
                            label = { Text("Case Reference #", fontSize = 12.sp) },
                            modifier = Modifier.weight(1f),
                            singleLine = true
                        )

                        // Branch Selector
                        var branchExpanded by remember { mutableStateOf(false) }
                        ExposedDropdownMenuBox(
                            expanded = branchExpanded,
                            onExpandedChange = { branchExpanded = it },
                            modifier = Modifier.weight(1f)
                        ) {
                            OutlinedTextField(
                                value = selectedBranch,
                                onValueChange = {},
                                readOnly = true,
                                label = { Text("Branch", fontSize = 12.sp) },
                                trailingIcon = { ExposedDropdownMenuDefaults.TrailingIcon(expanded = branchExpanded) },
                                modifier = Modifier.menuAnchor()
                            )
                            ExposedDropdownMenu(
                                expanded = branchExpanded,
                                onDismissRequest = { branchExpanded = false }
                            ) {
                                JABIMA_BRANCHES.forEach { b ->
                                    DropdownMenuItem(
                                        text = { Text(b, fontSize = 12.sp) },
                                        onClick = {
                                            selectedBranch = b
                                            branchExpanded = false
                                        }
                                    )
                                }
                            }
                        }
                    }

                    Spacer(modifier = Modifier.height(10.dp))

                    // Origin Casket Selection
                    var originExpanded by remember { mutableStateOf(false) }
                    ExposedDropdownMenuBox(
                        expanded = originExpanded,
                        onExpandedChange = { originExpanded = it },
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        OutlinedTextField(
                            value = "${originCasket.name} (KES ${String.format(Locale.getDefault(), "%,.0f", originCasket.priceKes)})",
                            onValueChange = {},
                            readOnly = true,
                            label = { Text("Current Casket to Return", fontSize = 12.sp) },
                            trailingIcon = { ExposedDropdownMenuDefaults.TrailingIcon(expanded = originExpanded) },
                            modifier = Modifier
                                .fillMaxWidth()
                                .menuAnchor()
                        )
                        ExposedDropdownMenu(
                            expanded = originExpanded,
                            onDismissRequest = { originExpanded = false }
                        ) {
                            caskets.forEach { c ->
                                DropdownMenuItem(
                                    text = { Text("${c.name} - KES ${String.format(Locale.getDefault(), "%,.0f", c.priceKes)}", fontSize = 12.sp) },
                                    onClick = {
                                        originCasket = c
                                        originExpanded = false
                                    }
                                )
                            }
                        }
                    }

                    Spacer(modifier = Modifier.height(8.dp))

                    // Target Casket Selection
                    var targetExpanded by remember { mutableStateOf(false) }
                    ExposedDropdownMenuBox(
                        expanded = targetExpanded,
                        onExpandedChange = { targetExpanded = it },
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        OutlinedTextField(
                            value = "${targetCasket.name} (KES ${String.format(Locale.getDefault(), "%,.0f", targetCasket.priceKes)})",
                            onValueChange = {},
                            readOnly = true,
                            label = { Text("New Casket Requested", fontSize = 12.sp) },
                            trailingIcon = { ExposedDropdownMenuDefaults.TrailingIcon(expanded = targetExpanded) },
                            modifier = Modifier
                                .fillMaxWidth()
                                .menuAnchor()
                        )
                        ExposedDropdownMenu(
                            expanded = targetExpanded,
                            onDismissRequest = { targetExpanded = false }
                        ) {
                            caskets.forEach { c ->
                                DropdownMenuItem(
                                    text = { Text("${c.name} - KES ${String.format(Locale.getDefault(), "%,.0f", c.priceKes)}", fontSize = 12.sp) },
                                    onClick = {
                                        targetCasket = c
                                        targetExpanded = false
                                    }
                                )
                            }
                        }
                    }

                    Spacer(modifier = Modifier.height(8.dp))

                    // PRICE VARIANCE CARD
                    Surface(
                        color = if (isUpgrade) RoyalCobaltIce else Color(0xFFFEF3C7),
                        shape = RoundedCornerShape(8.dp),
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Column(modifier = Modifier.padding(10.dp)) {
                            Text(
                                text = if (isUpgrade) "UPGRADE SUMMARY" else "DOWNGRADE SUMMARY",
                                fontSize = 10.sp,
                                fontWeight = FontWeight.Bold,
                                color = if (isUpgrade) RoyalCobaltBlue else Color(0xFFD97706)
                            )
                            Text(
                                text = if (isUpgrade) "Client Top-Up Payment Due: KES ${String.format(Locale.getDefault(), "%,.0f", priceDiff)}"
                                else "Client Refund Credit Note: KES ${String.format(Locale.getDefault(), "%,.0f", -priceDiff)}",
                                fontSize = 13.sp,
                                fontWeight = FontWeight.Bold,
                                color = if (isUpgrade) RoyalCobaltBlue else Color(0xFFD97706)
                            )
                            Text(
                                text = if (isUpgrade) "Type: Return Outward (New casket dispatched)"
                                else "Type: Return Inward (Casket returned to stock)",
                                fontSize = 10.sp,
                                color = Color(0xFF475569)
                            )
                        }
                    }

                    Spacer(modifier = Modifier.height(8.dp))

                    OutlinedTextField(
                        value = exchangeReason,
                        onValueChange = { exchangeReason = it },
                        label = { Text("Reason for Exchange", fontSize = 12.sp) },
                        modifier = Modifier.fillMaxWidth(),
                        singleLine = true
                    )

                    Spacer(modifier = Modifier.height(14.dp))

                    Button(
                        onClick = {
                            val client = if (clientFamilyName.isNotBlank()) clientFamilyName.trim() else "Family of Case $caseRef"
                            val record = CasketExchangeRecord(
                                id = "EXC-${(100..999).random()}",
                                clientFamily = client,
                                caseReference = caseRef.trim(),
                                originalCasketName = originCasket.name,
                                originalCasketPrice = originCasket.priceKes,
                                newCasketName = targetCasket.name,
                                newCasketPrice = targetCasket.priceKes,
                                returnType = if (isUpgrade) CasketReturnType.RETURN_OUTWARD else CasketReturnType.RETURN_INWARD,
                                priceDifferenceKes = priceDiff,
                                reason = exchangeReason,
                                conditionAssessment = conditionNote,
                                branch = selectedBranch,
                                processedByStaffName = currentAccount?.fullName ?: "Staff Counselor",
                                date = SimpleDateFormat("dd MMM yyyy", Locale.getDefault()).format(Date()),
                                status = if (isUpgrade) "Approved & Dispatched" else "Credit Note Issued"
                            )
                            viewModel.recordCasketExchange(record)
                            showExchangeDialog = false
                            selectedSection = 2
                        },
                        colors = ButtonDefaults.buttonColors(containerColor = RoyalCobaltBlue),
                        shape = RoundedCornerShape(6.dp),
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(44.dp)
                            .testTag("confirm_casket_exchange_button")
                    ) {
                        Icon(Icons.Default.Check, contentDescription = null, modifier = Modifier.size(16.dp))
                        Spacer(modifier = Modifier.width(6.dp))
                        Text("Confirm & Record Exchange", fontWeight = FontWeight.Bold)
                    }
                }
            }
        }
    }

    // ADMIN DIALOG: EDIT CASKET TYPE & PRICE
    editingCasketForAdmin?.let { csk ->
        var editName by remember { mutableStateOf(csk.name) }
        var editWood by remember { mutableStateOf(csk.woodType) }
        var editTier by remember { mutableStateOf(csk.tier) }
        var editFinish by remember { mutableStateOf(csk.finish) }
        var editLining by remember { mutableStateOf(csk.interiorLining) }
        var editPrice by remember { mutableStateOf(csk.priceKes.toLong().toString()) }
        var editStock by remember { mutableStateOf(csk.stockCount.toString()) }

        Dialog(onDismissRequest = { editingCasketForAdmin = null }) {
            Surface(
                shape = RoundedCornerShape(14.dp),
                color = MaterialTheme.colorScheme.surface,
                modifier = Modifier.fillMaxWidth().padding(8.dp)
            ) {
                Column(modifier = Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    Text("Admin: Edit Casket Type & Price", fontSize = 16.sp, fontWeight = FontWeight.Bold)
                    OutlinedTextField(value = editName, onValueChange = { editName = it }, label = { Text("Casket Name") }, singleLine = true, modifier = Modifier.fillMaxWidth())
                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        OutlinedTextField(value = editWood, onValueChange = { editWood = it }, label = { Text("Wood") }, singleLine = true, modifier = Modifier.weight(1f))
                        OutlinedTextField(value = editTier, onValueChange = { editTier = it }, label = { Text("Tier") }, singleLine = true, modifier = Modifier.weight(1f))
                    }
                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        OutlinedTextField(value = editFinish, onValueChange = { editFinish = it }, label = { Text("Finish") }, singleLine = true, modifier = Modifier.weight(1f))
                        OutlinedTextField(value = editLining, onValueChange = { editLining = it }, label = { Text("Lining") }, singleLine = true, modifier = Modifier.weight(1f))
                    }
                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        OutlinedTextField(
                            value = editPrice,
                            onValueChange = { editPrice = it },
                            label = { Text("Price (KES)") },
                            keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                            singleLine = true,
                            modifier = Modifier.weight(1.2f)
                        )
                        OutlinedTextField(
                            value = editStock,
                            onValueChange = { editStock = it },
                            label = { Text("Stock") },
                            keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                            singleLine = true,
                            modifier = Modifier.weight(0.8f)
                        )
                    }
                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp), modifier = Modifier.fillMaxWidth()) {
                        OutlinedButton(onClick = { editingCasketForAdmin = null }, modifier = Modifier.weight(1f)) { Text("Cancel") }
                        Button(
                            onClick = {
                                val price = editPrice.toDoubleOrNull() ?: csk.priceKes
                                val stock = editStock.toIntOrNull() ?: csk.stockCount
                                viewModel.addOrReplaceCasketItem(
                                    csk.copy(
                                        name = editName.trim().ifBlank { csk.name },
                                        woodType = editWood.trim().ifBlank { csk.woodType },
                                        tier = editTier.trim().ifBlank { csk.tier },
                                        finish = editFinish.trim().ifBlank { csk.finish },
                                        interiorLining = editLining.trim().ifBlank { csk.interiorLining },
                                        priceKes = price,
                                        priceUsd = price / 130.0,
                                        stockCount = stock,
                                        inStock = stock > 0
                                    )
                                )
                                viewModel.updateCasketPrice(csk.id, price, price / 130.0, stock, stock > 0, "Casket catalog admin revision")
                                editingCasketForAdmin = null
                            },
                            colors = ButtonDefaults.buttonColors(containerColor = RoyalCobaltBlue),
                            modifier = Modifier.weight(1f)
                        ) { Text("Save") }
                    }
                }
            }
        }
    }
}
