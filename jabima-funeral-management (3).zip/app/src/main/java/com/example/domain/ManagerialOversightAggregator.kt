package com.example.domain

import com.example.model.ActivityStatus
import com.example.model.Department
import com.example.model.FuneralArrangementStage
import com.example.model.StaffAccount
import com.example.model.StaffActivity
import com.example.model.TaskPriority
import kotlin.math.roundToInt

enum class OversightChartDimension(val label: String) {
    DEPARTMENT("By Department"),
    STAFF("By Staff"),
    STAGE("Pending Stages")
}

enum class OversightMetricMode(val label: String) {
    TASK_COUNTS("Task Counts"),
    WORKLOAD_HOURS("Hours")
}

data class OversightBarEntry(
    val key: String,
    val label: String,
    val shortLabel: String,
    val activeCount: Int,
    val pendingCount: Int,
    val completedCount: Int,
    val urgentPendingCount: Int,
    val totalMinutes: Int,
    val activeMinutes: Int,
    val pendingMinutes: Int,
    val completedMinutes: Int,
    val pendingAllowanceKes: Double
) {
    val totalTasks: Int get() = activeCount + pendingCount + completedCount
    val totalHours: Double get() = totalMinutes / 60.0
    val activeHours: Double get() = activeMinutes / 60.0
    val pendingHours: Double get() = pendingMinutes / 60.0
    val completedHours: Double get() = completedMinutes / 60.0
}

data class ManagerialOversightSummary(
    val totalTasks: Int,
    val activeCount: Int,
    val pendingCount: Int,
    val urgentHighPendingCount: Int,
    val completedCount: Int,
    val completionRatePercent: Int,
    val totalHours: Double,
    val pendingHoursTotal: Double,
    val pendingAllowanceTotalKes: Double,
    val bars: List<OversightBarEntry>,
    val pendingTasks: List<StaffActivity>,
    val availableDates: List<String>
)

/**
 * Pure aggregation engine powering the Managerial Oversight Summary Dashboard & Bar Chart.
 * Classifies all funeral service tasks into Active (In Progress / In Transit), Pending
 * (Scheduled / On Hold), and Completed (Completed / Verified by Admin).
 */
object ManagerialOversightAggregator {

    fun isActiveStatus(status: ActivityStatus): Boolean =
        status == ActivityStatus.IN_PROGRESS || status == ActivityStatus.IN_TRANSIT

    fun isPendingStatus(status: ActivityStatus): Boolean =
        status == ActivityStatus.SCHEDULED || status == ActivityStatus.ON_HOLD

    fun isCompletedStatus(status: ActivityStatus): Boolean =
        status == ActivityStatus.COMPLETED || status == ActivityStatus.VERIFIED_BY_ADMIN

    fun buildOversightSummary(
        staffAccounts: List<StaffAccount>,
        activities: List<StaffActivity>,
        dimension: OversightChartDimension,
        dateFilter: String? = null,
        departmentFilter: Department? = null
    ): ManagerialOversightSummary {
        val availableDates = activities
            .map { it.date.trim() }
            .filter { it.isNotEmpty() }
            .distinct()
            .sortedDescending()

        val filtered = activities.filter { act ->
            val matchesDate = dateFilter.isNullOrBlank() || act.date.equals(dateFilter, ignoreCase = true)
            val matchesDept = departmentFilter == null || act.department == departmentFilter
            matchesDate && matchesDept
        }

        val activeCount = filtered.count { isActiveStatus(it.status) }
        val pendingCount = filtered.count { isPendingStatus(it.status) }
        val completedCount = filtered.count { isCompletedStatus(it.status) }
        val totalTasks = filtered.size
        val urgentHighPendingCount = filtered.count {
            isPendingStatus(it.status) &&
                (it.priority == TaskPriority.URGENT || it.priority == TaskPriority.HIGH)
        }
        val completionRatePercent = if (totalTasks == 0) {
            0
        } else {
            ((completedCount.toDouble() / totalTasks.toDouble()) * 100.0).roundToInt()
        }
        val totalHours = filtered.sumOf { it.durationMinutes } / 60.0
        val pendingHoursTotal = filtered
            .filter { isPendingStatus(it.status) }
            .sumOf { it.durationMinutes } / 60.0
        val pendingAllowanceTotalKes = filtered
            .filter { isPendingStatus(it.status) }
            .sumOf { it.allowanceEarned }

        val bars = when (dimension) {
            OversightChartDimension.DEPARTMENT -> buildDepartmentBars(staffAccounts, filtered, departmentFilter)
            OversightChartDimension.STAFF -> buildStaffBars(staffAccounts, filtered, departmentFilter)
            OversightChartDimension.STAGE -> buildStageBars(filtered)
        }

        val pendingTasks = filtered
            .filter { isPendingStatus(it.status) }
            .sortedWith(
                compareBy<StaffActivity>(
                    { -priorityWeight(it.priority) },
                    { TimelineScheduleHelper.parseTimeToMinutes(it.time) },
                    { it.date },
                    { it.id }
                )
            )

        return ManagerialOversightSummary(
            totalTasks = totalTasks,
            activeCount = activeCount,
            pendingCount = pendingCount,
            urgentHighPendingCount = urgentHighPendingCount,
            completedCount = completedCount,
            completionRatePercent = completionRatePercent,
            totalHours = totalHours,
            pendingHoursTotal = pendingHoursTotal,
            pendingAllowanceTotalKes = pendingAllowanceTotalKes,
            bars = bars,
            pendingTasks = pendingTasks,
            availableDates = availableDates
        )
    }

    private fun buildDepartmentBars(
        staffAccounts: List<StaffAccount>,
        activities: List<StaffActivity>,
        departmentFilter: Department?
    ): List<OversightBarEntry> {
        val departments = if (departmentFilter != null) {
            listOf(departmentFilter)
        } else {
            Department.values().filter { dept ->
                activities.any { it.department == dept } || staffAccounts.any { it.department == dept }
            }
        }

        return departments.map { dept ->
            val deptTasks = activities.filter { it.department == dept }
            toBarEntry(
                key = dept.name,
                label = dept.displayName,
                shortLabel = shortDepartmentLabel(dept),
                tasks = deptTasks
            )
        }.sortedWith(
            compareByDescending<OversightBarEntry> { it.pendingCount + it.activeCount }
                .thenByDescending { it.totalTasks }
                .thenBy { it.label }
        )
    }

    private fun buildStaffBars(
        staffAccounts: List<StaffAccount>,
        activities: List<StaffActivity>,
        departmentFilter: Department?
    ): List<OversightBarEntry> {
        val grouped = activities.groupBy { it.staffId }
        val knownIds = staffAccounts
            .filter { departmentFilter == null || it.department == departmentFilter }
            .filter { acc -> grouped.containsKey(acc.id) || activities.isEmpty() }
            .associateBy { it.id }

        val entries = mutableListOf<OversightBarEntry>()
        val seenIds = mutableSetOf<String>()

        knownIds.values.forEach { staff ->
            seenIds.add(staff.id)
            val tasks = grouped[staff.id].orEmpty()
            entries.add(
                toBarEntry(
                    key = staff.id,
                    label = "${staff.fullName} (${shortDepartmentLabel(staff.department)})",
                    shortLabel = shortPersonName(staff.fullName),
                    tasks = tasks
                )
            )
        }

        grouped.forEach { (staffId, tasks) ->
            if (!seenIds.contains(staffId)) {
                val sample = tasks.firstOrNull()
                val fullName = sample?.staffName ?: staffId
                entries.add(
                    toBarEntry(
                        key = staffId,
                        label = fullName,
                        shortLabel = shortPersonName(fullName),
                        tasks = tasks
                    )
                )
            }
        }

        return entries.sortedWith(
            compareByDescending<OversightBarEntry> { it.pendingCount + it.activeCount }
                .thenByDescending { it.totalTasks }
                .thenBy { it.shortLabel }
        )
    }

    private fun buildStageBars(activities: List<StaffActivity>): List<OversightBarEntry> {
        return FuneralArrangementStage.values().map { stage ->
            val stageTasks = activities.filter { it.arrangementStage == stage }
            toBarEntry(
                key = stage.name,
                label = stage.label,
                shortLabel = shortStageLabel(stage),
                tasks = stageTasks
            )
        }.filter { it.totalTasks > 0 }
            .ifEmpty {
                FuneralArrangementStage.values().map { stage ->
                    toBarEntry(
                        key = stage.name,
                        label = stage.label,
                        shortLabel = shortStageLabel(stage),
                        tasks = emptyList()
                    )
                }
            }
    }

    private fun toBarEntry(
        key: String,
        label: String,
        shortLabel: String,
        tasks: List<StaffActivity>
    ): OversightBarEntry {
        val active = tasks.filter { isActiveStatus(it.status) }
        val pending = tasks.filter { isPendingStatus(it.status) }
        val completed = tasks.filter { isCompletedStatus(it.status) }

        return OversightBarEntry(
            key = key,
            label = label,
            shortLabel = shortLabel,
            activeCount = active.size,
            pendingCount = pending.size,
            completedCount = completed.size,
            urgentPendingCount = pending.count {
                it.priority == TaskPriority.URGENT || it.priority == TaskPriority.HIGH
            },
            totalMinutes = tasks.sumOf { it.durationMinutes },
            activeMinutes = active.sumOf { it.durationMinutes },
            pendingMinutes = pending.sumOf { it.durationMinutes },
            completedMinutes = completed.sumOf { it.durationMinutes },
            pendingAllowanceKes = pending.sumOf { it.allowanceEarned }
        )
    }

    private fun priorityWeight(priority: TaskPriority): Int = when (priority) {
        TaskPriority.URGENT -> 3
        TaskPriority.HIGH -> 2
        TaskPriority.NORMAL -> 1
    }

    fun shortDepartmentLabel(department: Department): String = when (department) {
        Department.CEO -> "CEO"
        Department.WORKSHOP -> "Workshop"
        Department.DRIVERS -> "Drivers"
        Department.OPERATORS -> "Operators"
        Department.SALES_MARKETING -> "Sales"
        Department.ADMINISTRATION -> "Admin"
    }

    private fun shortStageLabel(stage: FuneralArrangementStage): String = when (stage) {
        FuneralArrangementStage.INTAKE_MORTUARY -> "Intake"
        FuneralArrangementStage.FAMILY_PLANNING -> "Planning"
        FuneralArrangementStage.CASKET_FLORALS -> "Casket"
        FuneralArrangementStage.FLEET_CORTEGE -> "Cortege"
        FuneralArrangementStage.CHAPEL_VIGIL -> "Chapel"
        FuneralArrangementStage.GRAVESITE_LOWERING -> "Gravesite"
        FuneralArrangementStage.DEBRIEF_COMPLETION -> "Debrief"
    }

    private fun shortPersonName(fullName: String): String {
        val parts = fullName.trim().split(Regex("\\s+")).filter { it.isNotBlank() }
        return when {
            parts.isEmpty() -> "Staff"
            parts.size == 1 -> parts[0].take(10)
            else -> "${parts[0].take(8)} ${parts[1].first()}."
        }
    }
}
