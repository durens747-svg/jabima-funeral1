package com.example.ui.screens

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Analytics
import androidx.compose.material.icons.filled.Build
import androidx.compose.material.icons.filled.Calculate
import androidx.compose.material.icons.filled.Category
import androidx.compose.material.icons.filled.ExpandLess
import androidx.compose.material.icons.filled.ExpandMore
import androidx.compose.material.icons.filled.Groups
import androidx.compose.material.icons.filled.Inventory
import androidx.compose.material.icons.filled.LocalOffer
import androidx.compose.material.icons.filled.PrecisionManufacturing
import androidx.compose.material.icons.filled.ShoppingCartCheckout
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.FilterChip
import androidx.compose.material3.FilterChipDefaults
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.ScrollableTabRow
import androidx.compose.material3.Surface
import androidx.compose.material3.Tab
import androidx.compose.material3.TabRowDefaults
import androidx.compose.material3.TabRowDefaults.tabIndicatorOffset
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.domain.BomSpecLineItem
import com.example.domain.CasketCostingEngine
import com.example.domain.CasketProductionCostModel
import com.example.domain.CostingBomPhase
import com.example.model.MainAppTab
import com.example.ui.StaffPortalViewModel
import com.example.ui.theme.AmberLight
import com.example.ui.theme.AmberWarning
import com.example.ui.theme.BorderLight
import com.example.ui.theme.EmeraldLight
import com.example.ui.theme.EmeraldSuccess
import com.example.ui.theme.ForestGreenDark
import com.example.ui.theme.ForestGreenLight
import com.example.ui.theme.ForestGreenPrimary
import com.example.ui.theme.Navy900
import com.example.ui.theme.PureWhite
import com.example.ui.theme.RoyalCobaltBlue
import com.example.ui.theme.RoyalCobaltIce
import com.example.ui.theme.StrokeRed
import com.example.ui.theme.TextMuted
import com.example.ui.theme.TextSecondary
import java.util.Locale

@Composable
fun CostingsAndPricingScreen(
    viewModel: StaffPortalViewModel,
    onNavigateMainTab: (MainAppTab) -> Unit = { viewModel.setMainAppTab(it) }
) {
    var selectedSubTab by remember { mutableIntStateOf(0) }
    var currencyMode by remember { mutableStateOf("KES") }
    var useBulkGlue by remember { mutableStateOf(false) }
    var includeSpindlesSet by remember { mutableStateOf(false) }
    var upgradeSwingBar by remember { mutableStateOf(false) }
    var expandedModelId by remember { mutableStateOf<String?>(CasketCostingEngine.casketProductionModels.firstOrNull()?.id) }

    val formulatedModels = remember(useBulkGlue, includeSpindlesSet, upgradeSwingBar) {
        CasketCostingEngine.casketProductionModels.map { base ->
            CasketCostingEngine.calculateModelWithOptions(
                modelId = base.id,
                useBulkGlue = useBulkGlue,
                includeSpindlesSet = includeSpindlesSet,
                upgradeToSwingBarHandles = upgradeSwingBar
            )
        }
    }

    val avgGrossMarginPct = remember(formulatedModels) {
        val avg = formulatedModels.map { it.grossMarginPercent }.average()
        String.format(Locale.US, "%.1f%%", avg)
    }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(MaterialTheme.colorScheme.background)
            .testTag("costings_and_pricing_screen")
    ) {
        // Executive Hero Header
        Box(
            modifier = Modifier
                .fillMaxWidth()
                .background(
                    brush = Brush.linearGradient(
                        colors = listOf(ForestGreenDark, ForestGreenPrimary, ForestGreenLight)
                    )
                )
                .padding(horizontal = 16.dp, vertical = 14.dp)
        ) {
            Column {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Column(modifier = Modifier.weight(1f)) {
                        Text(
                            text = "PRODUCTION COSTINGS & ORDER PRICE GUIDE",
                            fontSize = 10.sp,
                            fontWeight = FontWeight.ExtraBold,
                            color = Color(0xFF86EFAC),
                            letterSpacing = 0.8.sp
                        )
                        Text(
                            text = "Demystified BOM, Materials & Client Pricing",
                            fontSize = 16.sp,
                            fontWeight = FontWeight.Bold,
                            color = Color.White,
                            maxLines = 1,
                            overflow = TextOverflow.Ellipsis
                        )
                        Text(
                            text = "9 Casket Models • 32 Raw Materials • Equipment Hire & 8 Shops",
                            fontSize = 11.sp,
                            color = Color(0xFFDBEAFE),
                            maxLines = 1,
                            overflow = TextOverflow.Ellipsis
                        )
                    }

                    // Currency Switch
                    Surface(
                        shape = RoundedCornerShape(16.dp),
                        color = Color.White.copy(alpha = 0.16f)
                    ) {
                        Row(modifier = Modifier.padding(3.dp)) {
                            listOf("KES", "USD").forEach { curr ->
                                val active = currencyMode == curr
                                Surface(
                                    shape = RoundedCornerShape(12.dp),
                                    color = if (active) Color.White else Color.Transparent,
                                    modifier = Modifier
                                        .clickable { currencyMode = curr }
                                        .testTag("costings_currency_$curr")
                                ) {
                                    Text(
                                        text = curr,
                                        fontSize = 10.sp,
                                        fontWeight = FontWeight.ExtraBold,
                                        color = if (active) Navy900 else Color.White,
                                        modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp)
                                    )
                                }
                            }
                        }
                    }
                }

                Spacer(modifier = Modifier.height(10.dp))

                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    CostingHeroBadge("Models", "${formulatedModels.size} Formulated", Modifier.weight(1f))
                    CostingHeroBadge("Avg Margin", avgGrossMarginPct, Modifier.weight(1f))
                    CostingHeroBadge("Materials", "${CasketCostingEngine.rawMaterialCatalog.size} Rated", Modifier.weight(1f))
                    CostingHeroBadge("Branches", "${CasketCostingEngine.shopBranchNetwork.size} Shops", Modifier.weight(1f))
                }
            }
        }

        HorizontalDivider(thickness = 2.dp, color = StrokeRed)

        // Sub-Tab Bar
        val subTabs = listOf(
            "Casket Costings" to Icons.Default.Calculate,
            "Cost Analytics" to Icons.Default.Analytics,
            "Order Price Guide" to Icons.Default.LocalOffer,
            "Raw Materials (32)" to Icons.Default.Category,
            "Crew & Shops" to Icons.Default.Groups
        )
        Surface(
            color = PureWhite,
            shadowElevation = 1.dp,
            modifier = Modifier.fillMaxWidth()
        ) {
            ScrollableTabRow(
                selectedTabIndex = selectedSubTab,
                containerColor = PureWhite,
                contentColor = ForestGreenPrimary,
                edgePadding = 8.dp,
                indicator = { positions ->
                    if (selectedSubTab < positions.size) {
                        TabRowDefaults.SecondaryIndicator(
                            modifier = Modifier.tabIndicatorOffset(positions[selectedSubTab]),
                            color = ForestGreenPrimary,
                            height = 3.dp
                        )
                    }
                }
            ) {
                subTabs.forEachIndexed { idx, (label, icon) ->
                    val selected = selectedSubTab == idx
                    Tab(
                        selected = selected,
                        onClick = { selectedSubTab = idx },
                        text = {
                            Row(
                                verticalAlignment = Alignment.CenterVertically,
                                horizontalArrangement = Arrangement.spacedBy(5.dp)
                            ) {
                                Icon(
                                    imageVector = icon,
                                    contentDescription = null,
                                    modifier = Modifier.size(14.dp),
                                    tint = if (selected) ForestGreenPrimary else TextMuted
                                )
                                Text(
                                    text = label,
                                    fontSize = 12.sp,
                                    fontWeight = if (selected) FontWeight.Bold else FontWeight.Medium,
                                    color = if (selected) RoyalCobaltBlue else TextSecondary,
                                    maxLines = 1,
                                    softWrap = false
                                )
                            }
                        },
                        modifier = Modifier.testTag("costings_subtab_$idx")
                    )
                }
            }
        }

        // Tab Body
        when (selectedSubTab) {
            0 -> {
                LazyColumn(
                    modifier = Modifier
                        .weight(1f)
                        .padding(horizontal = 14.dp),
                    verticalArrangement = Arrangement.spacedBy(12.dp),
                    contentPadding = PaddingValues(vertical = 12.dp)
                ) {
                    // What-If Material & Hardware Options Card
                    item {
                        Card(
                            shape = RoundedCornerShape(12.dp),
                            colors = CardDefaults.cardColors(containerColor = PureWhite),
                            border = BorderStroke(1.dp, BorderLight),
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            Column(modifier = Modifier.padding(12.dp)) {
                                Text(
                                    text = "Workshop Formulation Toggles (Live Recalculation)",
                                    fontSize = 12.sp,
                                    fontWeight = FontWeight.Bold,
                                    color = Navy900
                                )
                                Text(
                                    text = "Demystifies raw timber, bottom foot-lengths, hardware & finishing allocations.",
                                    fontSize = 10.sp,
                                    color = TextMuted
                                )
                                Spacer(modifier = Modifier.height(6.dp))
                                Row(
                                    modifier = Modifier
                                        .fillMaxWidth()
                                        .horizontalScroll(rememberScrollState()),
                                    horizontalArrangement = Arrangement.spacedBy(6.dp)
                                ) {
                                    FilterChip(
                                        selected = useBulkGlue,
                                        onClick = { useBulkGlue = !useBulkGlue },
                                        label = {
                                            Text(
                                                "Bulk Glue (KES 900/Ltr)",
                                                fontSize = 11.sp,
                                                maxLines = 1,
                                                softWrap = false
                                            )
                                        },
                                        colors = FilterChipDefaults.filterChipColors(
                                            selectedContainerColor = EmeraldSuccess,
                                            selectedLabelColor = PureWhite
                                        ),
                                        modifier = Modifier.testTag("toggle_bulk_glue")
                                    )
                                    FilterChip(
                                        selected = includeSpindlesSet,
                                        onClick = { includeSpindlesSet = !includeSpindlesSet },
                                        label = {
                                            Text(
                                                "+ Spindles Set (KES 3,000)",
                                                fontSize = 11.sp,
                                                maxLines = 1,
                                                softWrap = false
                                            )
                                        },
                                        colors = FilterChipDefaults.filterChipColors(
                                            selectedContainerColor = RoyalCobaltBlue,
                                            selectedLabelColor = PureWhite
                                        ),
                                        modifier = Modifier.testTag("toggle_spindles_set")
                                    )
                                    FilterChip(
                                        selected = upgradeSwingBar,
                                        onClick = { upgradeSwingBar = !upgradeSwingBar },
                                        label = {
                                            Text(
                                                "Upgrade Swing Bar (KES 6,500)",
                                                fontSize = 11.sp,
                                                maxLines = 1,
                                                softWrap = false
                                            )
                                        },
                                        colors = FilterChipDefaults.filterChipColors(
                                            selectedContainerColor = AmberWarning,
                                            selectedLabelColor = PureWhite
                                        ),
                                        modifier = Modifier.testTag("toggle_swing_bar")
                                    )
                                }
                            }
                        }
                    }

                    items(formulatedModels, key = { it.id }) { model ->
                        CasketCostingModelCard(
                            model = model,
                            currencyMode = currencyMode,
                            isExpanded = expandedModelId == model.id,
                            onToggleExpand = {
                                expandedModelId = if (expandedModelId == model.id) null else model.id
                            },
                            onOrderAtGuidePrice = {
                                viewModel.openOrderWithCasketGuide(model.matchedBranchCasketTypes.firstOrNull() ?: model.modelName)
                            },
                            onStartWorkshopJob = {
                                viewModel.startWorkshopJobFromCosting(model)
                            }
                        )
                    }
                }
            }

            1 -> Box(modifier = Modifier.weight(1f)) {
                CostAnalyticsScreen(
                    viewModel = viewModel,
                    onOpenBomCostings = { selectedSubTab = 0 },
                    onOpenOrderDashboard = { onNavigateMainTab(MainAppTab.ORDER_DASHBOARD) }
                )
            }

            2 -> CostingOrderPriceGuideTab(
                models = formulatedModels,
                currencyMode = currencyMode,
                onSendToOrderCheckout = { model ->
                    viewModel.openOrderWithCasketGuide(model.matchedBranchCasketTypes.firstOrNull() ?: model.modelName)
                },
                modifier = Modifier.weight(1f)
            )

            3 -> CostingRawMaterialsTab(
                onOpenInventory = { onNavigateMainTab(MainAppTab.INVENTORY_MANAGEMENT) },
                modifier = Modifier.weight(1f)
            )

            4 -> CostingCrewAndShopsTab(
                onOpenBranchesBoards = { onNavigateMainTab(MainAppTab.BRANCH_BOARDS) },
                modifier = Modifier.weight(1f)
            )
        }
    }
}

@Composable
private fun CostingHeroBadge(label: String, value: String, modifier: Modifier = Modifier) {
    Surface(
        color = Color.White.copy(alpha = 0.13f),
        shape = RoundedCornerShape(8.dp),
        modifier = modifier
    ) {
        Column(modifier = Modifier.padding(horizontal = 8.dp, vertical = 6.dp)) {
            Text(text = label, fontSize = 9.sp, color = Color(0xFFBFDBFE), maxLines = 1)
            Text(
                text = value,
                fontSize = 11.sp,
                fontWeight = FontWeight.ExtraBold,
                color = Color.White,
                maxLines = 1,
                overflow = TextOverflow.Ellipsis
            )
        }
    }
}

@Composable
private fun CasketCostingModelCard(
    model: CasketProductionCostModel,
    currencyMode: String,
    isExpanded: Boolean,
    onToggleExpand: () -> Unit,
    onOrderAtGuidePrice: () -> Unit,
    onStartWorkshopJob: () -> Unit
) {
    Card(
        shape = RoundedCornerShape(14.dp),
        colors = CardDefaults.cardColors(containerColor = PureWhite),
        border = BorderStroke(1.dp, if (isExpanded) RoyalCobaltBlue else BorderLight),
        elevation = CardDefaults.cardElevation(defaultElevation = if (isExpanded) 3.dp else 1.dp),
        modifier = Modifier
            .fillMaxWidth()
            .testTag("costing_model_card_${model.id}")
    ) {
        Column(modifier = Modifier.padding(14.dp)) {
            // Top Summary Header (tap to expand/collapse)
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .clickable { onToggleExpand() },
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.Top
            ) {
                Column(modifier = Modifier.weight(1f)) {
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(6.dp)
                    ) {
                        Surface(color = RoyalCobaltIce, shape = RoundedCornerShape(5.dp)) {
                            Text(
                                text = model.tierLabel.uppercase(Locale.US),
                                fontSize = 9.sp,
                                fontWeight = FontWeight.ExtraBold,
                                color = RoyalCobaltBlue,
                                modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp)
                            )
                        }
                        Surface(color = EmeraldLight, shape = RoundedCornerShape(5.dp)) {
                            Text(
                                text = "${model.grossMarginPercent}% Margin",
                                fontSize = 9.sp,
                                fontWeight = FontWeight.Bold,
                                color = EmeraldSuccess,
                                modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp)
                            )
                        }
                    }

                    Spacer(modifier = Modifier.height(4.dp))

                    Text(
                        text = model.modelName,
                        fontSize = 15.sp,
                        fontWeight = FontWeight.ExtraBold,
                        color = Navy900
                    )
                    Text(
                        text = "Covers: ${model.coveredVariants} • ${model.sizeSpec}",
                        fontSize = 11.sp,
                        color = TextSecondary
                    )
                }

                Column(horizontalAlignment = Alignment.End) {
                    Text(
                        text = formatCurrencyDisplay(model.recommendedOrderPriceKes, currencyMode),
                        fontSize = 15.sp,
                        fontWeight = FontWeight.ExtraBold,
                        color = RoyalCobaltBlue
                    )
                    Text(
                        text = "Prod Cost: ${formatCurrencyDisplay(model.totalProductionCostKes, currencyMode)}",
                        fontSize = 10.sp,
                        fontWeight = FontWeight.SemiBold,
                        color = AmberWarning
                    )
                    Icon(
                        imageVector = if (isExpanded) Icons.Default.ExpandLess else Icons.Default.ExpandMore,
                        contentDescription = if (isExpanded) "Collapse BOM details" else "Expand BOM details",
                        tint = TextMuted,
                        modifier = Modifier.size(20.dp)
                    )
                }
            }

            Spacer(modifier = Modifier.height(10.dp))

            // Stacked Cost Composition Bar (Body + Finishing + Paint/Abr + Labor)
            CostCompositionStackedBar(model = model)

            Spacer(modifier = Modifier.height(8.dp))

            // 4-Column Quick Cost Figures
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(6.dp)
            ) {
                CostMiniBox("Body Mat", formatCurrencyDisplay(model.baseBodyMaterialCostKes, currencyMode), RoyalCobaltBlue, Modifier.weight(1f))
                CostMiniBox("Finishing", formatCurrencyDisplay(model.finishingMaterialCostKes, currencyMode), AmberWarning, Modifier.weight(1f))
                CostMiniBox("Paint+Lab", formatCurrencyDisplay(model.paintAndAbrasivesCostKes + model.crewLaborCostKes, currencyMode), ForestGreenPrimary, Modifier.weight(1f))
                CostMiniBox("Est Profit", formatCurrencyDisplay(model.grossProfitAtGuideKes, currencyMode), EmeraldSuccess, Modifier.weight(1f))
            }

            // Expanded Demystified Line-by-Line BOM Table & Action Buttons
            AnimatedVisibility(visible = isExpanded) {
                Column(modifier = Modifier.padding(top = 12.dp)) {
                    HorizontalDivider(color = BorderLight)
                    Spacer(modifier = Modifier.height(10.dp))

                    Text(
                        text = "Demystified Bill of Materials & Labor",
                        fontSize = 12.sp,
                        fontWeight = FontWeight.Bold,
                        color = Navy900
                    )
                    if (model.notes.isNotBlank()) {
                        Text(
                            text = model.notes,
                            fontSize = 10.sp,
                            color = TextMuted,
                            modifier = Modifier.padding(top = 2.dp, bottom = 6.dp)
                        )
                    }

                    CostingBomPhase.values().forEach { phase ->
                        val phaseItems = model.bomItems.filter { it.phase == phase }
                        if (phaseItems.isNotEmpty()) {
                            Surface(
                                color = Color(0xFFF8FAFC),
                                shape = RoundedCornerShape(8.dp),
                                border = BorderStroke(1.dp, BorderLight),
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .padding(vertical = 4.dp)
                            ) {
                                Column(modifier = Modifier.padding(10.dp)) {
                                    Text(
                                        text = phase.label,
                                        fontSize = 11.sp,
                                        fontWeight = FontWeight.ExtraBold,
                                        color = RoyalCobaltBlue
                                    )
                                    Spacer(modifier = Modifier.height(4.dp))
                                    phaseItems.forEach { item ->
                                        BomLineRow(item = item, currencyMode = currencyMode)
                                    }
                                }
                            }
                        }
                    }

                    // Crew Labor & Margin Summary Strip
                    Surface(
                        color = AmberLight.copy(alpha = 0.45f),
                        shape = RoundedCornerShape(8.dp),
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(vertical = 4.dp)
                    ) {
                        Row(
                            modifier = Modifier.padding(horizontal = 10.dp, vertical = 8.dp),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Column(modifier = Modifier.weight(1f)) {
                                Text(
                                    text = "Workshop Craft Labor (${model.matchedWorkshopTeam})",
                                    fontSize = 10.sp,
                                    fontWeight = FontWeight.Bold,
                                    color = Navy900
                                )
                                Text(
                                    text = "Direct Mat: ${formatCurrencyDisplay(model.directMaterialCostKes, currencyMode)} • Order Range: ${model.priceRangeLabel}",
                                    fontSize = 10.sp,
                                    color = TextSecondary
                                )
                            }
                            Text(
                                text = formatCurrencyDisplay(model.crewLaborCostKes, currencyMode),
                                fontSize = 11.sp,
                                fontWeight = FontWeight.ExtraBold,
                                color = AmberWarning
                            )
                        }
                    }

                    Spacer(modifier = Modifier.height(8.dp))

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        OutlinedButton(
                            onClick = onStartWorkshopJob,
                            shape = RoundedCornerShape(8.dp),
                            modifier = Modifier
                                .weight(1f)
                                .height(40.dp)
                                .testTag("btn_start_job_from_costing_${model.id}")
                        ) {
                            Icon(Icons.Default.PrecisionManufacturing, contentDescription = null, modifier = Modifier.size(15.dp))
                            Spacer(modifier = Modifier.width(4.dp))
                            Text("Start Job", fontSize = 11.sp, fontWeight = FontWeight.Bold, maxLines = 1, softWrap = false)
                        }
                        Button(
                            onClick = onOrderAtGuidePrice,
                            colors = ButtonDefaults.buttonColors(containerColor = ForestGreenPrimary),
                            shape = RoundedCornerShape(8.dp),
                            modifier = Modifier
                                .weight(1f)
                                .height(40.dp)
                                .testTag("btn_order_from_costing_${model.id}")
                        ) {
                            Icon(Icons.Default.ShoppingCartCheckout, contentDescription = null, modifier = Modifier.size(15.dp))
                            Spacer(modifier = Modifier.width(4.dp))
                            Text("Order @ Guide", fontSize = 11.sp, fontWeight = FontWeight.Bold, maxLines = 1, softWrap = false)
                        }
                    }
                }
            }
        }
    }
}

@Composable
private fun CostCompositionStackedBar(model: CasketProductionCostModel) {
    val guide = model.recommendedOrderPriceKes.coerceAtLeast(1.0)
    val bodyW = (model.baseBodyMaterialCostKes / guide).toFloat().coerceIn(0.02f, 1f)
    val finishW = (model.finishingMaterialCostKes / guide).toFloat().coerceIn(0.02f, 1f)
    val paintLabW = ((model.paintAndAbrasivesCostKes + model.crewLaborCostKes) / guide).toFloat().coerceIn(0.02f, 1f)
    val profitW = (model.grossProfitAtGuideKes / guide).toFloat().coerceAtLeast(0.02f)

    Row(
        modifier = Modifier
            .fillMaxWidth()
            .height(8.dp)
            .clip(RoundedCornerShape(4.dp))
            .background(Color(0xFFE2E8F0))
    ) {
        Box(modifier = Modifier.weight(bodyW).fillMaxHeight().background(RoyalCobaltBlue))
        Box(modifier = Modifier.weight(finishW).fillMaxHeight().background(AmberWarning))
        Box(modifier = Modifier.weight(paintLabW).fillMaxHeight().background(Navy900))
        Box(modifier = Modifier.weight(profitW).fillMaxHeight().background(EmeraldSuccess))
    }
}

@Composable
private fun CostMiniBox(label: String, value: String, tint: Color, modifier: Modifier = Modifier) {
    Surface(
        color = Color(0xFFF8FAFC),
        shape = RoundedCornerShape(6.dp),
        border = BorderStroke(1.dp, BorderLight),
        modifier = modifier
    ) {
        Column(modifier = Modifier.padding(horizontal = 6.dp, vertical = 5.dp)) {
            Text(text = label, fontSize = 9.sp, color = TextMuted, maxLines = 1)
            Text(
                text = value,
                fontSize = 10.sp,
                fontWeight = FontWeight.ExtraBold,
                color = tint,
                maxLines = 1,
                overflow = TextOverflow.Ellipsis
            )
        }
    }
}

@Composable
private fun BomLineRow(item: BomSpecLineItem, currencyMode: String) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .padding(vertical = 3.dp),
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.CenterVertically
    ) {
        Column(modifier = Modifier.weight(1f)) {
            Text(
                text = item.clarifiedLabel,
                fontSize = 11.sp,
                fontWeight = FontWeight.SemiBold,
                color = Navy900
            )
            Text(
                text = "PDF Spec: ${item.rawSpecName} (${item.rawQuantitySpec})" + if (item.isEstimatedAllocation) " • Workshop Est." else "",
                fontSize = 9.sp,
                color = TextMuted
            )
        }
        Text(
            text = formatCurrencyDisplay(item.lineCostKes, currencyMode),
            fontSize = 11.sp,
            fontWeight = FontWeight.Bold,
            color = RoyalCobaltBlue
        )
    }
}

internal fun formatCurrencyDisplay(amountKes: Double, currencyMode: String): String {
    return if (currencyMode == "USD") {
        val usd = amountKes / 130.0
        String.format(Locale.US, "$ %,.0f", usd)
    } else {
        String.format(Locale.US, "KES %,.0f", amountKes)
    }
}
