package com.example.ui.screens

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.Send
import androidx.compose.material.icons.filled.AutoAwesome
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.ContentCopy
import androidx.compose.material.icons.filled.DeleteSweep
import androidx.compose.material.icons.filled.ErrorOutline
import androidx.compose.material.icons.filled.Refresh
import androidx.compose.material.icons.filled.Sms
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.FilledIconButton
import androidx.compose.material3.FilterChip
import androidx.compose.material3.FilterChipDefaults
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.IconButtonDefaults
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalClipboardManager
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.AnnotatedString
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.viewmodel.compose.viewModel
import com.example.ai.GeminiChatMessage
import com.example.ai.GeminiUiState
import com.example.ai.GeminiWorkflowPreset
import com.example.ai.JabimaGeminiViewModel
import com.example.ai.JabimaPromptContextBuilder
import com.example.ai.StructuredCarePlan
import com.example.ui.StaffPortalViewModel
import com.example.ui.theme.ForestGreenDark
import com.example.ui.theme.ForestGreenLight
import com.example.ui.theme.ForestGreenPrimary
import com.example.ui.theme.PureWhite
import com.example.ui.theme.StrokeRed
import com.example.ui.theme.StrokeRedDark
import com.example.ui.theme.StrokeRedLight

@Composable
fun GeminiCopilotScreen(
    portalViewModel: StaffPortalViewModel,
    geminiViewModel: JabimaGeminiViewModel = viewModel(),
    onSendToBulkSms: (String) -> Unit = {}
) {
    val uiState by geminiViewModel.uiState.collectAsState()
    val messages by geminiViewModel.messages.collectAsState()
    val structuredPlan by geminiViewModel.structuredPlan.collectAsState()
    val isStructuredMode by geminiViewModel.isStructuredMode.collectAsState()

    val currentAccount by portalViewModel.currentAccount.collectAsState()
    val allActivities by portalViewModel.allActivities.collectAsState()
    val burialSchedules by portalViewModel.burialSchedules.collectAsState()
    val caskets by portalViewModel.caskets.collectAsState()
    val fleetVehicles by portalViewModel.fleetGpsVehicles.collectAsState()
    val customerOrders by portalViewModel.customerOrders.collectAsState()
    val staffAlerts by portalViewModel.staffAlerts.collectAsState()

    val liveSnapshot = remember(
        currentAccount,
        allActivities,
        burialSchedules,
        caskets,
        fleetVehicles,
        customerOrders,
        staffAlerts
    ) {
        JabimaPromptContextBuilder.buildSnapshot(
            currentAccount = currentAccount,
            activities = allActivities,
            burials = burialSchedules,
            caskets = caskets,
            fleet = fleetVehicles,
            orders = customerOrders,
            alerts = staffAlerts
        )
    }

    var promptInput by remember { mutableStateOf("") }
    val clipboardManager = LocalClipboardManager.current
    val listState = rememberLazyListState()

    LaunchedEffect(messages.size) {
        if (messages.isNotEmpty() && !isStructuredMode) {
            listState.animateScrollToItem(messages.lastIndex)
        }
    }

    val isBusy = uiState is GeminiUiState.Loading || uiState is GeminiUiState.Streaming

    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(MaterialTheme.colorScheme.background)
            .testTag("gemini_copilot_screen")
    ) {
        // Branded Hero Banner
        Surface(
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 12.dp, vertical = 8.dp),
            shape = RoundedCornerShape(16.dp),
            shadowElevation = 2.dp
        ) {
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .background(
                        Brush.horizontalGradient(
                            listOf(ForestGreenDark, ForestGreenPrimary, ForestGreenLight)
                        )
                    )
                    .padding(14.dp)
            ) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        modifier = Modifier.weight(1f)
                    ) {
                        Box(
                            modifier = Modifier
                                .size(42.dp)
                                .clip(CircleShape)
                                .background(PureWhite.copy(alpha = 0.18f)),
                            contentAlignment = Alignment.Center
                        ) {
                            Icon(
                                imageVector = Icons.Default.AutoAwesome,
                                contentDescription = "Jabima Gemini AI Copilot",
                                tint = PureWhite,
                                modifier = Modifier.size(22.dp)
                            )
                        }
                        Spacer(modifier = Modifier.width(12.dp))
                        Column {
                            Text(
                                text = "Jabima Gemini Copilot",
                                color = PureWhite,
                                fontSize = 16.sp,
                                fontWeight = FontWeight.ExtraBold,
                                maxLines = 1,
                                overflow = TextOverflow.Ellipsis
                            )
                            Text(
                                text = "${liveSnapshot.staffBranch} • ${liveSnapshot.activeDutiesCount} live duties • Gemini 3.8 Flash",
                                color = Color(0xFFD1FAE5),
                                fontSize = 11.sp,
                                maxLines = 1,
                                overflow = TextOverflow.Ellipsis
                            )
                        }
                    }

                    IconButton(
                        onClick = { geminiViewModel.clearSession() },
                        modifier = Modifier
                            .size(48.dp)
                            .testTag("ai_clear_session_button")
                    ) {
                        Icon(
                            imageVector = Icons.Default.DeleteSweep,
                            contentDescription = "Clear AI Conversation",
                            tint = PureWhite
                        )
                    }
                }
            }
        }

        // Mode Switch + Quick Operational Presets
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 12.dp),
            horizontalArrangement = Arrangement.spacedBy(8.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            FilterChip(
                selected = !isStructuredMode,
                onClick = { geminiViewModel.setStructuredMode(false) },
                label = { Text("Streaming Chat", fontSize = 12.sp, fontWeight = FontWeight.SemiBold) },
                colors = FilterChipDefaults.filterChipColors(
                    selectedContainerColor = MaterialTheme.colorScheme.primaryContainer,
                    selectedLabelColor = MaterialTheme.colorScheme.onPrimaryContainer
                ),
                modifier = Modifier.testTag("ai_mode_chat")
            )
            FilterChip(
                selected = isStructuredMode,
                onClick = { geminiViewModel.setStructuredMode(true) },
                label = { Text("Structured Plan (JSON)", fontSize = 12.sp, fontWeight = FontWeight.SemiBold) },
                colors = FilterChipDefaults.filterChipColors(
                    selectedContainerColor = MaterialTheme.colorScheme.secondaryContainer,
                    selectedLabelColor = MaterialTheme.colorScheme.onSecondaryContainer
                ),
                modifier = Modifier.testTag("ai_mode_structured")
            )
        }

        // Quick Workflow Action Strip
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .horizontalScroll(rememberScrollState())
                .padding(horizontal = 12.dp, vertical = 6.dp),
            horizontalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            GeminiWorkflowPreset.entries.forEach { preset ->
                OutlinedButton(
                    onClick = {
                        val builtPrompt = JabimaPromptContextBuilder.buildPresetPrompt(
                            preset = preset,
                            snapshot = liveSnapshot,
                            customDetails = promptInput.trim()
                        )
                        if (preset.isStructuredMode) {
                            geminiViewModel.generateStructuredCarePlan(builtPrompt)
                        } else {
                            geminiViewModel.sendStreamingPrompt(
                                displayPrompt = "${preset.title}${if (promptInput.isNotBlank()) ": ${promptInput.trim()}" else ""}",
                                fullContextPrompt = builtPrompt
                            )
                        }
                        promptInput = ""
                    },
                    enabled = !isBusy,
                    shape = RoundedCornerShape(10.dp),
                    contentPadding = PaddingValues(horizontal = 12.dp, vertical = 8.dp),
                    border = BorderStroke(
                        1.dp,
                        if (preset.isStructuredMode) StrokeRed.copy(alpha = 0.6f)
                        else MaterialTheme.colorScheme.outline
                    ),
                    modifier = Modifier
                        .heightIn(min = 48.dp)
                        .testTag("ai_preset_${preset.id}")
                ) {
                    Column {
                        Text(
                            text = preset.title,
                            fontSize = 12.sp,
                            fontWeight = FontWeight.Bold,
                            color = if (preset.isStructuredMode) StrokeRed else MaterialTheme.colorScheme.primary
                        )
                        Text(
                            text = preset.subtitle,
                            fontSize = 10.sp,
                            color = MaterialTheme.colorScheme.onSurfaceVariant,
                            maxLines = 1
                        )
                    }
                }
            }
        }

        // Transparent Error Banner (surfaces real App Check / network / API errors)
        AnimatedVisibility(visible = uiState is GeminiUiState.Error) {
            val errMsg = (uiState as? GeminiUiState.Error)?.message.orEmpty()
            Surface(
                color = StrokeRedLight,
                shape = RoundedCornerShape(12.dp),
                border = BorderStroke(1.dp, StrokeRed),
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 12.dp, vertical = 4.dp)
                    .testTag("ai_error_banner")
            ) {
                Row(
                    modifier = Modifier.padding(12.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Icon(
                        imageVector = Icons.Default.ErrorOutline,
                        contentDescription = "Gemini Error",
                        tint = StrokeRedDark,
                        modifier = Modifier.size(20.dp)
                    )
                    Spacer(modifier = Modifier.width(8.dp))
                    Text(
                        text = errMsg,
                        color = StrokeRedDark,
                        fontSize = 12.sp,
                        fontWeight = FontWeight.Medium,
                        modifier = Modifier.weight(1f)
                    )
                    TextButton(
                        onClick = { geminiViewModel.retryLastRequest() },
                        modifier = Modifier.testTag("ai_retry_button")
                    ) {
                        Icon(
                            imageVector = Icons.Default.Refresh,
                            contentDescription = "Retry Request",
                            tint = StrokeRedDark,
                            modifier = Modifier.size(16.dp)
                        )
                        Spacer(modifier = Modifier.width(4.dp))
                        Text("Retry", color = StrokeRedDark, fontWeight = FontWeight.Bold)
                    }
                }
            }
        }

        // Main Workspace Area: Structured Care Plan OR Streaming Conversation
        Box(
            modifier = Modifier
                .weight(1f)
                .fillMaxWidth()
        ) {
            if (isStructuredMode) {
                StructuredPlanWorkspace(
                    structuredPlan = structuredPlan,
                    isLoading = uiState is GeminiUiState.Loading,
                    onGenerateDefaultPlan = {
                        val prompt = JabimaPromptContextBuilder.buildPresetPrompt(
                            preset = GeminiWorkflowPreset.STRUCTURED_CARE_PLAN,
                            snapshot = liveSnapshot,
                            customDetails = promptInput.trim()
                        )
                        geminiViewModel.generateStructuredCarePlan(prompt)
                        promptInput = ""
                    },
                    onCopyPlan = { text ->
                        clipboardManager.setText(AnnotatedString(text))
                        portalViewModel.actionFeedbackMessage.value = "Structured care plan copied to clipboard."
                    },
                    onSendSms = { smsText ->
                        clipboardManager.setText(AnnotatedString(smsText))
                        portalViewModel.actionFeedbackMessage.value = "SMS notice copied & opening Bulk SMS tab."
                        onSendToBulkSms(smsText)
                    }
                )
            } else {
                if (messages.isEmpty()) {
                    EmptyCopilotState(
                        branch = liveSnapshot.staffBranch,
                        staffName = liveSnapshot.staffName
                    )
                } else {
                    LazyColumn(
                        state = listState,
                        contentPadding = PaddingValues(horizontal = 12.dp, vertical = 8.dp),
                        verticalArrangement = Arrangement.spacedBy(10.dp),
                        modifier = Modifier
                            .fillMaxSize()
                            .testTag("ai_chat_message_list")
                    ) {
                        items(messages, key = { it.id }) { msg ->
                            CopilotMessageBubble(
                                message = msg,
                                onCopy = {
                                    clipboardManager.setText(AnnotatedString(msg.text))
                                    portalViewModel.actionFeedbackMessage.value = "Response copied to clipboard."
                                },
                                onSendSms = {
                                    clipboardManager.setText(AnnotatedString(msg.text.take(320)))
                                    portalViewModel.actionFeedbackMessage.value = "Draft copied — opening Bulk SMS."
                                    onSendToBulkSms(msg.text.take(320))
                                }
                            )
                        }
                    }
                }
            }
        }

        // Input Composer Bar
        Surface(
            color = MaterialTheme.colorScheme.surface,
            tonalElevation = 4.dp,
            border = BorderStroke(1.dp, MaterialTheme.colorScheme.outline.copy(alpha = 0.4f)),
            modifier = Modifier.fillMaxWidth()
        ) {
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 12.dp, vertical = 8.dp),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                OutlinedTextField(
                    value = promptInput,
                    onValueChange = { promptInput = it },
                    placeholder = {
                        Text(
                            text = if (isStructuredMode) {
                                "Describe family requirements for JSON plan..."
                            } else {
                                "Ask Gemini about schedules, eulogies, stock..."
                            },
                            fontSize = 13.sp,
                            maxLines = 1,
                            overflow = TextOverflow.Ellipsis
                        )
                    },
                    maxLines = 3,
                    enabled = !isBusy,
                    shape = RoundedCornerShape(14.dp),
                    modifier = Modifier
                        .weight(1f)
                        .testTag("ai_prompt_input")
                )

                FilledIconButton(
                    onClick = {
                        val trimmed = promptInput.trim()
                        if (trimmed.isEmpty()) return@FilledIconButton
                        if (isStructuredMode) {
                            val prompt = JabimaPromptContextBuilder.buildPresetPrompt(
                                preset = GeminiWorkflowPreset.STRUCTURED_CARE_PLAN,
                                snapshot = liveSnapshot,
                                customDetails = trimmed
                            )
                            geminiViewModel.generateStructuredCarePlan(prompt)
                        } else {
                            val contextualPrompt = JabimaPromptContextBuilder.buildChatPrompt(trimmed, liveSnapshot)
                            geminiViewModel.sendStreamingPrompt(
                                displayPrompt = trimmed,
                                fullContextPrompt = contextualPrompt
                            )
                        }
                        promptInput = ""
                    },
                    enabled = promptInput.isNotBlank() && !isBusy,
                    colors = IconButtonDefaults.filledIconButtonColors(
                        containerColor = ForestGreenPrimary,
                        contentColor = PureWhite
                    ),
                    modifier = Modifier
                        .size(48.dp)
                        .testTag("ai_send_button")
                ) {
                    if (isBusy) {
                        CircularProgressIndicator(
                            modifier = Modifier.size(20.dp),
                            color = PureWhite,
                            strokeWidth = 2.dp
                        )
                    } else {
                        Icon(
                            imageVector = Icons.AutoMirrored.Filled.Send,
                            contentDescription = "Send prompt to Gemini"
                        )
                    }
                }
            }
        }
    }
}

@Composable
private fun EmptyCopilotState(
    branch: String,
    staffName: String
) {
    Column(
        modifier = Modifier
            .fillMaxSize()
            .padding(24.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.Center
    ) {
        Box(
            modifier = Modifier
                .size(64.dp)
                .clip(CircleShape)
                .background(MaterialTheme.colorScheme.primaryContainer),
            contentAlignment = Alignment.Center
        ) {
            Icon(
                imageVector = Icons.Default.AutoAwesome,
                contentDescription = null,
                tint = MaterialTheme.colorScheme.primary,
                modifier = Modifier.size(32.dp)
            )
        }
        Spacer(modifier = Modifier.height(14.dp))
        Text(
            text = "Ready for $staffName ($branch)",
            style = MaterialTheme.typography.titleMedium,
            fontWeight = FontWeight.Bold,
            color = MaterialTheme.colorScheme.onBackground
        )
        Spacer(modifier = Modifier.height(6.dp))
        Text(
            text = "Tap a quick workflow above or ask a question below. Grounded with your live branch schedules, caskets, and hearse fleet status.",
            style = MaterialTheme.typography.bodySmall,
            color = MaterialTheme.colorScheme.onSurfaceVariant,
            modifier = Modifier.widthIn(max = 420.dp)
        )
    }
}

@Composable
private fun CopilotMessageBubble(
    message: GeminiChatMessage,
    onCopy: () -> Unit,
    onSendSms: () -> Unit
) {
    Row(
        modifier = Modifier.fillMaxWidth(),
        horizontalArrangement = if (message.isUser) Arrangement.End else Arrangement.Start
    ) {
        Surface(
            color = if (message.isUser) {
                MaterialTheme.colorScheme.primary
            } else {
                MaterialTheme.colorScheme.surfaceVariant
            },
            shape = RoundedCornerShape(
                topStart = 16.dp,
                topEnd = 16.dp,
                bottomStart = if (message.isUser) 16.dp else 4.dp,
                bottomEnd = if (message.isUser) 4.dp else 16.dp
            ),
            border = if (!message.isUser) BorderStroke(1.dp, MaterialTheme.colorScheme.outline.copy(alpha = 0.4f)) else null,
            modifier = Modifier.widthIn(max = 520.dp)
        ) {
            Column(modifier = Modifier.padding(12.dp)) {
                Text(
                    text = message.text.ifBlank { "Thinking..." },
                    color = if (message.isUser) MaterialTheme.colorScheme.onPrimary else MaterialTheme.colorScheme.onSurface,
                    fontSize = 13.sp,
                    lineHeight = 19.sp
                )
                if (!message.isUser && !message.isStreaming && message.text.isNotBlank()) {
                    Spacer(modifier = Modifier.height(8.dp))
                    HorizontalDivider(color = MaterialTheme.colorScheme.outline.copy(alpha = 0.25f))
                    Row(
                        modifier = Modifier.padding(top = 4.dp),
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        TextButton(
                            onClick = onCopy,
                            contentPadding = PaddingValues(horizontal = 8.dp, vertical = 4.dp),
                            modifier = Modifier.heightIn(min = 48.dp)
                        ) {
                            Icon(Icons.Default.ContentCopy, contentDescription = "Copy response", modifier = Modifier.size(14.dp))
                            Spacer(modifier = Modifier.width(4.dp))
                            Text("Copy", fontSize = 11.sp, fontWeight = FontWeight.SemiBold)
                        }
                        TextButton(
                            onClick = onSendSms,
                            contentPadding = PaddingValues(horizontal = 8.dp, vertical = 4.dp),
                            modifier = Modifier.heightIn(min = 48.dp)
                        ) {
                            Icon(Icons.Default.Sms, contentDescription = "Open Bulk SMS with draft", modifier = Modifier.size(14.dp))
                            Spacer(modifier = Modifier.width(4.dp))
                            Text("Bulk SMS", fontSize = 11.sp, fontWeight = FontWeight.SemiBold)
                        }
                    }
                }
            }
        }
    }
}

@Composable
private fun StructuredPlanWorkspace(
    structuredPlan: StructuredCarePlan?,
    isLoading: Boolean,
    onGenerateDefaultPlan: () -> Unit,
    onCopyPlan: (String) -> Unit,
    onSendSms: (String) -> Unit
) {
    LazyColumn(
        contentPadding = PaddingValues(12.dp),
        verticalArrangement = Arrangement.spacedBy(10.dp),
        modifier = Modifier
            .fillMaxSize()
            .testTag("ai_structured_plan_workspace")
    ) {
        if (isLoading) {
            item {
                Card(
                    modifier = Modifier.fillMaxWidth(),
                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface)
                ) {
                    Row(
                        modifier = Modifier.padding(16.dp),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(12.dp)
                    ) {
                        CircularProgressIndicator(modifier = Modifier.size(22.dp), strokeWidth = 2.5.dp)
                        Text("Generating structured JSON coordination plan...", fontSize = 13.sp, fontWeight = FontWeight.SemiBold)
                    }
                }
            }
        } else if (structuredPlan == null) {
            item {
                Card(
                    modifier = Modifier.fillMaxWidth(),
                    border = BorderStroke(1.dp, MaterialTheme.colorScheme.outline.copy(alpha = 0.5f)),
                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface)
                ) {
                    Column(
                        modifier = Modifier.padding(16.dp),
                        verticalArrangement = Arrangement.spacedBy(10.dp)
                    ) {
                        Text(
                            text = "Structured Burial Action Plan (JSON Schema)",
                            fontSize = 15.sp,
                            fontWeight = FontWeight.Bold,
                            color = MaterialTheme.colorScheme.onSurface
                        )
                        Text(
                            text = "Generate a schema-validated coordination checklist with estimated KES budget, staff role assignments, and a family SMS notice.",
                            fontSize = 12.sp,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                        Button(
                            onClick = onGenerateDefaultPlan,
                            colors = ButtonDefaults.buttonColors(containerColor = ForestGreenPrimary),
                            modifier = Modifier
                                .heightIn(min = 48.dp)
                                .testTag("ai_generate_structured_plan_btn")
                        ) {
                            Icon(Icons.Default.AutoAwesome, contentDescription = null, modifier = Modifier.size(16.dp))
                            Spacer(modifier = Modifier.width(6.dp))
                            Text("Generate Plan from Live Branch Data", fontWeight = FontWeight.Bold)
                        }
                    }
                }
            }
        } else {
            item {
                Card(
                    modifier = Modifier
                        .fillMaxWidth()
                        .testTag("ai_structured_plan_card"),
                    border = BorderStroke(1.dp, ForestGreenPrimary.copy(alpha = 0.45f)),
                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface)
                ) {
                    Column(
                        modifier = Modifier.padding(14.dp),
                        verticalArrangement = Arrangement.spacedBy(10.dp)
                    ) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Text(
                                text = structuredPlan.planTitle,
                                fontSize = 16.sp,
                                fontWeight = FontWeight.ExtraBold,
                                color = MaterialTheme.colorScheme.primary,
                                modifier = Modifier.weight(1f)
                            )
                            Surface(
                                color = MaterialTheme.colorScheme.primaryContainer,
                                shape = RoundedCornerShape(8.dp)
                            ) {
                                Text(
                                    text = "KES ${String.format("%,d", structuredPlan.estimatedBudgetKes)}",
                                    fontSize = 12.sp,
                                    fontWeight = FontWeight.Bold,
                                    color = MaterialTheme.colorScheme.onPrimaryContainer,
                                    modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp)
                                )
                            }
                        }

                        Text(
                            text = structuredPlan.prioritySummary,
                            fontSize = 12.sp,
                            color = MaterialTheme.colorScheme.onSurface
                        )

                        HorizontalDivider()

                        Text(
                            text = "Checklist Steps",
                            fontSize = 13.sp,
                            fontWeight = FontWeight.Bold,
                            color = MaterialTheme.colorScheme.onSurface
                        )
                        structuredPlan.checklistSteps.forEachIndexed { idx, step ->
                            Row(
                                verticalAlignment = Alignment.Top,
                                horizontalArrangement = Arrangement.spacedBy(6.dp)
                            ) {
                                Icon(
                                    imageVector = Icons.Default.CheckCircle,
                                    contentDescription = null,
                                    tint = ForestGreenPrimary,
                                    modifier = Modifier
                                        .padding(top = 2.dp)
                                        .size(15.dp)
                                )
                                Text(
                                    text = "${idx + 1}. $step",
                                    fontSize = 12.sp,
                                    color = MaterialTheme.colorScheme.onSurface
                                )
                            }
                        }

                        if (structuredPlan.assignedRoles.isNotEmpty()) {
                            Text(
                                text = "Assigned Roles: ${structuredPlan.assignedRoles.joinToString(" • ")}",
                                fontSize = 11.sp,
                                fontWeight = FontWeight.SemiBold,
                                color = MaterialTheme.colorScheme.secondary
                            )
                        }

                        if (structuredPlan.recommendedSmsNotice.isNotBlank()) {
                            Surface(
                                color = MaterialTheme.colorScheme.surfaceVariant,
                                shape = RoundedCornerShape(10.dp),
                                modifier = Modifier.fillMaxWidth()
                            ) {
                                Column(modifier = Modifier.padding(10.dp)) {
                                    Text("Recommended Family SMS", fontSize = 11.sp, fontWeight = FontWeight.Bold)
                                    Spacer(modifier = Modifier.height(4.dp))
                                    Text(structuredPlan.recommendedSmsNotice, fontSize = 12.sp)
                                }
                            }
                        }

                        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                            OutlinedButton(
                                onClick = {
                                    val formatted = buildString {
                                        appendLine(structuredPlan.planTitle)
                                        appendLine("Budget: KES ${structuredPlan.estimatedBudgetKes}")
                                        appendLine(structuredPlan.prioritySummary)
                                        structuredPlan.checklistSteps.forEachIndexed { i, s -> appendLine("${i + 1}. $s") }
                                    }
                                    onCopyPlan(formatted)
                                },
                                modifier = Modifier.heightIn(min = 48.dp)
                            ) {
                                Icon(Icons.Default.ContentCopy, contentDescription = null, modifier = Modifier.size(16.dp))
                                Spacer(modifier = Modifier.width(6.dp))
                                Text("Copy Plan")
                            }
                            if (structuredPlan.recommendedSmsNotice.isNotBlank()) {
                                Button(
                                    onClick = { onSendSms(structuredPlan.recommendedSmsNotice) },
                                    colors = ButtonDefaults.buttonColors(containerColor = ForestGreenPrimary),
                                    modifier = Modifier.heightIn(min = 48.dp)
                                ) {
                                    Icon(Icons.Default.Sms, contentDescription = null, modifier = Modifier.size(16.dp))
                                    Spacer(modifier = Modifier.width(6.dp))
                                    Text("Use SMS")
                                }
                            }
                        }
                    }
                }
            }
        }
    }
}
